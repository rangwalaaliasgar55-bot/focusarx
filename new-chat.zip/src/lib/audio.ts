// Small WebAudio engine: procedural ambient layers + a soft completion chime.
// Everything is generated on-device — no audio files.

export type LayerId = "rain" | "brown" | "waves" | "wind";

type Layer = { gain: GainNode; stop: () => void };

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
const layers: Partial<Record<LayerId, Layer>> = {};
const SCALE: Record<LayerId, number> = { rain: 0.5, brown: 0.55, waves: 0.9, wind: 0.6 };

function getCtx() {
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 1;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function noise(c: AudioContext, kind: "white" | "brown" | "pink") {
  const len = c.sampleRate * 4;
  const buf = c.createBuffer(1, len, c.sampleRate);
  const d = buf.getChannelData(0);
  let last = 0;
  let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
  for (let i = 0; i < len; i++) {
    const w = Math.random() * 2 - 1;
    if (kind === "white") d[i] = w;
    else if (kind === "brown") {
      last = (last + 0.02 * w) / 1.02;
      d[i] = last * 3.5;
    } else {
      b0 = 0.99886 * b0 + w * 0.0555179;
      b1 = 0.99332 * b1 + w * 0.0750759;
      b2 = 0.969 * b2 + w * 0.153852;
      b3 = 0.8665 * b3 + w * 0.3104856;
      b4 = 0.55 * b4 + w * 0.5329522;
      b5 = -0.7616 * b5 - w * 0.016898;
      d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11;
      b6 = w * 0.115926;
    }
  }
  const src = c.createBufferSource();
  src.buffer = buf;
  src.loop = true;
  return src;
}

function build(id: LayerId): Layer {
  const c = getCtx();
  const out = c.createGain();
  out.gain.value = 0;
  out.connect(master!);
  const stops: Array<() => void> = [];

  if (id === "rain") {
    const s = noise(c, "white");
    const hp = c.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 900;
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 9000;
    s.connect(hp).connect(lp).connect(out);
    s.start();
    stops.push(() => s.stop());
  } else if (id === "brown") {
    const s = noise(c, "brown");
    s.connect(out);
    s.start();
    stops.push(() => s.stop());
  } else if (id === "waves") {
    const s = noise(c, "brown");
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 1000;
    const swell = c.createGain();
    swell.gain.value = 0.55;
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.11;
    const depth = c.createGain();
    depth.gain.value = 0.45;
    lfo.connect(depth).connect(swell.gain);
    s.connect(lp).connect(swell).connect(out);
    s.start();
    lfo.start();
    stops.push(() => { s.stop(); lfo.stop(); });
  } else {
    const s = noise(c, "pink");
    const bp = c.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 520;
    bp.Q.value = 0.7;
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.09;
    const depth = c.createGain();
    depth.gain.value = 260;
    lfo.connect(depth).connect(bp.frequency);
    s.connect(bp).connect(out);
    s.start();
    lfo.start();
    stops.push(() => { s.stop(); lfo.stop(); });
  }
  return { gain: out, stop: () => stops.forEach((f) => f()) };
}

export const volumes: Partial<Record<LayerId, number>> = {};

export function setLayer(id: LayerId, volume: number) {
  volumes[id] = Math.max(0, volume);
  if (volume <= 0) {
    const l = layers[id];
    if (!l || !ctx) return;
    l.gain.gain.setTargetAtTime(0, ctx.currentTime, 0.12);
    window.setTimeout(() => {
      l.stop();
      if (layers[id] === l) delete layers[id];
    }, 600);
    return;
  }
  let l = layers[id];
  if (!l) {
    l = build(id);
    layers[id] = l;
  }
  const c = getCtx();
  l.gain.gain.setTargetAtTime(volume * SCALE[id], c.currentTime, 0.2);
}

export function chime(kind: "done" | "break" = "done") {
  try {
    const c = getCtx();
    const notes = kind === "done" ? [659.25, 783.99, 987.77] : [783.99, 587.33];
    notes.forEach((f, i) => {
      const o = c.createOscillator();
      const g = c.createGain();
      o.type = "sine";
      o.frequency.value = f;
      const t = c.currentTime + i * 0.17;
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.16, t + 0.03);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 1.3);
      o.connect(g).connect(master!);
      o.start(t);
      o.stop(t + 1.4);
    });
  } catch {
    /* audio blocked — ignore */
  }
}

export function click() {
  try {
    const c = getCtx();
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = "triangle";
    o.frequency.value = 520;
    const t = c.currentTime;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.07, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.12);
    o.connect(g).connect(master!);
    o.start(t);
    o.stop(t + 0.14);
  } catch {
    /* ignore */
  }
}
