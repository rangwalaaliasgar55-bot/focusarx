import { useSyncExternalStore, type AnchorHTMLAttributes } from "react";

function subscribe(cb: () => void) {
  window.addEventListener("hashchange", cb);
  return () => window.removeEventListener("hashchange", cb);
}
const read = () => window.location.hash.replace(/^#/, "").split("?")[0] || "/";

export function usePath() {
  return useSyncExternalStore(subscribe, read, () => "/");
}

export function navigate(to: string) {
  window.location.hash = to;
}

export function Link({ to, children, ...rest }: { to: string } & AnchorHTMLAttributes<HTMLAnchorElement>) {
  return (
    <a href={`#${to}`} {...rest}>
      {children}
    </a>
  );
}
