import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { addDays, dayKey, levelInfo, mondayOf, rewardFor, SAMPLE_TASKS } from "./data";
import { chime, setLayer, type LayerId } from "./audio";

/* ───────────────────────── types ───────────────────────── */
export type Task = { id: string; title: string; done: boolean; priority: "low" | "med" | "high"; est: number; spent: number; created: number; doneAt?: number };
export type Session = { id: string; start: number; minutes: number; score: number; task?: string; completed: boolean; demo?: boolean };
export type Habit = { id: string; name: string; days: string[] };
export type Goal = { id: string; title: string; target: number; progress: number; unit: string };

type State = {
  tasks: Task[];
  sessions: Session[];
  habits: Habit[];
  goals: Goal[];
  xp: number;
  coins: number;
  dailyGoal: number;
  activePet: string;
  owned: string[];
  bond: Record<string, number>;
  nicknames: Record<string, string>;
  claimed: Record<string, boolean>;
  cards: Record<string, { box: number; due: number }>;
  reviewed: Record<string, number>;
  prefs: { focus: number; short: number; long: number };
  sounds: Partial<Record<LayerId, number>>;
  hasDemo: boolean;
};

const uid = () => Math.random().toString(36).slice(2, 10);

/* ───────────── seed: a believable five weeks of history ───────────── */
function rng(seed: number) {
  return () => {
    seed |= 0;
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seed(): State {
  const r = rng(20260904);
  const labels = ["Thermodynamics", "Essay draft", "Spanish", "Problem set", "Reading", "Thesis notes"];
  const hours = [9, 9, 10, 10, 11, 15, 16, 16, 20, 21];
  const sessions: Session[] = [];
  for (let i = 1; i <= 42; i++) {
    const active = i <= 6 || r() < 0.8;
    if (!active) continue;
    const n = 1 + Math.floor(r() * 4);
    const day = addDays(new Date(), -i);
    for (let k = 0; k < n; k++) {
      const minutes = [25, 25, 25, 50, 45][Math.floor(r() * 5)];
      const start = new Date(day);
      start.setHours(hours[Math.floor(r() * hours.length)], Math.floor(r() * 50), 0, 0);
      sessions.push({
        id: uid(),
        start: start.getTime(),
        minutes,
        score: 68 + Math.floor(r() * 32),
        task: labels[Math.floor(r() * labels.length)],
        completed: true,
        demo: true,
      });
    }
  }
  const now = Date.now();
  const tasks: Task[] = SAMPLE_TASKS.map((t, i) => ({ id: uid(), title: t.title, priority: t.priority, est: t.est, done: false, spent: i === 0 ? 1 : 0, created: now - i * 3600_000 }));
  const habitDays = (p: number) =>
    Array.from({ length: 12 }, (_, i) => i + 1)
      .filter(() => r() < p)
      .map((i) => dayKey(addDays(new Date(), -i)));
  return {
    tasks,
    sessions,
    habits: [
      { id: uid(), name: "Read 20 pages", days: habitDays(0.8) },
      { id: uid(), name: "Morning walk", days: habitDays(0.6) },
      { id: uid(), name: "Phone away before 9am", days: habitDays(0.7) },
    ],
    goals: [
      { id: uid(), title: "Deep work this week", target: 12, progress: 0, unit: "h" },
      { id: uid(), title: "Finish thesis chapter 2", target: 5, progress: 3, unit: "sections" },
      { id: uid(), title: "Spanish: 200 new words", target: 200, progress: 126, unit: "words" },
    ],
    xp: 1840,
    coins: 420,
    dailyGoal: 120,
    activePet: "fox",
    owned: ["fox"],
    bond: { fox: 260 },
    nicknames: {},
    claimed: {},
    cards: {},
    reviewed: {},
    prefs: { focus: 25, short: 5, long: 15 },
    sounds: {},
    hasDemo: true,
  };
}

const KEY = "focusarx.v2";
function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...seed(), ...JSON.parse(raw) };
  } catch {
    /* corrupt storage — fall through */
  }
  return seed();
}

/* ───────────────────────── context ───────────────────────── */
type Actions = ReturnType<typeof makeActions>;

function makeActions(set: (fn: (s: State) => State) => void) {
  return {
    addTask: (title: string, priority: Task["priority"] = "med", est = 1) =>
      set((s) => ({ ...s, tasks: [{ id: uid(), title: title.trim(), priority, est, done: false, spent: 0, created: Date.now() }, ...s.tasks] })),
    toggleTask: (id: string) =>
      set((s) => ({ ...s, tasks: s.tasks.map((t) => (t.id === id ? { ...t, done: !t.done, doneAt: !t.done ? Date.now() : undefined } : t)) })),
    removeTask: (id: string) => set((s) => ({ ...s, tasks: s.tasks.filter((t) => t.id !== id) })),
    addHabit: (name: string) => set((s) => ({ ...s, habits: [...s.habits, { id: uid(), name: name.trim(), days: [] }] })),
    removeHabit: (id: string) => set((s) => ({ ...s, habits: s.habits.filter((h) => h.id !== id) })),
    toggleHabit: (id: string, day: string) =>
      set((s) => ({ ...s, habits: s.habits.map((h) => (h.id === id ? { ...h, days: h.days.includes(day) ? h.days.filter((d) => d !== day) : [...h.days, day] } : h)) })),
    bumpGoal: (id: string, by: number) =>
      set((s) => ({ ...s, goals: s.goals.map((g) => (g.id === id ? { ...g, progress: Math.max(0, Math.min(g.target, g.progress + by)) } : g)) })),
    addGoal: (title: string, target: number, unit: string) =>
      set((s) => ({ ...s, goals: [...s.goals, { id: uid(), title: title.trim(), target, progress: 0, unit }] })),
    removeGoal: (id: string) => set((s) => ({ ...s, goals: s.goals.filter((g) => g.id !== id) })),
    setDailyGoal: (m: number) => set((s) => ({ ...s, dailyGoal: m })),
    recordSession: (x: { minutes: number; score: number; task?: string; taskId?: string | null; completed: boolean; start: number }) =>
      set((s) => {
        const { xp, coins } = rewardFor(x.minutes, x.score);
        const gain = x.completed ? { xp, coins } : { xp: Math.round(xp / 2), coins: 0 };
        return {
          ...s,
          sessions: [...s.sessions, { id: uid(), start: x.start, minutes: x.minutes, score: x.score, task: x.task, completed: x.completed }],
          xp: s.xp + gain.xp,
          coins: s.coins + gain.coins,
          bond: { ...s.bond, [s.activePet]: (s.bond[s.activePet] ?? 0) + Math.round(x.minutes) },
          tasks: x.taskId ? s.tasks.map((t) => (t.id === x.taskId ? { ...t, spent: t.spent + (x.completed ? 1 : 0) } : t)) : s.tasks,
        };
      }),
    claim: (id: string, xp: number, coins: number) =>
      set((s) => (s.claimed[id] ? s : { ...s, xp: s.xp + xp, coins: s.coins + coins, claimed: { ...s.claimed, [id]: true } })),
    adopt: (id: string, price: number) =>
      set((s) => (s.owned.includes(id) || s.coins < price ? s : { ...s, coins: s.coins - price, owned: [...s.owned, id], activePet: id })),
    setActivePet: (id: string) => set((s) => (s.owned.includes(id) ? { ...s, activePet: id } : s)),
    treat: (id: string) =>
      set((s) => (s.coins < 10 ? s : { ...s, coins: s.coins - 10, bond: { ...s.bond, [id]: (s.bond[id] ?? 0) + 25 } })),
    rename: (id: string, name: string) => set((s) => ({ ...s, nicknames: { ...s.nicknames, [id]: name.slice(0, 16) } })),
    rateCard: (id: string, rating: 0 | 1 | 2) =>
      set((s) => {
        const prev = s.cards[id]?.box ?? 0;
        const box = rating === 0 ? 0 : Math.min(4, prev + rating);
        const days = [0, 1, 3, 7, 16][box];
        const k = dayKey();
        return {
          ...s,
          cards: { ...s.cards, [id]: { box, due: rating === 0 ? Date.now() + 10 * 60_000 : Date.now() + days * 86_400_000 } },
          reviewed: { ...s.reviewed, [k]: (s.reviewed[k] ?? 0) + 1 },
        };
      }),
    setPrefs: (p: Partial<State["prefs"]>) => set((s) => ({ ...s, prefs: { ...s.prefs, ...p } })),
    setSound: (id: LayerId, v: number) => set((s) => ({ ...s, sounds: { ...s.sounds, [id]: v } })),
    clearDemo: () => set((s) => ({ ...s, sessions: s.sessions.filter((x) => !x.demo), hasDemo: false })),
  };
}

const Ctx = createContext<{ state: State; act: Actions } | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<State>(load);
  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(state));
  }, [state]);
  const act = useMemo(() => makeActions(setState), []);
  const value = useMemo(() => ({ state, act }), [state, act]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const c = useContext(Ctx);
  if (!c) throw new Error("AppProvider missing");
  return c;
}

/* ───────────────────────── derived stats ───────────────────────── */
export function useStats() {
  const { state } = useApp();
  return useMemo(() => {
    const byDay: Record<string, number> = {};
    const byHour = Array(24).fill(0) as number[];
    const byTask: Record<string, number> = {};
    for (const s of state.sessions) {
      const k = dayKey(s.start);
      byDay[k] = (byDay[k] ?? 0) + s.minutes;
      byHour[new Date(s.start).getHours()] += s.minutes;
      const label = s.task ?? "Unlabelled";
      byTask[label] = (byTask[label] ?? 0) + s.minutes;
    }
    const today = dayKey();
    const d = new Date();
    if (!byDay[dayKey(d)]) d.setDate(d.getDate() - 1);
    let streak = 0;
    while (byDay[dayKey(d)]) {
      streak++;
      d.setDate(d.getDate() - 1);
    }
    const mon = mondayOf(new Date());
    const week = Array.from({ length: 7 }, (_, i) => {
      const day = addDays(mon, i);
      return { date: day, key: dayKey(day), minutes: byDay[dayKey(day)] ?? 0 };
    });
    const todaySessions = state.sessions.filter((s) => dayKey(s.start) === today);
    return {
      byDay,
      byHour,
      byTask,
      today: byDay[today] ?? 0,
      todaySessions,
      streak,
      week,
      weekMinutes: week.reduce((a, b) => a + b.minutes, 0),
      level: levelInfo(state.xp),
      totalMinutes: state.sessions.reduce((a, b) => a + b.minutes, 0),
    };
  }, [state.sessions, state.xp]);
}

/* ───────────────────────── timer ───────────────────────── */
export type Mode = "focus" | "short" | "long";
type TState = {
  mode: Mode;
  status: "idle" | "running" | "paused";
  total: number;
  endAt: number;
  remaining: number;
  startedAt: number;
  taskId: string | null;
  cycle: number;
  pauses: number;
};
export type SessionResult = { minutes: number; score: number; xp: number; coins: number; completed: boolean; task?: string };

type TimerApi = {
  t: TState;
  remaining: number;
  progress: number;
  result: SessionResult | null;
  dismiss: () => void;
  start: () => void;
  pause: () => void;
  resume: () => void;
  reset: () => void;
  skip: () => void;
  finishEarly: () => void;
  setMode: (m: Mode) => void;
  setMinutes: (m: number) => void;
  setTask: (id: string | null) => void;
  minutesFor: (m: Mode) => number;
};

const TKEY = "focusarx.timer.v2";
const TCtx = createContext<TimerApi | null>(null);

export function TimerProvider({ children }: { children: ReactNode }) {
  const { state, act } = useApp();
  const prefsRef = useRef(state.prefs);
  prefsRef.current = state.prefs;
  const tasksRef = useRef(state.tasks);
  tasksRef.current = state.tasks;

  const [t, setT] = useState<TState>(() => {
    try {
      const raw = localStorage.getItem(TKEY);
      if (raw) return JSON.parse(raw) as TState;
    } catch {
      /* ignore */
    }
    return { mode: "focus", status: "idle", total: state.prefs.focus * 60_000, endAt: 0, remaining: state.prefs.focus * 60_000, startedAt: 0, taskId: null, cycle: 0, pauses: 0 };
  });
  const [now, setNow] = useState(Date.now());
  const [result, setResult] = useState<SessionResult | null>(null);
  const finishing = useRef(false);

  useEffect(() => {
    localStorage.setItem(TKEY, JSON.stringify(t));
  }, [t]);

  useEffect(() => {
    if (t.status !== "running") return;
    setNow(Date.now());
    const id = window.setInterval(() => setNow(Date.now()), 200);
    return () => window.clearInterval(id);
  }, [t.status]);

  const minutesFor = useCallback((m: Mode) => prefsRef.current[m], []);
  const remaining = t.status === "running" ? Math.max(0, t.endAt - now) : t.status === "paused" ? t.remaining : t.total;
  const progress = t.total ? 1 - remaining / t.total : 0;

  const taskTitle = useCallback((id: string | null) => tasksRef.current.find((x) => x.id === id)?.title, []);

  const tRef = useRef(t);
  tRef.current = t;

  const complete = useCallback(() => {
    if (finishing.current) return;
    finishing.current = true;
    const cur = tRef.current;
    if (cur.mode === "focus") {
      const minutes = cur.total / 60_000;
      const score = Math.max(55, 100 - cur.pauses * 8);
      const task = taskTitle(cur.taskId);
      act.recordSession({ minutes, score, task, taskId: cur.taskId, completed: true, start: cur.startedAt || Date.now() - cur.total });
      const { xp, coins } = rewardFor(minutes, score);
      setResult({ minutes, score, xp, coins, completed: true, task });
      chime("done");
      const cycle = cur.cycle + 1;
      const next: Mode = cycle % 4 === 0 ? "long" : "short";
      const ms = prefsRef.current[next] * 60_000;
      setT({ ...cur, mode: next, status: "idle", total: ms, remaining: ms, endAt: 0, cycle, pauses: 0 });
    } else {
      chime("break");
      const ms = prefsRef.current.focus * 60_000;
      setT({ ...cur, mode: "focus", status: "idle", total: ms, remaining: ms, endAt: 0, pauses: 0 });
    }
    window.setTimeout(() => {
      finishing.current = false;
    }, 600);
  }, [act, taskTitle]);

  useEffect(() => {
    if (t.status === "running" && now >= t.endAt) complete();
  }, [now, t.status, t.endAt, complete]);

  // tab title
  useEffect(() => {
    const m = Math.floor(Math.ceil(remaining / 1000) / 60);
    const s = Math.ceil(remaining / 1000) % 60;
    document.title =
      t.status === "idle"
        ? "FocusArx — Focus timer with a companion"
        : `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")} · ${t.mode === "focus" ? "Focus" : "Break"}${t.status === "paused" ? " (paused)" : ""}`;
  }, [remaining, t.status, t.mode]);

  const start = useCallback(() => {
    setT((c) => ({ ...c, status: "running", endAt: Date.now() + c.total, remaining: c.total, startedAt: Date.now(), pauses: 0 }));
  }, []);
  const pause = useCallback(() => {
    setT((c) => (c.status === "running" ? { ...c, status: "paused", remaining: Math.max(0, c.endAt - Date.now()), pauses: c.pauses + 1 } : c));
  }, []);
  const resume = useCallback(() => {
    setT((c) => (c.status === "paused" ? { ...c, status: "running", endAt: Date.now() + c.remaining } : c));
  }, []);
  const reset = useCallback(() => {
    setT((c) => ({ ...c, status: "idle", remaining: c.total, endAt: 0, pauses: 0 }));
  }, []);
  const setMode = useCallback((m: Mode) => {
    const ms = prefsRef.current[m] * 60_000;
    setT((c) => ({ ...c, mode: m, status: "idle", total: ms, remaining: ms, endAt: 0, pauses: 0 }));
  }, []);
  const skip = useCallback(() => {
    setT((c) => {
      const next: Mode = c.mode === "focus" ? "short" : "focus";
      const ms = prefsRef.current[next] * 60_000;
      return { ...c, mode: next, status: "idle", total: ms, remaining: ms, endAt: 0, pauses: 0 };
    });
  }, []);
  const setMinutes = useCallback(
    (m: number) => {
      const v = Math.max(1, Math.min(180, Math.round(m)));
      const c = tRef.current;
      act.setPrefs({ [c.mode]: v } as Partial<State["prefs"]>);
      prefsRef.current = { ...prefsRef.current, [c.mode]: v };
      if (c.status === "idle") setT({ ...c, total: v * 60_000, remaining: v * 60_000 });
    },
    [act],
  );
  const setTask = useCallback((id: string | null) => setT((c) => ({ ...c, taskId: id })), []);

  const finishEarly = useCallback(() => {
    const c = tRef.current;
    if (c.status === "idle") return;
    const left = c.status === "running" ? Math.max(0, c.endAt - Date.now()) : c.remaining;
    const done = Math.floor((c.total - left) / 60_000);
    const ms = prefsRef.current[c.mode] * 60_000;
    if (c.mode === "focus" && done >= 1) {
      const task = taskTitle(c.taskId);
      const score = Math.max(40, 80 - c.pauses * 8);
      act.recordSession({ minutes: done, score, task, taskId: c.taskId, completed: false, start: c.startedAt });
      const { xp } = rewardFor(done, score);
      setResult({ minutes: done, score, xp: Math.round(xp / 2), coins: 0, completed: false, task });
    }
    setT({ ...c, status: "idle", total: ms, remaining: ms, endAt: 0, pauses: 0 });
  }, [act, taskTitle]);

  const value: TimerApi = {
    t,
    remaining,
    progress,
    result,
    dismiss: () => setResult(null),
    start,
    pause,
    resume,
    reset,
    skip,
    finishEarly,
    setMode,
    setMinutes,
    setTask,
    minutesFor,
  };
  return <TCtx.Provider value={value}>{children}</TCtx.Provider>;
}

export function useTimer() {
  const c = useContext(TCtx);
  if (!c) throw new Error("TimerProvider missing");
  return c;
}

/* ambient sounds: re-apply saved volumes only after a user gesture */
export function applySounds(sounds: State["sounds"]) {
  (Object.keys(sounds) as LayerId[]).forEach((k) => setLayer(k, sounds[k] ?? 0));
}
