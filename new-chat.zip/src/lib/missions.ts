import { useMemo } from "react";
import { addDays, dayKey, mondayOf } from "./data";
import { useApp, useStats } from "./store";

export type Mission = { id: string; title: string; desc: string; progress: number; target: number; xp: number; coins: number; scope: "daily" | "weekly"; claimed: boolean };

export function useMissions(): Mission[] {
  const { state } = useApp();
  const stats = useStats();
  return useMemo(() => {
    const today = dayKey();
    const mon = mondayOf(new Date());
    const monKey = dayKey(mon);
    const inWeek = (ts?: number) => ts !== undefined && ts >= mon.getTime() && ts < addDays(mon, 7).getTime();
    const tasksToday = state.tasks.filter((t) => t.doneAt && dayKey(t.doneAt) === today).length;
    const tasksWeek = state.tasks.filter((t) => inWeek(t.doneAt)).length;
    const habitsToday = state.habits.filter((h) => h.days.includes(today)).length;
    const cardsToday = state.reviewed[today] ?? 0;
    const focusDays = stats.week.filter((d) => d.minutes > 0).length;

    const defs: Omit<Mission, "claimed">[] = [
      { id: `d:${today}:sessions`, scope: "daily", title: "Two clean sessions", desc: "Complete 2 focus sessions today", progress: stats.todaySessions.filter((s) => s.completed).length, target: 2, xp: 40, coins: 15 },
      { id: `d:${today}:minutes`, scope: "daily", title: "Hit your daily goal", desc: `Focus for ${state.dailyGoal} minutes`, progress: stats.today, target: state.dailyGoal, xp: 60, coins: 25 },
      { id: `d:${today}:tasks`, scope: "daily", title: "Close the loop", desc: "Finish 2 tasks", progress: tasksToday, target: 2, xp: 30, coins: 10 },
      { id: `d:${today}:habits`, scope: "daily", title: "Keep the habits", desc: "Log 2 habits", progress: habitsToday, target: 2, xp: 25, coins: 10 },
      { id: `d:${today}:cards`, scope: "daily", title: "Retrieval practice", desc: "Review 10 flashcards", progress: cardsToday, target: 10, xp: 30, coins: 10 },
      { id: `w:${monKey}:days`, scope: "weekly", title: "Show up 5 days", desc: "Focus on 5 different days this week", progress: focusDays, target: 5, xp: 150, coins: 60 },
      { id: `w:${monKey}:minutes`, scope: "weekly", title: "Five-hour week", desc: "Log 300 minutes of focus", progress: stats.weekMinutes, target: 300, xp: 200, coins: 80 },
      { id: `w:${monKey}:tasks`, scope: "weekly", title: "Clear the deck", desc: "Finish 8 tasks this week", progress: tasksWeek, target: 8, xp: 120, coins: 50 },
    ];
    return defs.map((d) => ({ ...d, progress: Math.min(d.progress, d.target), claimed: !!state.claimed[d.id] }));
  }, [state.tasks, state.habits, state.reviewed, state.claimed, state.dailyGoal, stats]);
}
