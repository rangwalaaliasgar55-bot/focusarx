export type Species = "fox" | "panda" | "owl" | "slime";

export const dayKey = (t: number | Date = Date.now()) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

export const addDays = (d: Date, n: number) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};

export const mondayOf = (d: Date) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  x.setDate(x.getDate() - ((x.getDay() + 6) % 7));
  return x;
};

export const fmtMin = (m: number) => {
  if (m < 60) return `${Math.round(m)}m`;
  const h = Math.floor(m / 60);
  const r = Math.round(m % 60);
  return r ? `${h}h ${r}m` : `${h}h`;
};

export const fmtClock = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
};

export function rewardFor(minutes: number, score: number) {
  const xp = Math.round(minutes * 2 + (score >= 90 ? 10 : 0));
  const coins = Math.max(1, Math.round(minutes / 5));
  return { xp, coins };
}

export function levelInfo(xp: number) {
  const level = Math.floor(Math.sqrt(xp / 100)) + 1;
  const base = 100 * (level - 1) ** 2;
  const next = 100 * level ** 2;
  return { level, base, next, into: xp - base, span: next - base, pct: ((xp - base) / (next - base)) * 100 };
}

export type PetDef = {
  id: string;
  species: Species;
  name: string;
  rarity: "Starter" | "Common" | "Rare" | "Epic";
  price: number;
  blurb: string;
  trait: string;
  accent: string;
};

export const PETS: PetDef[] = [
  { id: "fox", species: "fox", name: "Ember", rarity: "Starter", price: 0, blurb: "Quick-witted and warm. Curls its tail around your deadline.", trait: "Cheers loudest after long sessions", accent: "#f08a3c" },
  { id: "panda", species: "panda", name: "Bao", rarity: "Common", price: 250, blurb: "Unbothered. Believes every hard problem is solved one snack at a time.", trait: "Naps through your breaks", accent: "#e8e8ea" },
  { id: "owl", species: "owl", name: "Sage", rarity: "Rare", price: 600, blurb: "Keeps late hours so you can keep early ones. Judges nothing, notices everything.", trait: "Wide-eyed during deep work", accent: "#d9a35c" },
  { id: "slime", species: "slime", name: "Mochi", rarity: "Epic", price: 1000, blurb: "Soft, translucent, quietly proud of you. Grows a little leaf for every streak.", trait: "Wobbles when you hit a streak", accent: "#7ee6c4" },
];

export const LEVEL_PERKS: Record<number, string> = {
  1: "Companion joins your desk",
  3: "Headphones for deep work",
  5: "Cheer animation on completion",
  8: "Sleep animation during breaks",
  10: "Nickname & bond badge",
  15: "Rare sparkle trail",
  20: "Legendary bond",
};

export type Card = { id: string; q: string; a: string };
export type Deck = { id: string; name: string; subject: string; cards: Card[] };

export const DECKS: Deck[] = [
  {
    id: "thermo",
    name: "Thermodynamics",
    subject: "Physics",
    cards: [
      { id: "t1", q: "State the first law of thermodynamics.", a: "Energy is conserved: ΔU = Q − W. The change in internal energy equals heat added minus work done by the system." },
      { id: "t2", q: "What does entropy measure?", a: "The number of microstates consistent with a macrostate — loosely, how dispersed energy is." },
      { id: "t3", q: "Efficiency of a Carnot engine?", a: "η = 1 − T_c / T_h, with temperatures in kelvin. No engine between the same reservoirs can beat it." },
      { id: "t4", q: "Isothermal vs adiabatic process?", a: "Isothermal: constant temperature, heat flows. Adiabatic: no heat exchange (Q = 0), temperature changes." },
      { id: "t5", q: "Ideal gas law?", a: "PV = nRT. Pressure × volume equals moles × gas constant × temperature." },
      { id: "t6", q: "Second law, Kelvin–Planck form?", a: "No cyclic process can convert heat from a single reservoir entirely into work." },
    ],
  },
  {
    id: "spanish",
    name: "Spanish essentials",
    subject: "Languages",
    cards: [
      { id: "s1", q: "ser vs estar", a: "Ser: identity and lasting traits. Estar: states, locations and feelings that can change." },
      { id: "s2", q: "“I would like” (polite)", a: "Me gustaría… / Quisiera…" },
      { id: "s3", q: "Preterite of “ir”, yo form", a: "fui (identical to the preterite of “ser”)." },
      { id: "s4", q: "“Since when…?”", a: "¿Desde cuándo…?" },
      { id: "s5", q: "Por vs para (purpose)", a: "Para marks purpose or destination. Por marks cause, exchange or duration." },
      { id: "s6", q: "“I miss you”", a: "Te extraño (Latin America) / Te echo de menos (Spain)." },
    ],
  },
  {
    id: "learning",
    name: "How learning works",
    subject: "Cognitive science",
    cards: [
      { id: "l1", q: "What is the testing effect?", a: "Retrieving information from memory strengthens it more than re-reading the same material." },
      { id: "l2", q: "Spaced repetition in one line", a: "Reviewing just before you would forget flattens the forgetting curve and cuts total study time." },
      { id: "l3", q: "Interleaving", a: "Mixing problem types within a session. Feels harder, produces better transfer than blocked practice." },
      { id: "l4", q: "Why do breaks help?", a: "Diffuse-mode thinking consolidates what focused-mode work just loaded; attention also recovers." },
      { id: "l5", q: "Desirable difficulty", a: "Learning conditions that slow initial progress but improve long-term retention." },
      { id: "l6", q: "The Feynman technique", a: "Explain the idea in plain language as if teaching a beginner; gaps in the explanation reveal gaps in understanding." },
    ],
  },
];

export type Rival = { name: string; level: number; weekMin: number; allMin: number; streak: number; tag: string };

export const RIVALS: Rival[] = [
  { name: "Mira Okafor", level: 14, weekMin: 1260, allMin: 41800, streak: 63, tag: "Med school" },
  { name: "Jonas Weber", level: 12, weekMin: 1105, allMin: 30220, streak: 41, tag: "Software" },
  { name: "Aarav Shah", level: 13, weekMin: 980, allMin: 36410, streak: 28, tag: "CA finals" },
  { name: "Lucía Fernández", level: 10, weekMin: 905, allMin: 21040, streak: 19, tag: "Architecture" },
  { name: "Hana Takeda", level: 11, weekMin: 840, allMin: 25990, streak: 34, tag: "Thesis" },
  { name: "Diego Alvarez", level: 8, weekMin: 735, allMin: 12760, streak: 12, tag: "Law" },
  { name: "Priya Nair", level: 9, weekMin: 610, allMin: 15880, streak: 22, tag: "JEE prep" },
  { name: "Tom Reilly", level: 7, weekMin: 520, allMin: 9450, streak: 9, tag: "Writing" },
  { name: "Sofia Rossi", level: 6, weekMin: 410, allMin: 7120, streak: 6, tag: "Design" },
  { name: "Ben Carter", level: 5, weekMin: 285, allMin: 4380, streak: 3, tag: "Finance" },
];

export type Room = { id: string; name: string; topic: string; people: number; cycle: [number, number]; offset: number; tags: string[] };

export const ROOMS: Room[] = [
  { id: "r1", name: "Library, 2nd floor", topic: "Silent study. Cameras optional, chat muted.", people: 38, cycle: [50, 10], offset: 7, tags: ["Silent", "50/10"] },
  { id: "r2", name: "Exam week", topic: "Past papers and problem sets. Pace yourselves.", people: 64, cycle: [25, 5], offset: 12, tags: ["Exams", "25/5"] },
  { id: "r3", name: "Night owls", topic: "Quiet hours after 10pm. Lo-fi allowed.", people: 21, cycle: [45, 15], offset: 31, tags: ["Late", "45/15"] },
  { id: "r4", name: "Code & coffee", topic: "Ship something small today.", people: 27, cycle: [50, 10], offset: 19, tags: ["Software", "50/10"] },
  { id: "r5", name: "Writers’ room", topic: "Drafts only. Edit tomorrow.", people: 15, cycle: [25, 5], offset: 3, tags: ["Writing", "25/5"] },
  { id: "r6", name: "ADHD body-doubling", topic: "Short cycles, gentle check-ins, zero judgment.", people: 33, cycle: [15, 5], offset: 9, tags: ["ADHD", "15/5"] },
];

export const SAMPLE_TASKS = [
  { title: "Thermodynamics problem set 4", priority: "high" as const, est: 3 },
  { title: "Draft essay introduction", priority: "med" as const, est: 2 },
  { title: "Review Spanish preterite deck", priority: "low" as const, est: 1 },
  { title: "Read chapter 6 — Attention", priority: "med" as const, est: 2 },
];

export const GREETING = () => {
  const h = new Date().getHours();
  return h < 5 ? "Still up" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
};
