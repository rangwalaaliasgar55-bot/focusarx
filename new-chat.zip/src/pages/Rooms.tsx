import { useEffect, useState } from "react";
import { ArrowLeft, Send, Users } from "lucide-react";
import { Pet3D } from "../components/Pet3D";
import { Ring } from "../components/charts";
import { Button, Card, PageHeader } from "../components/ui";
import { fmtClock, PETS, RIVALS, ROOMS, type Room } from "../lib/data";
import { useApp } from "../lib/store";
import { cn } from "../utils/cn";

function phase(room: Room, now: number) {
  const [f, b] = room.cycle;
  const len = f + b;
  const pos = (now / 60000 + room.offset) % len;
  const focus = pos < f;
  const total = (focus ? f : b) * 60000;
  const left = ((focus ? f : len) - pos) * 60000;
  return { focus, left, total };
}

function useNow() {
  const [n, setN] = useState(Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setN(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, []);
  return n;
}

function RoomView({ room, onLeave }: { room: Room; onLeave: () => void }) {
  const now = useNow();
  const { state } = useApp();
  const pet = PETS.find((p) => p.id === state.activePet) ?? PETS[0];
  const ph = phase(room, now);
  const [msgs, setMsgs] = useState<{ id: number; text: string }[]>([]);
  const [draft, setDraft] = useState("");
  const people = RIVALS.map((r) => r.name);

  return (
    <div>
      <button onClick={onLeave} className="mb-5 flex items-center gap-2 text-sm text-ink-3 hover:text-ink-2">
        <ArrowLeft size={15} /> All rooms
      </button>
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-5">
          <Card className="flex flex-wrap items-center gap-8 p-7">
            <Ring value={1 - ph.left / ph.total} size={170} stroke={10} tone={ph.focus ? "#a3a6ff" : "#6fd3a0"}>
              <div className="text-center">
                <div className="num font-display text-[38px] font-semibold leading-none tracking-tight">{fmtClock(ph.left)}</div>
                <div className="mt-1.5 text-xs text-ink-3">{ph.focus ? "Focus block" : "Break"}</div>
              </div>
            </Ring>
            <div className="min-w-[200px] flex-1">
              <h1 className="font-display text-[28px] font-semibold leading-tight tracking-tight">{room.name}</h1>
              <p className="mt-2 text-[15px] text-ink-2">{room.topic}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {room.tags.map((t) => (
                  <span key={t} className="rounded-md bg-s3 px-2 py-1 text-xs text-ink-2">
                    {t}
                  </span>
                ))}
                <span className="flex items-center gap-1.5 rounded-md bg-s3 px-2 py-1 text-xs text-ink-2">
                  <Users size={12} />
                  <span className="num">{room.people + 1}</span> here
                </span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h2 className="mb-4 font-display text-lg font-semibold">In the room</h2>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
              <div className="overflow-hidden rounded-2xl border border-brand/40 bg-brand/[0.06]">
                <Pet3D species={pet.species} mood={ph.focus ? "focus" : "rest"} accent={pet.accent} className="h-[120px] w-full" />
                <p className="px-3 pb-3 text-center text-[13px] font-medium">You</p>
              </div>
              {people.slice(0, 7).map((n, i) => (
                <div key={n} className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-line bg-s2 px-3 py-4">
                  <span className="grid size-12 place-items-center rounded-full bg-s4 font-display text-sm font-semibold text-ink-2">{n.split(" ").map((x) => x[0]).join("")}</span>
                  <p className="max-w-full truncate text-[13px]">{n}</p>
                  <p className="flex items-center gap-1.5 text-xs text-ink-3">
                    <span className={cn("size-1.5 rounded-full", ph.focus ? "bg-brand" : "bg-ok")} />
                    {ph.focus ? (i % 3 === 0 ? "Deep work" : "Focusing") : "On break"}
                  </p>
                </div>
              ))}
            </div>
            <p className="mt-4 text-xs text-ink-3">+ {room.people - 7} more studying quietly</p>
          </Card>
        </div>

        <Card className="flex h-[520px] flex-col lg:sticky lg:top-8">
          <div className="border-b border-line px-5 py-4">
            <h2 className="font-display text-[15px] font-semibold">Room chat</h2>
            <p className="text-xs text-ink-3">{ph.focus ? "Keep it short during focus blocks." : "Break time — say hi."}</p>
          </div>
          <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4 text-sm">
            <p className="rounded-xl bg-s2 px-3.5 py-2.5 text-[13px] text-ink-2">Room rules: be kind, stay on task, mute notifications. Body-doubling works because someone is there — you don’t have to talk.</p>
            {msgs.map((m) => (
              <div key={m.id} className="ml-8 rounded-xl rounded-br-sm bg-brand/15 px-3.5 py-2.5">
                {m.text}
              </div>
            ))}
            {msgs.length === 0 && <p className="pt-2 text-center text-xs text-ink-3">Preview build: messages stay on this device.</p>}
          </div>
          <form
            className="flex gap-2 border-t border-line p-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (!draft.trim()) return;
              setMsgs((m) => [...m, { id: Date.now(), text: draft.trim() }]);
              setDraft("");
            }}
          >
            <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Message…" className="h-10 min-w-0 flex-1 rounded-xl border border-line bg-s2 px-3.5 text-sm outline-none placeholder:text-ink-3 focus:border-brand/50" />
            <Button type="submit" variant="primary" size="icon" aria-label="Send">
              <Send size={15} />
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
}

export default function Rooms() {
  const [open, setOpen] = useState<string | null>(null);
  const now = useNow();
  const room = ROOMS.find((r) => r.id === open);
  if (room) return <RoomView room={room} onLeave={() => setOpen(null)} />;
  return (
    <div>
      <PageHeader eyebrow="Together" title="Study rooms" desc="Body-doubling: work in silence beside other people on a shared clock. Pick a rhythm, join, and start." />
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {ROOMS.map((r) => {
          const ph = phase(r, now);
          return (
            <button key={r.id} onClick={() => setOpen(r.id)} className="group rounded-2xl border border-line bg-s1 p-6 text-left transition-colors hover:border-line-2 hover:bg-s2">
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-display text-lg font-semibold leading-snug">{r.name}</h3>
                <span className={cn("mt-1 flex shrink-0 items-center gap-1.5 rounded-full px-2.5 py-1 text-xs", ph.focus ? "bg-brand/10 text-brand" : "bg-ok/10 text-ok")}>
                  <span className="size-1.5 rounded-full bg-current" />
                  {ph.focus ? "Focus" : "Break"}
                </span>
              </div>
              <p className="mt-2 min-h-[42px] text-sm leading-relaxed text-ink-3">{r.topic}</p>
              <div className="mt-6 flex items-end justify-between">
                <div>
                  <p className="num font-display text-[28px] font-semibold leading-none tracking-tight">{fmtClock(ph.left)}</p>
                  <p className="mt-1.5 text-xs text-ink-3">left in this block</p>
                </div>
                <div className="text-right">
                  <p className="num flex items-center justify-end gap-1.5 text-sm text-ink-2">
                    <Users size={14} /> {r.people}
                  </p>
                  <div className="mt-2 flex justify-end gap-1.5">
                    {r.tags.map((t) => (
                      <span key={t} className="rounded bg-s3 px-1.5 py-0.5 text-[11px] text-ink-3">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
