import { useState } from "react";
import { Check, Coins, Cookie, Lock, Pencil } from "lucide-react";
import { Pet3D, type Mood } from "../components/Pet3D";
import { Bar, Button, Card, PageHeader } from "../components/ui";
import { LEVEL_PERKS, PETS } from "../lib/data";
import { useApp } from "../lib/store";
import { cn } from "../utils/cn";

const MOODS: { id: Mood; label: string }[] = [
  { id: "idle", label: "Idle" },
  { id: "focus", label: "Focus" },
  { id: "rest", label: "Rest" },
  { id: "cheer", label: "Cheer" },
];

const RARITY: Record<string, string> = {
  Starter: "bg-s3 text-ink-2",
  Common: "bg-ok/10 text-ok",
  Rare: "bg-[#6aa8ff]/10 text-[#7fb4ff]",
  Epic: "bg-[#c58cff]/10 text-[#cf9dff]",
};

export default function Pets() {
  const { state, act } = useApp();
  const [view, setView] = useState(state.activePet);
  const [mood, setMood] = useState<Mood>("idle");
  const [editing, setEditing] = useState(false);
  const pet = PETS.find((p) => p.id === view) ?? PETS[0];
  const owned = state.owned.includes(pet.id);
  const active = state.activePet === pet.id;
  const bond = state.bond[pet.id] ?? 0;
  const level = Math.min(20, Math.floor(bond / 100) + 1);
  const name = state.nicknames[pet.id] || pet.name;
  const canAfford = state.coins >= pet.price;

  return (
    <div>
      <PageHeader
        eyebrow="Companion"
        title="Someone on your side"
        desc="Your companion sits next to the timer, wears headphones while you focus, naps through your breaks and celebrates when you finish. Every focused minute deepens the bond."
        actions={
          <span className="flex items-center gap-2 rounded-xl border border-line bg-s1 px-4 py-2 text-sm">
            <Coins size={15} className="text-warn" />
            <span className="num font-medium">{state.coins}</span>
            <span className="text-ink-3">coins</span>
          </span>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        <Card className="relative overflow-hidden">
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
          <Pet3D key={pet.id} species={pet.species} mood={mood} accent={pet.accent} className="h-[440px] w-full sm:h-[500px]" />
          <div className="absolute left-5 top-5 rounded-xl border border-line bg-s0/70 px-3 py-1.5 text-xs text-ink-3 backdrop-blur">Tap to pet · move your cursor to be watched</div>
          <div className="absolute inset-x-0 bottom-5 flex justify-center">
            <div className="inline-flex rounded-full border border-line-2 bg-s0/80 p-1 backdrop-blur">
              {MOODS.map((m) => (
                <button key={m.id} onClick={() => setMood(m.id)} className={cn("rounded-full px-4 py-1.5 text-[13px] font-medium transition-colors", mood === m.id ? "bg-white/10 text-ink" : "text-ink-3 hover:text-ink-2")}>
                  {m.label}
                </button>
              ))}
            </div>
          </div>
        </Card>

        <div className="space-y-5">
          <Card className="p-6">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <span className={cn("rounded-md px-2 py-1 text-xs font-medium", RARITY[pet.rarity])}>{pet.rarity}</span>
                <div className="mt-3 flex items-center gap-2">
                  {editing && owned ? (
                    <input
                      autoFocus
                      defaultValue={name}
                      maxLength={16}
                      onBlur={(e) => {
                        act.rename(pet.id, e.target.value.trim() || pet.name);
                        setEditing(false);
                      }}
                      onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
                      className="h-10 w-48 rounded-lg border border-brand/50 bg-s2 px-3 font-display text-2xl font-semibold outline-none"
                    />
                  ) : (
                    <h2 className="truncate font-display text-[30px] font-semibold leading-none tracking-tight">{name}</h2>
                  )}
                  {owned && !editing && (
                    <button onClick={() => setEditing(true)} className="rounded-lg p-1.5 text-ink-3 hover:bg-white/5 hover:text-ink" aria-label="Rename">
                      <Pencil size={14} />
                    </button>
                  )}
                </div>
              </div>
              {active && <span className="flex items-center gap-1 rounded-full bg-brand/10 px-3 py-1 text-xs font-medium text-brand"><Check size={12} /> On your desk</span>}
            </div>
            <p className="mt-4 text-[15px] leading-relaxed text-ink-2">{pet.blurb}</p>
            <p className="mt-2 text-sm text-ink-3">{pet.trait}</p>

            {owned ? (
              <>
                <div className="mt-6">
                  <div className="mb-2 flex items-baseline justify-between text-sm">
                    <span className="font-medium">Bond level <span className="num">{level}</span><span className="text-ink-3"> / 20</span></span>
                    <span className="num text-xs text-ink-3">{level >= 20 ? "max" : `${bond % 100} / 100`}</span>
                  </div>
                  <Bar value={level >= 20 ? 100 : bond % 100} />
                </div>
                <div className="mt-6 flex flex-wrap gap-2">
                  <Button onClick={() => { act.treat(pet.id); setMood("cheer"); window.setTimeout(() => setMood("idle"), 2200); }} disabled={state.coins < 10}>
                    <Cookie size={15} /> Give a treat · 10
                  </Button>
                  {!active && (
                    <Button variant="primary" onClick={() => act.setActivePet(pet.id)}>
                      Make active
                    </Button>
                  )}
                </div>
              </>
            ) : (
              <div className="mt-6">
                <Button variant="primary" size="lg" className="w-full" disabled={!canAfford} onClick={() => act.adopt(pet.id, pet.price)}>
                  <Coins size={16} /> Adopt for {pet.price}
                </Button>
                {!canAfford && <p className="mt-2 text-center text-xs text-ink-3">Need {pet.price - state.coins} more coins — finish a few sessions.</p>}
              </div>
            )}
          </Card>

          <Card className="p-6">
            <h3 className="mb-4 font-display text-[15px] font-semibold">Bond rewards</h3>
            <ol className="space-y-3">
              {Object.entries(LEVEL_PERKS).map(([lv, perk]) => {
                const l = Number(lv);
                const got = owned && level >= l;
                return (
                  <li key={lv} className="flex items-center gap-3 text-sm">
                    <span className={cn("num grid size-7 shrink-0 place-items-center rounded-full text-xs font-semibold", got ? "bg-brand text-s0" : "bg-s3 text-ink-3")}>{l}</span>
                    <span className={got ? "text-ink" : "text-ink-3"}>{perk}</span>
                    {got && <Check size={14} className="ml-auto text-brand" />}
                  </li>
                );
              })}
            </ol>
          </Card>
        </div>
      </div>

      <h2 className="mb-4 mt-10 font-display text-xl font-semibold">Collection</h2>
      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {PETS.map((p) => {
          const has = state.owned.includes(p.id);
          return (
            <button
              key={p.id}
              onClick={() => setView(p.id)}
              className={cn("group overflow-hidden rounded-2xl border bg-s1 text-left transition-colors", view === p.id ? "border-brand/50" : "border-line hover:border-line-2")}
            >
              <div className={cn("relative", !has && "opacity-80")}>
                <Pet3D species={p.species} accent={p.accent} className="h-[190px] w-full" />
                {!has && (
                  <span className="absolute right-3 top-3 grid size-8 place-items-center rounded-full border border-line-2 bg-s0/80 text-ink-2">
                    <Lock size={14} />
                  </span>
                )}
              </div>
              <div className="flex items-center justify-between border-t border-line px-4 py-3.5">
                <div>
                  <p className="font-medium">{state.nicknames[p.id] || p.name}</p>
                  <span className={cn("mt-1 inline-block rounded px-1.5 py-0.5 text-[11px]", RARITY[p.rarity])}>{p.rarity}</span>
                </div>
                <span className="num text-sm text-ink-2">{state.activePet === p.id ? "Active" : has ? "Owned" : (<span className="flex items-center gap-1"><Coins size={13} className="text-warn" />{p.price}</span>)}</span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
