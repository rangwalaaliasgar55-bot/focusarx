import { useState } from "react";
import { Minus, Plus, Play, Trash2 } from "lucide-react";
import { Bar, Button, Card, Check, Empty, PageHeader, Segmented } from "../components/ui";
import { navigate } from "../lib/router";
import { useApp, useTimer, type Task } from "../lib/store";
import { cn } from "../utils/cn";

const PRI: { id: Task["priority"]; label: string }[] = [
  { id: "low", label: "Low" },
  { id: "med", label: "Medium" },
  { id: "high", label: "High" },
];

export default function Tasks() {
  const { state, act } = useApp();
  const { setTask } = useTimer();
  const [filter, setFilter] = useState<"open" | "done" | "all">("open");
  const [title, setTitle] = useState("");
  const [pri, setPri] = useState<Task["priority"]>("med");
  const [est, setEst] = useState(2);
  const [goalDraft, setGoalDraft] = useState("");

  const list = state.tasks.filter((t) => (filter === "all" ? true : filter === "open" ? !t.done : t.done));
  const openCount = state.tasks.filter((t) => !t.done).length;
  const order = { high: 0, med: 1, low: 2 };
  const sorted = [...list].sort((a, b) => Number(a.done) - Number(b.done) || order[a.priority] - order[b.priority] || b.created - a.created);

  return (
    <div>
      <PageHeader eyebrow="Plan" title="Tasks & goals" desc="Estimate in focus sessions. Pick one, press focus, and the timer attributes the time to it." />
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div className="space-y-5">
          <Card className="p-5">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!title.trim()) return;
                act.addTask(title, pri, est);
                setTitle("");
              }}
              className="space-y-4"
            >
              <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="What needs doing?" className="h-12 w-full rounded-xl border border-line bg-s2 px-4 text-[15px] outline-none placeholder:text-ink-3 focus:border-brand/50" />
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex flex-wrap items-center gap-4">
                  <Segmented options={PRI} value={pri} onChange={setPri} />
                  <div className="flex items-center gap-2 text-sm text-ink-2">
                    <button type="button" onClick={() => setEst(Math.max(1, est - 1))} className="grid size-8 place-items-center rounded-lg border border-line hover:bg-white/5" aria-label="Fewer sessions">
                      <Minus size={14} />
                    </button>
                    <span className="num w-20 text-center">{est} {est === 1 ? "session" : "sessions"}</span>
                    <button type="button" onClick={() => setEst(Math.min(12, est + 1))} className="grid size-8 place-items-center rounded-lg border border-line hover:bg-white/5" aria-label="More sessions">
                      <Plus size={14} />
                    </button>
                  </div>
                </div>
                <Button type="submit" variant="primary" disabled={!title.trim()}>
                  Add task
                </Button>
              </div>
            </form>
          </Card>

          <div className="flex items-center justify-between">
            <Segmented
              options={[
                { id: "open", label: `Open · ${openCount}` },
                { id: "done", label: "Done" },
                { id: "all", label: "All" },
              ]}
              value={filter}
              onChange={setFilter}
            />
          </div>

          {sorted.length === 0 ? (
            <Empty title={filter === "done" ? "Nothing finished yet" : "Nothing here"} desc="Add a task above — a small, concrete one is easiest to start." />
          ) : (
            <Card className="divide-y divide-line">
              {sorted.map((t) => (
                <div key={t.id} className="group flex items-center gap-4 px-5 py-4">
                  <Check checked={t.done} onChange={() => act.toggleTask(t.id)} label={`Complete ${t.title}`} />
                  <div className="min-w-0 flex-1">
                    <p className={cn("truncate text-[15px]", t.done && "text-ink-3 line-through")}>{t.title}</p>
                    <div className="mt-1.5 flex items-center gap-3 text-xs text-ink-3">
                      <span className={cn("rounded px-1.5 py-0.5", t.priority === "high" ? "bg-bad/10 text-bad" : t.priority === "med" ? "bg-warn/10 text-warn" : "bg-s3")}>{t.priority}</span>
                      <span className="flex items-center gap-1" aria-label={`${t.spent} of ${t.est} sessions`}>
                        {Array.from({ length: Math.min(t.est, 8) }, (_, i) => (
                          <span key={i} className={cn("size-2 rounded-full", i < t.spent ? "bg-brand" : "bg-s4")} />
                        ))}
                        <span className="num ml-1">{t.spent}/{t.est}</span>
                      </span>
                    </div>
                  </div>
                  {!t.done && (
                    <Button
                      size="sm"
                      onClick={() => {
                        setTask(t.id);
                        navigate("/focus");
                      }}
                    >
                      <Play size={12} fill="currentColor" /> Focus
                    </Button>
                  )}
                  <button onClick={() => act.removeTask(t.id)} className="rounded-lg p-2 text-ink-3 opacity-100 transition hover:bg-bad/10 hover:text-bad lg:opacity-0 lg:group-hover:opacity-100" aria-label={`Delete ${t.title}`}>
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </Card>
          )}
        </div>

        <div className="space-y-5">
          <Card className="p-6">
            <h2 className="mb-5 font-display text-lg font-semibold">Goals</h2>
            <div className="space-y-6">
              {state.goals.map((g) => (
                <div key={g.id} className="group">
                  <div className="mb-2 flex items-start justify-between gap-3">
                    <p className="text-[15px] leading-snug">{g.title}</p>
                    <button onClick={() => act.removeGoal(g.id)} className="text-ink-3 opacity-0 hover:text-bad group-hover:opacity-100" aria-label="Remove goal">
                      <Trash2 size={13} />
                    </button>
                  </div>
                  <Bar value={g.progress} max={g.target} tone={g.progress >= g.target ? "ok" : "brand"} />
                  <div className="mt-2.5 flex items-center justify-between">
                    <span className="num text-[13px] text-ink-3">
                      {g.progress} / {g.target} {g.unit}
                    </span>
                    <div className="flex gap-1">
                      <button onClick={() => act.bumpGoal(g.id, -1)} className="grid size-7 place-items-center rounded-lg border border-line text-ink-2 hover:bg-white/5" aria-label="Decrease">
                        <Minus size={13} />
                      </button>
                      <button onClick={() => act.bumpGoal(g.id, g.target >= 100 ? 10 : 1)} className="grid size-7 place-items-center rounded-lg border border-line text-ink-2 hover:bg-white/5" aria-label="Increase">
                        <Plus size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
              {state.goals.length === 0 && <p className="text-sm text-ink-3">No goals yet. Set one that takes weeks, not hours.</p>}
            </div>
            <form
              className="mt-6 flex gap-2 border-t border-line pt-5"
              onSubmit={(e) => {
                e.preventDefault();
                if (!goalDraft.trim()) return;
                act.addGoal(goalDraft, 10, "steps");
                setGoalDraft("");
              }}
            >
              <input value={goalDraft} onChange={(e) => setGoalDraft(e.target.value)} placeholder="New goal…" className="h-10 min-w-0 flex-1 rounded-xl border border-line bg-s2 px-3.5 text-sm outline-none placeholder:text-ink-3 focus:border-brand/50" />
              <Button type="submit" size="icon" aria-label="Add goal">
                <Plus size={16} />
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </div>
  );
}
