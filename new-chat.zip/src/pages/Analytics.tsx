import { useMemo, useState } from "react";
import { BarChart, Heatmap } from "../components/charts";
import { Button, Card, PageHeader, Segmented, Stat } from "../components/ui";
import { addDays, dayKey, fmtMin } from "../lib/data";
import { useApp, useStats } from "../lib/store";
import { Clock, Gauge, Layers, Trophy } from "lucide-react";

const hourLabel = (h: number) => `${((h + 11) % 12) + 1}${h < 12 ? "am" : "pm"}`;

export default function Analytics() {
  const { state, act } = useApp();
  const stats = useStats();
  const [range, setRange] = useState<7 | 30 | 90>(30);

  const d = useMemo(() => {
    const cutoff = addDays(new Date(), -(range - 1));
    cutoff.setHours(0, 0, 0, 0);
    const sessions = state.sessions.filter((s) => s.start >= cutoff.getTime());
    const days = Array.from({ length: range }, (_, i) => {
      const date = addDays(cutoff, i);
      return { date, minutes: stats.byDay[dayKey(date)] ?? 0 };
    });
    const total = sessions.reduce((a, s) => a + s.minutes, 0);
    const active = days.filter((x) => x.minutes > 0).length;
    const best = days.reduce((a, b) => (b.minutes > a.minutes ? b : a), days[0]);
    const avgScore = sessions.length ? Math.round(sessions.reduce((a, s) => a + s.score, 0) / sessions.length) : 0;
    const byHour = Array(24).fill(0) as number[];
    const byTask: Record<string, number> = {};
    const buckets = [0, 0, 0, 0];
    for (const s of sessions) {
      byHour[new Date(s.start).getHours()] += s.minutes;
      const k = s.task ?? "Unlabelled";
      byTask[k] = (byTask[k] ?? 0) + s.minutes;
      buckets[s.score >= 90 ? 3 : s.score >= 80 ? 2 : s.score >= 70 ? 1 : 0]++;
    }
    let peak = 0;
    let peakV = -1;
    for (let h = 0; h < 23; h++) {
      const v = byHour[h] + byHour[h + 1];
      if (v > peakV) {
        peakV = v;
        peak = h;
      }
    }
    const tasks = Object.entries(byTask).sort((a, b) => b[1] - a[1]).slice(0, 6);
    return { sessions, days, total, active, best, avgScore, byHour, peak, peakV, tasks, buckets };
  }, [state.sessions, range, stats.byDay]);

  const chartData = d.days.map((x) => ({
    label: range === 7 ? x.date.toLocaleDateString("en", { weekday: "short" }) : String(x.date.getDate()),
    value: x.minutes,
    sub: x.date.toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" }),
  }));
  const maxTask = d.tasks[0]?.[1] ?? 1;
  const maxBucket = Math.max(1, ...d.buckets);

  return (
    <div>
      <PageHeader
        eyebrow="Insight"
        title="Analytics"
        desc="Computed from your sessions. The score rewards finishing what you start — pauses and early exits cost points, hours alone don’t."
        actions={<Segmented options={[{ id: 7, label: "7 days" }, { id: 30, label: "30 days" }, { id: 90, label: "90 days" }]} value={range} onChange={setRange} />}
      />

      {state.hasDemo && (
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-line-2 bg-s1 px-5 py-3.5 text-sm">
          <p className="text-ink-2">You’re looking at sample history so the charts aren’t empty. New sessions are added on top.</p>
          <Button size="sm" onClick={act.clearDemo}>
            Clear sample data
          </Button>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label="Total focus" value={fmtMin(d.total)} sub={`${d.sessions.length} sessions`} icon={<Clock size={16} />} />
        <Stat label="Average score" value={d.avgScore || "—"} sub="completion & consistency" icon={<Gauge size={16} />} />
        <Stat label="Active days" value={`${d.active}/${range}`} sub={d.active ? `${fmtMin(d.total / d.active)} per active day` : "No sessions yet"} icon={<Layers size={16} />} />
        <Stat label="Best day" value={fmtMin(d.best?.minutes ?? 0)} sub={d.best?.minutes ? d.best.date.toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" }) : "—"} icon={<Trophy size={16} />} />
      </div>

      <Card className="mt-5 p-6">
        <h2 className="mb-6 font-display text-lg font-semibold">Focus time per day</h2>
        <BarChart data={chartData} goal={state.dailyGoal} highlight={chartData.length - 1} height={200} />
      </Card>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Card className="p-6">
          <div className="mb-1 flex items-start justify-between gap-4">
            <h2 className="font-display text-lg font-semibold">Focus DNA</h2>
            {d.peakV > 0 && <span className="rounded-lg bg-brand/10 px-2.5 py-1 text-xs font-medium text-brand">Peak {hourLabel(d.peak)}–{hourLabel(d.peak + 2)}</span>}
          </div>
          <p className="mb-6 text-sm text-ink-3">When your sessions actually happen, by hour of day.</p>
          <BarChart data={d.byHour.map((v, h) => ({ label: String(h), value: v, sub: hourLabel(h) }))} height={150} highlight={d.peakV > 0 ? d.peak : undefined} />
        </Card>

        <Card className="p-6">
          <h2 className="mb-5 font-display text-lg font-semibold">Where the time went</h2>
          <div className="space-y-4">
            {d.tasks.map(([name, m]) => (
              <div key={name}>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span>{name}</span>
                  <span className="num text-ink-3">{fmtMin(m)}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-s3">
                  <div className="h-full rounded-full bg-brand/70" style={{ width: `${(m / maxTask) * 100}%` }} />
                </div>
              </div>
            ))}
            {d.tasks.length === 0 && <p className="text-sm text-ink-3">No sessions in this range.</p>}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="mb-5 font-display text-lg font-semibold">Session quality</h2>
          <div className="space-y-4">
            {[
              ["90+", "Locked in", 3, "bg-ok"],
              ["80–89", "Solid", 2, "bg-brand"],
              ["70–79", "Interrupted", 1, "bg-warn"],
              ["< 70", "Scattered", 0, "bg-bad"],
            ].map(([range, label, i, tone]) => (
              <div key={range as string} className="flex items-center gap-4">
                <span className="num w-14 text-sm text-ink-3">{range}</span>
                <div className="h-2 flex-1 overflow-hidden rounded-full bg-s3">
                  <div className={`h-full rounded-full ${tone}`} style={{ width: `${(d.buckets[i as number] / maxBucket) * 100}%` }} />
                </div>
                <span className="w-24 text-right text-sm text-ink-2">
                  <span className="num">{d.buckets[i as number]}</span> <span className="text-ink-3">{label}</span>
                </span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-6">
          <h2 className="mb-5 font-display text-lg font-semibold">Consistency</h2>
          <Heatmap byDay={stats.byDay} weeks={16} />
        </Card>
      </div>
    </div>
  );
}
