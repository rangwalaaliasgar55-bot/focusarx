import { useEffect, useState } from "react";
import { ArrowLeft, RotateCw } from "lucide-react";
import { Bar, Button, Card, PageHeader } from "../components/ui";
import { DECKS, type Deck } from "../lib/data";
import { useApp } from "../lib/store";
import { cn } from "../utils/cn";

function useDue(deck: Deck) {
  const { state } = useApp();
  const now = Date.now();
  const due = deck.cards.filter((c) => !state.cards[c.id] || state.cards[c.id].due <= now);
  const mastered = deck.cards.filter((c) => (state.cards[c.id]?.box ?? 0) >= 3).length;
  return { due, mastered };
}

function DeckCard({ deck, onStudy }: { deck: Deck; onStudy: () => void }) {
  const { due, mastered } = useDue(deck);
  return (
    <Card className="flex flex-col p-6">
      <p className="text-xs font-medium uppercase tracking-[0.14em] text-ink-3">{deck.subject}</p>
      <h3 className="mt-2 font-display text-xl font-semibold">{deck.name}</h3>
      <div className="mt-6 grid grid-cols-3 gap-2 text-center">
        {[
          [deck.cards.length, "cards"],
          [due.length, "due"],
          [mastered, "mastered"],
        ].map(([v, l]) => (
          <div key={l as string} className="rounded-xl bg-s2 py-3">
            <p className="num font-display text-xl font-semibold">{v}</p>
            <p className="text-[11px] text-ink-3">{l}</p>
          </div>
        ))}
      </div>
      <Bar value={mastered} max={deck.cards.length} tone="ok" className="mt-5" />
      <Button variant={due.length ? "primary" : "soft"} className="mt-5" disabled={!due.length} onClick={onStudy}>
        {due.length ? `Study ${due.length} due` : "All caught up"}
      </Button>
    </Card>
  );
}

function Study({ deck, onExit }: { deck: Deck; onExit: () => void }) {
  const { state, act } = useApp();
  const [ids] = useState(() => deck.cards.filter((c) => !state.cards[c.id] || state.cards[c.id].due <= Date.now()).map((c) => c.id));
  const [i, setI] = useState(0);
  const [flipped, setFlipped] = useState(false);
  const [tally, setTally] = useState([0, 0, 0]);
  const card = deck.cards.find((c) => c.id === ids[i]);
  const finished = i >= ids.length;

  const rate = (r: 0 | 1 | 2) => {
    if (!card) return;
    act.rateCard(card.id, r);
    setTally((t) => t.map((v, k) => (k === r ? v + 1 : v)));
    setFlipped(false);
    setI((n) => n + 1);
  };

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (finished) return;
      if (e.code === "Space") {
        e.preventDefault();
        setFlipped((f) => !f);
      }
      if (flipped && ["Digit1", "Digit2", "Digit3"].includes(e.code)) rate((Number(e.code.slice(-1)) - 1) as 0 | 1 | 2);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  });

  return (
    <div className="mx-auto max-w-2xl">
      <button onClick={onExit} className="mb-6 flex items-center gap-2 text-sm text-ink-3 hover:text-ink-2">
        <ArrowLeft size={15} /> Decks
      </button>
      <div className="mb-5 flex items-center gap-4">
        <Bar value={Math.min(i, ids.length)} max={ids.length} className="flex-1" />
        <span className="num text-sm text-ink-3">
          {Math.min(i + 1, ids.length)} / {ids.length}
        </span>
      </div>

      {finished ? (
        <Card className="px-8 py-14 text-center">
          <h2 className="font-display text-3xl font-semibold">Deck done</h2>
          <p className="mt-2 text-ink-2">{deck.name} · {ids.length} cards reviewed</p>
          <div className="mx-auto mt-8 grid max-w-sm grid-cols-3 gap-3">
            {[
              ["Again", tally[0], "text-bad"],
              ["Good", tally[1], "text-brand"],
              ["Easy", tally[2], "text-ok"],
            ].map(([l, v, c]) => (
              <div key={l as string} className="rounded-xl bg-s2 py-4">
                <p className={cn("num font-display text-2xl font-semibold", c as string)}>{v}</p>
                <p className="text-xs text-ink-3">{l}</p>
              </div>
            ))}
          </div>
          <Button variant="primary" size="lg" className="mt-8" onClick={onExit}>
            Back to decks
          </Button>
        </Card>
      ) : (
        <>
          <div className="flip">
            <button onClick={() => setFlipped((f) => !f)} className={cn("flip-inner relative block h-[340px] w-full text-left sm:h-[380px]", flipped && "is-flipped")} aria-label="Flip card">
              <div className="flip-face absolute inset-0 flex flex-col justify-between rounded-3xl border border-line-2 bg-s1 p-8 sm:p-10">
                <span className="text-xs font-medium uppercase tracking-[0.14em] text-ink-3">Question</span>
                <p className="font-display text-[26px] font-semibold leading-snug tracking-tight sm:text-[32px]">{card?.q}</p>
                <span className="flex items-center gap-2 text-[13px] text-ink-3">
                  <RotateCw size={13} /> Tap or press Space to reveal
                </span>
              </div>
              <div className="flip-face flip-back absolute inset-0 flex flex-col justify-between rounded-3xl border border-brand/30 bg-s2 p-8 sm:p-10">
                <span className="text-xs font-medium uppercase tracking-[0.14em] text-brand">Answer</span>
                <p className="text-[19px] leading-relaxed text-ink sm:text-[21px]">{card?.a}</p>
                <span className="text-[13px] text-ink-3">How well did you recall it?</span>
              </div>
            </button>
          </div>
          <div className={cn("mt-5 grid grid-cols-3 gap-3 transition-opacity", flipped ? "opacity-100" : "pointer-events-none opacity-30")}>
            <Button variant="danger" size="lg" onClick={() => rate(0)}>
              Again <kbd className="text-xs opacity-60">1</kbd>
            </Button>
            <Button size="lg" onClick={() => rate(1)}>
              Good <kbd className="text-xs opacity-60">2</kbd>
            </Button>
            <Button variant="primary" size="lg" onClick={() => rate(2)}>
              Easy <kbd className="text-xs opacity-60">3</kbd>
            </Button>
          </div>
        </>
      )}
    </div>
  );
}

export default function Flashcards() {
  const [deck, setDeck] = useState<Deck | null>(null);
  if (deck) return <Study deck={deck} onExit={() => setDeck(null)} />;
  return (
    <div>
      <PageHeader eyebrow="Study" title="Flashcards" desc="Spaced repetition on a five-box Leitner schedule. Miss a card and it returns in ten minutes; nail it and it waits longer each time." />
      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {DECKS.map((d) => (
          <DeckCard key={d.id} deck={d} onStudy={() => setDeck(d)} />
        ))}
      </div>
    </div>
  );
}
