import { useEffect, useState } from "react";
import { ArrowRight, BarChart3, Layers, PawPrint, Timer, Users, Gauge } from "lucide-react";
import { Ring } from "../components/charts";
import { Pet3D } from "../components/Pet3D";
import { Logo } from "../components/ui";
import { fmtClock } from "../lib/data";
import { Link } from "../lib/router";

const FEATURES = [
  { icon: Timer, title: "A timer you can trust", body: "Deadline-based, so background tabs, screen lock and sleep never skew it. Close the tab and your session is still there.", to: "/focus" },
  { icon: PawPrint, title: "A companion, not a mascot", body: "A 3D pet that wears headphones while you focus, naps on breaks and celebrates when you finish. Pet it. It notices your cursor.", to: "/pets" },
  { icon: Gauge, title: "Focus score, not hours", body: "Each session is rated 0–100 from completion and interruptions. Eight scattered hours and two deep ones stop looking the same.", to: "/analytics" },
  { icon: Users, title: "Study rooms", body: "Body-doubling on a shared clock. Sit in silence next to other people and let the room carry some of the effort.", to: "/rooms" },
  { icon: BarChart3, title: "Focus DNA", body: "See the hours your brain is actually sharpest, a year of consistency at a glance, and where your time really went.", to: "/analytics" },
  { icon: Layers, title: "Flashcards & habits", body: "Spaced repetition, daily habits and missions that fill in on their own as you work. No manual bookkeeping.", to: "/flashcards" },
];

const FAQ = [
  ["Do I need an account to use the timer?", "No. The focus timer is guest-first: open it, set a length and start. An account is only worth creating when you want sessions and streaks saved across devices."],
  ["Is FocusArx actually free?", "The core is free forever: the timer, tasks, streaks, study rooms, leaderboards, flashcards and analytics. Premium is optional and paid for with Focus Tokens earned by finishing sessions."],
  ["What is the Focus Score?", "A 0–100 rating for a session, derived from completion, consistency and distraction events rather than elapsed time. Hours logged is a vanity metric."],
  ["Does the webcam feature record me?", "The attention monitor is optional and runs on-device. Only the derived attention signal is stored; no video is uploaded. Everything else works with the camera off."],
];

function MiniTimer() {
  const [left, setLeft] = useState(24 * 60 * 1000 + 12_000);
  useEffect(() => {
    const id = window.setInterval(() => setLeft((l) => (l <= 1000 ? 25 * 60 * 1000 : l - 1000)), 1000);
    return () => window.clearInterval(id);
  }, []);
  const total = 25 * 60 * 1000;
  return (
    <div className="relative">
      <div className="rounded-[28px] border border-line-2 bg-s1 p-6 sm:p-8">
        <div className="flex items-center justify-between text-[13px] text-ink-3">
          <span className="flex items-center gap-2">
            <span className="size-1.5 animate-pulse rounded-full bg-brand" /> In focus
          </span>
          <span className="num">Session 2 of 4</span>
        </div>
        <div className="mt-6 flex justify-center">
          <Ring value={1 - left / total} size={250} stroke={12}>
            <div className="text-center">
              <div className="num font-display text-[58px] font-semibold leading-none tracking-[-0.045em]">{fmtClock(left)}</div>
              <div className="mt-2 text-[13px] text-ink-3">Thermodynamics set 4</div>
            </div>
          </Ring>
        </div>
        <div className="mt-6 grid grid-cols-3 gap-2 text-center text-xs text-ink-3">
          {[["Score", "94"], ["Streak", "11d"], ["XP", "+50"]].map(([l, v]) => (
            <div key={l} className="rounded-xl bg-s2 py-2.5">
              <p className="num font-display text-base font-semibold text-ink">{v}</p>
              {l}
            </div>
          ))}
        </div>
      </div>
      <div className="pointer-events-auto absolute -bottom-10 -right-2 h-[230px] w-[230px] sm:-right-14 sm:h-[280px] sm:w-[280px]">
        <Pet3D species="fox" mood="focus" accent="#f08a3c" className="size-full" />
      </div>
    </div>
  );
}

export default function Landing() {
  return (
    <div className="min-h-screen overflow-x-hidden">
      <header className="mx-auto flex max-w-[1180px] items-center justify-between px-5 py-5 sm:px-8">
        <Link to="/" className="flex items-center gap-2.5">
          <Logo />
          <span className="font-display text-xl font-bold tracking-tight">FocusArx</span>
        </Link>
        <nav className="hidden items-center gap-8 text-sm text-ink-2 md:flex">
          <a href="#features" className="hover:text-ink">Features</a>
          <a href="#how" className="hover:text-ink">How it works</a>
          <a href="#faq" className="hover:text-ink">FAQ</a>
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/dashboard" className="hidden rounded-xl px-4 py-2 text-sm text-ink-2 hover:text-ink sm:block">Dashboard</Link>
          <Link to="/focus" className="rounded-xl bg-brand px-4 py-2.5 text-sm font-semibold text-s0 hover:bg-[#b6b8ff]">Open timer</Link>
        </div>
      </header>

      <section className="mx-auto grid max-w-[1180px] items-center gap-16 px-5 pb-24 pt-12 sm:px-8 lg:grid-cols-[1.05fr_1fr] lg:pt-20">
        <div>
          <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-line-2 px-3.5 py-1.5 text-[13px] text-ink-2">
            <span className="size-1.5 rounded-full bg-ok" /> Free · no account needed
          </p>
          <h1 className="font-display text-[44px] font-semibold leading-[1.02] tracking-[-0.035em] sm:text-[68px]">
            Focus, with<br />someone on your side.
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-2">
            A calm Pomodoro timer, a 3D companion who keeps you company, deep-work tracking and live study rooms — so you don’t just plan to focus, you actually do.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-3">
            <Link to="/focus" className="inline-flex h-14 items-center gap-2 rounded-full bg-brand px-8 font-display text-base font-semibold text-s0 transition-colors hover:bg-[#b6b8ff]">
              Start a session <ArrowRight size={18} />
            </Link>
            <Link to="/dashboard" className="inline-flex h-14 items-center rounded-full border border-line-2 px-7 text-[15px] font-medium text-ink-2 transition-colors hover:bg-white/5 hover:text-ink">
              See the dashboard
            </Link>
          </div>
          <dl className="mt-14 grid max-w-lg grid-cols-3 gap-6 border-t border-line pt-6">
            {[["25 min", "default slice"], ["0–100", "focus score"], ["On-device", "camera signal"]].map(([v, l]) => (
              <div key={l}>
                <dt className="font-display text-xl font-semibold tracking-tight">{v}</dt>
                <dd className="mt-1 text-[13px] text-ink-3">{l}</dd>
              </div>
            ))}
          </dl>
        </div>
        <div className="mx-auto w-full max-w-[460px] pb-8 lg:mx-0 lg:ml-auto">
          <MiniTimer />
        </div>
      </section>

      <section id="features" className="border-t border-line bg-s1/50 py-24">
        <div className="mx-auto max-w-[1180px] px-5 sm:px-8">
          <p className="mb-3 text-xs font-medium uppercase tracking-[0.14em] text-ink-3">What it does</p>
          <h2 className="max-w-2xl font-display text-[34px] font-semibold leading-tight tracking-tight sm:text-5xl">The timer is the product. Everything else supports it.</h2>
          <div className="mt-14 grid gap-px overflow-hidden rounded-3xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <Link key={f.title} to={f.to} className="group bg-s0 p-8 transition-colors hover:bg-s2">
                <f.icon size={22} className="text-brand" strokeWidth={1.8} />
                <h3 className="mt-5 font-display text-xl font-semibold tracking-tight">{f.title}</h3>
                <p className="mt-2.5 text-[15px] leading-relaxed text-ink-2">{f.body}</p>
                <span className="mt-5 inline-flex items-center gap-1.5 text-[13px] text-ink-3 transition-colors group-hover:text-brand">
                  Open <ArrowRight size={13} />
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section id="how" className="py-24">
        <div className="mx-auto grid max-w-[1180px] gap-14 px-5 sm:px-8 lg:grid-cols-[1fr_1.4fr]">
          <div>
            <p className="mb-3 text-xs font-medium uppercase tracking-[0.14em] text-ink-3">How a session works</p>
            <h2 className="font-display text-[34px] font-semibold leading-tight tracking-tight sm:text-[44px]">Three steps. No setup screen.</h2>
          </div>
          <ol className="space-y-9">
            {[
              ["Pick a slice", "Choose a duration, or link straight to one — focusarx.site/focus?duration=25&task=Revise+thermo."],
              ["Press start once", "Pause preserves the slice. Finishing records minutes, XP, coins and streak progress, and your companion cheers."],
              ["Read the result", "A focus score, a heatmap and your Focus DNA turn sessions into something you can actually improve."],
            ].map(([t, b], i) => (
              <li key={t} className="flex gap-6 border-b border-line pb-9 last:border-0">
                <span className="num font-display text-[38px] font-semibold leading-none text-ink-3">0{i + 1}</span>
                <div>
                  <h3 className="font-display text-xl font-semibold">{t}</h3>
                  <p className="mt-2 max-w-lg text-[15px] leading-relaxed text-ink-2">{b}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section id="faq" className="border-t border-line py-24">
        <div className="mx-auto max-w-3xl px-5 sm:px-8">
          <h2 className="font-display text-[34px] font-semibold tracking-tight sm:text-[44px]">Questions</h2>
          <div className="mt-10 divide-y divide-line border-y border-line">
            {FAQ.map(([q, a]) => (
              <details key={q} className="group py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-6 text-[17px] font-medium">
                  {q}
                  <span className="text-xl text-ink-3 transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 max-w-2xl text-[15px] leading-relaxed text-ink-2">{a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="px-5 pb-24 sm:px-8">
        <div className="mx-auto flex max-w-[1180px] flex-wrap items-center justify-between gap-8 rounded-[32px] border border-line-2 bg-s1 px-8 py-14 sm:px-14">
          <div>
            <h2 className="font-display text-[32px] font-semibold leading-tight tracking-tight sm:text-5xl">Ready when you are.</h2>
            <p className="mt-3 text-ink-2">Open the timer. Your companion is already waiting.</p>
          </div>
          <Link to="/focus" className="inline-flex h-14 items-center gap-2 rounded-full bg-brand px-8 font-display text-base font-semibold text-s0 hover:bg-[#b6b8ff]">
            Start focusing <ArrowRight size={18} />
          </Link>
        </div>
      </section>

      <footer className="border-t border-line py-8 text-sm text-ink-3">
        <div className="mx-auto flex max-w-[1180px] flex-wrap items-center justify-between gap-4 px-5 sm:px-8">
          <span className="flex items-center gap-2"><Logo size={18} /> FocusArx</span>
          <span>Frontend preview · your data stays in this browser</span>
        </div>
      </footer>
    </div>
  );
}
