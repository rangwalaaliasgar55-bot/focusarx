import { Check, Coins, Sparkles } from "lucide-react";
import { Bar, Button, Card, PageHeader } from "../components/ui";
import { useMissions, type Mission } from "../lib/missions";
import { useApp, useStats } from "../lib/store";
import { Link } from "../lib/router";
import { cn } from "../utils/cn";

function Row({ m }: { m: Mission }) {
  const { act } = useApp();
  const done = m.progress >= m.target;
  return (
    <div className="flex flex-wrap items-center gap-x-5 gap-y-3 px-5 py-4 sm:flex-nowrap">
      <span className={cn("grid size-10 shrink-0 place-items-center rounded-xl border", m.claimed ? "border-ok/30 bg-ok/10 text-ok" : done ? "border-brand/40 bg-brand/10 text-brand" : "border-line text-ink-3")}>
        {m.claimed ? <Check size={17} /> : <Sparkles size={17} />}
      </span>
      <div className="min-w-0 flex-1 basis-48">
        <p className={cn("font-medium", m.claimed && "text-ink-3")}>{m.title}</p>
        <p className="text-[13px] text-ink-3">{m.desc}</p>
        <div className="mt-2.5 flex items-center gap-3">
          <Bar value={m.progress} max={m.target} tone={done ? "ok" : "brand"} />
          <span className="num shrink-0 text-xs text-ink-3">
            {Math.round(m.progress)}/{m.target}
          </span>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-right text-[13px]">
          <p className="num text-brand">+{m.xp} XP</p>
          <p className="num flex items-center justify-end gap-1 text-warn">
            <Coins size={12} />+{m.coins}
          </p>
        </div>
        <Button variant={done && !m.claimed ? "primary" : "soft"} size="sm" disabled={!done || m.claimed} onClick={() => act.claim(m.id, m.xp, m.coins)} className="w-[76px]">
          {m.claimed ? "Claimed" : "Claim"}
        </Button>
      </div>
    </div>
  );
}

export default function Missions() {
  const missions = useMissions();
  const stats = useStats();
  const claimable = missions.filter((m) => m.progress >= m.target && !m.claimed).length;
  const daily = missions.filter((m) => m.scope === "daily");
  const weekly = missions.filter((m) => m.scope === "weekly");
  return (
    <div>
      <PageHeader
        eyebrow="Play"
        title="Missions"
        desc="Progress fills in by itself as you focus, finish tasks, log habits and review cards. Claim rewards when a bar is full."
        actions={
          <span className="rounded-xl border border-line bg-s1 px-4 py-2 text-sm">
            <span className="num font-medium text-brand">{claimable}</span> <span className="text-ink-3">ready to claim</span>
          </span>
        }
      />
      <section>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="font-display text-lg font-semibold">Today</h2>
          <span className="text-[13px] text-ink-3">Resets at midnight</span>
        </div>
        <Card className="divide-y divide-line">{daily.map((m) => <Row key={m.id} m={m} />)}</Card>
      </section>
      <section className="mt-9">
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="font-display text-lg font-semibold">This week</h2>
          <span className="text-[13px] text-ink-3">Resets Monday</span>
        </div>
        <Card className="divide-y divide-line">{weekly.map((m) => <Row key={m.id} m={m} />)}</Card>
      </section>
      <p className="mt-6 text-sm text-ink-3">
        Streak: <span className="num text-ink-2">{stats.streak} days</span> ·{" "}
        <Link to="/focus" className="text-brand hover:underline">
          Start a session
        </Link>
      </p>
    </div>
  );
}
