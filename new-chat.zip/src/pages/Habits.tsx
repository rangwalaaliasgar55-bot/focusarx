import { useState } from "react";
import { Flame, Plus, Trash2 } from "lucide-react";
import { Button, Card, Empty, PageHeader } from "../components/ui";
import { addDays, dayKey } from "../lib/data";
import { useApp } from "../lib/store";
import { cn } from "../utils/cn";

function streakOf(days: string[]) {
  const set = new Set(days);
  const d = new Date();
  if (!set.has(dayKey(d))) d.setDate(d.getDate() - 1);
  let n = 0;
  while (set.has(dayKey(d))) {
    n++;
    d.setDate(d.getDate() - 1);
  }
  return n;
}

export default function Habits() {
  const { state, act } = useApp();
  const [name, setName] = useState("");
  const today = dayKey();
  const strip = Array.from({ length: 14 }, (_, i) => addDays(new Date(), i - 13));
  const doneToday = state.habits.filter((h) => h.days.includes(today)).length;

  return (
    <div>
      <PageHeader
        eyebrow="Routine"
        title="Habits"
        desc="Small things, same time, every day. Tap a day to mark it — you can fix yesterday, too."
        actions={
          <span className="num rounded-xl border border-line bg-s1 px-4 py-2 text-sm">
            {doneToday}/{state.habits.length} <span className="text-ink-3">today</span>
          </span>
        }
      />

      <Card className="mb-5 p-5">
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!name.trim()) return;
            act.addHabit(name);
            setName("");
          }}
        >
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="New habit — e.g. “Stretch for 5 minutes”" className="h-11 min-w-0 flex-1 rounded-xl border border-line bg-s2 px-4 text-[15px] outline-none placeholder:text-ink-3 focus:border-brand/50" />
          <Button type="submit" variant="primary" size="lg" className="h-11 rounded-xl px-5 text-sm">
            <Plus size={16} /> Add
          </Button>
        </form>
      </Card>

      {state.habits.length === 0 ? (
        <Empty title="No habits yet" desc="Start with one you can do in under two minutes." />
      ) : (
        <div className="space-y-3">
          {state.habits.map((h) => {
            const s = streakOf(h.days);
            return (
              <Card key={h.id} className="group p-5">
                <div className="flex flex-wrap items-center gap-x-6 gap-y-4">
                  <div className="min-w-[200px] flex-1">
                    <p className="text-[16px] font-medium">{h.name}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-[13px] text-ink-3">
                      <Flame size={13} className={s > 0 ? "text-warn" : ""} />
                      <span className="num">{s}</span> day streak · <span className="num">{h.days.filter((d) => d >= dayKey(addDays(new Date(), -29))).length}</span>/30 this month
                    </p>
                  </div>
                  <div className="flex gap-1.5 overflow-x-auto pb-1">
                    {strip.map((d) => {
                      const k = dayKey(d);
                      const on = h.days.includes(k);
                      const isToday = k === today;
                      return (
                        <button
                          key={k}
                          onClick={() => act.toggleHabit(h.id, k)}
                          aria-pressed={on}
                          aria-label={`${h.name} on ${d.toDateString()}`}
                          className={cn("flex w-[34px] shrink-0 flex-col items-center gap-1.5 rounded-xl border py-2 transition-colors", on ? "border-brand/40 bg-brand/15" : "border-line hover:border-line-2", isToday && !on && "border-line-2")}
                        >
                          <span className={cn("text-[10px] uppercase", isToday ? "text-ink" : "text-ink-3")}>{d.toLocaleDateString("en", { weekday: "narrow" })}</span>
                          <span className={cn("size-3.5 rounded-full", on ? "bg-brand" : "bg-s4")} />
                          <span className="num text-[10px] text-ink-3">{d.getDate()}</span>
                        </button>
                      );
                    })}
                  </div>
                  <button onClick={() => act.removeHabit(h.id)} className="rounded-lg p-2 text-ink-3 hover:bg-bad/10 hover:text-bad lg:opacity-0 lg:group-hover:opacity-100" aria-label={`Delete ${h.name}`}>
                    <Trash2 size={15} />
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
