import { useMemo, useState } from "react";
import { Crown, Flame } from "lucide-react";
import { Card, PageHeader, Segmented } from "../components/ui";
import { fmtMin, RIVALS } from "../lib/data";
import { useStats } from "../lib/store";
import { cn } from "../utils/cn";

export default function Leaderboard() {
  const stats = useStats();
  const [tab, setTab] = useState<"week" | "all">("week");

  const rows = useMemo(() => {
    const me = { name: "You", level: stats.level.level, weekMin: stats.weekMinutes, allMin: stats.totalMinutes, streak: stats.streak, tag: "Guest", me: true };
    const all = [...RIVALS.map((r) => ({ ...r, me: false })), me];
    return all.sort((a, b) => (tab === "week" ? b.weekMin - a.weekMin : b.allMin - a.allMin));
  }, [stats, tab]);

  const val = (r: (typeof rows)[number]) => (tab === "week" ? r.weekMin : r.allMin);
  const myRank = rows.findIndex((r) => r.me) + 1;
  const top3 = rows.slice(0, 3);
  const podium = [top3[1], top3[0], top3[2]];

  return (
    <div>
      <PageHeader
        eyebrow="Together"
        title="Leaderboard"
        desc="Ranked by focused minutes — not by who talks the most. You’re compared with a sample cohort in this preview."
        actions={<Segmented options={[{ id: "week", label: "This week" }, { id: "all", label: "All time" }]} value={tab} onChange={setTab} />}
      />

      <div className="mb-6 grid grid-cols-3 items-end gap-3 sm:gap-5">
        {podium.map((r, i) => {
          const place = i === 1 ? 1 : i === 0 ? 2 : 3;
          return (
            <Card key={r.name} className={cn("flex flex-col items-center px-3 pb-5 pt-6 text-center", r.me && "border-brand/40", place === 1 ? "pb-8 pt-8" : "")}>
              {place === 1 && <Crown size={18} className="mb-2 text-warn" />}
              <span className={cn("grid place-items-center rounded-full bg-s4 font-display font-semibold text-ink-2", place === 1 ? "size-16 text-lg" : "size-12 text-sm")}>{r.name.split(" ").map((x) => x[0]).join("")}</span>
              <p className="mt-3 max-w-full truncate text-[15px] font-medium">{r.name}</p>
              <p className="num mt-1 font-display text-xl font-semibold">{fmtMin(val(r))}</p>
              <span className="num mt-2 rounded-md bg-s3 px-2 py-0.5 text-xs text-ink-3">#{place}</span>
            </Card>
          );
        })}
      </div>

      <Card className="overflow-hidden">
        <div className="hidden grid-cols-[56px_1fr_90px_110px_90px] gap-4 border-b border-line px-5 py-3 text-xs font-medium uppercase tracking-wider text-ink-3 sm:grid">
          <span>Rank</span>
          <span>Name</span>
          <span>Level</span>
          <span className="text-right">Focus</span>
          <span className="text-right">Streak</span>
        </div>
        {rows.map((r, i) => (
          <div key={r.name} className={cn("grid grid-cols-[40px_1fr_auto] items-center gap-4 border-b border-line px-5 py-3.5 last:border-0 sm:grid-cols-[56px_1fr_90px_110px_90px]", r.me && "bg-brand/[0.07]")}>
            <span className="num text-sm text-ink-3">{i + 1}</span>
            <div className="flex min-w-0 items-center gap-3">
              <span className="grid size-9 shrink-0 place-items-center rounded-full bg-s4 text-xs font-semibold text-ink-2">{r.name.split(" ").map((x) => x[0]).join("")}</span>
              <div className="min-w-0">
                <p className="truncate text-[15px] font-medium">
                  {r.name} {r.me && <span className="ml-1 rounded bg-brand/15 px-1.5 py-0.5 text-[11px] text-brand">you</span>}
                </p>
                <p className="truncate text-xs text-ink-3">{r.tag}</p>
              </div>
            </div>
            <span className="num hidden text-sm text-ink-2 sm:block">Lv {r.level}</span>
            <span className="num text-right text-sm font-medium">{fmtMin(val(r))}</span>
            <span className="num hidden items-center justify-end gap-1.5 text-sm text-ink-2 sm:flex">
              <Flame size={13} className="text-warn" />
              {r.streak}
            </span>
          </div>
        ))}
      </Card>
      <p className="mt-4 text-sm text-ink-3">
        You’re <span className="num text-ink-2">#{myRank}</span> of {rows.length}
        {myRank > 1 && <> — {fmtMin(val(rows[myRank - 2]) - val(rows[myRank - 1]))} to pass {rows[myRank - 2].name}.</>}
      </p>
    </div>
  );
}
