import { useEffect, useMemo, useState } from "react";
import { CloudRain, Maximize2, Minimize2, Minus, Pause, Play, Plus, RotateCcw, SkipForward, Square, Volume2, Waves, Wind, Flame, Clock3 } from "lucide-react";
import { Button, Card, Modal } from "../components/ui";
import { Pet3D, type Mood } from "../components/Pet3D";
import { Ring } from "../components/charts";
import { useApp, useStats, useTimer, type Mode } from "../lib/store";
import { fmtClock, fmtMin, PETS } from "../lib/data";
import { setLayer, volumes, type LayerId } from "../lib/audio";
import { cn } from "../utils/cn";
import { Link } from "../lib/router";

const MODES: { id: Mode; label: string }[] = [
  { id: "focus", label: "Focus" },
  { id: "short", label: "Short break" },
  { id: "long", label: "Long break" },
];

const GREEN = "#6fd3a0";
const BRAND = "#a3a6ff";

/* ───────────── the face of the timer ───────────── */
function TimerFace({ big = false }: { big?: boolean }) {
  const { t, remaining, progress } = useTimer();
  const { state } = useApp();
  const tone = t.mode === "focus" ? BRAND : GREEN;
  const running = t.status === "running";
  const task = state.tasks.find((x) => x.id === t.taskId);
  const R = 196;
  const C = 2 * Math.PI * R;
  const a = (1 - progress) * 2 * Math.PI;
  const done = t.mode === "long" && t.cycle > 0 && t.cycle % 4 === 0 ? 4 : t.cycle % 4;
  const label = t.status === "paused" ? "Paused" : running ? (t.mode === "focus" ? "In focus" : "Resting") : t.mode === "focus" ? "Ready to focus" : t.mode === "short" ? "Short break" : "Long break";

  const ticks = useMemo(
    () =>
      Array.from({ length: 60 }, (_, i) => {
        const ang = (i / 60) * 2 * Math.PI;
        const major = i % 5 === 0;
        const r1 = major ? 211 : 216;
        return { i, major, x1: 240 + Math.sin(ang) * r1, y1: 240 - Math.cos(ang) * r1, x2: 240 + Math.sin(ang) * 226, y2: 240 - Math.cos(ang) * 226 };
      }),
    [],
  );

  return (
    <div className={cn("relative mx-auto aspect-square w-full", big ? "max-w-[min(78vh,640px)]" : "max-w-[460px]")}>
      <div
        className="pointer-events-none absolute -inset-10 rounded-full transition-opacity duration-1000"
        style={{ background: `radial-gradient(closest-side, ${tone}1c, transparent)`, opacity: running ? 1 : 0 }}
      />
      <svg viewBox="0 0 480 480" className="relative size-full" aria-hidden>
        {ticks.map((k) => (
          <line
            key={k.i}
            x1={k.x1}
            y1={k.y1}
            x2={k.x2}
            y2={k.y2}
            strokeLinecap="round"
            strokeWidth={k.major ? 2.6 : 1.5}
            stroke={k.i / 60 <= 1 - progress + 0.0001 ? (k.major ? tone : "#8e9199") : "#26272b"}
            strokeOpacity={k.i / 60 <= 1 - progress + 0.0001 ? (k.major ? 1 : 0.55) : 1}
            style={{ transition: "stroke .4s" }}
          />
        ))}
        <circle cx="240" cy="240" r={R} fill="#121214" stroke="#1d1e22" strokeWidth="12" />
        <circle
          cx="240"
          cy="240"
          r={R}
          fill="none"
          stroke={tone}
          strokeWidth="12"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={Math.min(C - 0.1, C * progress)}
          transform="rotate(-90 240 240)"
          style={{ transition: running ? "stroke-dashoffset .25s linear" : "stroke-dashoffset .5s ease, stroke .4s", filter: running ? `drop-shadow(0 0 8px ${tone}55)` : undefined }}
        />
        <circle cx={240 + Math.sin(a) * R} cy={240 - Math.cos(a) * R} r="7" fill="#0b0b0c" stroke={tone} strokeWidth="3" style={{ transition: running ? "all .25s linear" : "all .5s ease" }} />
        <circle cx="240" cy="240" r="168" fill="none" stroke="#ffffff" strokeOpacity=".04" />
      </svg>

      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="mb-1 flex items-center gap-2 text-[13px] font-medium text-ink-2">
          <span className="size-1.5 rounded-full" style={{ background: tone, opacity: running ? 1 : 0.5 }} />
          {label}
        </span>
        <div className={cn("num font-display font-semibold leading-none tracking-[-0.045em]", big ? "text-[clamp(64px,13vw,132px)]" : "text-[clamp(64px,16vw,100px)]")}>{fmtClock(remaining)}</div>
        <p className={cn("mt-3 max-w-[70%] truncate text-center text-sm", task ? "text-ink-2" : "text-ink-3")}>{task ? task.title : "No task selected"}</p>
        <div className="mt-5 flex items-center gap-2" aria-label={`Session ${Math.min(4, t.cycle % 4 + 1)} of 4`}>
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={cn("h-1.5 rounded-full transition-all", i < done ? "w-6 bg-brand" : i === done && t.mode === "focus" ? "w-6 bg-brand/35" : "w-1.5 bg-s4")} />
          ))}
        </div>
      </div>
    </div>
  );
}

/* ───────────── controls ───────────── */
function Controls({ onZen, zen }: { onZen: () => void; zen: boolean }) {
  const { t, start, pause, resume, reset, skip, finishEarly, progress } = useTimer();
  const idle = t.status === "idle";
  const elapsedOk = t.mode === "focus" && !idle && progress * (t.total / 60000) >= 1;
  return (
    <div className="flex items-center justify-center gap-3">
      <Button variant="soft" size="icon" onClick={reset} disabled={idle} title="Reset" aria-label="Reset timer" className="size-12 rounded-full">
        <RotateCcw size={18} />
      </Button>
      <button
        onClick={idle ? start : t.status === "running" ? pause : resume}
        className="flex h-16 min-w-[176px] items-center justify-center gap-2.5 rounded-full bg-brand px-9 font-display text-[17px] font-semibold text-s0 transition-[transform,background-color] hover:bg-[#b6b8ff] active:scale-[0.97]"
      >
        {t.status === "running" ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
        {idle ? (t.mode === "focus" ? "Start focus" : "Start break") : t.status === "running" ? "Pause" : "Resume"}
      </button>
      {elapsedOk ? (
        <Button variant="soft" size="icon" onClick={finishEarly} title="End session & save progress" aria-label="End session early" className="size-12 rounded-full">
          <Square size={16} fill="currentColor" />
        </Button>
      ) : (
        <Button variant="soft" size="icon" onClick={skip} title={t.mode === "focus" ? "Skip to break" : "Skip to focus"} aria-label="Skip" className="size-12 rounded-full">
          <SkipForward size={18} />
        </Button>
      )}
      {!zen && (
        <Button variant="ghost" size="icon" onClick={onZen} title="Zen mode (Z)" aria-label="Enter zen mode" className="absolute right-4 top-4 hidden sm:inline-flex">
          <Maximize2 size={18} />
        </Button>
      )}
    </div>
  );
}

function DurationPicker() {
  const { t, setMinutes, minutesFor } = useTimer();
  const m = minutesFor(t.mode);
  const locked = t.status !== "idle";
  const presets = t.mode === "focus" ? [15, 25, 45, 50, 90] : t.mode === "short" ? [3, 5, 10] : [15, 20, 30];
  return (
    <div className={cn("flex flex-wrap items-center justify-center gap-3 transition-opacity", locked && "pointer-events-none opacity-35")}>
      <div className="flex items-center rounded-full border border-line bg-s2 p-1">
        <button className="grid size-8 place-items-center rounded-full text-ink-2 hover:bg-white/5 hover:text-ink" onClick={() => setMinutes(m - 5)} aria-label="Minus 5 minutes">
          <Minus size={15} />
        </button>
        <span className="num w-[68px] text-center text-sm font-medium">{m} min</span>
        <button className="grid size-8 place-items-center rounded-full text-ink-2 hover:bg-white/5 hover:text-ink" onClick={() => setMinutes(m + 5)} aria-label="Plus 5 minutes">
          <Plus size={15} />
        </button>
      </div>
      <div className="flex gap-1.5">
        {presets.map((p) => (
          <button key={p} onClick={() => setMinutes(p)} className={cn("num rounded-full border px-3 py-1.5 text-[13px] transition-colors", m === p ? "border-brand/50 bg-brand/10 text-brand" : "border-line text-ink-3 hover:border-line-2 hover:text-ink-2")}>
            {p}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ───────────── side panels ───────────── */
function Companion({ mood }: { mood: Mood }) {
  const { state } = useApp();
  const { t, progress, result } = useTimer();
  const pet = PETS.find((p) => p.id === state.activePet) ?? PETS[0];
  const name = state.nicknames[pet.id] || pet.name;
  const msg = result
    ? "Session logged. That was a good one."
    : t.status === "running" && t.mode === "focus"
      ? progress < 0.33
        ? "Headphones on. Let’s settle in."
        : progress < 0.66
          ? "Halfway there. Keep going."
          : "Final stretch — you’ve got this."
      : t.status === "running"
        ? "Rest your eyes. I’m napping too."
        : t.status === "paused"
          ? "Paused. Breathe, then come back."
          : "Ready when you are. Tap me.";
  return (
    <Card className="relative overflow-hidden">
      <div className="absolute left-4 top-4 z-10 max-w-[70%] rounded-2xl rounded-bl-md border border-line-2 bg-s2/95 px-3.5 py-2 text-[13px] leading-snug text-ink-2">
        <span className="font-medium text-ink">{name}: </span>
        {msg}
      </div>
      <Pet3D species={pet.species} mood={mood} accent={pet.accent} className="h-[290px] w-full" />
      <Link to="/pets" className="absolute bottom-3 right-4 text-xs text-ink-3 hover:text-ink-2">
        Companion →
      </Link>
    </Card>
  );
}

function TaskPicker() {
  const { state, act } = useApp();
  const { t, setTask } = useTimer();
  const [draft, setDraft] = useState("");
  const open = state.tasks.filter((x) => !x.done).slice(0, 5);
  return (
    <Card className="p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-[15px] font-semibold">Working on</h3>
        {t.taskId && (
          <button onClick={() => setTask(null)} className="text-xs text-ink-3 hover:text-ink-2">
            Clear
          </button>
        )}
      </div>
      <div className="space-y-1">
        {open.map((x) => (
          <button
            key={x.id}
            onClick={() => setTask(t.taskId === x.id ? null : x.id)}
            className={cn("flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left text-sm transition-colors", t.taskId === x.id ? "border-brand/40 bg-brand/10" : "border-transparent hover:bg-white/[0.04]")}
          >
            <span className={cn("size-3.5 shrink-0 rounded-full border-2", t.taskId === x.id ? "border-brand bg-brand" : "border-ink-3")} />
            <span className="min-w-0 flex-1 truncate">{x.title}</span>
            <span className="num shrink-0 text-xs text-ink-3">
              {x.spent}/{x.est}
            </span>
          </button>
        ))}
        {open.length === 0 && <p className="px-1 py-2 text-sm text-ink-3">All clear. Add something to work on.</p>}
      </div>
      <form
        className="mt-3 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!draft.trim()) return;
          act.addTask(draft);
          setDraft("");
        }}
      >
        <input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Add a task…" className="h-10 min-w-0 flex-1 rounded-xl border border-line bg-s2 px-3.5 text-sm outline-none placeholder:text-ink-3 focus:border-brand/50" />
        <Button type="submit" size="icon" aria-label="Add task">
          <Plus size={16} />
        </Button>
      </form>
    </Card>
  );
}

const LAYERS: { id: LayerId; label: string; icon: typeof CloudRain }[] = [
  { id: "rain", label: "Rain", icon: CloudRain },
  { id: "waves", label: "Waves", icon: Waves },
  { id: "wind", label: "Wind", icon: Wind },
  { id: "brown", label: "Brown noise", icon: Volume2 },
];

function Sounds() {
  const [vol, setVol] = useState<Partial<Record<LayerId, number>>>({ ...volumes });
  const change = (id: LayerId, v: number) => {
    setLayer(id, v);
    setVol((s) => ({ ...s, [id]: v }));
  };
  return (
    <Card className="p-5">
      <h3 className="mb-3 font-display text-[15px] font-semibold">Ambient sound</h3>
      <div className="space-y-3">
        {LAYERS.map((l) => {
          const v = vol[l.id] ?? 0;
          return (
            <div key={l.id} className="flex items-center gap-3">
              <button
                onClick={() => change(l.id, v > 0 ? 0 : 0.6)}
                aria-pressed={v > 0}
                aria-label={`${l.label} ${v > 0 ? "off" : "on"}`}
                className={cn("grid size-9 shrink-0 place-items-center rounded-xl border transition-colors", v > 0 ? "border-brand/40 bg-brand/10 text-brand" : "border-line text-ink-3 hover:text-ink-2")}
              >
                <l.icon size={16} />
              </button>
              <span className="w-[88px] text-sm text-ink-2">{l.label}</span>
              <input type="range" min={0} max={1} step={0.01} value={v} onChange={(e) => change(l.id, Number(e.target.value))} aria-label={`${l.label} volume`} className="min-w-0 flex-1" />
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function Today() {
  const stats = useStats();
  const { state } = useApp();
  return (
    <div className="grid grid-cols-3 gap-3">
      {[
        { icon: Clock3, v: fmtMin(stats.today), l: `of ${fmtMin(state.dailyGoal)}` },
        { icon: Play, v: String(stats.todaySessions.length), l: "sessions" },
        { icon: Flame, v: String(stats.streak), l: "day streak" },
      ].map((s) => (
        <Card key={s.l} className="px-4 py-3.5">
          <s.icon size={14} className="text-ink-3" />
          <p className="num mt-2 font-display text-xl font-semibold leading-none">{s.v}</p>
          <p className="mt-1.5 text-xs text-ink-3">{s.l}</p>
        </Card>
      ))}
    </div>
  );
}

/* ───────────── result dialog ───────────── */
function ResultDialog() {
  const { result, dismiss, setMode, start, t } = useTimer();
  const { state } = useApp();
  const pet = PETS.find((p) => p.id === state.activePet) ?? PETS[0];
  if (!result) return null;
  return (
    <Modal open onClose={dismiss} className="max-w-sm text-center">
      <Pet3D species={pet.species} mood={result.completed ? "cheer" : "idle"} accent={pet.accent} className="-mx-2 -mt-2 h-[210px]" />
      <h2 className="font-display text-2xl font-semibold">{result.completed ? "Session complete" : "Progress saved"}</h2>
      <p className="mt-1 text-sm text-ink-2">
        {fmtMin(result.minutes)} {result.task ? `on “${result.task}”` : "of focus"}
      </p>
      <div className="mt-5 flex items-center justify-center gap-6">
        <Ring value={result.score / 100} size={92} stroke={8}>
          <div>
            <div className="num font-display text-2xl font-semibold leading-none">{result.score}</div>
            <div className="mt-1 text-[10px] uppercase tracking-wider text-ink-3">score</div>
          </div>
        </Ring>
        <div className="space-y-2 text-left text-sm">
          <p className="flex items-center gap-2">
            <span className="num w-14 font-display text-lg font-semibold text-brand">+{result.xp}</span> XP
          </p>
          <p className="flex items-center gap-2">
            <span className="num w-14 font-display text-lg font-semibold text-warn">+{result.coins}</span> coins
          </p>
          <p className="text-xs text-ink-3">+{Math.round(result.minutes)} bond</p>
        </div>
      </div>
      <div className="mt-6 flex gap-2">
        <Button variant="soft" className="flex-1" onClick={dismiss}>
          Done
        </Button>
        {result.completed && (
          <Button
            variant="primary"
            className="flex-1"
            onClick={() => {
              dismiss();
              if (t.mode === "focus") setMode("focus");
              start();
            }}
          >
            {t.mode === "focus" ? "Another round" : "Start break"}
          </Button>
        )}
      </div>
    </Modal>
  );
}

/* ───────────── page ───────────── */
export default function Focus() {
  const { t, setMode, start, pause, resume, result } = useTimer();
  const { state } = useApp();
  const [zen, setZen] = useState(false);
  const pet = PETS.find((p) => p.id === state.activePet) ?? PETS[0];
  const mood: Mood = result?.completed ? "cheer" : t.status === "running" ? (t.mode === "focus" ? "focus" : "rest") : "idle";

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "BUTTON") return;
      if (e.key === "Escape") setZen(false);
      if (e.code === "Space") {
        e.preventDefault();
        if (t.status === "idle") start();
        else if (t.status === "running") pause();
        else resume();
      }
      if (e.key.toLowerCase() === "z") setZen((z) => !z);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [t.status, start, pause, resume]);

  if (zen) {
    return (
      <div className="fixed inset-0 z-50 flex animate-fade flex-col items-center justify-center gap-8 bg-s0 p-6">
        <TimerFace big />
        <div className="relative">
          <Controls onZen={() => setZen(false)} zen />
        </div>
        <Pet3D species={pet.species} mood={mood} accent={pet.accent} className="pointer-events-auto absolute bottom-4 right-4 hidden h-[220px] w-[220px] md:block" />
        <button onClick={() => setZen(false)} className="absolute right-5 top-5 flex items-center gap-2 rounded-full border border-line px-4 py-2 text-sm text-ink-2 hover:bg-white/5">
          <Minimize2 size={15} /> Exit zen
        </button>
        <ResultDialog />
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="mb-2 text-xs font-medium uppercase tracking-[0.14em] text-ink-3">Focus timer</p>
          <h1 className="font-display text-[28px] font-semibold tracking-tight sm:text-[34px]">One screen. One task.</h1>
        </div>
        <p className="hidden text-[13px] text-ink-3 sm:block">
          <kbd className="rounded-md border border-line-2 bg-s2 px-1.5 py-0.5 font-sans text-xs">Space</kbd> start / pause · <kbd className="rounded-md border border-line-2 bg-s2 px-1.5 py-0.5 font-sans text-xs">Z</kbd> zen
        </p>
      </div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_368px]">
        <Card className="relative flex flex-col items-center gap-7 overflow-hidden px-4 py-7 sm:px-8 sm:py-9">
          <div className="inline-flex rounded-full border border-line bg-s2 p-1" role="tablist" aria-label="Timer mode">
            {MODES.map((m) => (
              <button
                key={m.id}
                role="tab"
                aria-selected={t.mode === m.id}
                onClick={() => setMode(m.id)}
                className={cn("rounded-full px-4 py-2 text-[13px] font-medium transition-colors sm:px-5", t.mode === m.id ? (m.id === "focus" ? "bg-brand text-s0" : "bg-ok text-s0") : "text-ink-3 hover:text-ink-2")}
              >
                {m.label}
              </button>
            ))}
          </div>
          <TimerFace />
          <Controls onZen={() => setZen(true)} zen={false} />
          <DurationPicker />
        </Card>

        <div className="space-y-5">
          <Companion mood={mood} />
          <TaskPicker />
          <Sounds />
        </div>
      </div>

      <div className="mt-5">
        <Today />
      </div>
      <ResultDialog />
    </div>
  );
}
