import { ArrowRight, Coins, Flame, Play, Sparkles, Timer, TrendingUp } from "lucide-react";
import { BarChart, Heatmap } from "../components/charts";
import { Pet3D } from "../components/Pet3D";
import { Bar, Button, Card, Check, PageHeader } from "../components/ui";
import { fmtMin, GREETING, PETS } from "../lib/data";
import { useMissions } from "../lib/missions";
import { Link, navigate } from "../lib/router";
import { useApp, useStats, useTimer } from "../lib/store";
import { cn } from "../utils/cn";

const DAYS = ["M", "T", "W", "T", "F", "S", "S"];

export default function Dashboard() {
  const { state, act } = useApp();
  const stats = useStats();
  const missions = useMissions();
  const { setTask } = useTimer();
  const pet = PETS.find((p) => p.id === state.activePet) ?? PETS[0];
  const name = state.nicknames[pet.id] || pet.name;
  const bond = state.bond[pet.id] ?? 0;
  const remaining = Math.max(0, state.dailyGoal - stats.today);
  const open = state.tasks.filter((t) => !t.done).slice(0, 4);
  const recent = [...state.sessions].sort((a, b) => b.start - a.start).slice(0, 5);
  const todayIdx = (new Date().getDay() + 6) % 7;

  return (
    <div>
      <PageHeader
        eyebrow={new Date().toLocaleDateString("en", { weekday: "long", month: "long", day: "numeric" })}
        title={`${GREETING()}.`}
        desc={remaining === 0 ? "Daily goal reached. Anything more is a bonus." : stats.today === 0 ? `Nothing logged yet today. ${fmtMin(remaining)} to hit your goal.` : `${fmtMin(stats.today)} focused so far — ${fmtMin(remaining)} to go.`}
        actions={
          <Button variant="primary" size="lg" onClick={() => navigate("/focus")}>
            <Play size={16} fill="currentColor" /> Start focus
          </Button>
        }
      />

      {/* headline numbers */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="col-span-2 p-5 lg:col-span-1">
          <div className="flex items-center justify-between text-ink-3">
            <span className="text-[13px] font-medium">Today</span>
            <Timer size={16} />
          </div>
          <p className="num mt-3 font-display text-[30px] font-semibold leading-none tracking-tight">{fmtMin(stats.today)}</p>
          <Bar value={stats.today} max={state.dailyGoal} className="mt-4" tone={stats.today >= state.dailyGoal ? "ok" : "brand"} />
          <p className="mt-2 text-[13px] text-ink-3">goal {fmtMin(state.dailyGoal)}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center justify-between text-ink-3">
            <span className="text-[13px] font-medium">Streak</span>
            <Flame size={16} className="text-warn" />
          </div>
          <p className="num mt-3 font-display text-[30px] font-semibold leading-none tracking-tight">
            {stats.streak}
            <span className="ml-1.5 text-base font-medium text-ink-3">days</span>
          </p>
          <p className="mt-4 text-[13px] text-ink-3">{stats.today > 0 ? "Locked in for today" : "Focus today to keep it"}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center justify-between text-ink-3">
            <span className="text-[13px] font-medium">Level</span>
            <TrendingUp size={16} />
          </div>
          <p className="num mt-3 font-display text-[30px] font-semibold leading-none tracking-tight">{stats.level.level}</p>
          <Bar value={stats.level.pct} className="mt-4" />
          <p className="num mt-2 text-[13px] text-ink-3">{stats.level.span - stats.level.into} XP to next</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center justify-between text-ink-3">
            <span className="text-[13px] font-medium">Coins</span>
            <Coins size={16} className="text-warn" />
          </div>
          <p className="num mt-3 font-display text-[30px] font-semibold leading-none tracking-tight">{state.coins}</p>
          <Link to="/pets" className="mt-4 inline-flex items-center gap-1 text-[13px] text-ink-3 hover:text-ink-2">
            Adopt a companion <ArrowRight size={13} />
          </Link>
        </Card>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <Card className="p-6">
            <div className="mb-6 flex items-baseline justify-between">
              <div>
                <h2 className="font-display text-lg font-semibold">This week</h2>
                <p className="num mt-0.5 text-sm text-ink-3">{fmtMin(stats.weekMinutes)} focused</p>
              </div>
              <Link to="/analytics" className="flex items-center gap-1 text-[13px] text-ink-3 hover:text-ink-2">
                Analytics <ArrowRight size={13} />
              </Link>
            </div>
            <BarChart
              data={stats.week.map((d, i) => ({ label: DAYS[i], value: d.minutes, sub: d.date.toLocaleDateString("en", { weekday: "long" }) }))}
              goal={state.dailyGoal}
              highlight={todayIdx}
            />
          </Card>

          <Card className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold">Up next</h2>
              <Link to="/tasks" className="flex items-center gap-1 text-[13px] text-ink-3 hover:text-ink-2">
                All tasks <ArrowRight size={13} />
              </Link>
            </div>
            {open.length === 0 ? (
              <p className="py-6 text-center text-sm text-ink-3">Nothing open. Enjoy it, or add a task.</p>
            ) : (
              <ul className="divide-y divide-line">
                {open.map((t) => (
                  <li key={t.id} className="flex items-center gap-3.5 py-3">
                    <Check checked={t.done} onChange={() => act.toggleTask(t.id)} label={`Complete ${t.title}`} />
                    <span className="min-w-0 flex-1 truncate text-[15px]">{t.title}</span>
                    <span className={cn("hidden rounded-md px-2 py-0.5 text-xs sm:block", t.priority === "high" ? "bg-bad/10 text-bad" : t.priority === "med" ? "bg-warn/10 text-warn" : "bg-s3 text-ink-3")}>{t.priority}</span>
                    <Button
                      size="sm"
                      onClick={() => {
                        setTask(t.id);
                        navigate("/focus");
                      }}
                    >
                      Focus
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <Card className="p-6">
            <h2 className="mb-5 font-display text-lg font-semibold">Consistency</h2>
            <Heatmap byDay={stats.byDay} weeks={22} />
          </Card>
        </div>

        <div className="space-y-5">
          <Card className="overflow-hidden">
            <Pet3D species={pet.species} mood={stats.today > 0 ? "idle" : "rest"} accent={pet.accent} className="h-[260px] w-full" />
            <div className="border-t border-line p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-display text-lg font-semibold">{name}</p>
                  <p className="text-[13px] text-ink-3">{stats.today > 0 ? "Happy you showed up" : "Napping until you start"}</p>
                </div>
                <span className="rounded-md bg-s3 px-2 py-1 text-xs text-ink-2">Bond {Math.min(20, Math.floor(bond / 100) + 1)}</span>
              </div>
              <Bar value={bond % 100} className="mt-4" />
              <Link to="/pets" className="mt-4 flex items-center justify-between text-[13px] text-ink-3 hover:text-ink-2">
                Visit companion <ArrowRight size={13} />
              </Link>
            </div>
          </Card>

          <Card className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold">Today’s missions</h2>
              <Link to="/missions" className="text-[13px] text-ink-3 hover:text-ink-2">
                View all
              </Link>
            </div>
            <ul className="space-y-4">
              {missions
                .filter((m) => m.scope === "daily")
                .slice(0, 3)
                .map((m) => (
                  <li key={m.id}>
                    <div className="mb-1.5 flex items-center justify-between text-sm">
                      <span className={cn(m.claimed && "text-ink-3 line-through")}>{m.title}</span>
                      <span className="num text-xs text-ink-3">
                        {Math.round(m.progress)}/{m.target}
                      </span>
                    </div>
                    <Bar value={m.progress} max={m.target} tone={m.progress >= m.target ? "ok" : "brand"} />
                  </li>
                ))}
            </ul>
          </Card>

          <Card className="p-6">
            <h2 className="mb-3 font-display text-lg font-semibold">Recent sessions</h2>
            <ul className="divide-y divide-line">
              {recent.map((s) => (
                <li key={s.id} className="flex items-center gap-3 py-2.5 text-sm">
                  <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-s3 text-ink-3">
                    <Sparkles size={14} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate">{s.task ?? "Focus session"}</p>
                    <p className="text-xs text-ink-3">{new Date(s.start).toLocaleDateString("en", { month: "short", day: "numeric" })} · {new Date(s.start).toLocaleTimeString("en", { hour: "numeric", minute: "2-digit" })}</p>
                  </div>
                  <div className="text-right">
                    <p className="num">{fmtMin(s.minutes)}</p>
                    <p className="num text-xs text-ink-3">score {s.score}</p>
                  </div>
                </li>
              ))}
              {recent.length === 0 && <li className="py-4 text-center text-sm text-ink-3">No sessions yet.</li>}
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
