import { useEffect, useState, type ReactNode } from "react";
import { BarChart3, Coins, Flame, Layers, LayoutDashboard, ListChecks, Menu, PawPrint, Repeat, Target, Timer, Trophy, Users, X } from "lucide-react";
import { Link, usePath } from "../lib/router";
import { useApp, useStats, useTimer } from "../lib/store";
import { fmtClock, PETS } from "../lib/data";
import { cn } from "../utils/cn";
import { Bar, Logo } from "./ui";

const NAV = [
  { group: "Focus", items: [
    { to: "/focus", label: "Timer", icon: Timer },
    { to: "/tasks", label: "Tasks & goals", icon: ListChecks },
    { to: "/habits", label: "Habits", icon: Repeat },
  ] },
  { group: "Insight", items: [
    { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { to: "/analytics", label: "Analytics", icon: BarChart3 },
  ] },
  { group: "Play", items: [
    { to: "/pets", label: "Companion", icon: PawPrint },
    { to: "/missions", label: "Missions", icon: Target },
  ] },
  { group: "Together", items: [
    { to: "/rooms", label: "Study rooms", icon: Users },
    { to: "/leaderboard", label: "Leaderboard", icon: Trophy },
    { to: "/flashcards", label: "Flashcards", icon: Layers },
  ] },
];

const MOBILE = [NAV[0].items[0], NAV[1].items[0], NAV[0].items[1], NAV[2].items[0]];

function LiveTimerPill() {
  const { t, remaining } = useTimer();
  const path = usePath();
  if (t.status === "idle" || path === "/focus") return null;
  return (
    <Link to="/focus" className="mx-3 mb-3 flex items-center gap-3 rounded-xl border border-brand/30 bg-brand/10 px-3.5 py-2.5">
      <span className={cn("size-2 rounded-full bg-brand", t.status === "running" && "animate-pulse")} />
      <span className="num font-display text-lg font-semibold">{fmtClock(remaining)}</span>
      <span className="ml-auto text-xs text-ink-2">{t.status === "paused" ? "Paused" : t.mode === "focus" ? "Focusing" : "Break"}</span>
    </Link>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const path = usePath();
  const { state } = useApp();
  const stats = useStats();
  const [more, setMore] = useState(false);
  const pet = PETS.find((p) => p.id === state.activePet) ?? PETS[0];

  useEffect(() => {
    setMore(false);
    window.scrollTo({ top: 0 });
  }, [path]);

  return (
    <div className="min-h-screen lg:pl-[252px]">
      {/* desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[252px] flex-col border-r border-line bg-s0 lg:flex">
        <Link to="/" className="flex items-center gap-2.5 px-6 pb-5 pt-6">
          <Logo />
          <span className="font-display text-[19px] font-bold tracking-tight">FocusArx</span>
        </Link>
        <nav className="flex-1 overflow-y-auto px-3 pb-4">
          {NAV.map((g) => (
            <div key={g.group} className="mb-5">
              <p className="px-3 pb-1.5 text-[11px] font-medium uppercase tracking-[0.14em] text-ink-3">{g.group}</p>
              {g.items.map((i) => {
                const on = path === i.to;
                return (
                  <Link
                    key={i.to}
                    to={i.to}
                    aria-current={on ? "page" : undefined}
                    className={cn("group relative flex items-center gap-3 rounded-lg px-3 py-2 text-[14px] font-medium transition-colors", on ? "bg-white/[0.06] text-ink" : "text-ink-2 hover:bg-white/[0.04] hover:text-ink")}
                  >
                    {on && <span className="absolute -left-3 top-2 h-5 w-[3px] rounded-r bg-brand" />}
                    <i.icon size={17} strokeWidth={1.9} className={on ? "text-brand" : "text-ink-3 group-hover:text-ink-2"} />
                    {i.label}
                  </Link>
                );
              })}
            </div>
          ))}
        </nav>
        <LiveTimerPill />
        <div className="m-3 mt-0 rounded-2xl border border-line bg-s1 p-4">
          <div className="flex items-center gap-3">
            <div className="grid size-9 place-items-center rounded-full font-display text-sm font-bold text-s0" style={{ background: pet.accent }}>
              {pet.name[0]}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">Guest · Level {stats.level.level}</p>
              <p className="num text-xs text-ink-3">
                {stats.level.into} / {stats.level.span} XP
              </p>
            </div>
          </div>
          <Bar value={stats.level.pct} className="mt-3" />
          <div className="mt-3 flex items-center justify-between text-[13px] text-ink-2">
            <span className="flex items-center gap-1.5">
              <Flame size={14} className="text-warn" />
              <span className="num">{stats.streak}</span> day streak
            </span>
            <span className="flex items-center gap-1.5">
              <Coins size={14} className="text-warn" />
              <span className="num">{state.coins}</span>
            </span>
          </div>
        </div>
      </aside>

      {/* mobile top bar */}
      <div className="sticky top-0 z-30 flex items-center justify-between border-b border-line bg-s0/90 px-5 py-3 backdrop-blur lg:hidden">
        <Link to="/" className="flex items-center gap-2">
          <Logo size={24} />
          <span className="font-display text-base font-bold">FocusArx</span>
        </Link>
        <div className="flex items-center gap-4 text-[13px] text-ink-2">
          <span className="flex items-center gap-1">
            <Flame size={14} className="text-warn" />
            <span className="num">{stats.streak}</span>
          </span>
          <span className="flex items-center gap-1">
            <Coins size={14} className="text-warn" />
            <span className="num">{state.coins}</span>
          </span>
          <span className="rounded-md bg-s3 px-1.5 py-0.5 text-xs">Lv {stats.level.level}</span>
        </div>
      </div>

      <main key={path} className="mx-auto w-full max-w-[1180px] animate-rise px-5 pb-28 pt-6 sm:px-8 lg:pb-14 lg:pt-10">
        {children}
      </main>

      {/* mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-s0/95 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden">
        <div className="mx-auto grid max-w-md grid-cols-5">
          {MOBILE.map((i) => {
            const on = path === i.to;
            return (
              <Link key={i.to} to={i.to} className={cn("flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium", on ? "text-brand" : "text-ink-3")}>
                <i.icon size={20} strokeWidth={1.9} />
                {i.label.split(" ")[0]}
              </Link>
            );
          })}
          <button onClick={() => setMore((m) => !m)} className={cn("flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium", more ? "text-brand" : "text-ink-3")}>
            {more ? <X size={20} /> : <Menu size={20} />}
            More
          </button>
        </div>
      </nav>
      {more && (
        <div className="fixed inset-0 z-30 bg-black/60 lg:hidden" onClick={() => setMore(false)}>
          <div className="absolute inset-x-3 bottom-[76px] animate-[pop_0.2s_ease-out_both] rounded-2xl border border-line-2 bg-s2 p-2" onClick={(e) => e.stopPropagation()}>
            {[NAV[0].items[2], NAV[1].items[1], NAV[2].items[1], ...NAV[3].items].map((i) => (
              <Link key={i.to} to={i.to} className="flex items-center gap-3 rounded-xl px-4 py-3 text-[15px] text-ink-2 hover:bg-white/5">
                <i.icon size={18} className="text-ink-3" />
                {i.label}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
