import { Component, useEffect, useRef, useState, type ReactNode, type RefObject } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, Html, Sparkles } from "@react-three/drei";
import * as THREE from "three";
import type { Species } from "../lib/data";

export type Mood = "idle" | "focus" | "rest" | "cheer";

/* ── global cursor so every companion can look at it from anywhere on the page ── */
const cursor = { x: 0, y: 0, active: false };
if (typeof window !== "undefined") {
  window.addEventListener(
    "pointermove",
    (e) => {
      cursor.x = e.clientX;
      cursor.y = e.clientY;
      cursor.active = true;
    },
    { passive: true },
  );
}

/* ── tiny geometry helpers ── */
type V3 = [number, number, number];
function Ball({ p = [0, 0, 0], s = 1, c, r = 0.62, rot, op, gloss }: { p?: V3; s?: number | V3; c: string; r?: number; rot?: V3; op?: number; gloss?: boolean }) {
  const sc: V3 = typeof s === "number" ? [s, s, s] : s;
  return (
    <mesh position={p} scale={sc} rotation={rot}>
      <sphereGeometry args={[1, 40, 28]} />
      {gloss ? (
        <meshPhysicalMaterial color={c} roughness={r} clearcoat={1} clearcoatRoughness={0.12} transparent={op !== undefined} opacity={op ?? 1} />
      ) : (
        <meshStandardMaterial color={c} roughness={r} transparent={op !== undefined} opacity={op ?? 1} />
      )}
    </mesh>
  );
}

function Cone({ p = [0, 0, 0], rot, w, h, c, r = 0.62 }: { p?: V3; rot?: V3; w: number; h: number; c: string; r?: number }) {
  return (
    <mesh position={p} rotation={rot}>
      <coneGeometry args={[w, h, 28]} />
      <meshStandardMaterial color={c} roughness={r} />
    </mesh>
  );
}

type G = RefObject<THREE.Group | null>;
function Eye({ p, size = 0.1, color = "#1b1420", g }: { p: V3; size?: number; color?: string; g?: G }) {
  return (
    <group position={p} ref={g}>
      <Ball s={[size, size * 1.15, size * 0.7]} c={color} r={0.18} />
      <Ball p={[size * 0.34, size * 0.46, size * 0.5]} s={size * 0.3} c="#ffffff" r={0.1} />
    </group>
  );
}

function Headphones({ r, y = 0, z = 0, sy = 1, accent = "#a3a6ff", on }: { r: number; y?: number; z?: number; sy?: number; accent?: string; on: boolean }) {
  return (
    <group position={[0, y, z]} scale={[1, sy, 1]} visible={on}>
      <mesh>
        <torusGeometry args={[r, 0.055, 14, 56, Math.PI]} />
        <meshStandardMaterial color="#22232a" roughness={0.45} metalness={0.2} />
      </mesh>
      {[-1, 1].map((side) => (
        <group key={side} position={[side * (r - 0.02), 0, 0]} rotation={[0, 0, Math.PI / 2]}>
          <mesh>
            <cylinderGeometry args={[0.2, 0.2, 0.15, 32]} />
            <meshStandardMaterial color="#2c2d36" roughness={0.4} metalness={0.2} />
          </mesh>
          <mesh position={[0, -side * 0.082, 0]}>
            <cylinderGeometry args={[0.13, 0.13, 0.02, 32]} />
            <meshStandardMaterial color={accent} roughness={0.35} emissive={accent} emissiveIntensity={0.25} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

type Rig = { head: G; body: G; tail: G; armL: G; armR: G; eyeL: G; eyeR: G; earL: G; earR: G };

/* ───────────── species ───────────── */
function Fox({ rig, hp }: { rig: Rig; hp: boolean }) {
  const O = "#f08a3c";
  const CR = "#fff1e0";
  const D = "#48291f";
  return (
    <>
      <group ref={rig.body} position={[0, -0.42, 0]}>
        <Ball s={[0.66, 0.64, 0.58]} c={O} />
        <Ball p={[0, -0.06, 0.34]} s={[0.46, 0.5, 0.3]} c={CR} />
        {[-1, 1].map((s) => (
          <Ball key={s} p={[s * 0.28, -0.5, 0.3]} s={[0.2, 0.14, 0.28]} c={D} />
        ))}
        <group ref={rig.armL} position={[-0.58, 0.14, 0.2]}>
          <Ball p={[0, -0.25, 0]} s={[0.14, 0.3, 0.15]} c={O} />
          <Ball p={[0, -0.5, 0.02]} s={[0.13, 0.1, 0.14]} c={D} />
        </group>
        <group ref={rig.armR} position={[0.58, 0.14, 0.2]}>
          <Ball p={[0, -0.25, 0]} s={[0.14, 0.3, 0.15]} c={O} />
          <Ball p={[0, -0.5, 0.02]} s={[0.13, 0.1, 0.14]} c={D} />
        </group>
        <group ref={rig.tail} position={[0.12, -0.32, -0.46]}>
          <group rotation={[0.55, 1.05, 0]}>
            <Ball p={[0, 0, -0.45]} s={[0.27, 0.27, 0.62]} c={O} />
            <Ball p={[0, 0, -0.98]} s={[0.255, 0.255, 0.3]} c={CR} />
          </group>
        </group>
      </group>
      <group ref={rig.head} position={[0, 0.52, 0.08]}>
        <Ball s={[0.86, 0.7, 0.74]} c={O} />
        {[-1, 1].map((s) => (
          <Ball key={s} p={[s * 0.52, -0.2, 0.22]} s={[0.36, 0.28, 0.38]} c={CR} rot={[0, 0, s * -0.3]} />
        ))}
        <Ball p={[0, -0.14, 0.6]} s={[0.3, 0.22, 0.28]} c={CR} />
        <Ball p={[0, -0.05, 0.86]} s={[0.1, 0.075, 0.08]} c="#2a1a1a" r={0.3} />
        <Ball p={[-0.56, -0.08, 0.58]} s={[0.1, 0.06, 0.04]} c="#ff9aa8" op={0.55} />
        <Ball p={[0.56, -0.08, 0.58]} s={[0.1, 0.06, 0.04]} c="#ff9aa8" op={0.55} />
        <Eye g={rig.eyeL} p={[-0.31, 0.1, 0.67]} size={0.105} />
        <Eye g={rig.eyeR} p={[0.31, 0.1, 0.67]} size={0.105} />
        <group ref={rig.earL} position={[-0.52, 0.56, -0.02]}>
          <Cone p={[-0.06, 0.3, 0]} rot={[0, 0, 0.28]} w={0.3} h={0.7} c={O} />
          <Cone p={[-0.05, 0.24, 0.07]} rot={[0, 0, 0.28]} w={0.17} h={0.5} c="#ffd0ab" />
        </group>
        <group ref={rig.earR} position={[0.52, 0.56, -0.02]}>
          <Cone p={[0.06, 0.3, 0]} rot={[0, 0, -0.28]} w={0.3} h={0.7} c={O} />
          <Cone p={[0.05, 0.24, 0.07]} rot={[0, 0, -0.28]} w={0.17} h={0.5} c="#ffd0ab" />
        </group>
        <Headphones r={0.93} on={hp} />
      </group>
    </>
  );
}

function Owl({ rig, hp }: { rig: Rig; hp: boolean }) {
  const T = "#a77b52";
  const W = "#8c6340";
  const F = "#f6e8cf";
  const OR = "#f2a03a";
  return (
    <>
      <group ref={rig.body} position={[0, -0.4, 0]}>
        <Ball s={[0.8, 0.72, 0.7]} c={T} />
        <Ball p={[0, -0.05, 0.38]} s={[0.5, 0.54, 0.3]} c={F} />
        {[[0, 0.06], [-0.17, -0.06], [0.17, -0.06], [-0.08, -0.2], [0.08, -0.2], [-0.24, -0.22], [0.24, -0.22]].map(([x, y], i) => (
          <Ball key={i} p={[x, y, 0.66]} s={[0.07, 0.04, 0.03]} c="#d9bd91" rot={[0, 0, x * 2]} />
        ))}
        {[-1, 1].map((s) => (
          <Ball key={s} p={[s * 0.2, -0.68, 0.42]} s={[0.17, 0.08, 0.22]} c={OR} />
        ))}
        <group ref={rig.armL} position={[-0.76, 0.12, 0]}>
          <Ball p={[-0.03, -0.28, 0]} s={[0.14, 0.46, 0.38]} c={W} />
        </group>
        <group ref={rig.armR} position={[0.76, 0.12, 0]}>
          <Ball p={[0.03, -0.28, 0]} s={[0.14, 0.46, 0.38]} c={W} />
        </group>
        <group ref={rig.tail} position={[0, -0.55, -0.62]}>
          <Ball p={[0, 0, -0.12]} s={[0.3, 0.12, 0.34]} c={W} />
        </group>
      </group>
      <group ref={rig.head} position={[0, 0.5, 0.05]}>
        <Ball s={[0.88, 0.72, 0.72]} c={T} />
        {[-1, 1].map((s) => (
          <Ball key={s} p={[s * 0.33, 0.02, 0.52]} s={[0.37, 0.37, 0.2]} c={F} />
        ))}
        {[-1, 1].map((s) => (
          <Ball key={s} p={[s * 0.33, 0.04, 0.67]} s={[0.25, 0.25, 0.09]} c="#f2b84b" r={0.35} />
        ))}
        <Eye g={rig.eyeL} p={[-0.33, 0.04, 0.72]} size={0.13} />
        <Eye g={rig.eyeR} p={[0.33, 0.04, 0.72]} size={0.13} />
        <Cone p={[0, -0.16, 0.8]} rot={[Math.PI / 2, 0, 0]} w={0.1} h={0.26} c={OR} r={0.4} />
        <group ref={rig.earL} position={[-0.5, 0.5, 0]}>
          <Cone p={[-0.04, 0.17, 0]} rot={[0, 0, 0.5]} w={0.17} h={0.4} c={W} />
        </group>
        <group ref={rig.earR} position={[0.5, 0.5, 0]}>
          <Cone p={[0.04, 0.17, 0]} rot={[0, 0, -0.5]} w={0.17} h={0.4} c={W} />
        </group>
        <Headphones r={0.95} on={hp} accent="#f2b84b" />
      </group>
    </>
  );
}

function Panda({ rig, hp }: { rig: Rig; hp: boolean }) {
  const K = "#1c1c22";
  const W = "#fbfbfa";
  return (
    <>
      <group ref={rig.body} position={[0, -0.4, 0]}>
        <Ball s={[0.74, 0.7, 0.64]} c={W} />
        {[-1, 1].map((s) => (
          <Ball key={s} p={[s * 0.4, -0.5, 0.2]} s={[0.26, 0.22, 0.3]} c={K} />
        ))}
        <group ref={rig.armL} position={[-0.68, 0.16, 0.14]}>
          <Ball p={[-0.02, -0.25, 0]} s={[0.2, 0.38, 0.2]} c={K} />
        </group>
        <group ref={rig.armR} position={[0.68, 0.16, 0.14]}>
          <Ball p={[0.02, -0.25, 0]} s={[0.2, 0.38, 0.2]} c={K} />
        </group>
        <group ref={rig.tail} position={[0, -0.3, -0.58]}>
          <Ball p={[0, 0, -0.06]} s={0.2} c={W} />
        </group>
      </group>
      <group ref={rig.head} position={[0, 0.5, 0.06]}>
        <Ball s={[0.9, 0.78, 0.78]} c={W} />
        <group ref={rig.earL} position={[-0.64, 0.6, -0.05]}>
          <Ball s={[0.27, 0.27, 0.17]} c={K} />
        </group>
        <group ref={rig.earR} position={[0.64, 0.6, -0.05]}>
          <Ball s={[0.27, 0.27, 0.17]} c={K} />
        </group>
        {[-1, 1].map((s) => (
          <Ball key={s} p={[s * 0.34, 0.06, 0.64]} s={[0.2, 0.26, 0.13]} c={K} rot={[0, 0, s * 0.45]} />
        ))}
        {[-1, 1].map((s) => (
          <Ball key={s} p={[s * 0.34, 0.08, 0.75]} s={[0.1, 0.115, 0.06]} c="#ffffff" r={0.3} />
        ))}
        <Eye g={rig.eyeL} p={[-0.34, 0.08, 0.79]} size={0.062} color="#0a0a0c" />
        <Eye g={rig.eyeR} p={[0.34, 0.08, 0.79]} size={0.062} color="#0a0a0c" />
        <Ball p={[0, -0.2, 0.66]} s={[0.26, 0.2, 0.2]} c="#f0ebe4" />
        <Ball p={[0, -0.12, 0.84]} s={[0.1, 0.07, 0.06]} c={K} r={0.3} />
        <Ball p={[-0.58, -0.17, 0.58]} s={[0.1, 0.06, 0.04]} c="#ffb0c0" op={0.6} />
        <Ball p={[0.58, -0.17, 0.58]} s={[0.1, 0.06, 0.04]} c="#ffb0c0" op={0.6} />
        <Headphones r={0.98} z={-0.26} on={hp} accent="#8fd0ff" />
      </group>
    </>
  );
}

function Slime({ rig, hp }: { rig: Rig; hp: boolean }) {
  return (
    <group ref={rig.head} position={[0, -0.15, 0]}>
      <group ref={rig.body}>
        <Ball s={[1.05, 0.88, 0.95]} c="#7ee6c4" r={0.14} gloss op={0.94} />
        <Ball p={[0.25, -0.3, -0.1]} s={0.24} c="#d6fff0" op={0.55} r={0.3} />
        <Ball p={[-0.42, 0.34, 0.6]} s={[0.17, 0.09, 0.06]} c="#ffffff" op={0.7} rot={[0, 0, 0.6]} r={0.2} />
      </group>
      <Eye g={rig.eyeL} p={[-0.3, 0.1, 0.86]} size={0.12} />
      <Eye g={rig.eyeR} p={[0.3, 0.1, 0.86]} size={0.12} />
      <mesh position={[0, -0.14, 0.94]} rotation={[0, 0, Math.PI]}>
        <torusGeometry args={[0.09, 0.022, 8, 24, Math.PI]} />
        <meshStandardMaterial color="#1b1420" roughness={0.4} />
      </mesh>
      <Ball p={[-0.55, -0.12, 0.8]} s={[0.11, 0.065, 0.04]} c="#ff9ab0" op={0.55} />
      <Ball p={[0.55, -0.12, 0.8]} s={[0.11, 0.065, 0.04]} c="#ff9ab0" op={0.55} />
      <group position={[0.3, 0.78, 0]} rotation={[0, 0, -0.3]} ref={rig.earL}>
        <mesh position={[0, 0.12, 0]}>
          <cylinderGeometry args={[0.022, 0.035, 0.3, 10]} />
          <meshStandardMaterial color="#38a67b" roughness={0.6} />
        </mesh>
        <Ball p={[-0.13, 0.3, 0]} s={[0.15, 0.07, 0.06]} rot={[0, 0, 0.4]} c="#52c996" />
        <Ball p={[0.13, 0.3, 0]} s={[0.15, 0.07, 0.06]} rot={[0, 0, -0.4]} c="#52c996" />
      </group>
      <Headphones r={1.1} y={-0.02} sy={0.78} on={hp} accent="#c9fbe9" />
    </group>
  );
}

/* ───────────── rig + behaviour ───────────── */
const damp = THREE.MathUtils.damp;
const clamp = THREE.MathUtils.clamp;

function PetModel({ species, mood, onPet }: { species: Species; mood: Mood; onPet: () => void }) {
  const root = useRef<THREE.Group>(null);
  const rig: Rig = {
    head: useRef<THREE.Group>(null),
    body: useRef<THREE.Group>(null),
    tail: useRef<THREE.Group>(null),
    armL: useRef<THREE.Group>(null),
    armR: useRef<THREE.Group>(null),
    eyeL: useRef<THREE.Group>(null),
    eyeR: useRef<THREE.Group>(null),
    earL: useRef<THREE.Group>(null),
    earR: useRef<THREE.Group>(null),
  };
  const hop = useRef(0);
  const lookAmp = species === "slime" ? 0.35 : 1;
  const squish = species === "slime" ? 3 : 1;

  useFrame((state, dt) => {
    const t = state.clock.elapsedTime;
    const g = root.current;
    if (!g) return;
    dt = Math.min(dt, 0.05);

    // hop / cheer
    let y = 0;
    if (hop.current > 0) {
      hop.current = Math.max(0, hop.current - dt * 1.7);
      y = Math.sin((1 - hop.current) * Math.PI) * 0.5;
    }
    if (mood === "cheer") y = Math.max(y, Math.abs(Math.sin(t * 5.5)) * 0.42);
    g.position.y = damp(g.position.y, y, 22, dt);
    g.rotation.y = damp(g.rotation.y, mood === "cheer" ? Math.sin(t * 2.5) * 0.25 : 0, 5, dt);

    // breathing
    const breath = Math.sin(t * (mood === "rest" ? 1.2 : mood === "focus" ? 1.8 : 2.2));
    const body = rig.body.current;
    if (body) {
      body.scale.y = 1 + breath * 0.018 * squish;
      body.scale.x = body.scale.z = 1 - breath * 0.009 * squish;
    }

    // look at cursor (or nod off when resting)
    const head = rig.head.current;
    if (head) {
      const rect = state.gl.domElement.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height * 0.35;
      const nx = cursor.active ? clamp((cursor.x - cx) / 420, -1, 1) : 0;
      const ny = cursor.active ? clamp((cursor.y - cy) / 420, -1, 1) : 0;
      const ty = mood === "rest" ? 0 : nx * (mood === "focus" ? 0.18 : 0.6) * lookAmp;
      const tx = mood === "rest" ? 0.34 + Math.sin(t * 1.2) * 0.04 : mood === "focus" ? 0.2 : ny * 0.32 * lookAmp;
      const tz = mood === "rest" ? Math.sin(t * 0.8) * 0.06 : mood === "idle" ? Math.sin(t * 0.7) * 0.03 : 0;
      head.rotation.y = damp(head.rotation.y, ty, 6, dt);
      head.rotation.x = damp(head.rotation.x, tx, 5, dt);
      head.rotation.z = damp(head.rotation.z, tz, 4, dt);
    }

    // eyes
    const blink = t % 3.7 < 0.12 ? 0.08 : 1;
    const eyeTarget = mood === "rest" ? 0.07 : mood === "focus" ? Math.min(blink, 0.82) : mood === "cheer" ? 0.9 : blink;
    for (const e of [rig.eyeL.current, rig.eyeR.current]) if (e) e.scale.y = damp(e.scale.y, eyeTarget, 34, dt);

    // arms
    const aL = rig.armL.current;
    const aR = rig.armR.current;
    if (aL && aR) {
      const sway = mood === "cheer" ? 0 : Math.sin(t * 2) * 0.03;
      const lz = mood === "cheer" ? -2.55 + Math.sin(t * 11) * 0.28 : mood === "focus" ? -0.08 + Math.sin(t * 7) * 0.035 : -0.12 + sway;
      const rz = mood === "cheer" ? 2.55 - Math.sin(t * 11 + 1) * 0.28 : mood === "focus" ? 0.08 - Math.sin(t * 7.5) * 0.035 : 0.12 - sway;
      aL.rotation.z = damp(aL.rotation.z, lz, 10, dt);
      aR.rotation.z = damp(aR.rotation.z, rz, 10, dt);
    }

    // tail
    const tail = rig.tail.current;
    if (tail) {
      const sp = mood === "cheer" ? 13 : mood === "rest" ? 0.8 : mood === "focus" ? 1.6 : 2.4;
      const amp = mood === "cheer" ? 0.55 : mood === "rest" ? 0.08 : mood === "focus" ? 0.14 : 0.3;
      tail.rotation.y = Math.sin(t * sp) * amp;
    }

    // ears
    const twitch = t % 5.2 < 0.28 ? Math.sin((t % 5.2) * 28) * 0.22 : 0;
    const eL = rig.earL.current;
    const eR = rig.earR.current;
    if (species !== "slime") {
      if (eL) eL.rotation.z = twitch + (mood === "rest" ? 0.12 : 0);
      if (eR) eR.rotation.z = -twitch * 0.6 - (mood === "rest" ? 0.12 : 0);
    } else if (eL) {
      eL.rotation.z = -0.3 + Math.sin(t * 2) * 0.1;
    }
  });

  const Model = species === "fox" ? Fox : species === "owl" ? Owl : species === "panda" ? Panda : Slime;
  const hp = mood === "focus";
  return (
    <group
      ref={root}
      onClick={(e) => {
        e.stopPropagation();
        hop.current = 1;
        onPet();
      }}
      onPointerOver={() => (document.body.style.cursor = "pointer")}
      onPointerOut={() => (document.body.style.cursor = "")}
    >
      <Model rig={rig} hp={hp} />
    </group>
  );
}

function Scene({ species, mood, accent }: { species: Species; mood: Mood; accent: string }) {
  const [hearts, setHearts] = useState<number[]>([]);
  const pet = () => {
    const id = Date.now() + Math.random();
    setHearts((h) => [...h.slice(-6), id]);
    window.setTimeout(() => setHearts((h) => h.filter((x) => x !== id)), 1400);
  };
  return (
    <>
      <ambientLight intensity={0.9} />
      <hemisphereLight args={["#ffffff", "#4a4a5a", 0.7]} />
      <directionalLight position={[3, 5, 4]} intensity={2.4} />
      <directionalLight position={[-4, 2, -3]} intensity={1.1} color="#a3a6ff" />
      <pointLight position={[0, 0.5, 3]} intensity={6} color="#fff4e6" distance={9} />

      {/* stage */}
      <mesh rotation-x={-Math.PI / 2} position={[0, -1.075, 0]}>
        <circleGeometry args={[1.6, 72]} />
        <meshStandardMaterial color="#1a1b21" roughness={0.9} />
      </mesh>
      <mesh rotation-x={-Math.PI / 2} position={[0, -1.07, 0]}>
        <ringGeometry args={[1.52, 1.6, 72]} />
        <meshBasicMaterial color={accent} transparent opacity={0.4} />
      </mesh>
      <ContactShadows position={[0, -1.06, 0]} opacity={0.65} scale={5} blur={2.4} far={2.4} />

      <group position={[0, -0.02, 0]}>
        <PetModel species={species} mood={mood} onPet={pet} />
        {mood === "cheer" && <Sparkles count={36} scale={[3.2, 3, 3.2]} size={5} speed={0.7} color="#ffd36b" position={[0, 0.3, 0]} />}
        {mood === "rest" && (
          <Html position={[0.85, 1.35, 0]} center style={{ pointerEvents: "none" }}>
            <div className="zzz">
              <span style={{ fontSize: 20 }}>z</span>
              <span style={{ fontSize: 20 }}>z</span>
              <span style={{ fontSize: 20 }}>z</span>
            </div>
          </Html>
        )}
        {hearts.map((id, i) => (
          <Html key={id} position={[0, 1.2, 0.4]} center style={{ pointerEvents: "none" }} zIndexRange={[20, 0]}>
            <div className="heart" style={{ ["--dx" as string]: `${(i % 2 ? 1 : -1) * (8 + (i * 13) % 34)}px` }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 21s-7.5-4.6-9.6-9.2C.9 8.4 2.7 5 6 5c2 0 3.3 1 4 2.3h4C14.7 6 16 5 18 5c3.3 0 5.1 3.4 3.6 6.8C19.5 16.400 12 21 12 21z" />
              </svg>
            </div>
          </Html>
        ))}
      </group>
    </>
  );
}

/* ───────────── shell with graceful fallback ───────────── */
function hasWebGL() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch {
    return false;
  }
}

class Boundary extends Component<{ fallback: ReactNode; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

function Fallback({ species, accent }: { species: Species; accent: string }) {
  return (
    <div className="grid h-full w-full place-items-center">
      <div className="grid size-28 place-items-center rounded-full border border-line-2 font-display text-3xl font-extrabold capitalize" style={{ color: accent, background: `${accent}18` }}>
        {species[0]}
      </div>
    </div>
  );
}

export function Pet3D({ species, mood = "idle", accent = "#a3a6ff", className = "" }: { species: Species; mood?: Mood; accent?: string; className?: string }) {
  const [ok] = useState(hasWebGL);
  const [visible, setVisible] = useState(true);
  const wrap = useRef<HTMLDivElement>(null);

  // pause rendering when scrolled off-screen
  useEffect(() => {
    const el = wrap.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const io = new IntersectionObserver(([e]) => setVisible(e.isIntersecting), { rootMargin: "100px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div ref={wrap} className={className} role="img" aria-label={`3D ${species} companion, ${mood}`}>
      {ok ? (
        <Boundary fallback={<Fallback species={species} accent={accent} />}>
          <Canvas
            dpr={[1, 2]}
            frameloop={visible ? "always" : "never"}
            camera={{ position: [0, 0.95, 6.5], fov: 30 }}
            gl={{ antialias: true, alpha: true }}
            style={{ touchAction: "pan-y" }}
          >
            <Scene species={species} mood={mood} accent={accent} />
          </Canvas>
        </Boundary>
      ) : (
        <Fallback species={species} accent={accent} />
      )}
    </div>
  );
}
