import { useEffect, type ButtonHTMLAttributes, type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../utils/cn";

export function Card({ className, ...p }: HTMLAttributes<HTMLDivElement>) {
  return <div className={cn("rounded-2xl border border-line bg-s1", className)} {...p} />;
}

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "soft" | "ghost" | "danger"; size?: "sm" | "md" | "lg" | "icon" };
export function Button({ variant = "soft", size = "md", className, ...p }: BtnProps) {
  return (
    <button
      className={cn(
        "inline-flex select-none items-center justify-center gap-2 whitespace-nowrap font-medium transition-[background-color,transform,color,border-color] duration-150 active:scale-[0.97] disabled:opacity-40 disabled:active:scale-100",
        size === "sm" && "h-8 rounded-lg px-3 text-[13px]",
        size === "md" && "h-10 rounded-xl px-4 text-sm",
        size === "lg" && "h-12 rounded-2xl px-6 text-[15px]",
        size === "icon" && "size-10 rounded-xl",
        variant === "primary" && "bg-brand text-s0 hover:bg-[#b6b8ff]",
        variant === "soft" && "border border-line-2 bg-s2 text-ink hover:bg-s3",
        variant === "ghost" && "text-ink-2 hover:bg-white/5 hover:text-ink",
        variant === "danger" && "border border-bad/30 bg-bad/10 text-bad hover:bg-bad/20",
        className,
      )}
      {...p}
    />
  );
}

export function PageHeader({ eyebrow, title, desc, actions }: { eyebrow?: string; title: string; desc?: string; actions?: ReactNode }) {
  return (
    <header className="mb-7 flex flex-wrap items-end justify-between gap-4">
      <div className="max-w-2xl">
        {eyebrow && <p className="mb-2 text-xs font-medium uppercase tracking-[0.14em] text-ink-3">{eyebrow}</p>}
        <h1 className="font-display text-[28px] font-semibold leading-tight tracking-tight sm:text-[34px]">{title}</h1>
        {desc && <p className="mt-2 text-[15px] leading-relaxed text-ink-2">{desc}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </header>
  );
}

export function Bar({ value, max = 100, className, tone = "brand" }: { value: number; max?: number; className?: string; tone?: "brand" | "ok" | "warn" }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className={cn("h-1.5 w-full overflow-hidden rounded-full bg-s4", className)} role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100}>
      <div
        className={cn("h-full rounded-full transition-[width] duration-500", tone === "brand" && "bg-brand", tone === "ok" && "bg-ok", tone === "warn" && "bg-warn")}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

export function Segmented<T extends string | number>({ options, value, onChange, className }: { options: { id: T; label: string }[]; value: T; onChange: (v: T) => void; className?: string }) {
  return (
    <div className={cn("inline-flex rounded-xl border border-line bg-s1 p-1", className)} role="tablist">
      {options.map((o) => (
        <button
          key={String(o.id)}
          role="tab"
          aria-selected={o.id === value}
          onClick={() => onChange(o.id)}
          className={cn("rounded-lg px-3.5 py-1.5 text-[13px] font-medium transition-colors", o.id === value ? "bg-s3 text-ink" : "text-ink-3 hover:text-ink-2")}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Stat({ label, value, sub, icon }: { label: string; value: ReactNode; sub?: ReactNode; icon?: ReactNode }) {
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between text-ink-3">
        <span className="text-[13px] font-medium">{label}</span>
        {icon}
      </div>
      <div className="num mt-3 font-display text-[30px] font-semibold leading-none tracking-tight">{value}</div>
      {sub && <div className="mt-2 text-[13px] text-ink-3">{sub}</div>}
    </Card>
  );
}

export function Modal({ open, onClose, children, className }: { open: boolean; onClose: () => void; children: ReactNode; className?: string }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[60] grid place-items-center p-4" role="dialog" aria-modal="true">
      <div className="absolute inset-0 animate-fade bg-black/70 backdrop-blur-[2px]" onClick={onClose} />
      <div className={cn("relative w-full max-w-md animate-[pop_0.25s_ease-out_both] rounded-3xl border border-line-2 bg-s2 p-6 shadow-2xl shadow-black/60", className)}>{children}</div>
    </div>
  );
}

export function Empty({ title, desc, action }: { title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="rounded-2xl border border-dashed border-line-2 px-6 py-12 text-center">
      <p className="font-display text-lg font-semibold">{title}</p>
      {desc && <p className="mx-auto mt-1.5 max-w-sm text-sm text-ink-3">{desc}</p>}
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}

export function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
      <circle cx="16" cy="16" r="14" stroke="#a3a6ff" strokeWidth="2" />
      <circle cx="16" cy="16" r="8" stroke="#a3a6ff" strokeOpacity=".45" strokeWidth="2" strokeDasharray="3 3.2" />
      <circle cx="16" cy="16" r="3.6" fill="#a3a6ff" />
      <circle cx="17.4" cy="14.6" r="1" fill="#0b0b0c" />
    </svg>
  );
}

export function Check({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return (
    <button
      role="checkbox"
      aria-checked={checked}
      aria-label={label}
      onClick={onChange}
      className={cn("grid size-[22px] shrink-0 place-items-center rounded-full border transition-colors", checked ? "border-brand bg-brand text-s0" : "border-line-2 hover:border-ink-3")}
    >
      {checked && (
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M2.5 6.4 5 8.9l4.5-5.4" />
        </svg>
      )}
    </button>
  );
}
