import { useMemo, type ReactNode } from "react";
import { addDays, dayKey, fmtMin, mondayOf } from "../lib/data";
import { cn } from "../utils/cn";

export function BarChart({ data, height = 168, goal, highlight }: { data: { label: string; value: number; sub?: string }[]; height?: number; goal?: number; highlight?: number }) {
  const max = Math.max(goal ?? 0, ...data.map((d) => d.value), 30);
  const top = Math.ceil(max / 30) * 30;
  const dense = data.length > 14;
  return (
    <div className="relative" style={{ height: height + 28 }}>
      {[1, 0.5, 0].map((f) => (
        <div key={f} className="absolute inset-x-0 flex items-center gap-2" style={{ bottom: 28 + f * height - 0.5 }}>
          <span className="num w-9 shrink-0 text-[11px] text-ink-3">{f ? fmtMin(top * f) : "0"}</span>
          <div className={cn("h-px flex-1", f ? "border-t border-dashed border-line" : "bg-line-2")} />
        </div>
      ))}
      {goal !== undefined && (
        <div className="absolute left-11 right-0 border-t border-dashed border-brand/50" style={{ bottom: 28 + (goal / top) * height }}>
          <span className="absolute -top-5 right-0 text-[11px] text-brand">goal {fmtMin(goal)}</span>
        </div>
      )}
      <div className="absolute inset-y-0 left-11 right-0 flex items-end" style={{ gap: dense ? 3 : 10 }}>
        {data.map((d, i) => (
          <div key={i} className="group relative flex h-full flex-1 flex-col items-center justify-end">
            <div className="pointer-events-none absolute z-10 -translate-y-1 whitespace-nowrap rounded-lg border border-line-2 bg-s3 px-2.5 py-1.5 text-xs opacity-0 shadow-lg transition-opacity group-hover:opacity-100" style={{ bottom: 28 + (d.value / top) * height + 6 }}>
              <span className="font-medium">{fmtMin(d.value)}</span>
              <span className="ml-1.5 text-ink-3">{d.sub ?? d.label}</span>
            </div>
            <div
              className={cn("w-full max-w-[44px] rounded-t-md transition-[height,background-color] duration-500", i === highlight ? "bg-brand" : "bg-brand/40 group-hover:bg-brand/70")}
              style={{ height: Math.max(d.value ? 3 : 0, (d.value / top) * height) }}
            />
            <span className={cn("absolute bottom-0 text-[11px]", i === highlight ? "text-ink" : "text-ink-3", dense && i % 5 !== 0 && "hidden")}>{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Heatmap({ byDay, weeks = 20 }: { byDay: Record<string, number>; weeks?: number }) {
  const { cells, months } = useMemo(() => {
    const start = addDays(mondayOf(new Date()), -(weeks - 1) * 7);
    const cells: { key: string; col: number; row: number; v: number; future: boolean; date: Date }[] = [];
    const months: { col: number; label: string }[] = [];
    let lastM = -1;
    for (let w = 0; w < weeks; w++) {
      for (let r = 0; r < 7; r++) {
        const date = addDays(start, w * 7 + r);
        const key = dayKey(date);
        cells.push({ key, col: w + 1, row: r + 1, v: byDay[key] ?? 0, future: date.getTime() > Date.now(), date });
      }
      const m = addDays(start, w * 7).getMonth();
      if (m !== lastM) {
        months.push({ col: w + 1, label: addDays(start, w * 7).toLocaleString("en", { month: "short" }) });
        lastM = m;
      }
    }
    return { cells, months };
  }, [byDay, weeks]);

  const tone = (v: number) => (v === 0 ? "bg-s3" : v < 30 ? "bg-brand/25" : v < 60 ? "bg-brand/45" : v < 120 ? "bg-brand/70" : "bg-brand");
  return (
    <div>
      <div className="grid gap-[3px] pl-0" style={{ gridTemplateColumns: `repeat(${weeks}, minmax(0, 1fr))` }}>
        {months.map((m) => (
          <span key={m.col} className="text-[11px] text-ink-3" style={{ gridColumn: m.col, gridRow: 1 }}>
            {m.label}
          </span>
        ))}
        {cells.map((c) => (
          <div
            key={c.key}
            title={`${c.date.toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" })} — ${c.v ? fmtMin(c.v) : "no focus"}`}
            className={cn("aspect-square rounded-[3px]", c.future ? "bg-transparent" : tone(c.v))}
            style={{ gridColumn: c.col, gridRow: c.row + 1 }}
          />
        ))}
      </div>
      <div className="mt-3 flex items-center justify-end gap-1.5 text-[11px] text-ink-3">
        less
        {["bg-s3", "bg-brand/25", "bg-brand/45", "bg-brand/70", "bg-brand"].map((c) => (
          <span key={c} className={cn("size-3 rounded-[3px]", c)} />
        ))}
        more
      </div>
    </div>
  );
}

export function Ring({ value, size = 96, stroke = 8, children, tone = "#a3a6ff" }: { value: number; size?: number; stroke?: number; children?: ReactNode; tone?: string }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#26272b" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={tone} strokeWidth={stroke} strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - Math.min(1, Math.max(0, value)))} style={{ transition: "stroke-dashoffset .6s ease" }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}
