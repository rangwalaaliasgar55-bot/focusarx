import type { ComponentType } from "react";
import { Shell } from "./components/Shell";
import { Link, usePath } from "./lib/router";
import { AppProvider, TimerProvider } from "./lib/store";
import Analytics from "./pages/Analytics";
import Dashboard from "./pages/Dashboard";
import Flashcards from "./pages/Flashcards";
import Focus from "./pages/Focus";
import Habits from "./pages/Habits";
import Landing from "./pages/Landing";
import Leaderboard from "./pages/Leaderboard";
import Missions from "./pages/Missions";
import Pets from "./pages/Pets";
import Rooms from "./pages/Rooms";
import Tasks from "./pages/Tasks";

const ROUTES: Record<string, ComponentType> = {
  "/focus": Focus,
  "/dashboard": Dashboard,
  "/tasks": Tasks,
  "/habits": Habits,
  "/analytics": Analytics,
  "/pets": Pets,
  "/missions": Missions,
  "/rooms": Rooms,
  "/leaderboard": Leaderboard,
  "/flashcards": Flashcards,
};

function NotFound() {
  return (
    <div className="grid min-h-[60vh] place-items-center text-center">
      <div>
        <p className="num font-display text-7xl font-semibold tracking-tight text-ink-3">404</p>
        <p className="mt-4 text-ink-2">That page doesn’t exist.</p>
        <Link to="/focus" className="mt-6 inline-flex h-11 items-center rounded-xl bg-brand px-5 text-sm font-semibold text-s0">
          Back to the timer
        </Link>
      </div>
    </div>
  );
}

function Router() {
  const path = usePath();
  if (path === "/") return <Landing />;
  const Page = ROUTES[path];
  return <Shell>{Page ? <Page /> : <NotFound />}</Shell>;
}

export default function App() {
  return (
    <AppProvider>
      <TimerProvider>
        <Router />
      </TimerProvider>
    </AppProvider>
  );
}
