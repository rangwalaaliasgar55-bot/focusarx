import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import manropeUrl from "@fontsource-variable/manrope/files/manrope-latin-wght-normal.woff2?url";
import geistUrl from "@fontsource-variable/geist/files/geist-latin-wght-normal.woff2?url";
import "./index.css";
import App from "./App";

const faces = document.createElement("style");
faces.textContent = `
@font-face{font-family:'Manrope Variable';font-style:normal;font-display:swap;font-weight:200 800;src:url(${manropeUrl}) format('woff2-variations');}
@font-face{font-family:'Geist Variable';font-style:normal;font-display:swap;font-weight:100 900;src:url(${geistUrl}) format('woff2-variations');}
`;
document.head.appendChild(faces);

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
