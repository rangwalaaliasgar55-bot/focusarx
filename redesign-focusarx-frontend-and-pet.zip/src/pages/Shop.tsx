import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Coins, Ticket } from "lucide-react";
import { useStore, useActivePet } from "../lib/store";
import { ACCESSORIES, ELEMENT_COLOR, SPECIES_LIST, SPECIES, TREATS, type AccessoryId, type SpeciesId } from "../lib/pets";
import { Button, Chip, EASE, Segmented, rise, stagger } from "../components/ui";
import { PetStage } from "../components/pet/PetStage";
import { PetAvatar } from "../components/pet/PetAvatar";
import { mkAnim, type PetAnim } from "../components/pet/Pet3D";
import { sfx } from "../lib/sound";
import { useUI } from "../lib/ui";
import { cn } from "../utils/cn";

type Tab = "pets" | "style" | "treats" | "tickets";

const PACKS = [
  { qty: 3, price: 60, tag: "" },
  { qty: 10, price: 170, tag: "Popular" },
  { qty: 25, price: 380, tag: "Best value" },
];

export default function Shop() {
  const s = useStore();
  const active = useActivePet();
  const [tab, setTab] = useState<Tab>("pets");
  const [species, setSpecies] = useState<SpeciesId>("bubbo");
  const [acc, setAcc] = useState<AccessoryId>("crown");
  const [anim, setAnim] = useState<PetAnim>(() => mkAnim("wave"));
  const toast = useUI((u) => u.toast);

  useEffect(() => setAnim(mkAnim("wave")), [species, acc, tab]);

  const showSpecies: SpeciesId = tab === "pets" ? species : active.species;
  const showAcc: AccessoryId | null = tab === "style" ? acc : tab === "pets" ? null : active.accessory;
  const sp = SPECIES[species];

  const adopt = (id: SpeciesId) => {
    if (s.adopt(id)) {
      sfx("buy");
      setAnim(mkAnim("victory"));
      toast({ title: `${SPECIES[id].name} joined your team`, body: "They're now your active companion.", tone: "success" });
    } else toast({ title: "Not enough coins", body: "Focus sessions earn 2 coins per minute.", tone: "warn" });
  };

  return (
    <div className="mx-auto w-full max-w-[1200px] px-4 pb-14 pt-2 md:px-8">
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: EASE }} className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="eyebrow">Spend your focus</div>
          <h1 className="font-display mt-1 text-[34px] font-extrabold tracking-tight">Shop</h1>
        </div>
        <Segmented id="shoptab" value={tab} onChange={setTab} options={[{ value: "pets", label: "Companions" }, { value: "style", label: "Style" }, { value: "treats", label: "Treats" }, { value: "tickets", label: "Tickets" }]} />
      </motion.div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        {/* preview */}
        <div className="panel relative h-[380px] overflow-hidden lg:sticky lg:top-2 lg:h-[560px]">
          <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at 50% 85%, ${ELEMENT_COLOR[SPECIES[showSpecies].element]}33, transparent 62%)` }} />
          {(tab === "pets" || tab === "style") ? (
            <PetStage className="absolute inset-0" species={showSpecies} anim={anim} accessory={showAcc} interactive follow={false} camera={[0, 1.45, 5.6]} />
          ) : (
            <div className="absolute inset-0 grid place-items-center">
              <motion.div key={tab} initial={{ opacity: 0, scale: 0.8, rotate: -6 }} animate={{ opacity: 1, scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 200, damping: 18 }} className="text-center">
                <div className="mx-auto grid h-28 w-28 place-items-center rounded-[34px] bg-gradient-to-b from-white/10 to-white/[0.02] shadow-[0_30px_60px_-20px_rgba(0,0,0,.8)]">
                  {tab === "treats" ? <PetAvatar species={active.species} size={72} /> : <Ticket size={52} className="text-nova" />}
                </div>
                <div className="font-display mt-5 text-xl font-extrabold">{tab === "treats" ? `Treats for ${active.name}` : "Battle tickets"}</div>
                <div className="mx-auto mt-1 max-w-[260px] text-[13px] text-ink-3">{tab === "treats" ? "Keep your companion fed and happy for bonus XP." : "Each ticket is one ranked Arena battle. You earn one per 15+ minute session."}</div>
              </motion.div>
            </div>
          )}
          <AnimatePresence mode="wait">
            {(tab === "pets" || tab === "style") && (
              <motion.div key={tab === "pets" ? species : acc} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} transition={{ duration: 0.3 }} className="absolute inset-x-0 bottom-0 p-5">
                <div className="glass flex items-center justify-between gap-3 rounded-2xl px-4 py-3">
                  <div>
                    <div className="font-display font-extrabold">{tab === "pets" ? sp.name : ACCESSORIES.find((a) => a.id === acc)!.name}</div>
                    <div className="text-[12px] text-ink-3">{tab === "pets" ? `${sp.element[0].toUpperCase() + sp.element.slice(1)} · ${sp.rarity}` : `Previewing on ${active.name}`}</div>
                  </div>
                  <div className="text-[11px] text-ink-4">Drag to rotate</div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* list */}
        <motion.div key={tab} variants={stagger} initial="hidden" animate="show" className="space-y-2.5">
          {tab === "pets" &&
            SPECIES_LIST.map((p) => {
              const owned = s.pets.some((x) => x.species === p.id);
              const sel = species === p.id;
              return (
                <motion.div
                  key={p.id}
                  variants={rise}
                  onClick={() => setSpecies(p.id)}
                  className={cn("panel-flat flex cursor-pointer items-center gap-4 p-4 transition-all duration-300", sel ? "border-white/25 bg-surface-2" : "hover:bg-surface-2")}
                  style={sel ? { boxShadow: `0 0 0 1px ${ELEMENT_COLOR[p.element]}55, 0 20px 40px -24px ${ELEMENT_COLOR[p.element]}66` } : undefined}
                >
                  <div className="grid h-[68px] w-[68px] shrink-0 place-items-center rounded-2xl bg-white/[0.04]"><PetAvatar species={p.id} size={52} /></div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-display text-[16px] font-extrabold">{p.name}</span>
                      <Chip color={ELEMENT_COLOR[p.element]}>{p.element}</Chip>
                      <span className="text-[11px] font-semibold text-ink-4">{p.rarity}</span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-[12.5px] leading-snug text-ink-3">{p.blurb}</p>
                    <div className="num mt-2 flex gap-3 text-[11px] font-semibold text-ink-3">
                      <span>HP {p.base.hp}</span><span>ATK {p.base.atk}</span><span>DEF {p.base.def}</span><span>SPD {p.base.spd}</span>
                    </div>
                  </div>
                  {owned ? (
                    <span className="flex items-center gap-1 text-[12.5px] font-semibold text-leaf"><Check size={15} />Owned</span>
                  ) : (
                    <Button size="sm" variant="primary" onClick={(e) => { e.stopPropagation(); adopt(p.id); }} className={cn(s.coins < p.price && "opacity-60")}>
                      <Coins size={13} />{p.price}
                    </Button>
                  )}
                </motion.div>
              );
            })}

          {tab === "style" &&
            ACCESSORIES.map((a) => {
              const owned = s.accessories.includes(a.id);
              const worn = active.accessory === a.id;
              return (
                <motion.div
                  key={a.id}
                  variants={rise}
                  onClick={() => setAcc(a.id)}
                  className={cn("panel-flat flex cursor-pointer items-center gap-4 p-4 transition-all duration-300", acc === a.id ? "border-white/25 bg-surface-2" : "hover:bg-surface-2")}
                >
                  <div className="min-w-0 flex-1">
                    <div className="font-display text-[16px] font-extrabold">{a.name}</div>
                    <p className="mt-0.5 text-[12.5px] text-ink-3">{a.blurb}</p>
                  </div>
                  {worn ? (
                    <span className="flex items-center gap-1 text-[12.5px] font-semibold text-leaf"><Check size={15} />Worn</span>
                  ) : owned ? (
                    <Button size="sm" variant="secondary" onClick={(e) => { e.stopPropagation(); s.equip(active.id, a.id); sfx("pop"); setAnim(mkAnim("happy")); }}>Equip</Button>
                  ) : (
                    <Button size="sm" variant="primary" onClick={(e) => { e.stopPropagation(); if (s.buyAccessory(a.id)) { s.equip(active.id, a.id); sfx("buy"); setAnim(mkAnim("happy")); toast({ title: `${a.name} equipped`, body: `${active.name} looks great.`, tone: "success" }); } else toast({ title: "Not enough coins", tone: "warn" }); }}>
                      <Coins size={13} />{a.price}
                    </Button>
                  )}
                </motion.div>
              );
            })}

          {tab === "treats" &&
            TREATS.map((t) => (
              <motion.div key={t.id} variants={rise} className="panel-flat flex items-center gap-4 p-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline gap-2">
                    <span className="font-display text-[16px] font-extrabold">{t.name}</span>
                    <span className="num text-[12px] text-ink-3">{t.id === "kibble" ? "∞" : `×${s.treats[t.id]}`} owned</span>
                  </div>
                  <p className="mt-0.5 text-[12.5px] text-ink-3">{t.blurb}</p>
                  <div className="num mt-1.5 text-[11px] font-semibold text-ink-3">+{t.hunger} fullness{t.joy ? ` · +${t.joy} joy` : ""}{t.xp ? ` · +${t.xp} XP` : ""}</div>
                </div>
                {t.price === 0 ? (
                  <span className="text-[12.5px] font-semibold text-ink-4">Free</span>
                ) : (
                  <div className="flex gap-2">
                    {[1, 5].map((q) => (
                      <Button key={q} size="sm" variant={q === 1 ? "secondary" : "primary"} onClick={() => { if (s.buyTreat(t.id, q)) sfx("buy"); else toast({ title: "Not enough coins", tone: "warn" }); }}>
                        ×{q} · <Coins size={12} />{t.price * q}
                      </Button>
                    ))}
                  </div>
                )}
              </motion.div>
            ))}

          {tab === "tickets" &&
            PACKS.map((p) => (
              <motion.div key={p.qty} variants={rise} className="panel-flat flex items-center gap-4 p-4">
                <div className="grid h-14 w-14 place-items-center rounded-2xl bg-nova/10 text-nova"><Ticket size={26} /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-[18px] font-extrabold">{p.qty} tickets</span>
                    {p.tag && <Chip color="#c084fc">{p.tag}</Chip>}
                  </div>
                  <div className="num text-[12.5px] text-ink-3">{Math.round(p.price / p.qty)} coins each · you have {s.tickets}</div>
                </div>
                <Button variant="primary" onClick={() => { if (s.buyTickets(p.qty, p.price)) { sfx("buy"); toast({ title: `+${p.qty} battle tickets`, tone: "success" }); } else toast({ title: "Not enough coins", tone: "warn" }); }}>
                  <Coins size={14} />{p.price}
                </Button>
              </motion.div>
            ))}
        </motion.div>
      </div>
    </div>
  );
}
