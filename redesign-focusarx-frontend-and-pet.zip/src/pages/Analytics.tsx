import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { Award, CalendarDays, Clock, Gauge, Layers } from "lucide-react";
import { bestStreak, streakOf, useStore } from "../lib/store";
import { dailyMinutes, heatmap, hourly, inRange, taskBreakdown } from "../lib/stats";
import { minutesLabel, weekdayShort } from "../lib/format";
import { AnimatedNumber, Bar, EASE, Segmented, SectionTitle, rise, stagger } from "../components/ui";
import { BarChart, Heatmap } from "../components/charts";
import { cn } from "../utils/cn";

function hourLabel(h: number) {
  const x = h % 12 === 0 ? 12 : h % 12;
  return `${x}${h < 12 ? "a" : "p"}`;
}

export default function Analytics() {
  const sessions = useStore((s) => s.sessions);
  const [range, setRange] = useState<"7" | "30" | "90">("30");
  const days = +range;

  const data = useMemo(() => dailyMinutes(sessions, days), [sessions, days]);
  const scoped = useMemo(() => inRange(sessions, days), [sessions, days]);
  const total = scoped.reduce((n, s) => n + s.minutes, 0);
  const avgScore = scoped.length ? Math.round(scoped.reduce((n, s) => n + s.score, 0) / scoped.length) : 0;
  const activeDays = data.filter((d) => d.minutes > 0).length;
  const hours = useMemo(() => hourly(scoped), [scoped]);
  const peakHour = hours.indexOf(Math.max(...hours));
  const maxHour = Math.max(...hours, 1);
  const tasks = useMemo(() => taskBreakdown(scoped).slice(0, 5), [scoped]);
  const cols = useMemo(() => heatmap(sessions, 26), [sessions]);
  const longest = sessions.reduce((m, s) => Math.max(m, s.minutes), 0);
  const bestDay = Math.max(0, ...dailyMinutes(sessions, 90).map((d) => d.minutes));
  const topScore = sessions.reduce((m, s) => Math.max(m, s.score), 0);
  const peakWindow = hours.reduce((best, _, h) => {
    const v = hours[h] + hours[(h + 1) % 24] + hours[(h + 2) % 24];
    return v > best.v ? { h, v } : best;
  }, { h: 0, v: 0 });

  const stats = [
    { icon: Clock, label: "Focus time", value: total / 60, fmt: (n: number) => n.toFixed(1), unit: "hours", color: "#7b7cff" },
    { icon: Layers, label: "Sessions", value: scoped.length, fmt: (n: number) => `${Math.round(n)}`, unit: "", color: "#38bdf8" },
    { icon: Gauge, label: "Avg focus score", value: avgScore, fmt: (n: number) => `${Math.round(n)}`, unit: "/100", color: "#34d399" },
    { icon: CalendarDays, label: "Active days", value: activeDays, fmt: (n: number) => `${Math.round(n)}`, unit: `of ${days}`, color: "#fbbf24" },
  ];

  return (
    <div className="mx-auto w-full max-w-[1100px] px-4 pb-14 pt-2 md:px-8">
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: EASE }} className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="eyebrow">Insights</div>
          <h1 className="font-display mt-1 text-[34px] font-extrabold tracking-tight">Analytics</h1>
          <p className="mt-1 text-[14px] text-ink-3">Calculated from your real sessions. Nothing leaves this device.</p>
        </div>
        <Segmented id="range" value={range} onChange={setRange} options={[{ value: "7", label: "7 days" }, { value: "30", label: "30 days" }, { value: "90", label: "90 days" }]} />
      </motion.div>

      <motion.div variants={stagger} initial="hidden" animate="show" className="grid grid-cols-12 gap-4">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <motion.div key={s.label} variants={rise} className="panel col-span-6 p-5 lg:col-span-3">
              <div className="flex items-center gap-2 text-[12px] font-semibold text-ink-3">
                <span className="grid h-7 w-7 place-items-center rounded-lg" style={{ background: `${s.color}22`, color: s.color }}><Icon size={15} /></span>
                {s.label}
              </div>
              <div className="font-display mt-4 text-[34px] font-extrabold leading-none">
                <AnimatedNumber key={range} value={s.value} format={s.fmt} />
                <span className="ml-1.5 text-sm font-semibold text-ink-3">{s.unit}</span>
              </div>
            </motion.div>
          );
        })}

        <motion.div variants={rise} className="panel col-span-12 p-5 md:p-6">
          <SectionTitle title="Daily focus" sub={`${minutesLabel(total)} across the last ${days} days`} />
          <BarChart
            key={range}
            height={220}
            showEvery={days === 7 ? 1 : days === 30 ? 3 : 10}
            data={data.map((d) => ({
              label: days === 7 ? weekdayShort(d.ts) : new Date(d.ts).getDate().toString(),
              value: d.minutes,
              tip: `${new Date(d.ts).toLocaleDateString(undefined, { month: "short", day: "numeric" })} · ${d.minutes ? minutesLabel(d.minutes) : "no focus"}`,
              highlight: d.minutes >= 60,
            }))}
          />
        </motion.div>

        <motion.div variants={rise} className="panel col-span-12 p-5 md:p-6 lg:col-span-7">
          <SectionTitle title="Focus DNA" sub="When your brain does its best work" />
          <div className="flex h-[150px] items-end gap-[3px]">
            {hours.map((v, h) => (
              <div key={h} className="group relative flex h-full flex-1 items-end">
                <motion.div
                  key={range + h}
                  className="w-full rounded-t-md"
                  style={{ background: h === peakHour ? "linear-gradient(180deg,#b4b5ff,#6466f1)" : "linear-gradient(180deg,rgba(123,124,255,.45),rgba(123,124,255,.1))" }}
                  initial={{ height: 0 }}
                  animate={{ height: `${Math.max(v > 0 ? 3 : 0, (v / maxHour) * 100)}%` }}
                  transition={{ duration: 0.9, delay: h * 0.02, ease: EASE }}
                />
                <div className="pointer-events-none absolute bottom-full left-1/2 z-10 mb-1.5 -translate-x-1/2 whitespace-nowrap rounded-lg bg-surface-4 px-2 py-1 text-[11px] font-semibold opacity-0 shadow-xl transition-opacity group-hover:opacity-100">
                  {hourLabel(h)} · {minutesLabel(v)}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-2 flex gap-[3px] text-[10px] text-ink-4">
            {hours.map((_, h) => <div key={h} className="flex-1 text-center">{h % 3 === 0 ? hourLabel(h) : ""}</div>)}
          </div>
          {total > 0 && (
            <p className="mt-5 rounded-2xl bg-white/[0.04] px-4 py-3 text-[13px] leading-relaxed text-ink-2">
              Your sharpest window is around <b className="text-ink">{hourLabel(peakWindow.h)}–{hourLabel((peakWindow.h + 3) % 24)}</b>. You focus most at <b className="text-ink">{hourLabel(peakHour)}</b>
              {" "}— protect that time for your hardest task.
            </p>
          )}
        </motion.div>

        <motion.div variants={rise} className="panel col-span-12 p-5 md:p-6 lg:col-span-5">
          <SectionTitle title="Where the time went" sub="Top tasks in this range" />
          {tasks.length === 0 ? (
            <p className="text-[13px] text-ink-3">Attach a task to a session and it will appear here.</p>
          ) : (
            <div className="space-y-4">
              {tasks.map((t, i) => (
                <div key={t.title}>
                  <div className="mb-1.5 flex items-center justify-between gap-3 text-[13px]">
                    <span className={cn("truncate font-semibold", t.title === "Unassigned" && "text-ink-3")}>{t.title}</span>
                    <span className="num shrink-0 text-ink-3">{minutesLabel(t.minutes)}</span>
                  </div>
                  <Bar value={t.minutes / tasks[0].minutes} color={["#7b7cff", "#38bdf8", "#34d399", "#fbbf24", "#fb7185"][i]} />
                </div>
              ))}
            </div>
          )}
        </motion.div>

        <motion.div variants={rise} className="panel col-span-12 p-5 md:p-6">
          <SectionTitle title="Six months at a glance" />
          <Heatmap cols={cols} />
        </motion.div>

        <motion.div variants={rise} className="col-span-12 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[
            { l: "Current streak", v: `${streakOf(sessions)} days` },
            { l: "Best streak", v: `${bestStreak(sessions)} days` },
            { l: "Longest session", v: minutesLabel(longest) },
            { l: "Best day", v: minutesLabel(bestDay) },
          ].map((b) => (
            <div key={b.l} className="panel-flat flex items-center gap-3.5 p-4">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-volt/10 text-volt"><Award size={18} /></span>
              <div>
                <div className="eyebrow !text-[10px]">{b.l}</div>
                <div className="font-display mt-0.5 text-lg font-extrabold">{b.v}</div>
              </div>
            </div>
          ))}
        </motion.div>
        {topScore > 0 && <p className="col-span-12 text-center text-[12px] text-ink-4">Best focus score on record: {topScore}/100</p>}
      </motion.div>
    </div>
  );
}
