import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion, useMotionValue, useSpring, useTransform, type MotionValue } from "framer-motion";
import { Check, ChevronDown, FastForward, Maximize2, Minimize2, Minus, Pause, Play, Plus, RotateCcw, Ticket, Volume2, VolumeX, Coins, Sparkles, Flame, ListChecks } from "lucide-react";
import { useStore, useActivePet, minutesOnDay, streakOf, type Mode } from "../lib/store";
import { useUI, type Route } from "../lib/ui";
import { clock, timeOfDay } from "../lib/format";
import { sfx, type Ambient } from "../lib/sound";
import { cn } from "../utils/cn";
import { AnimatedNumber, Button, EASE, Ring, SPRING, Segmented } from "../components/ui";
import { PetStage } from "../components/pet/PetStage";
import { mkAnim, type PetAnim } from "../components/pet/Pet3D";

const MODE_META: Record<Mode, { label: string; color: string; light: string; verb: string }> = {
  focus: { label: "Focus", color: "#7b7cff", light: "#b4b5ff", verb: "Start focus" },
  short: { label: "Short break", color: "#34d399", light: "#8ff0c8", verb: "Start break" },
  long: { label: "Long break", color: "#fbbf24", light: "#fde08a", verb: "Start break" },
};
const PRESETS: Record<Mode, number[]> = { focus: [15, 25, 45, 60, 90], short: [3, 5, 10], long: [10, 15, 20, 30] };

/* ───────────────────────── Dial ───────────────────────── */
function Tick({ i, p, color }: { i: number; p: MotionValue<number>; color: string }) {
  const major = i % 5 === 0;
  const a = (i / 60) * Math.PI * 2;
  const r1 = 205;
  const r2 = major ? 217 : 211;
  const opacity = useTransform(p, (v) => 0.14 + 0.86 * Math.min(1, Math.max(0, (i / 60 - v) * 60 + 0.5)));
  return (
    <motion.line
      x1={220 + Math.sin(a) * r1} y1={220 - Math.cos(a) * r1} x2={220 + Math.sin(a) * r2} y2={220 - Math.cos(a) * r2}
      stroke={major ? color : "#ffffff"} strokeWidth={major ? 2.4 : 1.4} strokeLinecap="round" style={{ opacity }}
    />
  );
}

function Digit({ c }: { c: string }) {
  const colon = c === ":";
  return (
    <span className="relative inline-block overflow-hidden" style={{ width: colon ? "0.32em" : "0.64em", height: "1.12em" }}>
      <AnimatePresence mode="popLayout" initial={false}>
        <motion.span
          key={c}
          initial={{ y: "55%", opacity: 0, filter: "blur(8px)" }}
          animate={{ y: "0%", opacity: colon ? 0.6 : 1, filter: "blur(0px)" }}
          exit={{ y: "-55%", opacity: 0, filter: "blur(8px)" }}
          transition={{ duration: 0.45, ease: EASE }}
          className="absolute inset-0 grid place-items-center"
        >
          {c}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}

function Dial({ mode, status, taskTitle, zen }: { mode: Mode; status: string; taskTitle?: string; zen: boolean }) {
  const meta = MODE_META[mode];
  const raw = useMotionValue(0);
  const p = useSpring(raw, { stiffness: 140, damping: 26, mass: 0.6 });
  const circ = 2 * Math.PI * 178;
  const offset = useTransform(p, (v) => circ * Math.min(1, Math.max(0, v)));
  const knob = useTransform(p, (v) => v * 360);
  const [sec, setSec] = useState(() => useStore.getState().timer.remaining);

  useEffect(() => {
    let raf = 0;
    const loop = () => {
      const t = useStore.getState().timer;
      const remain = t.status === "running" && t.endAt ? Math.max(0, t.endAt - Date.now()) : t.remaining * 1000;
      raw.set(1 - remain / (t.duration * 1000));
      const s = Math.ceil(remain / 1000);
      setSec((prev) => (prev === s ? prev : s));
      raf = requestAnimationFrame(loop);
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [raw]);

  const text = clock(sec);
  const running = status === "running";
  const endAt = useStore((s) => s.timer.endAt);

  return (
    <div className="relative mx-auto aspect-square" style={{ width: zen ? "min(92vw, 80vh, 680px)" : "min(88vw, 47vh, 470px)", containerType: "inline-size", transition: "width .7s cubic-bezier(.22,1,.36,1)" }}>
      {/* ambient glow */}
      <motion.div
        className="absolute inset-[8%] rounded-full blur-3xl"
        animate={{ opacity: running ? 0.38 : 0.14, scale: running ? [1, 1.06, 1] : 1, backgroundColor: meta.color }}
        transition={{ opacity: { duration: 1 }, backgroundColor: { duration: 1 }, scale: running ? { duration: 4, repeat: Infinity, ease: "easeInOut" } : { duration: 0.6 } }}
      />
      <svg viewBox="0 0 440 440" className="absolute inset-0 h-full w-full">
        <defs>
          <linearGradient id="arc" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={meta.light} />
            <stop offset="100%" stopColor={meta.color} />
          </linearGradient>
          <radialGradient id="disc" cx="50%" cy="38%" r="70%">
            <stop offset="0%" stopColor="rgba(255,255,255,0.06)" />
            <stop offset="100%" stopColor="rgba(255,255,255,0.008)" />
          </radialGradient>
          <filter id="soft" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="6" />
          </filter>
        </defs>
        {Array.from({ length: 60 }, (_, i) => (
          <Tick key={i} i={i} p={p} color={meta.light} />
        ))}
        <circle cx="220" cy="220" r="160" fill="url(#disc)" stroke="rgba(255,255,255,0.06)" />
        <circle cx="220" cy="220" r="178" fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="9" />
        <motion.circle
          cx="220" cy="220" r="178" fill="none" stroke="url(#arc)" strokeWidth="9" strokeLinecap="round"
          strokeDasharray={circ} style={{ strokeDashoffset: offset, rotate: -90, originX: "50%", originY: "50%" }}
        />
        <motion.circle
          cx="220" cy="220" r="178" fill="none" stroke={meta.color} strokeWidth="9" strokeLinecap="round" filter="url(#soft)"
          strokeDasharray={circ} style={{ strokeDashoffset: offset, rotate: -90, originX: "50%", originY: "50%", opacity: 0.55 }}
        />
      </svg>
      {/* knob */}
      <motion.div className="pointer-events-none absolute inset-0" style={{ rotate: knob }}>
        <div className="absolute left-1/2 grid -translate-x-1/2 -translate-y-1/2 place-items-center" style={{ top: "9.55%" }}>
          <motion.span className="absolute h-[5.2cqw] w-[5.2cqw] rounded-full blur-md" animate={{ backgroundColor: meta.color, opacity: running ? 0.9 : 0.4 }} />
          <span className="relative h-[2.5cqw] w-[2.5cqw] rounded-full bg-white shadow-[0_0_14px_rgba(255,255,255,0.9)]" />
        </div>
      </motion.div>

      {/* center */}
      <div className="absolute inset-0 grid place-items-center">
        <div className="flex flex-col items-center">
          <motion.div
            key={mode}
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            className="eyebrow flex items-center gap-2"
            style={{ fontSize: "2.6cqw", color: meta.light }}
          >
            <span className={cn("h-[1.4cqw] w-[1.4cqw] rounded-full", running && "animate-pulse")} style={{ background: meta.color }} />
            {status === "paused" ? "Paused" : meta.label}
          </motion.div>
          <div className="font-display num font-bold leading-none text-ink" style={{ fontSize: text.length > 5 ? "15.5cqw" : "22cqw", letterSpacing: "-0.04em", marginTop: "1.2cqw" }}>
            <span className="inline-flex">{text.split("").map((c, i) => <Digit key={text.length + "-" + i} c={c} />)}</span>
          </div>
          <div className="h-[4cqw] text-ink-3" style={{ fontSize: "2.9cqw", marginTop: "1.2cqw" }}>
            {running && endAt ? <>Ends at {timeOfDay(endAt)}</> : taskTitle ? <span className="line-clamp-1 max-w-[46cqw]">{taskTitle}</span> : status === "paused" ? "Resume when you're ready" : "Ready when you are"}
          </div>
        </div>
      </div>
    </div>
  );
}

/* ───────────────────────── Task picker ───────────────────────── */
function TaskPicker() {
  const tasks = useStore((s) => s.tasks);
  const taskId = useStore((s) => s.timer.taskId);
  const setTask = useStore((s) => s.setTimerTask);
  const addTask = useStore((s) => s.addTask);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState("");
  const active = tasks.find((t) => t.id === taskId);
  const open_ = tasks.filter((t) => !t.done);
  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="group flex max-w-[78vw] items-center gap-2.5 rounded-full border border-white/[0.08] bg-white/[0.045] py-2 pl-3.5 pr-3 text-[13px] font-semibold backdrop-blur transition-colors hover:bg-white/[0.08]"
      >
        <ListChecks size={15} className="text-brand-300" />
        <span className={cn("truncate", !active && "text-ink-3")}>{active ? active.title : "What are you working on?"}</span>
        <ChevronDown size={15} className={cn("shrink-0 text-ink-3 transition-transform duration-300", open && "rotate-180")} />
      </button>
      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: -8, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.97 }}
              transition={{ type: "spring", stiffness: 420, damping: 32 }}
              style={{ transformOrigin: "top center" }}
              className="glass absolute left-1/2 top-[calc(100%+10px)] z-40 w-[min(340px,86vw)] -translate-x-1/2 rounded-2xl p-2"
            >
              <div className="scroll-y max-h-60">
                <button onClick={() => { setTask(null); setOpen(false); }} className={cn("flex w-full items-center justify-between rounded-xl px-3 py-2.5 text-left text-[13px] hover:bg-white/[0.07]", !taskId && "text-brand-300")}>
                  No task <Check size={14} className={cn(!taskId ? "opacity-100" : "opacity-0")} />
                </button>
                {open_.map((t) => (
                  <button key={t.id} onClick={() => { setTask(t.id); setOpen(false); }} className="flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-left text-[13px] hover:bg-white/[0.07]">
                    <span className={cn("line-clamp-1", t.id === taskId && "text-brand-300")}>{t.title}</span>
                    {t.id === taskId && <Check size={14} className="shrink-0 text-brand-300" />}
                  </button>
                ))}
              </div>
              <form
                className="mt-1 flex gap-2 border-t border-white/[0.07] p-1 pt-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!draft.trim()) return;
                  addTask(draft, "med", 1);
                  const created = useStore.getState().tasks[0];
                  setTask(created.id);
                  setDraft("");
                  setOpen(false);
                }}
              >
                <input className="field !py-2 !text-[13px]" placeholder="New task…" value={draft} onChange={(e) => setDraft(e.target.value)} />
                <Button variant="primary" size="sm" type="submit">Add</Button>
              </form>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ───────────────────────── Result card ───────────────────────── */
function Confetti({ color }: { color: string }) {
  const bits = useMemo(
    () => Array.from({ length: 44 }, (_, i) => ({
      id: i, x: (Math.random() - 0.5) * 520, y: -120 - Math.random() * 260, rot: Math.random() * 720 - 360,
      c: [color, "#ffffff", "#fbbf24", "#34d399", "#fb7185", "#38bdf8"][i % 6], w: 6 + Math.random() * 6, d: 1.6 + Math.random() * 1.2, delay: Math.random() * 0.15,
    })),
    [color]
  );
  return (
    <div className="pointer-events-none absolute inset-x-0 top-1/2 z-10 h-0">
      {bits.map((b) => (
        <motion.span
          key={b.id}
          className="absolute left-1/2 block rounded-[2px]"
          style={{ width: b.w, height: b.w * 0.5, background: b.c }}
          initial={{ x: 0, y: 0, opacity: 1, rotate: 0 }}
          animate={{ x: b.x, y: [0, b.y, b.y + 520], opacity: [1, 1, 0], rotate: b.rot }}
          transition={{ duration: b.d, delay: b.delay, ease: "easeOut", times: [0, 0.35, 1] }}
        />
      ))}
    </div>
  );
}

function ResultCard({ onNext }: { onNext: () => void }) {
  const r = useStore((s) => s.lastResult);
  const dismiss = useStore((s) => s.dismissResult);
  if (!r) return null;
  const focus = r.kind === "focus";
  const meta = MODE_META[r.nextMode];
  return (
    <motion.div
      key={r.id}
      className="absolute inset-0 z-30 grid place-items-center rounded-[36px] p-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.35 }}
    >
      <div className="absolute inset-0 rounded-[36px] bg-surface-0/75 backdrop-blur-2xl" />
      {focus && !r.early && <Confetti color="#7b7cff" />}
      <motion.div
        initial={{ opacity: 0, y: 40, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.96 }}
        transition={{ type: "spring", stiffness: 240, damping: 24, delay: 0.1 }}
        className="relative w-full max-w-sm text-center"
      >
        <div className="mx-auto mb-4 grid h-16 w-16 place-items-center rounded-full bg-white/[0.07]">
          <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
            <motion.path d="M7 18.5 L14 25 L27 10" stroke={focus ? "#b4b5ff" : "#8ff0c8"} strokeWidth="3.4" strokeLinecap="round" strokeLinejoin="round"
              initial={{ pathLength: 0 }} animate={{ pathLength: 1 }} transition={{ duration: 0.6, delay: 0.35, ease: EASE }} />
          </svg>
        </div>
        <div className="eyebrow">{focus ? (r.early ? "Finished early" : "Session complete") : "Break's over"}</div>
        <h3 className="font-display mt-1 text-[30px] font-extrabold leading-tight">
          {focus ? <><AnimatedNumber value={r.minutes} duration={0.9} /> focused minutes</> : "Ready to focus again?"}
        </h3>
        {focus && (
          <div className="mt-6 flex items-center justify-center gap-6">
            <Ring value={r.score / 100} size={92} stroke={7} color={r.score >= 85 ? "#34d399" : r.score >= 60 ? "#7b7cff" : "#fbbf24"}>
              <div className="text-center">
                <div className="font-display text-2xl font-extrabold leading-none"><AnimatedNumber value={r.score} /></div>
                <div className="mt-0.5 text-[9px] font-semibold uppercase tracking-widest text-ink-3">Score</div>
              </div>
            </Ring>
            <div className="space-y-2 text-left">
              {[
                { icon: <Sparkles size={15} className="text-brand-300" />, label: "XP", v: r.xp },
                { icon: <Coins size={15} className="text-volt" />, label: "Coins", v: r.coins },
              ].map((row, i) => (
                <motion.div key={row.label} initial={{ opacity: 0, x: -14 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 + i * 0.12, ease: EASE }} className="flex items-center gap-2.5 text-[15px] font-semibold">
                  {row.icon}
                  <span className="num">+<AnimatedNumber value={row.v} duration={1.2} /></span>
                  <span className="text-ink-3">{row.label}</span>
                </motion.div>
              ))}
              {r.ticket && (
                <motion.div initial={{ opacity: 0, x: -14 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.76, ease: EASE }} className="flex items-center gap-2.5 text-[15px] font-semibold">
                  <Ticket size={15} className="text-nova" /> +1 <span className="text-ink-3">Battle ticket</span>
                </motion.div>
              )}
            </div>
          </div>
        )}
        {focus && r.petName && (
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.9 }} className="mt-5 text-[13px] text-ink-2">
            {r.petLeveled ? <><b className="text-brand-300">{r.petName}</b> grew to level {r.petLeveled}!</> : <>{r.petName} earned {r.minutes * 5} XP studying alongside you.</>}
          </motion.p>
        )}
        {r.accountLevel && (
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 1.0, type: "spring" }} className="mx-auto mt-3 w-fit rounded-full border border-brand-400/30 bg-brand-500/15 px-3 py-1 text-xs font-bold text-brand-300">
            Level {r.accountLevel} reached
          </motion.div>
        )}
        {focus && r.streak > 0 && (
          <div className="mt-3 flex items-center justify-center gap-1.5 text-xs text-ink-3"><Flame size={13} className="text-ember" /> {r.streak}-day streak</div>
        )}
        <div className="mt-7 flex items-center justify-center gap-2.5">
          <Button variant="ghost" onClick={dismiss}>Not now</Button>
          <Button variant="primary" size="lg" onClick={() => { dismiss(); onNext(); }} style={{ background: `linear-gradient(180deg, ${meta.light}, ${meta.color})`, color: "#0b0b0c" }}>
            {r.nextMode === "focus" ? "Start next focus" : `Start ${r.nextMode === "long" ? "long" : "short"} break`}
          </Button>
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ───────────────────────── Page ───────────────────────── */
export default function Focus({ go }: { go: (r: Route) => void }) {
  const timer = useStore((s) => s.timer);
  const settings = useStore((s) => s.settings);
  const tasks = useStore((s) => s.tasks);
  const sessions = useStore((s) => s.sessions);
  const result = useStore((s) => s.lastResult);
  const { setMode, setDurationMin, startTimer, pauseTimer, resetTimer, completeTimer, updateSettings } = useStore.getState();
  const pet = useActivePet();
  const zen = useUI((s) => s.zen);
  const setZen = useUI((s) => s.setZen);
  const ambient = useUI((s) => s.ambient);
  const playAmbient = useUI((s) => s.playAmbient);

  const meta = MODE_META[timer.mode];
  const running = timer.status === "running";
  const idle = timer.status === "idle";
  const task = tasks.find((t) => t.id === timer.taskId);
  const minutes = Math.round(timer.duration / 60);
  const todayMin = minutesOnDay(sessions, Date.now());
  const streak = streakOf(sessions);

  /* companion state follows the timer */
  const [anim, setAnim] = useState<PetAnim>(() => mkAnim("wave"));
  useEffect(() => {
    if (running) setAnim(mkAnim(timer.mode === "focus" ? "focus" : "sleep"));
    else if (timer.status === "paused") setAnim(mkAnim("idle"));
    else setAnim(mkAnim("wave"));
  }, [running, timer.status, timer.mode]);
  useEffect(() => {
    if (result?.kind === "focus") setAnim(mkAnim("victory"));
  }, [result?.id, result?.kind]);

  const toggle = useCallback(() => {
    const s = useStore.getState().timer;
    if (s.status === "running") {
      pauseTimer();
      sfx("tap");
    } else {
      startTimer();
      sfx("pop");
    }
  }, [pauseTimer, startTimer]);

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") return;
      if (e.code === "Space") { e.preventDefault(); if (!useStore.getState().lastResult) toggle(); }
      else if (e.key === "r" || e.key === "R") resetTimer();
      else if (e.key === "f" || e.key === "F") setZen(!useUI.getState().zen);
      else if (e.key === "Escape") setZen(false);
      else if (["1", "2", "3"].includes(e.key) && useStore.getState().timer.status === "idle") setMode((["focus", "short", "long"] as Mode[])[+e.key - 1]);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [toggle, resetTimer, setZen, setMode]);
  useEffect(() => () => setZen(false), [setZen]);

  const startNext = () => setTimeout(() => useStore.getState().startTimer(), 250);

  const ambients: { id: Ambient; label: string }[] = [
    { id: "off", label: "Off" }, { id: "brown", label: "Brown" }, { id: "rain", label: "Rain" }, { id: "waves", label: "Waves" },
  ];

  const petStatus = running ? (timer.mode === "focus" ? `${pet.name} is studying beside you` : `${pet.name} is taking a nap`) : timer.status === "paused" ? `${pet.name} is waiting for you` : `${pet.name} is ready when you are`;
  const mood = pet.hunger < 25 ? "hungry" : pet.joy < 30 ? "sad" : "happy";

  return (
    <div className="relative min-h-full overflow-hidden">
      {/* aurora */}
      <div className="pointer-events-none absolute inset-0 -z-0 overflow-hidden">
        <motion.div className="aurora-a absolute -left-[10%] -top-[20%] h-[70vh] w-[70vh] rounded-full blur-[110px]" animate={{ backgroundColor: meta.color, opacity: running ? 0.2 : 0.1 }} transition={{ duration: 1.4 }} />
        <motion.div className="aurora-b absolute -bottom-[25%] right-[5%] h-[60vh] w-[60vh] rounded-full blur-[120px]" animate={{ backgroundColor: meta.color, opacity: running ? 0.16 : 0.07 }} transition={{ duration: 1.4 }} />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,rgba(11,11,12,0.7)_100%)]" />
      </div>

      <div className={cn("relative z-10 mx-auto grid min-h-full max-w-[1280px] gap-6 px-4 pb-10 pt-2 md:px-8", zen ? "place-items-center" : "lg:grid-cols-[1fr_340px]")}>
        {/* center */}
        <div className="relative flex flex-col items-center justify-center gap-6 py-4 lg:py-8">
          <motion.div layout className="flex flex-col items-center gap-4">
            <Segmented
              id="mode"
              value={timer.mode}
              onChange={(m) => { if (idle) { setMode(m); sfx("tap"); } }}
              options={(["focus", "short", "long"] as Mode[]).map((m) => ({ value: m, label: MODE_META[m].label }))}
              className={cn(!idle && "pointer-events-none opacity-50", "transition-opacity duration-500")}
            />
            <TaskPicker />
          </motion.div>

          <Dial mode={timer.mode} status={timer.status} taskTitle={task?.title} zen={zen} />

          {/* controls */}
          <div className="flex items-center gap-4">
            <motion.button
              whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.9 }} transition={SPRING}
              onClick={() => { resetTimer(); sfx("tap"); }}
              disabled={idle}
              aria-label="Reset"
              className="grid h-12 w-12 place-items-center rounded-full border border-white/[0.08] bg-white/[0.05] text-ink-2 transition-opacity hover:text-ink disabled:opacity-30"
            >
              <RotateCcw size={18} />
            </motion.button>
            <motion.button
              layout
              whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.95 }} transition={SPRING}
              onClick={toggle}
              className="relative flex h-[68px] min-w-[190px] items-center justify-center gap-3 overflow-hidden rounded-full px-9 text-[17px] font-bold text-[#0b0b0c]"
              style={{ background: `linear-gradient(180deg, ${meta.light}, ${meta.color})`, boxShadow: `0 1px 0 rgba(255,255,255,.5) inset, 0 18px 50px -14px ${meta.color}` }}
            >
              <AnimatePresence mode="wait" initial={false}>
                <motion.span key={running ? "p" : timer.status} initial={{ opacity: 0, y: 14, filter: "blur(4px)" }} animate={{ opacity: 1, y: 0, filter: "blur(0px)" }} exit={{ opacity: 0, y: -14, filter: "blur(4px)" }} transition={{ duration: 0.25, ease: EASE }} className="flex items-center gap-3">
                  {running ? <Pause size={22} fill="currentColor" /> : <Play size={22} fill="currentColor" />}
                  {running ? "Pause" : timer.status === "paused" ? "Resume" : meta.verb}
                </motion.span>
              </AnimatePresence>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.06 }} whileTap={{ scale: 0.9 }} transition={SPRING}
              onClick={() => {
                if (idle) setMode(timer.mode === "focus" ? "short" : "focus");
                else completeTimer(true);
              }}
              aria-label={idle ? "Switch mode" : timer.mode === "focus" ? "Finish early" : "Skip break"}
              title={idle ? "Switch mode" : timer.mode === "focus" ? "Finish early" : "Skip break"}
              className="grid h-12 w-12 place-items-center rounded-full border border-white/[0.08] bg-white/[0.05] text-ink-2 hover:text-ink"
            >
              {idle || timer.mode !== "focus" ? <FastForward size={18} /> : <Check size={19} />}
            </motion.button>
          </div>

          {/* duration */}
          <AnimatePresence initial={false}>
            {idle && !zen && (
              <motion.div
                initial={{ opacity: 0, height: 0, y: 10 }} animate={{ opacity: 1, height: "auto", y: 0 }} exit={{ opacity: 0, height: 0, y: 10 }}
                transition={{ duration: 0.5, ease: EASE }} className="overflow-hidden"
              >
                <div className="flex flex-wrap items-center justify-center gap-2 px-1 py-1">
                  {PRESETS[timer.mode].map((m) => (
                    <button
                      key={m}
                      onClick={() => { setDurationMin(m); sfx("tap"); }}
                      className={cn("relative rounded-full px-3.5 py-1.5 text-[13px] font-semibold transition-colors", minutes === m ? "text-ink" : "text-ink-3 hover:text-ink-2")}
                    >
                      {minutes === m && <motion.span layoutId="preset" transition={SPRING} className="absolute inset-0 rounded-full border border-white/[0.14] bg-white/[0.09]" />}
                      <span className="relative num">{m}m</span>
                    </button>
                  ))}
                  <div className="ml-1 flex items-center gap-1 rounded-full border border-white/[0.07] bg-white/[0.03] p-0.5">
                    <button aria-label="Less" onClick={() => setDurationMin(minutes - 5)} className="grid h-7 w-7 place-items-center rounded-full text-ink-3 hover:bg-white/10 hover:text-ink"><Minus size={14} /></button>
                    <span className="num w-10 text-center text-[13px] font-semibold">{minutes}m</span>
                    <button aria-label="More" onClick={() => setDurationMin(minutes + 5)} className="grid h-7 w-7 place-items-center rounded-full text-ink-3 hover:bg-white/10 hover:text-ink"><Plus size={14} /></button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* cycle */}
          <div className="flex items-center gap-4 text-[12px] text-ink-3">
            <div className="flex items-center gap-1.5">
              {[0, 1, 2, 3].map((i) => {
                const done = i < timer.cycle % 4;
                const current = i === timer.cycle % 4 && timer.mode === "focus";
                return (
                  <motion.span key={i} animate={{ scale: current && running ? [1, 1.35, 1] : 1, backgroundColor: done ? meta.color : current ? meta.light : "rgba(255,255,255,0.14)" }} transition={{ duration: 1.6, repeat: current && running ? Infinity : 0 }} className="h-2 w-2 rounded-full" />
                );
              })}
            </div>
            <span>Session {(timer.cycle % 4) + 1} of 4</span>
            <button onClick={() => setZen(!zen)} className="ml-1 flex items-center gap-1.5 rounded-full px-2.5 py-1 font-semibold text-ink-3 transition-colors hover:bg-white/[0.06] hover:text-ink">
              {zen ? <Minimize2 size={13} /> : <Maximize2 size={13} />} {zen ? "Exit zen" : "Zen mode"}
            </button>
          </div>

          <AnimatePresence>{result && <ResultCard onNext={startNext} />}</AnimatePresence>
        </div>

        {/* side column */}
        <AnimatePresence initial={false}>
          {!zen && (
            <motion.aside
              initial={{ opacity: 0, x: 40 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 40 }}
              transition={{ duration: 0.6, ease: EASE }}
              className="flex flex-col gap-4 lg:py-8"
            >
              <div className="panel overflow-hidden !rounded-[28px]">
                <div className="relative h-[290px]">
                  <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_100%,rgba(123,124,255,0.16),transparent_65%)]" />
                  <PetStage className="absolute inset-0" species={pet.species} anim={anim} accessory={pet.accessory} mood={mood} follow camera={[0, 1.35, 5.4]} />
                </div>
                <div className="flex items-center justify-between gap-3 border-t border-white/[0.06] px-4 py-3">
                  <div className="min-w-0">
                    <div className="truncate text-[13px] font-semibold">{petStatus}</div>
                    <div className="text-[11.5px] text-ink-3">Lv {pet.level} · earns {Math.round(timer.duration / 60) * 5} XP per session</div>
                  </div>
                  <Button size="sm" variant="secondary" onClick={() => go("companion")}>Visit</Button>
                </div>
              </div>

              <div className="panel p-4">
                <div className="mb-3 flex items-center justify-between">
                  <div className="eyebrow">Ambient sound</div>
                  {ambient === "off" ? <VolumeX size={15} className="text-ink-4" /> : <Volume2 size={15} className="text-brand-300" />}
                </div>
                <Segmented
                  id="amb" size="sm" value={ambient} className="w-full [&>button]:flex-1"
                  onChange={(a) => { playAmbient(a, settings.volume); updateSettings({ sound: a }); }}
                  options={ambients.map((a) => ({ value: a.id, label: a.label }))}
                />
                <input
                  type="range" min={0} max={1} step={0.01} value={settings.volume} disabled={ambient === "off"}
                  onChange={(e) => { const v = +e.target.value; updateSettings({ volume: v }); useUI.getState().setVolume(v); }}
                  className="mt-4 h-1 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-brand-400 disabled:opacity-30"
                />
              </div>

              <div className="panel grid grid-cols-3 divide-x divide-white/[0.06] p-1 text-center">
                {[
                  { l: "Today", v: todayMin, f: (n: number) => `${Math.round(n)}m` },
                  { l: "Streak", v: streak, f: (n: number) => `${Math.round(n)}d` },
                  { l: "Cycle", v: (timer.cycle % 4) + 1, f: (n: number) => `${Math.round(n)}/4` },
                ].map((s) => (
                  <div key={s.l} className="py-3">
                    <div className="font-display text-xl font-extrabold"><AnimatedNumber value={s.v} format={s.f} duration={0.7} /></div>
                    <div className="eyebrow mt-0.5 !text-[10px]">{s.l}</div>
                  </div>
                ))}
              </div>

              <div className="panel p-4">
                <div className="eyebrow mb-3">Shortcuts</div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-[12.5px] text-ink-2">
                  {[["Space", "Start / pause"], ["R", "Reset"], ["F", "Zen mode"], ["1 · 2 · 3", "Switch mode"]].map(([k, d]) => (
                    <div key={k} className="flex items-center justify-between gap-2">
                      <span className="text-ink-3">{d}</span>
                      <kbd className="rounded-md border border-white/10 bg-white/[0.05] px-1.5 py-0.5 font-mono text-[11px]">{k}</kbd>
                    </div>
                  ))}
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>

      {/* zen companion */}
      <AnimatePresence>
        {zen && (
          <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 40 }} transition={{ duration: 0.6, ease: EASE }} className="pointer-events-none fixed bottom-2 right-2 z-20 h-[240px] w-[240px] md:h-[300px] md:w-[300px]">
            <PetStage className="h-full w-full" species={pet.species} anim={anim} accessory={pet.accessory} mood={mood} pedestal={false} sparkles={false} camera={[0, 1.2, 5.6]} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
