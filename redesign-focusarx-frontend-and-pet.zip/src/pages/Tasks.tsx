import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Minus, Play, Plus, Trash2 } from "lucide-react";
import { useStore, type Priority } from "../lib/store";
import { minutesLabel } from "../lib/format";
import { AnimatedNumber, Bar, Button, Empty, EASE, Segmented, SPRING } from "../components/ui";
import { TaskCheck } from "../components/TaskCheck";
import { sfx } from "../lib/sound";
import type { Route } from "../lib/ui";
import { cn } from "../utils/cn";

const PRI: Record<Priority, { label: string; color: string }> = {
  high: { label: "High", color: "#fb7185" },
  med: { label: "Medium", color: "#fbbf24" },
  low: { label: "Low", color: "#38bdf8" },
};

export default function Tasks({ go }: { go: (r: Route) => void }) {
  const tasks = useStore((s) => s.tasks);
  const { addTask, toggleTask, removeTask, setTimerTask } = useStore.getState();
  const [title, setTitle] = useState("");
  const [priority, setPriority] = useState<Priority>("med");
  const [est, setEst] = useState(1);
  const [filter, setFilter] = useState<"open" | "done" | "all">("open");

  const open = tasks.filter((t) => !t.done);
  const done = tasks.filter((t) => t.done);
  const shown = (filter === "open" ? open : filter === "done" ? done : tasks).slice().sort((a, b) => {
    if (a.done !== b.done) return a.done ? 1 : -1;
    const o = { high: 0, med: 1, low: 2 };
    return o[a.priority] - o[b.priority] || b.createdAt - a.createdAt;
  });
  const totalEst = open.reduce((n, t) => n + t.est, 0);
  const pct = tasks.length ? done.length / tasks.length : 0;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    addTask(title, priority, est);
    sfx("pop");
    setTitle("");
    setEst(1);
    setFilter("open");
  };

  return (
    <div className="mx-auto w-full max-w-[860px] px-4 pb-14 pt-2 md:px-8">
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: EASE }} className="mb-6 flex items-end justify-between gap-6">
        <div>
          <div className="eyebrow">Plan</div>
          <h1 className="font-display mt-1 text-[34px] font-extrabold tracking-tight">Tasks</h1>
          <p className="mt-1 text-[14px] text-ink-3">
            <AnimatedNumber value={open.length} duration={0.6} /> open · about <AnimatedNumber value={totalEst} duration={0.6} /> focus {totalEst === 1 ? "session" : "sessions"} of work
          </p>
        </div>
        <div className="hidden w-52 sm:block">
          <div className="mb-1.5 flex justify-between text-[11.5px] font-semibold text-ink-3"><span>Completed</span><span className="num">{done.length}/{tasks.length}</span></div>
          <Bar value={pct} color="#34d399" height={7} />
        </div>
      </motion.div>

      <motion.form onSubmit={submit} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.06, ease: EASE }} className="panel mb-6 p-3 md:p-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-center">
          <input className="field !border-transparent !bg-transparent !px-3 !py-2.5 !text-[15px] md:flex-1" placeholder="What needs doing?" value={title} onChange={(e) => setTitle(e.target.value)} />
          <div className="flex flex-wrap items-center gap-2 px-1">
            <Segmented size="sm" id="pri" value={priority} onChange={setPriority} options={(["low", "med", "high"] as Priority[]).map((p) => ({ value: p, label: PRI[p].label }))} />
            <div className="flex items-center gap-1 rounded-full border border-white/[0.06] bg-white/[0.04] p-0.5" title="Estimated focus sessions">
              <button type="button" aria-label="Fewer" onClick={() => setEst((e) => Math.max(1, e - 1))} className="grid h-7 w-7 place-items-center rounded-full text-ink-3 hover:bg-white/10 hover:text-ink"><Minus size={13} /></button>
              <span className="num w-9 text-center text-xs font-semibold">{est} × 25</span>
              <button type="button" aria-label="More" onClick={() => setEst((e) => Math.min(12, e + 1))} className="grid h-7 w-7 place-items-center rounded-full text-ink-3 hover:bg-white/10 hover:text-ink"><Plus size={13} /></button>
            </div>
            <Button type="submit" variant="primary" disabled={!title.trim()}>Add task</Button>
          </div>
        </div>
      </motion.form>

      <div className="mb-3 flex items-center justify-between">
        <Segmented id="tf" value={filter} onChange={setFilter} options={[{ value: "open", label: `Open · ${open.length}` }, { value: "done", label: `Done · ${done.length}` }, { value: "all", label: "All" }]} />
      </div>

      <div className="space-y-2">
        <AnimatePresence mode="popLayout" initial={false}>
          {shown.map((t) => (
            <motion.div
              key={t.id}
              layout
              initial={{ opacity: 0, y: 16, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, x: -40, scale: 0.95 }}
              transition={{ ...SPRING, opacity: { duration: 0.25 } }}
              className="group panel-flat flex items-center gap-3.5 px-4 py-3.5 transition-colors hover:bg-surface-2"
            >
              <TaskCheck done={t.done} onToggle={() => { toggleTask(t.id); sfx(t.done ? "tap" : "pop"); }} color={PRI[t.priority].color} />
              <div className="min-w-0 flex-1">
                <div className={cn("truncate text-[15px] font-semibold transition-all duration-500", t.done && "text-ink-4 line-through decoration-white/20")}>{t.title}</div>
                <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-[12px] text-ink-3">
                  <span className="flex items-center gap-1.5"><span className="h-1.5 w-1.5 rounded-full" style={{ background: PRI[t.priority].color }} />{PRI[t.priority].label}</span>
                  <span>{t.est} × 25 min planned</span>
                  {t.focusMin > 0 && <span className="text-brand-300">{minutesLabel(t.focusMin)} focused</span>}
                </div>
              </div>
              {!t.done && (
                <Button size="sm" variant="secondary" className="opacity-100 md:opacity-0 md:group-hover:opacity-100 focus-visible:opacity-100" onClick={() => { setTimerTask(t.id); go("focus"); }}>
                  <Play size={12} fill="currentColor" /> Focus
                </Button>
              )}
              <button onClick={() => removeTask(t.id)} aria-label="Delete task" className="grid h-8 w-8 place-items-center rounded-full text-ink-4 opacity-100 transition-all hover:bg-rose/10 hover:text-rose md:opacity-0 md:group-hover:opacity-100">
                <Trash2 size={15} />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
        {shown.length === 0 && (
          <Empty
            title={filter === "done" ? "Nothing completed yet" : "Nothing here"}
            body={filter === "done" ? "Finish a task and it will show up here." : "Add your first task above, then start a focus session on it."}
          />
        )}
      </div>
    </div>
  );
}
