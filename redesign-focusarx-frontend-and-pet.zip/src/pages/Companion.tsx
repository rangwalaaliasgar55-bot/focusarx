import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Cookie, Gamepad2, Heart, MoonStar, Pencil, Plus, Swords } from "lucide-react";
import { useStore, useActivePet } from "../lib/store";
import { ACCESSORIES, ELEMENT_COLOR, SPECIES, TREATS, petXpNeeded, statsFor, type TreatId } from "../lib/pets";
import { Bar, Button, Chip, EASE, SPRING, rise, stagger } from "../components/ui";
import { PetStage } from "../components/pet/PetStage";
import { PetAvatar } from "../components/pet/PetAvatar";
import { mkAnim, type PetAnim } from "../components/pet/Pet3D";
import type { ParticleAPI } from "../components/pet/Particles";
import { sfx } from "../lib/sound";
import { useUI, type Route } from "../lib/ui";
import { uid } from "../lib/format";
import { cn } from "../utils/cn";

export default function Companion({ go }: { go: (r: Route) => void }) {
  const s = useStore();
  const pet = useActivePet();
  const sp = SPECIES[pet.species];
  const color = ELEMENT_COLOR[sp.element];
  const stats = statsFor(pet.species, pet.level);
  const toast = useUI((u) => u.toast);

  const [anim, setAnim] = useState<PetAnim>(() => mkAnim("wave"));
  const [asleep, setAsleep] = useState(false);
  const [treat, setTreat] = useState<TreatId>("kibble");
  const [hearts, setHearts] = useState<{ id: string; x: number }[]>([]);
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(pet.name);
  const fx = useRef<ParticleAPI>(null);
  const lastPlay = useRef(0);

  useEffect(() => { setName(pet.name); setAsleep(false); setAnim(mkAnim("wave")); }, [pet.id, pet.name]);

  const mood = pet.hunger < 25 ? "hungry" : pet.joy < 30 ? "sad" : "happy";
  const moodText = asleep ? "Sleeping soundly" : mood === "happy" ? "Content and curious" : mood === "hungry" ? "Hungry" : "Feeling lonely";

  const burst = (c: string, n = 26) => fx.current?.emit({ pos: [0, 1.1, 0.3], count: n, color: c, speed: 2.4, life: 1.0, size: 0.06, gravity: -0.5, spread: 1 });

  const addHeart = () => {
    const id = uid();
    setHearts((h) => [...h.slice(-8), { id, x: 40 + Math.random() * 20 }]);
    setTimeout(() => setHearts((h) => h.filter((x) => x.id !== id)), 1800);
  };

  const pat = () => {
    if (asleep) { setAsleep(false); setAnim(mkAnim("wave")); return; }
    s.patPet(pet.id);
    setAnim(mkAnim("happy"));
    addHeart();
    burst("#fb7185", 10);
    sfx("pop");
  };

  const feed = () => {
    if (pet.hunger > 96) { toast({ title: `${pet.name} is full`, body: "Try playing instead." }); return; }
    if (!s.feedPet(pet.id, treat)) { toast({ title: "Out of that treat", body: "Pick another, or buy more in the shop.", tone: "warn" }); return; }
    setAsleep(false);
    setAnim(mkAnim("eat"));
    sfx("pop");
    setTimeout(() => { setAnim(mkAnim("happy")); addHeart(); burst("#fbbf24", 18); }, 1700);
  };

  const play = () => {
    if (Date.now() - lastPlay.current < 1500) return;
    lastPlay.current = Date.now();
    setAsleep(false);
    s.playWithPet(pet.id);
    setAnim(mkAnim("victory"));
    burst(color, 40);
    addHeart();
    sfx("boost");
  };

  const nap = () => {
    setAsleep((a) => {
      setAnim(mkAnim(a ? "wave" : "sleep"));
      return !a;
    });
  };

  const bars = [
    { l: "Fullness", v: pet.hunger / 100, c: "#fb923c" },
    { l: "Joy", v: pet.joy / 100, c: "#fb7185" },
  ];
  const maxStat = { hp: 260, atk: 90, def: 75, spd: 70 };

  return (
    <div className="mx-auto w-full max-w-[1240px] px-4 pb-14 pt-1 md:px-8">
      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.25fr)_minmax(0,1fr)]">
        {/* stage */}
        <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, ease: EASE }} className="panel relative h-[520px] overflow-hidden lg:sticky lg:top-1 lg:h-[calc(100vh-110px)] lg:min-h-[560px]">
          <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at 50% 90%, ${color}33, transparent 62%), radial-gradient(ellipse at 50% 0%, rgba(255,255,255,0.05), transparent 60%)` }} />
          <PetStage
            className="absolute inset-0 cursor-grab active:cursor-grabbing"
            species={pet.species} anim={asleep ? mkAnim("sleep") : anim} accessory={pet.accessory} mood={mood}
            interactive onPetClick={pat} fxRef={fx} camera={[0, 1.6, 6.3]} target={[0, 0.95, 0]} petScale={1.08}
          />
          {/* hearts */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            <AnimatePresence>
              {hearts.map((h) => (
                <motion.div key={h.id} initial={{ opacity: 0, y: 0, scale: 0.4 }} animate={{ opacity: [0, 1, 0], y: -200, scale: [0.4, 1.1, 0.9] }} transition={{ duration: 1.7, ease: "easeOut" }} className="absolute bottom-[42%] text-rose" style={{ left: `${h.x}%` }}>
                  <Heart size={26} fill="currentColor" />
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          <div className="absolute left-5 top-5 flex items-center gap-2">
            <Chip color={color}>{sp.element}</Chip>
            <Chip>{moodText}</Chip>
          </div>
          <div className="absolute right-5 top-5 hidden text-[11px] text-ink-4 sm:block">Drag to rotate · tap to pet</div>

          {/* dock */}
          <div className="absolute inset-x-0 bottom-5 flex justify-center px-4">
            <div className="glass flex items-center gap-1.5 rounded-[26px] p-2">
              {[
                { icon: Cookie, label: "Feed", on: feed },
                { icon: Gamepad2, label: "Play", on: play },
                { icon: Heart, label: "Pet", on: pat },
                { icon: MoonStar, label: asleep ? "Wake" : "Nap", on: nap },
              ].map((a) => {
                const Icon = a.icon;
                return (
                  <motion.button key={a.label} whileHover={{ y: -3 }} whileTap={{ scale: 0.9 }} transition={SPRING} onClick={a.on} className="flex w-[74px] flex-col items-center gap-1 rounded-[20px] py-2.5 text-[11.5px] font-semibold text-ink-2 transition-colors hover:bg-white/[0.08] hover:text-ink">
                    <Icon size={21} />
                    {a.label}
                  </motion.button>
                );
              })}
            </div>
          </div>
        </motion.div>

        {/* info */}
        <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-4">
          <motion.div variants={rise} className="panel p-5 md:p-6">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="eyebrow">{sp.name} · {sp.rarity}</div>
                {editing ? (
                  <form onSubmit={(e) => { e.preventDefault(); s.renamePet(pet.id, name); setEditing(false); }} className="mt-1 flex gap-2">
                    <input autoFocus maxLength={14} className="field !w-48 !py-1.5 font-display text-xl font-extrabold" value={name} onChange={(e) => setName(e.target.value)} onBlur={() => { s.renamePet(pet.id, name); setEditing(false); }} />
                    <Button type="submit" size="sm" variant="primary"><Check size={14} /></Button>
                  </form>
                ) : (
                  <button onClick={() => setEditing(true)} className="group mt-1 flex items-center gap-2">
                    <h1 className="font-display truncate text-[34px] font-extrabold leading-none tracking-tight">{pet.name}</h1>
                    <Pencil size={14} className="text-ink-4 opacity-0 transition-opacity group-hover:opacity-100" />
                  </button>
                )}
                <p className="mt-2 max-w-md text-[13.5px] leading-relaxed text-ink-3">{sp.blurb}</p>
              </div>
              <div className="shrink-0 text-right">
                <div className="eyebrow">Level</div>
                <div className="font-display text-[38px] font-extrabold leading-none" style={{ color }}>{pet.level}</div>
              </div>
            </div>
            <div className="mt-5">
              <div className="mb-1.5 flex justify-between text-[11.5px] font-semibold text-ink-3"><span>Experience</span><span className="num">{pet.xp} / {petXpNeeded(pet.level)} XP</span></div>
              <Bar value={pet.xp / petXpNeeded(pet.level)} color={color} height={8} />
              <p className="mt-2 text-[12px] text-ink-4">Your companion earns 5 XP for every focused minute while it's active.</p>
            </div>
            <div className="mt-5 grid grid-cols-2 gap-4">
              {bars.map((b) => (
                <div key={b.l}>
                  <div className="mb-1.5 flex justify-between text-[11.5px] font-semibold text-ink-3"><span>{b.l}</span><span className="num">{Math.round(b.v * 100)}%</span></div>
                  <Bar value={b.v} color={b.c} />
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div variants={rise} className="panel p-5 md:p-6">
            <div className="mb-4 flex items-center justify-between">
              <div className="font-display text-[16px] font-bold">Pantry</div>
              <button onClick={() => go("shop")} className="flex items-center gap-1 text-[12px] font-semibold text-brand-300 hover:text-brand-400"><Plus size={13} />Get more</button>
            </div>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
              {TREATS.map((t) => {
                const n = s.treats[t.id];
                const sel = treat === t.id;
                return (
                  <button key={t.id} onClick={() => setTreat(t.id)} disabled={n <= 0 && t.id !== "kibble"} className={cn("relative rounded-2xl border px-3 py-3 text-left transition-all duration-300 disabled:opacity-35", sel ? "border-brand-400/50 bg-brand-500/10" : "border-white/[0.07] bg-white/[0.03] hover:bg-white/[0.06]")}>
                    <div className="text-[13px] font-bold">{t.name}</div>
                    <div className="num mt-0.5 text-[11px] text-ink-3">{t.id === "kibble" ? "Unlimited" : `×${n}`}</div>
                    {sel && <motion.span layoutId="treatdot" className="absolute right-2.5 top-2.5 h-2 w-2 rounded-full bg-brand-400" />}
                  </button>
                );
              })}
            </div>
          </motion.div>

          <motion.div variants={rise} className="panel p-5 md:p-6">
            <div className="mb-4 font-display text-[16px] font-bold">Battle stats</div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-4">
              {(["hp", "atk", "def", "spd"] as const).map((k) => (
                <div key={k}>
                  <div className="mb-1.5 flex justify-between text-[11.5px] font-semibold text-ink-3"><span className="uppercase tracking-wider">{k}</span><span className="num text-ink">{stats[k]}</span></div>
                  <Bar value={stats[k] / maxStat[k]} color={color} />
                </div>
              ))}
            </div>
            <div className="mt-5 space-y-2">
              {sp.moves.map((m) => (
                <div key={m.id} className="flex items-center gap-3 rounded-xl bg-white/[0.035] px-3.5 py-2.5">
                  <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: ELEMENT_COLOR[m.element], boxShadow: `0 0 10px ${ELEMENT_COLOR[m.element]}` }} />
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] font-bold">{m.name}</div>
                    <div className="truncate text-[11.5px] text-ink-3">{m.desc}</div>
                  </div>
                  <div className="num shrink-0 text-right text-[11px] font-semibold text-ink-3">
                    {m.kind === "attack" ? `${m.power} pwr` : m.kind}<br />
                    {m.cost === 0 ? "free" : `${m.cost} energy`}
                  </div>
                </div>
              ))}
            </div>
            <Button variant="secondary" className="mt-5 w-full" onClick={() => go("arena")}><Swords size={16} /> Take {pet.name} to the Arena</Button>
          </motion.div>

          <motion.div variants={rise} className="panel p-5 md:p-6">
            <div className="mb-3 font-display text-[16px] font-bold">Wardrobe</div>
            <div className="flex flex-wrap gap-2">
              <button onClick={() => s.equip(pet.id, null)} className={cn("rounded-full border px-3.5 py-1.5 text-[12.5px] font-semibold transition-colors", !pet.accessory ? "border-brand-400/50 bg-brand-500/10 text-brand-300" : "border-white/[0.08] text-ink-3 hover:text-ink")}>None</button>
              {ACCESSORIES.filter((a) => s.accessories.includes(a.id)).map((a) => (
                <button key={a.id} onClick={() => { s.equip(pet.id, a.id); setAnim(mkAnim("happy")); sfx("pop"); }} className={cn("rounded-full border px-3.5 py-1.5 text-[12.5px] font-semibold transition-colors", pet.accessory === a.id ? "border-brand-400/50 bg-brand-500/10 text-brand-300" : "border-white/[0.08] text-ink-3 hover:text-ink")}>{a.name}</button>
              ))}
              <button onClick={() => go("shop")} className="rounded-full border border-dashed border-white/15 px-3.5 py-1.5 text-[12.5px] font-semibold text-ink-4 hover:text-ink-2">+ More</button>
            </div>
          </motion.div>

          <motion.div variants={rise} className="panel p-5 md:p-6">
            <div className="mb-3 font-display text-[16px] font-bold">Your companions</div>
            <div className="flex flex-wrap gap-3">
              {s.pets.map((p) => (
                <button key={p.id} onClick={() => s.setActivePet(p.id)} className="group relative flex w-[92px] flex-col items-center gap-1 rounded-2xl p-2.5 transition-colors hover:bg-white/[0.05]">
                  {p.id === pet.id && <motion.span layoutId="petsel" transition={SPRING} className="absolute inset-0 rounded-2xl border border-white/20 bg-white/[0.06]" />}
                  <span className="relative"><PetAvatar species={p.species} size={54} /></span>
                  <span className="relative max-w-full truncate text-[12px] font-bold">{p.name}</span>
                  <span className="relative text-[10.5px] text-ink-3">Lv {p.level}</span>
                </button>
              ))}
              <button onClick={() => go("shop")} className="flex w-[92px] flex-col items-center justify-center gap-1 rounded-2xl border border-dashed border-white/12 p-2.5 text-ink-4 transition-colors hover:text-ink-2">
                <Plus size={22} />
                <span className="text-[11px] font-semibold">Adopt</span>
              </button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}
