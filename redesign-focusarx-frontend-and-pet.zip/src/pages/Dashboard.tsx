import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, Flame, Play, Target, Timer as TimerIcon, Zap } from "lucide-react";
import { useStore, useActivePet, minutesOnDay, streakOf } from "../lib/store";
import { dailyMissions } from "../lib/missions";
import { dailyMinutes, heatmap, inRange } from "../lib/stats";
import { greeting, levelFromXp, minutesLabel, startOfDay, weekdayShort } from "../lib/format";
import { petXpNeeded, SPECIES } from "../lib/pets";
import { AnimatedNumber, Bar, Button, Chip, Empty, Ring, SectionTitle, rise, stagger } from "../components/ui";
import { BarChart, Heatmap } from "../components/charts";
import { TaskCheck } from "../components/TaskCheck";
import { PetStage } from "../components/pet/PetStage";
import { mkAnim, type PetAnim } from "../components/pet/Pet3D";
import type { Route } from "../lib/ui";
import { cn } from "../utils/cn";

function Card({ className, children, delay }: { className?: string; children: React.ReactNode; delay?: number }) {
  return (
    <motion.div variants={rise} custom={delay} className={cn("panel p-5 md:p-6", className)}>
      {children}
    </motion.div>
  );
}

export default function Dashboard({ go }: { go: (r: Route) => void }) {
  const s = useStore();
  const pet = useActivePet();
  const [anim, setAnim] = useState<PetAnim>(() => mkAnim("wave"));
  const now = Date.now();
  const todayMin = minutesOnDay(s.sessions, now);
  const streak = streakOf(s.sessions);
  const week = useMemo(() => dailyMinutes(s.sessions, 7), [s.sessions]);
  const weekTotal = week.reduce((n, d) => n + d.minutes, 0);
  const weekSessions = inRange(s.sessions, 7);
  const avgScore = weekSessions.length ? Math.round(weekSessions.reduce((n, x) => n + x.score, 0) / weekSessions.length) : 0;
  const goalMin = s.settings.weeklyGoalH * 60;
  const dailyGoal = goalMin / 7;
  const cols = useMemo(() => heatmap(s.sessions, 20), [s.sessions]);
  const lv = levelFromXp(s.xp);
  const openTasks = s.tasks.filter((t) => !t.done).slice(0, 4);
  const missions = dailyMissions(
    { sessions: s.sessions, tasks: s.tasks, battles: s.battles, pets: s.pets, daily: s.daily, accountLevel: lv.level },
    pet.name
  ).slice(0, 4);
  const mood = pet.hunger < 25 ? "hungry" : pet.joy < 30 ? "sad" : "happy";

  const quick = (m: number) => {
    const st = useStore.getState();
    if (st.timer.status === "idle") {
      st.setMode("focus");
      st.setDurationMin(m);
      st.startTimer();
    }
    go("focus");
  };

  const hint =
    todayMin === 0
      ? "Nothing logged yet today. One 25-minute session is a good start."
      : todayMin < dailyGoal
      ? `${minutesLabel(Math.max(0, dailyGoal - todayMin))} to go for today's share of your weekly goal.`
      : "You've hit today's share of your weekly goal. Anything more is a bonus.";

  return (
    <div className="mx-auto w-full max-w-[1240px] px-4 pb-12 pt-1 md:px-8">
      {s.hasSample && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="mb-4 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/[0.07] bg-white/[0.03] px-4 py-3 text-[13px] text-ink-2">
          <span>You're viewing sample history so the charts have something to show. Your own sessions mix in as you go.</span>
          <Button size="sm" variant="secondary" onClick={() => s.clearSample()}>Clear sample data</Button>
        </motion.div>
      )}

      <motion.div variants={stagger} initial="hidden" animate="show" className="grid grid-cols-12 gap-4">
        {/* hero */}
        <motion.div variants={rise} className="panel relative col-span-12 overflow-hidden p-6 md:p-8 lg:col-span-8">
          <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-brand-500/25 blur-[90px]" />
          <div className="pointer-events-none absolute -bottom-32 left-10 h-64 w-64 rounded-full bg-nova/10 blur-[90px]" />
          <div className="relative flex flex-col justify-between gap-8 md:flex-row md:items-center">
            <div className="max-w-md">
              <div className="eyebrow">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</div>
              <h1 className="font-display mt-2 text-[34px] font-extrabold leading-[1.05] tracking-tight md:text-[44px]">
                {greeting()},<br />
                <span className="shimmer-text">{s.settings.name}</span>
              </h1>
              <p className="mt-3 text-[14.5px] leading-relaxed text-ink-2">{hint}</p>
              <div className="mt-6 flex flex-wrap items-center gap-2">
                <Button variant="primary" size="lg" onClick={() => quick(s.settings.focusMin)}>
                  <Play size={17} fill="currentColor" /> Start {s.settings.focusMin} min
                </Button>
                {[15, 45].map((m) => (
                  <Button key={m} variant="secondary" size="lg" onClick={() => quick(m)}>
                    {m}m
                  </Button>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-6 self-center">
              <Ring value={weekTotal / goalMin} size={148} stroke={11} color="url(#g)">
                <div className="text-center">
                  <div className="font-display text-[30px] font-extrabold leading-none">
                    <AnimatedNumber value={weekTotal / 60} format={(n) => n.toFixed(1)} />
                    <span className="text-base text-ink-3">h</span>
                  </div>
                  <div className="eyebrow mt-1.5 !text-[10px]">of {s.settings.weeklyGoalH}h goal</div>
                </div>
              </Ring>
              <svg width="0" height="0">
                <defs>
                  <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#b4b5ff" />
                    <stop offset="100%" stopColor="#6466f1" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </motion.div>

        {/* companion */}
        <motion.div variants={rise} className="panel relative col-span-12 flex flex-col overflow-hidden !p-0 lg:col-span-4 lg:row-span-2">
          <div className="relative min-h-[320px] flex-1">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_90%,rgba(123,124,255,0.2),transparent_65%)]" />
            <PetStage className="absolute inset-0" species={pet.species} anim={anim} accessory={pet.accessory} mood={mood} follow onPetClick={() => setAnim(mkAnim("happy"))} camera={[0, 1.4, 5.5]} />
            <div className="absolute left-5 top-5 flex gap-2">
              <Chip color="#c084fc">Lv {pet.level}</Chip>
              <Chip>{SPECIES[pet.species].name}</Chip>
            </div>
          </div>
          <div className="space-y-4 p-5">
            <div className="flex items-end justify-between">
              <div>
                <div className="font-display text-xl font-extrabold">{pet.name}</div>
                <div className="text-[12.5px] text-ink-3">
                  {mood === "happy" ? "Feeling great — focus together." : mood === "hungry" ? "Getting hungry. Time for a snack." : "Could use some attention."}
                </div>
              </div>
              <Button size="sm" variant="secondary" onClick={() => go("companion")}>
                Visit <ArrowRight size={14} />
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="mb-1.5 flex justify-between text-[11px] font-semibold text-ink-3"><span>Fullness</span><span className="num">{Math.round(pet.hunger)}%</span></div>
                <Bar value={pet.hunger / 100} color="#fb923c" />
              </div>
              <div>
                <div className="mb-1.5 flex justify-between text-[11px] font-semibold text-ink-3"><span>Joy</span><span className="num">{Math.round(pet.joy)}%</span></div>
                <Bar value={pet.joy / 100} color="#fb7185" />
              </div>
            </div>
            <div>
              <div className="mb-1.5 flex justify-between text-[11px] font-semibold text-ink-3"><span>XP to level {pet.level + 1}</span><span className="num">{pet.xp} / {petXpNeeded(pet.level)}</span></div>
              <Bar value={pet.xp / petXpNeeded(pet.level)} color="#c084fc" />
            </div>
          </div>
        </motion.div>

        {/* stat tiles */}
        <motion.div variants={rise} className="col-span-12 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:col-span-8">
          {[
            { icon: <Flame size={16} className="text-ember" />, label: "Streak", value: streak, fmt: (n: number) => `${Math.round(n)}`, unit: streak === 1 ? "day" : "days" },
            { icon: <TimerIcon size={16} className="text-brand-300" />, label: "Today", value: todayMin, fmt: (n: number) => `${Math.round(n)}`, unit: "min" },
            { icon: <Zap size={16} className="text-volt" />, label: "Sessions · 7d", value: weekSessions.length, fmt: (n: number) => `${Math.round(n)}`, unit: "" },
            { icon: <Target size={16} className="text-leaf" />, label: "Avg score", value: avgScore, fmt: (n: number) => `${Math.round(n)}`, unit: "/100" },
          ].map((t) => (
            <div key={t.label} className="panel p-4 md:p-5">
              <div className="flex items-center gap-2 text-[12px] font-semibold text-ink-3">{t.icon}{t.label}</div>
              <div className="font-display mt-3 text-[32px] font-extrabold leading-none">
                <AnimatedNumber value={t.value} format={t.fmt} />
                <span className="ml-1 text-sm font-semibold text-ink-3">{t.unit}</span>
              </div>
            </div>
          ))}
        </motion.div>

        {/* week chart */}
        <Card className="col-span-12 lg:col-span-7">
          <SectionTitle title="This week" sub={`${minutesLabel(weekTotal)} focused · daily target ${minutesLabel(dailyGoal)}`} action={<Button size="sm" variant="ghost" onClick={() => go("analytics")}>Analytics <ArrowRight size={14} /></Button>} />
          <BarChart
            height={190}
            goal={dailyGoal}
            data={week.map((d, i) => ({
              label: i === 6 ? "Today" : weekdayShort(d.ts),
              value: d.minutes,
              tip: `${new Date(d.ts).toLocaleDateString(undefined, { weekday: "long" })} · ${d.minutes ? minutesLabel(d.minutes) : "no focus"}`,
              highlight: d.ts === startOfDay(),
            }))}
          />
        </Card>

        {/* tasks */}
        <Card className="col-span-12 lg:col-span-5">
          <SectionTitle title="Up next" action={<Button size="sm" variant="ghost" onClick={() => go("tasks")}>All tasks <ArrowRight size={14} /></Button>} />
          {openTasks.length === 0 ? (
            <Empty title="You're all caught up" body="Add a task to plan your next focus session." action={<Button size="sm" variant="secondary" onClick={() => go("tasks")}>Add a task</Button>} />
          ) : (
            <div className="-mx-2 space-y-0.5">
              {openTasks.map((t) => (
                <div key={t.id} className="group flex items-center gap-3 rounded-2xl px-2 py-2.5 transition-colors hover:bg-white/[0.04]">
                  <TaskCheck done={t.done} onToggle={() => s.toggleTask(t.id)} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[14px] font-semibold">{t.title}</div>
                    <div className="text-[11.5px] text-ink-3">{t.est} × focus · {minutesLabel(t.focusMin)} logged</div>
                  </div>
                  <button
                    onClick={() => { s.setTimerTask(t.id); go("focus"); }}
                    className="grid h-8 w-8 place-items-center rounded-full bg-white/[0.06] text-ink-2 opacity-0 transition-all hover:bg-brand-500 hover:text-white group-hover:opacity-100 focus-visible:opacity-100"
                    aria-label={`Focus on ${t.title}`}
                  >
                    <Play size={13} fill="currentColor" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* heatmap */}
        <Card className="col-span-12 lg:col-span-8">
          <SectionTitle title="Consistency" sub="Every square is a day. Darker means deeper." />
          <Heatmap cols={cols} />
        </Card>

        {/* missions */}
        <Card className="col-span-12 lg:col-span-4">
          <SectionTitle title="Today's missions" action={<Button size="sm" variant="ghost" onClick={() => go("missions")}>All <ArrowRight size={14} /></Button>} />
          <div className="space-y-4">
            {missions.map((m) => {
              const done = m.progress >= m.target;
              return (
                <div key={m.id}>
                  <div className="mb-1.5 flex items-center justify-between text-[13px]">
                    <span className={cn("font-semibold", done && "text-ink-3 line-through decoration-white/20")}>{m.title}</span>
                    <span className="num text-[11.5px] text-ink-3">{Math.round(m.progress)}/{m.target}{m.unit ? ` ${m.unit}` : ""}</span>
                  </div>
                  <Bar value={m.progress / m.target} color={done ? "#34d399" : "#7b7cff"} />
                </div>
              );
            })}
          </div>
          <div className="mt-5 flex items-center justify-between rounded-2xl bg-white/[0.04] px-4 py-3 text-[12.5px] text-ink-2">
            <span>Account level <b className="text-ink">{lv.level}</b></span>
            <span className="num">{lv.need - Math.round(lv.into)} XP to next</span>
          </div>
        </Card>
      </motion.div>
      <p className="mt-6 text-center text-[11.5px] text-ink-4">Everything is stored on this device. No account required.</p>
    </div>
  );
}
