import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowDown, ArrowUp, Coins, Flag, Shield, Swords, Ticket, Trophy, Zap } from "lucide-react";
import { useStore } from "../lib/store";
import { DIFFICULTIES, ENEMY_NAMES, MAX_ENERGY, Battle, makeFighter, type Difficulty, type Side, type Fighter } from "../lib/battle";
import { ELEMENT_COLOR, SPECIES, SPECIES_LIST, effectiveness, statsFor, type Move, type SpeciesId } from "../lib/pets";
import { AnimatedNumber, Button, Chip, EASE, SPRING, rise, stagger } from "../components/ui";
import { PetStage } from "../components/pet/PetStage";
import { PetAvatar } from "../components/pet/PetAvatar";
import { ArenaScene, type ArenaHandle } from "../components/pet/ArenaScene";
import { mkAnim, type PetAnim } from "../components/pet/Pet3D";
import { sfx } from "../lib/sound";
import { useUI, type Route } from "../lib/ui";
import { cn } from "../utils/cn";

interface Foe {
  species: SpeciesId;
  name: string;
  level: number;
  diff: Difficulty;
}

interface Snap {
  hp: number; maxHp: number; energy: number; guard: boolean; boost: number;
}
const snapOf = (f: Fighter): Snap => ({ hp: f.hp, maxHp: f.maxHp, energy: f.energy, guard: f.guard, boost: f.boost });
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function hpColor(p: number) {
  return p > 0.5 ? "#34d399" : p > 0.25 ? "#fbbf24" : "#fb7185";
}

function pickFoes(playerLevel: number, avoid?: SpeciesId): Foe[] {
  const pool = SPECIES_LIST.map((s) => s.id).filter((id) => id !== avoid);
  const shuffled = [...pool].sort(() => Math.random() - 0.5);
  return DIFFICULTIES.map((d, i) => {
    const species = shuffled[i % shuffled.length];
    const names = ENEMY_NAMES[species];
    return { species, name: names[Math.floor(Math.random() * names.length)], level: Math.max(1, playerLevel + d.delta), diff: d.id };
  });
}

/* ───────────── HUD pieces ───────────── */
function FighterCard({ f, snap, align }: { f: Fighter; snap: Snap; align: "left" | "right" }) {
  const sp = SPECIES[f.species];
  const pct = Math.max(0, snap.hp / snap.maxHp);
  return (
    <motion.div
      initial={{ opacity: 0, x: align === "left" ? -40 : 40 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ ...SPRING, delay: 0.2 }}
      className="glass w-[min(46vw,300px)] rounded-[22px] p-3 md:p-4"
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex min-w-0 items-center gap-2">
          <span className="truncate font-display text-[14px] font-extrabold md:text-[16px]">{f.name}</span>
          <span className="num text-[11px] font-semibold text-ink-3">Lv {f.level}</span>
        </div>
        <span className="hidden sm:block"><Chip color={ELEMENT_COLOR[sp.element]}>{sp.element}</Chip></span>
      </div>
      <div className="relative mt-2.5 h-2.5 overflow-hidden rounded-full bg-white/[0.08]">
        <motion.div className="absolute inset-y-0 left-0 rounded-full bg-white/40" initial={false} animate={{ width: `${pct * 100}%` }} transition={{ duration: 1.1, delay: 0.35, ease: EASE }} />
        <motion.div className="absolute inset-y-0 left-0 rounded-full" initial={false} animate={{ width: `${pct * 100}%`, backgroundColor: hpColor(pct) }} transition={{ duration: 0.55, ease: EASE }} />
      </div>
      <div className="mt-1.5 flex items-center justify-between">
        <span className="num text-[11px] font-semibold text-ink-2"><AnimatedNumber value={snap.hp} duration={0.6} /> / {snap.maxHp}</span>
        <div className="flex items-center gap-1.5">
          {snap.guard && <Shield size={13} className="text-aqua" />}
          {snap.boost > 0 && <ArrowUp size={13} className="text-volt" />}
          <div className="flex gap-[3px]">
            {Array.from({ length: MAX_ENERGY }, (_, i) => (
              <motion.span key={i} animate={{ backgroundColor: i < snap.energy ? "#facc15" : "rgba(255,255,255,0.14)", scale: i < snap.energy ? 1 : 0.85 }} className="h-2 w-2 rounded-[3px]" />
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function MoveButton({ m, idx, disabled, energy, foe, onUse }: { m: Move; idx: number; disabled: boolean; energy: number; foe: SpeciesId; onUse: () => void }) {
  const afford = energy >= m.cost;
  const color = ELEMENT_COLOR[m.element];
  const eff = m.kind === "attack" ? effectiveness(m.element, SPECIES[foe].element) : 1;
  return (
    <motion.button
      whileHover={!disabled && afford ? { y: -4, scale: 1.02 } : undefined}
      whileTap={!disabled && afford ? { scale: 0.96 } : undefined}
      transition={SPRING}
      disabled={disabled || !afford}
      onClick={onUse}
      className={cn("relative overflow-hidden rounded-[20px] border p-3 text-left transition-[opacity,border-color] duration-300 md:p-3.5", disabled || !afford ? "border-white/[0.05] bg-white/[0.03] opacity-45" : "border-white/[0.12] bg-white/[0.07] hover:border-white/25")}
    >
      <span className="pointer-events-none absolute -right-6 -top-6 h-20 w-20 rounded-full blur-2xl" style={{ background: color, opacity: afford && !disabled ? 0.28 : 0.08 }} />
      <div className="relative flex items-center justify-between gap-2">
        <span className="flex items-center gap-1.5 truncate text-[13px] font-bold md:text-[14px]">
          <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: color }} />
          <span className="truncate">{m.name}</span>
        </span>
        <kbd className="hidden rounded border border-white/10 px-1 font-mono text-[10px] text-ink-4 md:block">{idx + 1}</kbd>
      </div>
      <div className="relative mt-1.5 flex items-center justify-between text-[11px] font-semibold text-ink-3">
        <span className="flex items-center gap-1">
          {m.kind === "attack" ? <>Power {m.power}</> : m.kind === "heal" ? <>Heal {m.power}%</> : m.kind === "guard" ? <>Guard</> : <>+40% ATK</>}
          {eff > 1 && <ArrowUp size={11} className="text-leaf" />}
          {eff < 1 && <ArrowDown size={11} className="text-rose" />}
        </span>
        <span className="flex items-center gap-0.5" style={{ color: afford ? "#facc15" : "#fb7185" }}>
          <Zap size={11} fill="currentColor" />
          {m.cost}
        </span>
      </div>
    </motion.button>
  );
}

/* ───────────── Page ───────────── */
type Phase = "lobby" | "fight";

export default function Arena({ go }: { go: (r: Route) => void }) {
  const s = useStore();
  const toast = useUI((u) => u.toast);
  const [phase, setPhase] = useState<Phase>("lobby");
  const [petId, setPetId] = useState(s.activePetId);
  const pet = s.pets.find((p) => p.id === petId) ?? s.pets[0];
  const [foes, setFoes] = useState<Foe[]>(() => pickFoes(pet.level, pet.species));
  const [foeIdx, setFoeIdx] = useState(1);
  const [practice, setPractice] = useState(false);
  const [lobbyAnim] = useState<PetAnim>(() => mkAnim("wave"));

  // battle state
  const [fightKey, setFightKey] = useState(0);
  const arena = useRef<ArenaHandle>(null);
  const battle = useRef<Battle | null>(null);
  const alive = useRef(true);
  const [snaps, setSnaps] = useState<{ player: Snap; enemy: Snap } | null>(null);
  const [turn, setTurn] = useState<Side>("player");
  const [busy, setBusy] = useState(true);
  const [msg, setMsg] = useState("");
  const [round, setRound] = useState(1);
  const [intro, setIntro] = useState(true);
  const [result, setResult] = useState<null | { won: boolean; coins: number; xp: number; leveled: number | null; forfeit: boolean }>(null);
  const [foe, setFoe] = useState<Foe | null>(null);
  const practiceRef = useRef(false);
  const foeRef = useRef<Foe | null>(null);
  const petRef = useRef(pet);
  petRef.current = pet;

  useEffect(() => { alive.current = true; return () => { alive.current = false; }; }, []);
  useEffect(() => { setFoes(pickFoes(pet.level, pet.species)); }, [petId]); // eslint-disable-line react-hooks/exhaustive-deps

  const sync = useCallback(() => {
    const b = battle.current;
    if (!b) return;
    setSnaps({ player: snapOf(b.player), enemy: snapOf(b.enemy) });
    setRound(b.round);
  }, []);

  const finish = useCallback(async (winner: Side, forfeit = false) => {
    const won = winner === "player";
    const f = foeRef.current!;
    const d = DIFFICULTIES.find((x) => x.id === f.diff)!;
    const isPractice = practiceRef.current;
    const coins = isPractice ? 0 : won ? Math.round(d.coins * (1 + f.level * 0.04)) : 8;
    const xp = isPractice ? 6 : won ? 30 + f.level * 8 : 12;
    const r = useStore.getState().recordBattle({ won, practice: isPractice, petId: petRef.current.id, enemy: f.name, enemySpecies: f.species, enemyLevel: f.level, coins }, xp);
    sfx(won ? "win" : "lose");
    if (!alive.current) return;
    setResult({ won, coins, xp, leveled: r.leveled, forfeit });
  }, []);

  const nextTurn = useCallback(async () => {
    const b = battle.current;
    if (!b || !alive.current || b.winner) return;
    const side = b.turn;
    b.beginTurn(side);
    arena.current?.setGuard(side, false);
    sync();
    setTurn(side);
    if (side === "player") {
      setMsg(`Your move, ${b.player.name}`);
      setBusy(false);
    } else {
      setBusy(true);
      setMsg(`${b.enemy.name} is thinking…`);
      await sleep(900);
      if (!alive.current) return;
      await perform("enemy", b.chooseEnemyMove());
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const perform = useCallback(async (side: Side, idx: number) => {
    const b = battle.current;
    const a = arena.current;
    if (!b || !a || !alive.current) return;
    setBusy(true);
    const me = b.fighter(side);
    const def: Side = side === "player" ? "enemy" : "player";
    const ev = b.act(side, idx);
    const m = ev.move;
    setMsg(`${me.name} used ${m.name}!`);
    sync();

    if (m.kind === "attack") {
      await a.attack(side, m);
      if (!alive.current) return;
      if (ev.hit) {
        a.setGuard(def, false);
        a.impact(def, { dmg: ev.dmg, crit: ev.crit, eff: ev.eff, element: m.element, big: !!m.big });
        sync();
        setMsg(ev.crit ? "A critical hit!" : ev.eff > 1 ? "It's super effective!" : ev.eff < 1 ? "It's not very effective…" : `${ev.dmg} damage`);
        if (ev.fainted) {
          await sleep(500);
          a.faint(def);
          setMsg(`${b.fighter(def).name} is out!`);
          await sleep(1300);
          a.victory(side);
          await sleep(1800);
          await finish(side);
          return;
        }
      } else {
        a.miss(def);
        setMsg(`${b.fighter(def).name} dodged!`);
      }
    } else if (m.kind === "heal") {
      a.selfCast(side, "heal", m.element);
      a.heal(side, ev.heal);
      setMsg(`${me.name} recovered ${ev.heal} HP`);
    } else if (m.kind === "guard") {
      a.selfCast(side, "guard", m.element);
      a.setGuard(side, true);
      setMsg(`${me.name} braces for impact`);
    } else {
      a.selfCast(side, "boost", m.element);
      setMsg(`${me.name}'s power surges`);
    }
    sync();
    await sleep(1100);
    if (!alive.current) return;
    void nextTurn();
  }, [finish, nextTurn, sync]);

  const startBattle = (isPractice: boolean) => {
    const f = foes[foeIdx];
    if (!isPractice && !useStore.getState().spendTicket()) {
      toast({ title: "No battle tickets", body: "Finish a 15+ minute focus session or buy tickets in the shop.", tone: "warn" });
      return;
    }
    practiceRef.current = isPractice;
    setPractice(isPractice);
    foeRef.current = f;
    setFoe(f);
    const pf = makeFighter("player", pet.species, pet.level, pet.name);
    const ef = makeFighter("enemy", f.species, f.level, f.name);
    battle.current = new Battle(pf, ef);
    setSnaps({ player: snapOf(pf), enemy: snapOf(ef) });
    setResult(null);
    setIntro(true);
    setBusy(true);
    setMsg("");
    setRound(1);
    setFightKey((k) => k + 1);
    setPhase("fight");
    sfx("boost");
    setTimeout(() => alive.current && setIntro(false), 2100);
    setTimeout(() => alive.current && void nextTurn(), 2600);
  };

  const leave = () => {
    battle.current = null;
    setPhase("lobby");
    setResult(null);
    setFoes(pickFoes(pet.level, pet.species));
  };

  const useMove = (i: number) => {
    const b = battle.current;
    if (!b || busy || b.turn !== "player" || b.winner || !b.canUse("player", i)) return;
    void perform("player", i);
  };

  const forfeit = () => {
    const b = battle.current;
    if (!b || result) return;
    b.winner = "enemy";
    void finish("enemy", true);
  };

  useEffect(() => {
    if (phase !== "fight") return;
    const k = (e: KeyboardEvent) => {
      if (["1", "2", "3", "4"].includes(e.key)) useMove(+e.key - 1);
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }); // eslint-disable-line react-hooks/exhaustive-deps

  const wins = s.battles.filter((b) => b.won && !b.practice).length;
  const losses = s.battles.filter((b) => !b.won && !b.practice).length;
  const recent = useMemo(() => [...s.battles].reverse().slice(0, 5), [s.battles]);
  const selected = foes[foeIdx];
  const myStats = statsFor(pet.species, pet.level);

  /* ───────── FIGHT ───────── */
  if (phase === "fight" && battle.current && snaps) {
    const b = battle.current;
    return (
      <div className="relative h-full min-h-[520px] w-full overflow-hidden bg-[#07070c] md:rounded-tl-[28px]">
        <ArenaScene key={fightKey} className="absolute inset-0" handleRef={arena} player={pet.species} enemy={foe!.species} playerAcc={pet.accessory} />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/60 to-transparent" />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-72 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />

        {/* top HUD */}
        <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3 md:p-5">
          <FighterCard f={b.player} snap={snaps.player} align="left" />
          <div className="mt-1 flex flex-col items-center gap-2">
            <div className="glass rounded-full px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-widest text-ink-2">Round {round}</div>
            {practice && <span className="text-[10px] font-bold uppercase tracking-widest text-ink-3">Practice</span>}
            <button onClick={forfeit} className="pointer-events-auto flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-semibold text-ink-3 transition-colors hover:bg-white/10 hover:text-rose"><Flag size={12} />Forfeit</button>
          </div>
          <FighterCard f={b.enemy} snap={snaps.enemy} align="right" />
        </div>

        {/* bottom HUD */}
        <div className="absolute inset-x-0 bottom-0 mx-auto w-full max-w-[860px] p-3 md:p-5">
          <div className="mb-3 flex justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={msg}
                initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -8, filter: "blur(4px)" }}
                transition={{ duration: 0.28, ease: EASE }}
                className="glass rounded-full px-5 py-2 text-center text-[13.5px] font-semibold md:text-[15px]"
              >
                {msg || "…"}
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="grid grid-cols-2 gap-2 md:grid-cols-4 md:gap-3">
            {b.player.moves.map((m, i) => (
              <MoveButton key={m.id} m={m} idx={i} disabled={busy || turn !== "player" || !!b.winner} energy={snaps.player.energy} foe={foe!.species} onUse={() => useMove(i)} />
            ))}
          </div>
        </div>

        {/* VS intro */}
        <AnimatePresence>
          {intro && (
            <motion.div className="absolute inset-0 z-30 grid place-items-center bg-[#07070c]/85 backdrop-blur-xl" initial={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.6 }}>
              <div className="flex w-full max-w-3xl items-center justify-between px-6">
                <motion.div initial={{ x: -200, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ type: "spring", stiffness: 120, damping: 18 }} className="text-center">
                  <PetAvatar species={pet.species} size={130} />
                  <div className="font-display mt-2 text-2xl font-extrabold">{pet.name}</div>
                  <div className="text-[12px] font-semibold text-ink-3">Lv {pet.level}</div>
                </motion.div>
                <motion.div initial={{ scale: 3, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 200, damping: 14, delay: 0.5 }} className="font-display text-[64px] font-black italic tracking-tighter text-white/90">VS</motion.div>
                <motion.div initial={{ x: 200, opacity: 0 }} animate={{ x: 0, opacity: 1 }} transition={{ type: "spring", stiffness: 120, damping: 18, delay: 0.2 }} className="text-center">
                  <PetAvatar species={foe!.species} size={130} />
                  <div className="font-display mt-2 text-2xl font-extrabold">{foe!.name}</div>
                  <div className="text-[12px] font-semibold text-ink-3">Lv {foe!.level} · {SPECIES[foe!.species].element}</div>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* result */}
        <AnimatePresence>
          {result && (
            <motion.div className="absolute inset-0 z-40 grid place-items-center p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="absolute inset-0 bg-black/60 backdrop-blur-xl" />
              <motion.div initial={{ opacity: 0, y: 40, scale: 0.9 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ type: "spring", stiffness: 220, damping: 22, delay: 0.1 }} className="glass relative w-full max-w-sm rounded-[32px] p-7 text-center">
                <motion.div initial={{ scale: 0, rotate: -30 }} animate={{ scale: 1, rotate: 0 }} transition={{ type: "spring", stiffness: 260, damping: 14, delay: 0.3 }} className={cn("mx-auto grid h-16 w-16 place-items-center rounded-full", result.won ? "bg-volt/15 text-volt" : "bg-white/10 text-ink-3")}>
                  {result.won ? <Trophy size={30} /> : <Swords size={28} />}
                </motion.div>
                <div className="eyebrow mt-4">{result.forfeit ? "Forfeited" : practice ? "Practice bout" : "Battle result"}</div>
                <h2 className="font-display mt-1 text-[36px] font-extrabold leading-none">{result.won ? "Victory" : "Defeat"}</h2>
                <p className="mx-auto mt-2 max-w-[260px] text-[13.5px] text-ink-2">
                  {result.won ? `${pet.name} outplayed ${foe!.name}. Nicely done.` : `${foe!.name} won this one. Check type matchups and use Guard when low.`}
                </p>
                <div className="mt-5 flex justify-center gap-3">
                  {result.coins > 0 && (
                    <div className="rounded-2xl bg-white/[0.06] px-4 py-3">
                      <div className="flex items-center justify-center gap-1.5 font-display text-xl font-extrabold text-volt"><Coins size={16} />+<AnimatedNumber value={result.coins} /></div>
                      <div className="eyebrow mt-1 !text-[10px]">Coins</div>
                    </div>
                  )}
                  <div className="rounded-2xl bg-white/[0.06] px-4 py-3">
                    <div className="font-display text-xl font-extrabold text-brand-300">+<AnimatedNumber value={result.xp} /></div>
                    <div className="eyebrow mt-1 !text-[10px]">{pet.name} XP</div>
                  </div>
                </div>
                {result.leveled && <div className="mx-auto mt-3 w-fit rounded-full border border-brand-400/30 bg-brand-500/15 px-3 py-1 text-xs font-bold text-brand-300">{pet.name} reached level {result.leveled}!</div>}
                <div className="mt-6 flex flex-col gap-2">
                  <Button variant="primary" size="lg" onClick={() => { const t = useStore.getState().tickets; if (!practice && t <= 0) { toast({ title: "No tickets left", tone: "warn" }); leave(); return; } leave(); setTimeout(() => startBattle(practice), 50); }}>
                    Rematch {practice ? "(free)" : <><Ticket size={15} />1</>}
                  </Button>
                  <Button variant="ghost" onClick={leave}>Back to lobby</Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  /* ───────── LOBBY ───────── */
  return (
    <div className="mx-auto w-full max-w-[1200px] px-4 pb-14 pt-1 md:px-8">
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: EASE }} className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="eyebrow">Turn-based 3D battles</div>
          <h1 className="font-display mt-1 text-[34px] font-extrabold tracking-tight">Arena</h1>
          <p className="mt-1 max-w-lg text-[14px] text-ink-3">Manage energy, read type matchups and outsmart your rival. Every 15+ minute focus session earns a ticket.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="panel-flat flex items-center gap-2 px-4 py-2 text-[13px] font-semibold"><Ticket size={15} className="text-nova" /><AnimatedNumber value={s.tickets} duration={0.5} /> tickets</div>
          <div className="panel-flat px-4 py-2 text-[13px] font-semibold"><span className="text-leaf">{wins}W</span> <span className="text-ink-4">·</span> <span className="text-rose">{losses}L</span></div>
        </div>
      </motion.div>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)]">
        {/* my fighter */}
        <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.7, ease: EASE }} className="panel relative overflow-hidden">
          <div className="relative h-[360px]">
            <div className="absolute inset-0" style={{ background: `radial-gradient(ellipse at 50% 90%, ${ELEMENT_COLOR[SPECIES[pet.species].element]}33, transparent 62%)` }} />
            <PetStage className="absolute inset-0" species={pet.species} accessory={pet.accessory} anim={lobbyAnim} interactive camera={[0, 1.45, 5.5]} />
            <div className="absolute left-5 top-5 flex gap-2"><Chip color={ELEMENT_COLOR[SPECIES[pet.species].element]}>{SPECIES[pet.species].element}</Chip><Chip>Lv {pet.level}</Chip></div>
          </div>
          <div className="space-y-4 p-5">
            <div className="flex items-center justify-between">
              <div className="font-display text-xl font-extrabold">{pet.name}</div>
              <div className="num flex gap-3 text-[12px] font-semibold text-ink-3">
                <span>HP <b className="text-ink">{myStats.hp}</b></span><span>ATK <b className="text-ink">{myStats.atk}</b></span><span>DEF <b className="text-ink">{myStats.def}</b></span><span>SPD <b className="text-ink">{myStats.spd}</b></span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {s.pets.map((p) => (
                <button key={p.id} onClick={() => setPetId(p.id)} className={cn("relative flex items-center gap-2 rounded-full border py-1 pl-1 pr-3 text-[12.5px] font-semibold transition-colors", p.id === pet.id ? "border-white/25 bg-white/[0.08]" : "border-white/[0.07] text-ink-3 hover:text-ink")}>
                  <PetAvatar species={p.species} size={26} />{p.name}<span className="text-ink-4">Lv{p.level}</span>
                </button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-2">
              {SPECIES[pet.species].moves.map((m) => (
                <div key={m.id} className="flex items-center gap-2 rounded-xl bg-white/[0.035] px-3 py-2 text-[12px]">
                  <span className="h-2 w-2 rounded-full" style={{ background: ELEMENT_COLOR[m.element] }} />
                  <span className="truncate font-semibold">{m.name}</span>
                  <span className="ml-auto flex items-center text-volt"><Zap size={10} fill="currentColor" />{m.cost}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* opponents */}
        <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-4">
          <motion.div variants={rise} className="space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="font-display text-[16px] font-bold">Choose your opponent</div>
              <button onClick={() => setFoes(pickFoes(pet.level, pet.species))} className="text-[12px] font-semibold text-brand-300 hover:text-brand-400">Shuffle</button>
            </div>
            {foes.map((f, i) => {
              const d = DIFFICULTIES.find((x) => x.id === f.diff)!;
              const color = ELEMENT_COLOR[SPECIES[f.species].element];
              const edge = effectiveness(SPECIES[pet.species].element === "dragon" ? "dragon" : SPECIES[pet.species].element, SPECIES[f.species].element);
              const sel = foeIdx === i;
              return (
                <button key={i} onClick={() => setFoeIdx(i)} className={cn("relative flex w-full items-center gap-4 rounded-[22px] border p-4 text-left transition-colors duration-300", sel ? "border-white/25 bg-surface-2" : "border-white/[0.07] bg-surface-1 hover:bg-surface-2")}>
                  {sel && <motion.span layoutId="foesel" transition={SPRING} className="absolute inset-0 rounded-[22px]" style={{ boxShadow: `0 0 0 1px ${color}66, 0 24px 48px -28px ${color}` }} />}
                  <div className="relative grid h-[72px] w-[72px] shrink-0 place-items-center rounded-2xl bg-white/[0.04]"><PetAvatar species={f.species} size={56} /></div>
                  <div className="relative min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-display text-[17px] font-extrabold">{f.name}</span>
                      <Chip color={color}>{SPECIES[f.species].element}</Chip>
                    </div>
                    <div className="mt-0.5 text-[12.5px] text-ink-3">{d.label} · Lv {f.level} · {d.blurb}</div>
                    <div className="mt-1.5 text-[11.5px] font-semibold">
                      {edge > 1 ? <span className="text-leaf">You have the type edge</span> : edge < 1 ? <span className="text-rose">Type disadvantage</span> : <span className="text-ink-4">Even matchup</span>}
                    </div>
                  </div>
                  <div className="relative shrink-0 text-right">
                    <div className="flex items-center justify-end gap-1 font-display text-[17px] font-extrabold text-volt"><Coins size={14} />{Math.round(d.coins * (1 + f.level * 0.04))}</div>
                    <div className="text-[11px] text-ink-4">on win</div>
                  </div>
                </button>
              );
            })}
          </motion.div>

          <motion.div variants={rise} className="flex flex-col gap-2 sm:flex-row">
            <Button variant="primary" size="lg" className="flex-1" onClick={() => startBattle(false)}>
              <Swords size={18} /> Battle {selected?.name} · <Ticket size={15} />1
            </Button>
            <Button variant="secondary" size="lg" onClick={() => startBattle(true)}>Practice (free)</Button>
          </motion.div>
          {s.tickets === 0 && (
            <motion.div variants={rise} className="flex items-center justify-between rounded-2xl border border-white/[0.07] bg-white/[0.03] px-4 py-3 text-[13px] text-ink-2">
              Out of tickets — a 15+ minute focus session earns one.
              <div className="flex gap-2"><Button size="sm" variant="secondary" onClick={() => go("focus")}>Focus</Button><Button size="sm" variant="secondary" onClick={() => go("shop")}>Shop</Button></div>
            </motion.div>
          )}

          <motion.div variants={rise} className="panel p-5">
            <div className="mb-3 font-display text-[15px] font-bold">Type advantages</div>
            <div className="grid grid-cols-1 gap-x-6 gap-y-1.5 text-[12.5px] sm:grid-cols-2">
              {[
                ["fire", "nature"], ["water", "fire · dragon"], ["nature", "water"], ["electric", "water · cosmic"], ["cosmic", "dragon"], ["dragon", "cosmic · electric"],
              ].map(([a, b]) => (
                <div key={a} className="flex items-center gap-2 text-ink-3">
                  <span className="h-2 w-2 rounded-full" style={{ background: ELEMENT_COLOR[a as keyof typeof ELEMENT_COLOR] }} />
                  <span className="font-semibold capitalize text-ink-2">{a}</span>
                  <span>beats</span>
                  <span className="capitalize">{b}</span>
                </div>
              ))}
            </div>
            <p className="mt-3 text-[12px] leading-relaxed text-ink-4">Energy starts at 2 and refills by 1 each turn (max 5). Free moves keep you in the fight; save 3 energy for a finisher.</p>
          </motion.div>

          {recent.length > 0 && (
            <motion.div variants={rise} className="panel p-5">
              <div className="mb-3 font-display text-[15px] font-bold">Recent battles</div>
              <div className="space-y-2">
                {recent.map((r) => (
                  <div key={r.id} className="flex items-center gap-3 text-[13px]">
                    <span className={cn("w-9 rounded-md py-0.5 text-center text-[11px] font-bold", r.won ? "bg-leaf/15 text-leaf" : "bg-rose/15 text-rose")}>{r.won ? "WIN" : "LOSS"}</span>
                    <span className="font-semibold">vs {r.enemy}</span>
                    <span className="text-ink-4">Lv {r.enemyLevel}{r.practice ? " · practice" : ""}</span>
                    <span className="num ml-auto text-ink-3">{r.coins ? `+${r.coins}` : ""}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
