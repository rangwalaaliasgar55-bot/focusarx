import { motion } from "framer-motion";
import { Check, Coins, Lock, Trophy } from "lucide-react";
import { useStore, useActivePet } from "../lib/store";
import { achievements, dailyMissions, type Mission } from "../lib/missions";
import { dateKey, levelFromXp } from "../lib/format";
import { Bar, Button, EASE, SectionTitle, rise, stagger } from "../components/ui";
import { sfx } from "../lib/sound";
import { useUI, type Route } from "../lib/ui";
import { cn } from "../utils/cn";

function Row({ m, claimKey, accent }: { m: Mission; claimKey: string; accent: string }) {
  const claimed = useStore((s) => !!s.claimed[claimKey]);
  const claim = useStore((s) => s.claim);
  const done = m.progress >= m.target;
  return (
    <motion.div variants={rise} className={cn("panel-flat flex items-center gap-4 p-4 transition-colors", done && !claimed && "border-brand-500/30 bg-brand-500/[0.06]")}>
      <div className={cn("grid h-11 w-11 shrink-0 place-items-center rounded-2xl", claimed ? "bg-leaf/15 text-leaf" : done ? "bg-brand-500/20 text-brand-300" : "bg-white/[0.05] text-ink-4")}>
        {claimed ? <Check size={19} /> : done ? <Trophy size={18} /> : <Lock size={16} />}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-baseline justify-between gap-3">
          <div className="truncate text-[14.5px] font-bold">{m.title}</div>
          <div className="num shrink-0 text-[11.5px] text-ink-3">{Math.round(m.progress)}/{m.target}{m.unit ? ` ${m.unit}` : ""}</div>
        </div>
        <div className="mb-2 mt-0.5 text-[12.5px] text-ink-3">{m.desc}</div>
        <Bar value={m.progress / m.target} color={claimed ? "#34d399" : accent} height={5} />
      </div>
      <div className="w-[92px] shrink-0 text-right">
        {claimed ? (
          <span className="text-[12px] font-semibold text-ink-4">Claimed</span>
        ) : done ? (
          <Button size="sm" variant="primary" onClick={() => { claim(claimKey, m.reward); sfx("buy"); useUI.getState().toast({ title: `+${m.reward} coins`, body: m.title, tone: "success" }); }}>
            Claim
          </Button>
        ) : (
          <span className="inline-flex items-center gap-1 text-[13px] font-bold text-volt"><Coins size={14} />{m.reward}</span>
        )}
      </div>
    </motion.div>
  );
}

export default function Missions({ go }: { go: (r: Route) => void }) {
  const s = useStore();
  const pet = useActivePet();
  const lv = levelFromXp(s.xp);
  const snap = { sessions: s.sessions, tasks: s.tasks, battles: s.battles, pets: s.pets, daily: s.daily, accountLevel: lv.level };
  const daily = dailyMissions(snap, pet.name);
  const ach = achievements(snap);
  const today = dateKey();
  const dailyDone = daily.filter((d) => s.claimed[`${today}:${d.id}`]).length;
  const achDone = ach.filter((a) => s.claimed[a.id]).length;

  return (
    <div className="mx-auto w-full max-w-[920px] px-4 pb-14 pt-2 md:px-8">
      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, ease: EASE }} className="mb-7">
        <div className="eyebrow">Goals</div>
        <h1 className="font-display mt-1 text-[34px] font-extrabold tracking-tight">Missions</h1>
        <p className="mt-1 text-[14px] text-ink-3">Daily missions reset at midnight. Achievements are forever.</p>
      </motion.div>

      <SectionTitle title="Today" sub={`${dailyDone} of ${daily.length} claimed`} action={<Button size="sm" variant="secondary" onClick={() => go("focus")}>Start focusing</Button>} />
      <motion.div variants={stagger} initial="hidden" animate="show" className="mb-10 space-y-2.5">
        {daily.map((m) => <Row key={m.id} m={m} claimKey={`${today}:${m.id}`} accent="#7b7cff" />)}
      </motion.div>

      <SectionTitle title="Achievements" sub={`${achDone} of ${ach.length} claimed`} />
      <motion.div variants={stagger} initial="hidden" animate="show" className="space-y-2.5">
        {ach.map((m) => <Row key={m.id} m={m} claimKey={m.id} accent="#fbbf24" />)}
      </motion.div>
    </div>
  );
}
