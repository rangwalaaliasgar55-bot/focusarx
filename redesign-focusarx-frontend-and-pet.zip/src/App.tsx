import { lazy, Suspense } from "react";
import { Shell, useGlobalEngine } from "./components/Shell";
import { useRoute, type Route } from "./lib/ui";
import Dashboard from "./pages/Dashboard";
import Focus from "./pages/Focus";
import Tasks from "./pages/Tasks";
import Analytics from "./pages/Analytics";
import Shop from "./pages/Shop";
import Missions from "./pages/Missions";

// 3D-heavy pages are split out so the first paint stays quick
const Companion = lazy(() => import("./pages/Companion"));
const Arena = lazy(() => import("./pages/Arena"));

function Loading() {
  return (
    <div className="grid h-full place-items-center">
      <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/10 border-t-brand-400" />
    </div>
  );
}

export default function App() {
  const [route, go] = useRoute();
  useGlobalEngine(route);

  const page: Record<Route, React.ReactNode> = {
    dashboard: <Dashboard go={go} />,
    focus: <Focus go={go} />,
    tasks: <Tasks go={go} />,
    analytics: <Analytics />,
    companion: <Companion go={go} />,
    arena: <Arena go={go} />,
    shop: <Shop />,
    missions: <Missions go={go} />,
  };

  return (
    <Shell route={route} go={go}>
      <Suspense fallback={<Loading />}>{page[route]}</Suspense>
    </Shell>
  );
}
