export type Element = "fire" | "water" | "nature" | "electric" | "cosmic" | "dragon";
export type MoveElement = Element | "normal";
export type SpeciesId = "emberfox" | "bubbo" | "sprout" | "zappy" | "lunix" | "drakeling";
export type AccessoryId = "headphones" | "partyhat" | "glasses" | "bowtie" | "crown";
export type Rarity = "Starter" | "Common" | "Rare" | "Epic";

export const ELEMENT_COLOR: Record<MoveElement, string> = {
  fire: "#ff8a3d",
  water: "#38bdf8",
  nature: "#4ade80",
  electric: "#facc15",
  cosmic: "#c084fc",
  dragon: "#fb7185",
  normal: "#e5e7eb",
};

export const ELEMENT_LABEL: Record<MoveElement, string> = {
  fire: "Fire",
  water: "Water",
  nature: "Nature",
  electric: "Electric",
  cosmic: "Cosmic",
  dragon: "Dragon",
  normal: "Normal",
};

/** attacker element -> defenders it is strong against */
const ADVANTAGE: Partial<Record<MoveElement, Element[]>> = {
  fire: ["nature"],
  nature: ["water"],
  water: ["fire", "dragon"],
  electric: ["water", "cosmic"],
  cosmic: ["dragon"],
  dragon: ["cosmic", "electric"],
};

export function effectiveness(attack: MoveElement, defend: Element): number {
  if (ADVANTAGE[attack]?.includes(defend)) return 1.5;
  if (ADVANTAGE[defend]?.includes(attack as Element)) return 0.7;
  return 1;
}

export type MoveKind = "attack" | "guard" | "heal" | "boost";
export interface Move {
  id: string;
  name: string;
  element: MoveElement;
  kind: MoveKind;
  style: "melee" | "ranged" | "self";
  power: number;
  accuracy: number;
  cost: number;
  desc: string;
  big?: boolean;
}

export interface Look {
  fur: string;
  belly: string;
  accent: string;
  inner: string;
  cheek: string;
  eye: string;
  earTip?: string;
  muzzle?: string;
  wing?: string;
  ears: "pointy" | "round" | "long" | "none";
  tail: "fluffy" | "bolt" | "fin" | "dragon" | "moon" | "ball";
  extras: ("cheekfluff" | "flame" | "gills" | "sprout" | "wings" | "horns" | "star" | "spikes" | "orbs" | "bubbles")[];
  body: [number, number, number];
}

export interface Species {
  id: SpeciesId;
  name: string;
  element: Element;
  rarity: Rarity;
  price: number;
  blurb: string;
  base: { hp: number; atk: number; def: number; spd: number };
  moves: Move[];
  look: Look;
}

export const SPECIES: Record<SpeciesId, Species> = {
  emberfox: {
    id: "emberfox",
    name: "Emberfox",
    element: "fire",
    rarity: "Starter",
    price: 0,
    blurb: "Warm, quick and fiercely loyal. Its tail burns brighter the longer you focus.",
    base: { hp: 70, atk: 26, def: 20, spd: 28 },
    look: {
      fur: "#ff8a3d", belly: "#ffe9cf", accent: "#fff6ea", inner: "#ffb38a", cheek: "#ff6b6b", eye: "#26150f",
      earTip: "#3a2218", muzzle: "#ffe9cf", ears: "pointy", tail: "fluffy", extras: ["cheekfluff", "flame"], body: [1, 1, 1],
    },
    moves: [
      { id: "pounce", name: "Quick Pounce", element: "normal", kind: "attack", style: "melee", power: 38, accuracy: 100, cost: 0, desc: "A fast tackle. Always available." },
      { id: "ember", name: "Ember Burst", element: "fire", kind: "attack", style: "ranged", power: 55, accuracy: 95, cost: 1, desc: "Hurls a fireball." },
      { id: "comet", name: "Inferno Comet", element: "fire", kind: "attack", style: "ranged", power: 100, accuracy: 80, cost: 3, big: true, desc: "A huge blazing comet." },
      { id: "cinder", name: "Cinder Guard", element: "fire", kind: "guard", style: "self", power: 0, accuracy: 100, cost: 1, desc: "Halves the next hit." },
    ],
  },
  bubbo: {
    id: "bubbo",
    name: "Bubbo",
    element: "water",
    rarity: "Common",
    price: 260,
    blurb: "A calm little axolotl who hums while you work and heals when you need a breather.",
    base: { hp: 82, atk: 22, def: 24, spd: 20 },
    look: {
      fur: "#52c7ff", belly: "#e0f6ff", accent: "#ff9ec4", inner: "#ffb3d1", cheek: "#ff9ec4", eye: "#0e2233",
      ears: "none", tail: "fin", extras: ["gills", "bubbles"], body: [1.04, 0.98, 1],
    },
    moves: [
      { id: "bonk", name: "Bubble Bonk", element: "normal", kind: "attack", style: "melee", power: 36, accuracy: 100, cost: 0, desc: "A bouncy headbutt." },
      { id: "aqua", name: "Aqua Jet", element: "water", kind: "attack", style: "ranged", power: 54, accuracy: 95, cost: 1, desc: "A pressurised stream." },
      { id: "tidal", name: "Tidal Crash", element: "water", kind: "attack", style: "ranged", power: 98, accuracy: 80, cost: 3, big: true, desc: "Summons a crushing wave." },
      { id: "mist", name: "Healing Mist", element: "water", kind: "heal", style: "self", power: 38, accuracy: 100, cost: 2, desc: "Restores 38% HP." },
    ],
  },
  sprout: {
    id: "sprout",
    name: "Sprout",
    element: "nature",
    rarity: "Common",
    price: 260,
    blurb: "A leafy bunny that photosynthesises your good habits into pure power.",
    base: { hp: 74, atk: 24, def: 22, spd: 26 },
    look: {
      fur: "#92e07f", belly: "#f6ffe3", accent: "#2fa84f", inner: "#dcffb8", cheek: "#ffb4a8", eye: "#14260f",
      muzzle: "#f6ffe3", ears: "long", tail: "ball", extras: ["sprout"], body: [1, 1, 1],
    },
    moves: [
      { id: "tackle", name: "Leaf Tackle", element: "normal", kind: "attack", style: "melee", power: 38, accuracy: 100, cost: 0, desc: "A springy body slam." },
      { id: "razor", name: "Razor Leaf", element: "nature", kind: "attack", style: "ranged", power: 54, accuracy: 95, cost: 1, desc: "Spinning blades of leaf." },
      { id: "solar", name: "Solar Beam", element: "nature", kind: "attack", style: "ranged", power: 100, accuracy: 80, cost: 3, big: true, desc: "Gathers sunlight into a beam." },
      { id: "bloom", name: "Photosynthesis", element: "nature", kind: "boost", style: "self", power: 0, accuracy: 100, cost: 1, desc: "+40% attack for 3 turns." },
    ],
  },
  zappy: {
    id: "zappy",
    name: "Zappy",
    element: "electric",
    rarity: "Rare",
    price: 340,
    blurb: "Pure static energy. Never sits still — except when it's time to focus.",
    base: { hp: 64, atk: 30, def: 18, spd: 34 },
    look: {
      fur: "#ffd23f", belly: "#fff4b8", accent: "#2b2118", inner: "#ffeaa0", cheek: "#ff5a5a", eye: "#2b2118",
      earTip: "#2b2118", muzzle: "#fff4b8", ears: "pointy", tail: "bolt", extras: [], body: [0.96, 1, 0.98],
    },
    moves: [
      { id: "zip", name: "Zip Strike", element: "normal", kind: "attack", style: "melee", power: 40, accuracy: 100, cost: 0, desc: "A blinding-fast dash." },
      { id: "spark", name: "Thunder Spark", element: "electric", kind: "attack", style: "ranged", power: 56, accuracy: 95, cost: 1, desc: "Calls down lightning." },
      { id: "storm", name: "Storm Surge", element: "electric", kind: "attack", style: "ranged", power: 104, accuracy: 78, cost: 3, big: true, desc: "A colossal thunderbolt." },
      { id: "charge", name: "Charge Up", element: "electric", kind: "boost", style: "self", power: 0, accuracy: 100, cost: 1, desc: "+40% attack for 3 turns." },
    ],
  },
  lunix: {
    id: "lunix",
    name: "Lunix",
    element: "cosmic",
    rarity: "Epic",
    price: 640,
    blurb: "Born between constellations. Orbs of starlight follow it everywhere.",
    base: { hp: 72, atk: 29, def: 24, spd: 27 },
    look: {
      fur: "#8d6bff", belly: "#ddd3ff", accent: "#ffe27a", inner: "#c8b9ff", cheek: "#ff9ad5", eye: "#140c33",
      wing: "#6f4de0", muzzle: "#ddd3ff", ears: "round", tail: "moon", extras: ["wings", "star", "orbs"], body: [1, 1, 1],
    },
    moves: [
      { id: "nudge", name: "Comet Nudge", element: "normal", kind: "attack", style: "melee", power: 38, accuracy: 100, cost: 0, desc: "A glancing starry bump." },
      { id: "star", name: "Starfall", element: "cosmic", kind: "attack", style: "ranged", power: 57, accuracy: 95, cost: 1, desc: "Rains down star fragments." },
      { id: "nova", name: "Supernova", element: "cosmic", kind: "attack", style: "ranged", power: 106, accuracy: 78, cost: 3, big: true, desc: "Detonates a tiny sun." },
      { id: "veil", name: "Void Veil", element: "cosmic", kind: "guard", style: "self", power: 0, accuracy: 100, cost: 1, desc: "Halves the next hit." },
    ],
  },
  drakeling: {
    id: "drakeling",
    name: "Drakeling",
    element: "dragon",
    rarity: "Epic",
    price: 1200,
    blurb: "A baby dragon with a very big attitude. Hoards focus minutes like gold.",
    base: { hp: 88, atk: 32, def: 26, spd: 24 },
    look: {
      fur: "#e5484d", belly: "#ffd98a", accent: "#ffd166", inner: "#ff9a8a", cheek: "#ff9a8a", eye: "#2a0d10",
      wing: "#ff7a59", muzzle: "#ffd98a", ears: "none", tail: "dragon", extras: ["horns", "wings", "spikes"], body: [1.04, 1.02, 1.06],
    },
    moves: [
      { id: "claw", name: "Claw Swipe", element: "normal", kind: "attack", style: "melee", power: 40, accuracy: 100, cost: 0, desc: "A quick slash." },
      { id: "breath", name: "Dragon Breath", element: "dragon", kind: "attack", style: "ranged", power: 58, accuracy: 95, cost: 1, desc: "A roaring jet of fire." },
      { id: "meteor", name: "Draco Meteor", element: "dragon", kind: "attack", style: "ranged", power: 110, accuracy: 76, cost: 3, big: true, desc: "Calls down a dragon-fire meteor." },
      { id: "rage", name: "Dragon Rage", element: "dragon", kind: "boost", style: "self", power: 0, accuracy: 100, cost: 1, desc: "+40% attack for 3 turns." },
    ],
  },
};

export const SPECIES_LIST = Object.values(SPECIES);

export function statsFor(id: SpeciesId, level: number) {
  const b = SPECIES[id].base;
  return {
    hp: Math.round(b.hp + level * 9),
    atk: Math.round(b.atk + level * 2.4),
    def: Math.round(b.def + level * 1.9),
    spd: Math.round(b.spd + level * 1.2),
  };
}

export function petXpNeeded(level: number) {
  return 60 + level * 45;
}

export interface Accessory {
  id: AccessoryId;
  name: string;
  price: number;
  blurb: string;
}
export const ACCESSORIES: Accessory[] = [
  { id: "headphones", name: "Focus Headphones", price: 90, blurb: "Noise-cancelling, naturally." },
  { id: "partyhat", name: "Party Hat", price: 70, blurb: "Every session is a celebration." },
  { id: "glasses", name: "Scholar Glasses", price: 120, blurb: "+10 to looking smart." },
  { id: "bowtie", name: "Velvet Bowtie", price: 100, blurb: "Dressed for deep work." },
  { id: "crown", name: "Golden Crown", price: 420, blurb: "For true focus royalty." },
];

export type TreatId = "kibble" | "biscuit" | "berry" | "cake";
export interface Treat {
  id: TreatId;
  name: string;
  price: number;
  hunger: number;
  joy: number;
  xp: number;
  blurb: string;
}
export const TREATS: Treat[] = [
  { id: "kibble", name: "Kibble", price: 0, hunger: 14, joy: 0, xp: 0, blurb: "Always free. Always fine." },
  { id: "biscuit", name: "Crunch Biscuit", price: 12, hunger: 32, joy: 4, xp: 4, blurb: "A reliable favourite." },
  { id: "berry", name: "Glow Berry", price: 22, hunger: 18, joy: 16, xp: 8, blurb: "Sweet, bright, joyful." },
  { id: "cake", name: "Star Cake", price: 48, hunger: 55, joy: 35, xp: 24, blurb: "A proper celebration." },
];
