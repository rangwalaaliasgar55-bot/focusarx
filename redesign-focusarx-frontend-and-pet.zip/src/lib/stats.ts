import { DAY, startOfDay } from "./format";
import type { Session } from "./store";

export function dailyMinutes(sessions: Session[], days: number) {
  const today = startOfDay();
  const out = Array.from({ length: days }, (_, i) => {
    const ts = today - (days - 1 - i) * DAY;
    return { ts, minutes: 0, sessions: 0, scoreSum: 0 };
  });
  const first = out[0].ts;
  for (const s of sessions) {
    const d = startOfDay(s.end);
    if (d < first || d > today) continue;
    const idx = Math.round((d - first) / DAY);
    out[idx].minutes += s.minutes;
    out[idx].sessions += 1;
    out[idx].scoreSum += s.score;
  }
  return out;
}

export function hourly(sessions: Session[]) {
  const h = Array(24).fill(0) as number[];
  for (const s of sessions) {
    // split minutes across the hours the session spans
    let t = s.start;
    while (t < s.end) {
      const hr = new Date(t).getHours();
      const next = Math.min(s.end, (Math.floor(t / 3600000) + 1) * 3600000);
      h[hr] += (next - t) / 60000;
      t = next;
    }
  }
  return h;
}

export function heatmap(sessions: Session[], weeks: number) {
  const today = startOfDay();
  const dow = (new Date(today).getDay() + 6) % 7; // Monday=0
  const end = today + (6 - dow) * DAY;
  const start = end - (weeks * 7 - 1) * DAY;
  const map = new Map<number, number>();
  for (const s of sessions) {
    const d = startOfDay(s.end);
    map.set(d, (map.get(d) ?? 0) + s.minutes);
  }
  const cols: { ts: number; minutes: number; future: boolean }[][] = [];
  for (let w = 0; w < weeks; w++) {
    const col = [];
    for (let d = 0; d < 7; d++) {
      const ts = start + (w * 7 + d) * DAY;
      col.push({ ts, minutes: map.get(ts) ?? 0, future: ts > today });
    }
    cols.push(col);
  }
  return cols;
}

export function taskBreakdown(sessions: Session[]) {
  const m = new Map<string, number>();
  for (const s of sessions) {
    const k = s.taskTitle ?? "Unassigned";
    m.set(k, (m.get(k) ?? 0) + s.minutes);
  }
  return [...m.entries()].map(([title, minutes]) => ({ title, minutes })).sort((a, b) => b.minutes - a.minutes);
}

export function inRange(sessions: Session[], days: number) {
  const from = startOfDay() - (days - 1) * DAY;
  return sessions.filter((s) => s.end >= from);
}
