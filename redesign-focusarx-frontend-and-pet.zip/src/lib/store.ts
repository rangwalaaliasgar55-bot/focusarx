import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DAY, clamp, dateKey, levelFromXp, startOfDay, uid } from "./format";
import { ACCESSORIES, SPECIES, TREATS, petXpNeeded, type AccessoryId, type SpeciesId, type TreatId } from "./pets";
import type { Ambient } from "./sound";

export type Mode = "focus" | "short" | "long";
export type Priority = "low" | "med" | "high";

export interface Task {
  id: string;
  title: string;
  priority: Priority;
  est: number;
  done: boolean;
  createdAt: number;
  doneAt?: number;
  focusMin: number;
}

export interface Session {
  id: string;
  start: number;
  end: number;
  minutes: number;
  planned: number;
  taskId?: string;
  taskTitle?: string;
  score: number;
  xp: number;
  coins: number;
  sample?: boolean;
}

export interface OwnedPet {
  id: string;
  species: SpeciesId;
  name: string;
  level: number;
  xp: number;
  hunger: number;
  joy: number;
  accessory: AccessoryId | null;
  adoptedAt: number;
  lastTick: number;
  wins: number;
}

export interface BattleRecord {
  id: string;
  at: number;
  won: boolean;
  practice: boolean;
  petId: string;
  enemy: string;
  enemySpecies: SpeciesId;
  enemyLevel: number;
  coins: number;
}

export interface TimerState {
  mode: Mode;
  status: "idle" | "running" | "paused";
  duration: number;
  remaining: number;
  endAt: number | null;
  startedAt: number | null;
  pauses: number;
  taskId: string | null;
  cycle: number;
}

export interface SessionResult {
  id: string;
  kind: Mode;
  minutes: number;
  score: number;
  xp: number;
  coins: number;
  ticket: boolean;
  petName: string;
  petLeveled: number | null;
  accountLevel: number | null;
  early: boolean;
  nextMode: Mode;
  streak: number;
}

export interface Settings {
  name: string;
  focusMin: number;
  shortMin: number;
  longMin: number;
  autoBreaks: boolean;
  chime: boolean;
  sound: Ambient;
  volume: number;
  weeklyGoalH: number;
}

interface State {
  timer: TimerState;
  lastResult: SessionResult | null;
  settings: Settings;
  tasks: Task[];
  sessions: Session[];
  xp: number;
  coins: number;
  tickets: number;
  pets: OwnedPet[];
  activePetId: string;
  treats: Record<TreatId, number>;
  accessories: AccessoryId[];
  battles: BattleRecord[];
  claimed: Record<string, true>;
  daily: { date: string; care: number };
  hasSample: boolean;
  seenWelcome: boolean;

  setMode: (m: Mode) => void;
  setDurationMin: (m: number) => void;
  setTimerTask: (id: string | null) => void;
  startTimer: () => void;
  pauseTimer: () => void;
  resetTimer: () => void;
  completeTimer: (early?: boolean) => void;
  dismissResult: () => void;
  updateSettings: (p: Partial<Settings>) => void;

  addTask: (title: string, priority: Priority, est: number) => void;
  toggleTask: (id: string) => void;
  removeTask: (id: string) => void;

  decayPets: () => void;
  feedPet: (petId: string, treat: TreatId) => boolean;
  playWithPet: (petId: string) => void;
  patPet: (petId: string) => void;
  renamePet: (petId: string, name: string) => void;
  equip: (petId: string, a: AccessoryId | null) => void;
  setActivePet: (petId: string) => void;
  adopt: (species: SpeciesId) => boolean;
  buyAccessory: (a: AccessoryId) => boolean;
  buyTreat: (t: TreatId, qty: number) => boolean;
  buyTickets: (qty: number, price: number) => boolean;

  spendTicket: () => boolean;
  recordBattle: (r: Omit<BattleRecord, "id" | "at">, petXp: number) => { leveled: number | null };

  claim: (key: string, coins: number) => void;
  clearSample: () => void;
  markWelcome: () => void;
  resetAll: () => void;
}

const DEFAULT_SETTINGS: Settings = {
  name: "Alex",
  focusMin: 25,
  shortMin: 5,
  longMin: 15,
  autoBreaks: false,
  chime: true,
  sound: "off",
  volume: 0.55,
  weeklyGoalH: 10,
};

function durationFor(mode: Mode, s: Settings) {
  return (mode === "focus" ? s.focusMin : mode === "short" ? s.shortMin : s.longMin) * 60;
}

function idleTimer(mode: Mode, s: Settings, keep?: Partial<TimerState>): TimerState {
  const d = durationFor(mode, s);
  return {
    mode,
    status: "idle",
    duration: d,
    remaining: d,
    endAt: null,
    startedAt: null,
    pauses: 0,
    taskId: keep?.taskId ?? null,
    cycle: keep?.cycle ?? 0,
  };
}

/* ---------- derived helpers ---------- */
export function minutesOnDay(sessions: Session[], day: number) {
  const a = startOfDay(day);
  return sessions.filter((s) => s.end >= a && s.end < a + DAY).reduce((n, s) => n + s.minutes, 0);
}

export function streakOf(sessions: Session[]) {
  const days = new Set(sessions.map((s) => dateKey(s.end)));
  let day = startOfDay();
  if (!days.has(dateKey(day))) day -= DAY;
  let n = 0;
  while (days.has(dateKey(day))) {
    n++;
    day -= DAY;
  }
  return n;
}

export function bestStreak(sessions: Session[]) {
  const keys = [...new Set(sessions.map((s) => startOfDay(s.end)))].sort((a, b) => a - b);
  let best = 0;
  let run = 0;
  let prev = -Infinity;
  for (const k of keys) {
    run = Math.round((k - prev) / DAY) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    prev = k;
  }
  return best;
}

/* ---------- sample data (clearly flagged, removable) ---------- */
function seededRandom(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

function makeSample(): { sessions: Session[]; tasks: Task[] } {
  const rnd = seededRandom(42);
  const sessions: Session[] = [];
  const titles = ["Thermodynamics revision", "Write essay draft", "Algorithms problem set", "Read research paper", "Design review prep", "Spanish vocabulary"];
  const startHours = [8, 9, 10, 11, 14, 15, 16, 20, 21];
  const today = startOfDay();
  for (let back = 1; back <= 62; back++) {
    const day = today - back * DAY;
    const dow = new Date(day).getDay();
    const skip = back > 6 && rnd() < (dow === 0 || dow === 6 ? 0.55 : 0.22);
    if (skip) continue;
    const count = 1 + Math.floor(rnd() * 3) + (back < 6 ? 1 : 0);
    let hour = startHours[Math.floor(rnd() * 4)];
    for (let i = 0; i < count; i++) {
      const planned = [25, 25, 45, 50, 25, 30][Math.floor(rnd() * 6)];
      const score = Math.round(72 + rnd() * 28);
      const start = day + hour * 3600000 + Math.floor(rnd() * 25) * 60000;
      const t = titles[Math.floor(rnd() * titles.length)];
      sessions.push({
        id: uid(), start, end: start + planned * 60000, minutes: planned, planned, taskTitle: t, score,
        xp: Math.round(planned * 10 * (0.5 + score / 200)), coins: Math.round(planned * 2 * (score / 100)), sample: true,
      });
      hour += 1 + Math.floor(rnd() * 3);
      if (hour > 22) break;
    }
  }
  const now = Date.now();
  const tasks: Task[] = [
    { id: uid(), title: "Finish thermodynamics problem set", priority: "high", est: 3, done: false, createdAt: now - DAY, focusMin: 25 },
    { id: uid(), title: "Outline the history essay", priority: "med", est: 2, done: false, createdAt: now - DAY, focusMin: 0 },
    { id: uid(), title: "Review flashcards — chapter 6", priority: "low", est: 1, done: false, createdAt: now - 2 * DAY, focusMin: 0 },
    { id: uid(), title: "Email supervisor about thesis", priority: "med", est: 1, done: true, createdAt: now - 3 * DAY, doneAt: now - DAY, focusMin: 25 },
  ];
  return { sessions, tasks };
}

function freshPet(species: SpeciesId, name?: string): OwnedPet {
  return {
    id: uid(), species, name: name ?? SPECIES[species].name, level: 1, xp: 0, hunger: 80, joy: 80,
    accessory: null, adoptedAt: Date.now(), lastTick: Date.now(), wins: 0,
  };
}

function initial() {
  const { sessions, tasks } = makeSample();
  const starter = { ...freshPet("emberfox", "Ember"), level: 4, xp: 60 };
  const xp = sessions.reduce((n, s) => n + s.xp, 0);
  return {
    timer: idleTimer("focus", DEFAULT_SETTINGS),
    lastResult: null as SessionResult | null,
    settings: DEFAULT_SETTINGS,
    tasks,
    sessions,
    xp,
    coins: 240,
    tickets: 5,
    pets: [starter],
    activePetId: starter.id,
    treats: { kibble: 99, biscuit: 2, berry: 1, cake: 0 } as Record<TreatId, number>,
    accessories: ["headphones"] as AccessoryId[],
    battles: [] as BattleRecord[],
    claimed: {} as Record<string, true>,
    daily: { date: dateKey(), care: 0 },
    hasSample: true,
    seenWelcome: false,
  };
}

function addPetXp(pet: OwnedPet, amount: number): { pet: OwnedPet; leveled: number | null } {
  let { level, xp } = pet;
  xp += amount;
  const start = level;
  while (xp >= petXpNeeded(level)) {
    xp -= petXpNeeded(level);
    level++;
  }
  return { pet: { ...pet, level, xp }, leveled: level > start ? level : null };
}

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      ...initial(),

      setMode: (m) =>
        set((s) => (s.timer.status === "idle" ? { timer: idleTimer(m, s.settings, { taskId: s.timer.taskId, cycle: s.timer.cycle }) } : s)),

      setDurationMin: (m) =>
        set((s) => {
          const min = clamp(Math.round(m), 1, 180);
          const key = s.timer.mode === "focus" ? "focusMin" : s.timer.mode === "short" ? "shortMin" : "longMin";
          const settings = { ...s.settings, [key]: min };
          return s.timer.status === "idle"
            ? { settings, timer: { ...s.timer, duration: min * 60, remaining: min * 60 } }
            : { settings };
        }),

      setTimerTask: (id) => set((s) => ({ timer: { ...s.timer, taskId: id } })),

      startTimer: () =>
        set((s) => {
          const t = s.timer;
          if (t.status === "running") return s;
          const now = Date.now();
          return {
            timer: { ...t, status: "running", endAt: now + t.remaining * 1000, startedAt: t.startedAt ?? now },
          };
        }),

      pauseTimer: () =>
        set((s) => {
          const t = s.timer;
          if (t.status !== "running" || !t.endAt) return s;
          return {
            timer: { ...t, status: "paused", remaining: Math.max(1, Math.round((t.endAt - Date.now()) / 1000)), endAt: null, pauses: t.pauses + 1 },
          };
        }),

      resetTimer: () => set((s) => ({ timer: idleTimer(s.timer.mode, s.settings, { taskId: s.timer.taskId, cycle: s.timer.cycle }) })),

      completeTimer: (early = false) => {
        const s = get();
        const t = s.timer;
        if (t.status === "idle") return;
        const now = Date.now();
        const remainingSec = t.status === "running" && t.endAt ? Math.max(0, (t.endAt - now) / 1000) : t.remaining;
        const elapsedSec = early ? t.duration - remainingSec : t.duration;

        if (t.mode !== "focus") {
          const next: Mode = "focus";
          const timer = idleTimer(next, s.settings, { taskId: t.taskId, cycle: t.cycle });
          set({
            timer,
            lastResult: {
              id: uid(), kind: t.mode, minutes: Math.round(elapsedSec / 60), score: 0, xp: 0, coins: 0, ticket: false,
              petName: "", petLeveled: null, accountLevel: null, early, nextMode: next, streak: streakOf(s.sessions),
            },
          });
          return;
        }

        if (early && elapsedSec < 60) {
          set({ timer: idleTimer("focus", s.settings, { taskId: t.taskId, cycle: t.cycle }) });
          return;
        }

        const minutes = Math.max(1, Math.round(elapsedSec / 60));
        const completion = clamp(elapsedSec / t.duration, 0, 1);
        const score = Math.round(clamp(100 * (0.35 + 0.65 * completion) - t.pauses * 6, 20, 100));
        const xp = Math.round(minutes * 10 * (0.5 + score / 200));
        const coins = Math.round(minutes * 2 * (score / 100)) + (score >= 95 && minutes >= 25 ? 10 : 0);
        const ticket = !early && minutes >= 15;
        const task = s.tasks.find((x) => x.id === t.taskId);
        const session: Session = {
          id: uid(), start: t.startedAt ?? now - elapsedSec * 1000, end: now, minutes, planned: Math.round(t.duration / 60),
          taskId: task?.id, taskTitle: task?.title, score, xp, coins,
        };
        const sessions = [...s.sessions, session];

        const pet = s.pets.find((p) => p.id === s.activePetId);
        let pets = s.pets;
        let petLeveled: number | null = null;
        if (pet) {
          const r = addPetXp(pet, minutes * 5);
          petLeveled = r.leveled;
          pets = s.pets.map((p) => (p.id === pet.id ? { ...r.pet, joy: clamp(r.pet.joy + 6, 0, 100) } : p));
        }
        const before = levelFromXp(s.xp).level;
        const newXp = s.xp + xp;
        const after = levelFromXp(newXp).level;
        const cycle = early ? t.cycle : t.cycle + 1;
        const nextMode: Mode = early ? "focus" : cycle % 4 === 0 ? "long" : "short";

        set({
          sessions,
          xp: newXp,
          coins: s.coins + coins,
          tickets: s.tickets + (ticket ? 1 : 0),
          pets,
          tasks: task ? s.tasks.map((x) => (x.id === task.id ? { ...x, focusMin: x.focusMin + minutes } : x)) : s.tasks,
          timer: idleTimer(nextMode, s.settings, { taskId: t.taskId, cycle }),
          lastResult: {
            id: uid(), kind: "focus", minutes, score, xp, coins, ticket, petName: pet?.name ?? "", petLeveled,
            accountLevel: after > before ? after : null, early, nextMode, streak: streakOf(sessions),
          },
        });
      },

      dismissResult: () => set({ lastResult: null }),
      updateSettings: (p) =>
        set((s) => {
          const settings = { ...s.settings, ...p };
          const timer = s.timer.status === "idle" ? idleTimer(s.timer.mode, settings, { taskId: s.timer.taskId, cycle: s.timer.cycle }) : s.timer;
          return { settings, timer };
        }),

      addTask: (title, priority, est) =>
        set((s) => ({
          tasks: [{ id: uid(), title: title.trim(), priority, est, done: false, createdAt: Date.now(), focusMin: 0 }, ...s.tasks],
        })),
      toggleTask: (id) =>
        set((s) => ({
          tasks: s.tasks.map((t) => (t.id === id ? { ...t, done: !t.done, doneAt: !t.done ? Date.now() : undefined } : t)),
        })),
      removeTask: (id) =>
        set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id), timer: s.timer.taskId === id ? { ...s.timer, taskId: null } : s.timer })),

      decayPets: () =>
        set((s) => {
          const now = Date.now();
          let changed = false;
          const pets = s.pets.map((p) => {
            const min = (now - p.lastTick) / 60000;
            if (min < 0.5) return p;
            changed = true;
            return { ...p, hunger: clamp(p.hunger - min * 0.06, 0, 100), joy: clamp(p.joy - min * 0.045, 0, 100), lastTick: now };
          });
          const today = dateKey();
          const daily = s.daily.date === today ? s.daily : { date: today, care: 0 };
          return changed || daily !== s.daily ? { pets, daily } : s;
        }),

      feedPet: (petId, treat) => {
        const s = get();
        const t = TREATS.find((x) => x.id === treat)!;
        if (s.treats[treat] <= 0) return false;
        const pet = s.pets.find((p) => p.id === petId);
        if (!pet) return false;
        const r = addPetXp(pet, t.xp);
        const today = dateKey();
        const daily = s.daily.date === today ? s.daily : { date: today, care: 0 };
        set({
          treats: { ...s.treats, [treat]: treat === "kibble" ? s.treats.kibble : s.treats[treat] - 1 },
          pets: s.pets.map((p) => (p.id === petId ? { ...r.pet, hunger: clamp(p.hunger + t.hunger, 0, 100), joy: clamp(p.joy + t.joy, 0, 100) } : p)),
          daily: { ...daily, care: daily.care + 1 },
        });
        return true;
      },

      playWithPet: (petId) =>
        set((s) => {
          const today = dateKey();
          const daily = s.daily.date === today ? s.daily : { date: today, care: 0 };
          return {
            pets: s.pets.map((p) => (p.id === petId ? { ...p, joy: clamp(p.joy + 14, 0, 100), hunger: clamp(p.hunger - 3, 0, 100) } : p)),
            daily: { ...daily, care: daily.care + 1 },
          };
        }),

      patPet: (petId) => set((s) => ({ pets: s.pets.map((p) => (p.id === petId ? { ...p, joy: clamp(p.joy + 1.5, 0, 100) } : p)) })),
      renamePet: (petId, name) =>
        set((s) => ({ pets: s.pets.map((p) => (p.id === petId ? { ...p, name: name.trim().slice(0, 14) || p.name } : p)) })),
      equip: (petId, a) => set((s) => ({ pets: s.pets.map((p) => (p.id === petId ? { ...p, accessory: a } : p)) })),
      setActivePet: (petId) => set({ activePetId: petId }),

      adopt: (species) => {
        const s = get();
        const price = SPECIES[species].price;
        if (s.coins < price || s.pets.some((p) => p.species === species)) return false;
        const pet = freshPet(species);
        set({ coins: s.coins - price, pets: [...s.pets, pet], activePetId: pet.id });
        return true;
      },
      buyAccessory: (a) => {
        const s = get();
        const price = ACCESSORIES.find((x) => x.id === a)!.price;
        if (s.coins < price || s.accessories.includes(a)) return false;
        set({ coins: s.coins - price, accessories: [...s.accessories, a] });
        return true;
      },
      buyTreat: (t, qty) => {
        const s = get();
        const cost = TREATS.find((x) => x.id === t)!.price * qty;
        if (s.coins < cost) return false;
        set({ coins: s.coins - cost, treats: { ...s.treats, [t]: s.treats[t] + qty } });
        return true;
      },
      buyTickets: (qty, price) => {
        const s = get();
        if (s.coins < price) return false;
        set({ coins: s.coins - price, tickets: s.tickets + qty });
        return true;
      },

      spendTicket: () => {
        const s = get();
        if (s.tickets <= 0) return false;
        set({ tickets: s.tickets - 1 });
        return true;
      },

      recordBattle: (r, petXp) => {
        const s = get();
        const pet = s.pets.find((p) => p.id === r.petId);
        let leveled: number | null = null;
        let pets = s.pets;
        if (pet && petXp > 0) {
          const res = addPetXp(pet, petXp);
          leveled = res.leveled;
          pets = s.pets.map((p) => (p.id === pet.id ? { ...res.pet, wins: p.wins + (r.won && !r.practice ? 1 : 0), joy: clamp(p.joy + (r.won ? 8 : -4), 0, 100) } : p));
        }
        set({
          pets,
          coins: s.coins + r.coins,
          battles: [...s.battles, { ...r, id: uid(), at: Date.now() }].slice(-60),
        });
        return { leveled };
      },

      claim: (key, coins) => set((s) => (s.claimed[key] ? s : { claimed: { ...s.claimed, [key]: true }, coins: s.coins + coins })),
      clearSample: () =>
        set((s) => {
          const sessions = s.sessions.filter((x) => !x.sample);
          return { sessions, hasSample: false, xp: sessions.reduce((n, x) => n + x.xp, 0) + 20 };
        }),
      markWelcome: () => set({ seenWelcome: true }),
      resetAll: () => set({ ...initial(), sessions: [], hasSample: false, xp: 0, tasks: [] }),
    }),
    {
      name: "focusarx-v1",
      version: 1,
      // the celebration card is transient — never replay it after a reload
      partialize: (s) => ({ ...s, lastResult: null }) as State,
    }
  )
);

export function useActivePet() {
  return useStore((s) => s.pets.find((p) => p.id === s.activePetId) ?? s.pets[0]);
}
