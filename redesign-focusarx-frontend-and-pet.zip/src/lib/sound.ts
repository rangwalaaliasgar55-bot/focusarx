// Tiny Web Audio engine: generated ambience + UI/battle sound effects. No audio files, no network.
export type Ambient = "off" | "brown" | "rain" | "waves";

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let ambientNodes: { stop: () => void } | null = null;
let ambientGain: GainNode | null = null;

function ac() {
  if (!ctx) {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new Ctor();
    master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function noiseBuffer(c: AudioContext, kind: "white" | "brown") {
  const len = c.sampleRate * 4;
  const buf = c.createBuffer(2, len, c.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    let last = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      if (kind === "white") d[i] = w * 0.6;
      else {
        last = (last + 0.02 * w) / 1.02;
        d[i] = last * 3.5;
      }
    }
  }
  return buf;
}

export function setAmbient(kind: Ambient, volume = 0.5) {
  const c = ac();
  if (ambientNodes) {
    const old = ambientNodes;
    const g = ambientGain;
    if (g) g.gain.setTargetAtTime(0, c.currentTime, 0.2);
    setTimeout(() => old.stop(), 700);
    ambientNodes = null;
    ambientGain = null;
  }
  if (kind === "off") return;

  const g = c.createGain();
  g.gain.value = 0;
  g.connect(master!);
  g.gain.setTargetAtTime(volume * 0.5, c.currentTime, 0.6);
  const src = c.createBufferSource();
  const extra: AudioNode[] = [];
  const stops: (() => void)[] = [];

  if (kind === "brown") {
    src.buffer = noiseBuffer(c, "brown");
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 900;
    src.connect(lp).connect(g);
    extra.push(lp);
  } else if (kind === "rain") {
    src.buffer = noiseBuffer(c, "white");
    const hp = c.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 900;
    const bp = c.createBiquadFilter();
    bp.type = "peaking";
    bp.frequency.value = 3800;
    bp.gain.value = 5;
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 9000;
    src.connect(hp).connect(bp).connect(lp).connect(g);
  } else {
    src.buffer = noiseBuffer(c, "brown");
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 1400;
    const swell = c.createGain();
    swell.gain.value = 0.55;
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.09;
    const lfoGain = c.createGain();
    lfoGain.gain.value = 0.45;
    lfo.connect(lfoGain).connect(swell.gain);
    lfo.start();
    stops.push(() => lfo.stop());
    src.connect(lp).connect(swell).connect(g);
  }
  src.loop = true;
  src.start();
  stops.push(() => {
    try {
      src.stop();
    } catch {
      /* already stopped */
    }
    g.disconnect();
  });
  ambientNodes = { stop: () => stops.forEach((s) => s()) };
  ambientGain = g;
}

export function setAmbientVolume(v: number) {
  if (ambientGain && ctx) ambientGain.gain.setTargetAtTime(v * 0.5, ctx.currentTime, 0.1);
}

function tone(freq: number, start: number, dur: number, type: OscillatorType = "sine", vol = 0.2, slideTo?: number) {
  const c = ac();
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, c.currentTime + start);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, c.currentTime + start + dur);
  g.gain.setValueAtTime(0.0001, c.currentTime + start);
  g.gain.exponentialRampToValueAtTime(vol, c.currentTime + start + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + start + dur);
  o.connect(g).connect(master!);
  o.start(c.currentTime + start);
  o.stop(c.currentTime + start + dur + 0.05);
}

function noiseBurst(start: number, dur: number, freq: number, vol = 0.25) {
  const c = ac();
  const src = c.createBufferSource();
  src.buffer = noiseBuffer(c, "white");
  const f = c.createBiquadFilter();
  f.type = "bandpass";
  f.frequency.value = freq;
  const g = c.createGain();
  g.gain.setValueAtTime(vol, c.currentTime + start);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + start + dur);
  src.connect(f).connect(g).connect(master!);
  src.start(c.currentTime + start);
  src.stop(c.currentTime + start + dur + 0.05);
}

export type Sfx = "chime" | "pop" | "hit" | "crit" | "whoosh" | "heal" | "win" | "lose" | "tap" | "buy" | "cast" | "boost";

export function sfx(kind: Sfx) {
  try {
    switch (kind) {
      case "chime":
        [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => tone(f, i * 0.16, 1.4, "sine", 0.16));
        break;
      case "pop":
        tone(520, 0, 0.12, "sine", 0.14, 880);
        break;
      case "tap":
        tone(900, 0, 0.05, "sine", 0.06);
        break;
      case "buy":
        tone(660, 0, 0.1, "triangle", 0.12);
        tone(990, 0.08, 0.18, "triangle", 0.12);
        break;
      case "hit":
        noiseBurst(0, 0.18, 400, 0.35);
        tone(140, 0, 0.2, "sine", 0.3, 50);
        break;
      case "crit":
        noiseBurst(0, 0.3, 700, 0.45);
        tone(200, 0, 0.35, "sawtooth", 0.18, 40);
        tone(1200, 0, 0.1, "square", 0.05);
        break;
      case "whoosh":
        noiseBurst(0, 0.35, 1800, 0.12);
        break;
      case "cast":
        tone(300, 0, 0.5, "sine", 0.1, 900);
        break;
      case "boost":
        tone(400, 0, 0.4, "triangle", 0.12, 800);
        tone(600, 0.1, 0.4, "triangle", 0.1, 1200);
        break;
      case "heal":
        [660, 880, 1320].forEach((f, i) => tone(f, i * 0.1, 0.5, "sine", 0.1));
        break;
      case "win":
        [523.25, 659.25, 783.99, 1046.5, 1318.5].forEach((f, i) => tone(f, i * 0.12, 0.7, "triangle", 0.14));
        break;
      case "lose":
        [392, 349.23, 293.66].forEach((f, i) => tone(f, i * 0.22, 0.6, "triangle", 0.12));
        break;
    }
  } catch {
    /* audio is optional */
  }
}
