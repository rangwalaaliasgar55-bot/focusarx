import { DAY, dateKey, startOfDay } from "./format";
import { bestStreak, minutesOnDay, type Session, type Task, type BattleRecord, type OwnedPet } from "./store";

export interface Snapshot {
  sessions: Session[];
  tasks: Task[];
  battles: BattleRecord[];
  pets: OwnedPet[];
  daily: { date: string; care: number };
  accountLevel: number;
}

export interface Mission {
  id: string;
  title: string;
  desc: string;
  target: number;
  progress: number;
  reward: number;
  unit?: string;
}

export function dailyMissions(s: Snapshot, petName: string): Mission[] {
  const now = Date.now();
  const today = startOfDay(now);
  const min = minutesOnDay(s.sessions, now);
  const tasksDone = s.tasks.filter((t) => t.done && t.doneAt && t.doneAt >= today && t.doneAt < today + DAY).length;
  const wins = s.battles.filter((b) => b.won && !b.practice && dateKey(b.at) === dateKey(now)).length;
  const care = s.daily.date === dateKey(now) ? s.daily.care : 0;
  const cap = (p: number, t: number) => Math.min(p, t);
  return [
    { id: "focus25", title: "Warm up", desc: "Focus for 25 minutes today", target: 25, progress: cap(min, 25), reward: 30, unit: "min" },
    { id: "focus60", title: "Deep work hour", desc: "Reach 60 focused minutes today", target: 60, progress: cap(min, 60), reward: 70, unit: "min" },
    { id: "tasks", title: "Clear the list", desc: "Complete 2 tasks", target: 2, progress: cap(tasksDone, 2), reward: 25 },
    { id: "battle", title: "Arena victory", desc: "Win a battle in the Arena", target: 1, progress: cap(wins, 1), reward: 45 },
    { id: "care", title: `Look after ${petName}`, desc: "Feed or play with your companion twice", target: 2, progress: cap(care, 2), reward: 20 },
  ];
}

export function achievements(s: Snapshot): Mission[] {
  const total = s.sessions.reduce((n, x) => n + x.minutes, 0);
  const wins = s.battles.filter((b) => b.won && !b.practice).length;
  const best = bestStreak(s.sessions);
  const topPet = Math.max(1, ...s.pets.map((p) => p.level));
  const perfect = s.sessions.some((x) => x.score === 100) ? 1 : 0;
  const cap = (p: number, t: number) => Math.min(p, t);
  return [
    { id: "a-first", title: "First step", desc: "Complete a focus session", target: 1, progress: cap(s.sessions.length, 1), reward: 20 },
    { id: "a-25", title: "Getting serious", desc: "Complete 25 sessions", target: 25, progress: cap(s.sessions.length, 25), reward: 80 },
    { id: "a-10h", title: "Ten hours deep", desc: "Focus for 10 hours in total", target: 600, progress: cap(total, 600), reward: 120, unit: "min" },
    { id: "a-50h", title: "Fifty hour club", desc: "Focus for 50 hours in total", target: 3000, progress: cap(total, 3000), reward: 400, unit: "min" },
    { id: "a-streak7", title: "One full week", desc: "Reach a 7-day streak", target: 7, progress: cap(best, 7), reward: 100, unit: "days" },
    { id: "a-streak30", title: "Unbreakable", desc: "Reach a 30-day streak", target: 30, progress: cap(best, 30), reward: 500, unit: "days" },
    { id: "a-perfect", title: "Flawless", desc: "Earn a perfect 100 focus score", target: 1, progress: perfect, reward: 60 },
    { id: "a-wins", title: "Arena regular", desc: "Win 5 battles", target: 5, progress: cap(wins, 5), reward: 150 },
    { id: "a-pets", title: "Pack leader", desc: "Adopt 3 companions", target: 3, progress: cap(s.pets.length, 3), reward: 200 },
    { id: "a-petlv", title: "Best friends", desc: "Raise a companion to level 10", target: 10, progress: cap(topPet, 10), reward: 180 },
    { id: "a-lv5", title: "Rising focus", desc: "Reach account level 5", target: 5, progress: cap(s.accountLevel, 5), reward: 90 },
  ];
}
