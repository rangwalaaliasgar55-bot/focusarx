export const DAY = 86_400_000;

export function pad(n: number) {
  return n.toString().padStart(2, "0");
}

export function clock(totalSeconds: number) {
  const s = Math.max(0, Math.ceil(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return h > 0 ? `${h}:${pad(m)}:${pad(sec)}` : `${pad(m)}:${pad(sec)}`;
}

export function minutesLabel(min: number) {
  if (min < 60) return `${Math.round(min)}m`;
  const h = Math.floor(min / 60);
  const m = Math.round(min % 60);
  return m ? `${h}h ${m}m` : `${h}h`;
}

export function dateKey(ts: number | Date = Date.now()) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function startOfDay(ts: number | Date = Date.now()) {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

export function greeting(now = new Date()) {
  const h = now.getHours();
  if (h < 5) return "Burning the midnight oil";
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  if (h < 22) return "Good evening";
  return "Late night focus";
}

export function weekdayShort(ts: number) {
  return new Date(ts).toLocaleDateString(undefined, { weekday: "short" });
}

export function timeOfDay(ts: number) {
  return new Date(ts).toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
}

export function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

export function clamp(n: number, a: number, b: number) {
  return Math.min(b, Math.max(a, n));
}

export function levelFromXp(xp: number) {
  const level = Math.floor(Math.sqrt(xp / 120)) + 1;
  const floor = Math.pow(level - 1, 2) * 120;
  const next = Math.pow(level, 2) * 120;
  return { level, into: xp - floor, need: next - floor, pct: (xp - floor) / (next - floor) };
}
