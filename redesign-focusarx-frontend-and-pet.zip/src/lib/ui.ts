import { create } from "zustand";
import { setAmbient, setAmbientVolume, type Ambient } from "./sound";
import { uid } from "./format";

export interface Toast {
  id: string;
  title: string;
  body?: string;
  tone?: "default" | "success" | "warn";
}

interface UI {
  zen: boolean;
  setZen: (z: boolean) => void;
  ambient: Ambient;
  playAmbient: (a: Ambient, volume: number) => void;
  setVolume: (v: number) => void;
  toasts: Toast[];
  toast: (t: Omit<Toast, "id">) => void;
  dismissToast: (id: string) => void;
}

export const useUI = create<UI>((set) => ({
  zen: false,
  setZen: (zen) => set({ zen }),
  ambient: "off",
  playAmbient: (ambient, volume) => {
    setAmbient(ambient, volume);
    set({ ambient });
  },
  setVolume: (v) => setAmbientVolume(v),
  toasts: [],
  toast: (t) => {
    const id = uid();
    set((s) => ({ toasts: [...s.toasts.slice(-2), { ...t, id }] }));
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) })), 3800);
  },
  dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) })),
}));

/* ---- tiny hash router ---- */
import { useEffect, useState, useCallback } from "react";

export type Route = "dashboard" | "focus" | "tasks" | "analytics" | "companion" | "arena" | "shop" | "missions";
export const ROUTES: Route[] = ["dashboard", "focus", "tasks", "analytics", "companion", "arena", "shop", "missions"];

function parse(): Route {
  const h = window.location.hash.replace(/^#\/?/, "").split("?")[0] as Route;
  return ROUTES.includes(h) ? h : "dashboard";
}

export function useRoute(): [Route, (r: Route) => void] {
  const [route, setRoute] = useState<Route>(parse);
  useEffect(() => {
    const on = () => setRoute(parse());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const go = useCallback((r: Route) => {
    window.location.hash = `/${r}`;
  }, []);
  return [route, go];
}
