import { SPECIES, statsFor, effectiveness, type Move, type SpeciesId } from "./pets";

export type Side = "player" | "enemy";

export interface Fighter {
  side: Side;
  species: SpeciesId;
  name: string;
  level: number;
  maxHp: number;
  hp: number;
  atk: number;
  def: number;
  spd: number;
  energy: number;
  guard: boolean;
  boost: number;
  moves: Move[];
}

export interface TurnEvent {
  side: Side;
  move: Move;
  moveIndex: number;
  hit: boolean;
  dmg: number;
  crit: boolean;
  eff: number;
  heal: number;
  boosted: boolean;
  guarded: boolean;
  targetHp: number;
  selfHp: number;
  fainted: boolean;
}

export const MAX_ENERGY = 5;

export function makeFighter(side: Side, species: SpeciesId, level: number, name?: string): Fighter {
  const s = statsFor(species, level);
  return {
    side,
    species,
    name: name ?? SPECIES[species].name,
    level,
    maxHp: s.hp,
    hp: s.hp,
    atk: s.atk,
    def: s.def,
    spd: s.spd,
    energy: 2,
    guard: false,
    boost: 0,
    moves: SPECIES[species].moves,
  };
}

const other = (s: Side): Side => (s === "player" ? "enemy" : "player");

export class Battle {
  player: Fighter;
  enemy: Fighter;
  turn: Side;
  winner: Side | null = null;
  round = 1;

  constructor(player: Fighter, enemy: Fighter) {
    this.player = player;
    this.enemy = enemy;
    this.turn = player.spd >= enemy.spd ? "player" : "enemy";
  }

  fighter(side: Side) {
    return side === "player" ? this.player : this.enemy;
  }

  /** Called at the start of each side's turn. */
  beginTurn(side: Side) {
    const f = this.fighter(side);
    f.energy = Math.min(MAX_ENERGY, f.energy + 1);
    f.guard = false;
  }

  canUse(side: Side, idx: number) {
    const f = this.fighter(side);
    return f.moves[idx] != null && f.energy >= f.moves[idx].cost;
  }

  act(side: Side, idx: number): TurnEvent {
    const me = this.fighter(side);
    const foe = this.fighter(other(side));
    const move = me.moves[idx];
    me.energy -= move.cost;

    const ev: TurnEvent = {
      side, move, moveIndex: idx, hit: true, dmg: 0, crit: false, eff: 1, heal: 0,
      boosted: false, guarded: false, targetHp: foe.hp, selfHp: me.hp, fainted: false,
    };

    if (move.kind === "guard") {
      me.guard = true;
    } else if (move.kind === "boost") {
      me.boost = 3;
    } else if (move.kind === "heal") {
      const amt = Math.round(me.maxHp * (move.power / 100));
      const before = me.hp;
      me.hp = Math.min(me.maxHp, me.hp + amt);
      ev.heal = me.hp - before;
      ev.selfHp = me.hp;
    } else {
      ev.hit = Math.random() * 100 < move.accuracy;
      if (ev.hit) {
        ev.eff = effectiveness(move.element, SPECIES[foe.species].element);
        ev.crit = Math.random() < 0.12;
        ev.boosted = me.boost > 0;
        ev.guarded = foe.guard;
        const atk = me.atk * (ev.boosted ? 1.4 : 1);
        const base = (atk / foe.def) * move.power * 0.5;
        const rand = 0.9 + Math.random() * 0.2;
        let dmg = base * ev.eff * (ev.crit ? 1.5 : 1) * rand * (foe.guard ? 0.5 : 1);
        dmg = Math.max(1, Math.round(dmg));
        foe.hp = Math.max(0, foe.hp - dmg);
        foe.guard = false;
        ev.dmg = dmg;
        ev.targetHp = foe.hp;
        if (foe.hp <= 0) {
          ev.fainted = true;
          this.winner = side;
        }
      }
    }

    if (me.boost > 0 && move.kind !== "boost") me.boost -= 1;

    if (!this.winner) {
      this.turn = other(side);
      if (this.turn === "player" || side === "enemy") this.round += side === "enemy" ? 1 : 0;
    }
    return ev;
  }

  /** Simple but not dumb AI. */
  chooseEnemyMove(): number {
    const me = this.enemy;
    const foe = this.player;
    const usable = me.moves.map((m, i) => ({ m, i })).filter(({ m }) => me.energy >= m.cost);
    const heal = usable.find(({ m }) => m.kind === "heal");
    if (heal && me.hp / me.maxHp < 0.4 && Math.random() < 0.8) return heal.i;
    const guard = usable.find(({ m }) => m.kind === "guard");
    if (guard && !me.guard && me.hp / me.maxHp < 0.5 && Math.random() < 0.45) return guard.i;
    const boost = usable.find(({ m }) => m.kind === "boost");
    if (boost && me.boost === 0 && me.hp / me.maxHp > 0.5 && Math.random() < 0.5) return boost.i;

    const scored = usable
      .filter(({ m }) => m.kind === "attack")
      .map(({ m, i }) => {
        const eff = effectiveness(m.element, SPECIES[foe.species].element);
        const exp = m.power * eff * (m.accuracy / 100);
        // save big moves until they're affordable, but go for the kill
        const kill = (me.atk / foe.def) * m.power * 0.5 * eff >= foe.hp ? 60 : 0;
        return { i, score: exp + kill + Math.random() * 18 };
      })
      .sort((a, b) => b.score - a.score);
    return scored[0]?.i ?? 0;
  }
}

export type Difficulty = "rookie" | "challenger" | "champion";
export const DIFFICULTIES: { id: Difficulty; label: string; delta: number; coins: number; blurb: string }[] = [
  { id: "rookie", label: "Rookie", delta: -2, coins: 40, blurb: "A friendly warm-up bout." },
  { id: "challenger", label: "Challenger", delta: 0, coins: 85, blurb: "An even match. Use your type edge." },
  { id: "champion", label: "Champion", delta: 3, coins: 170, blurb: "Hits hard. Plan your energy." },
];

export const ENEMY_NAMES: Record<SpeciesId, string[]> = {
  emberfox: ["Cinder", "Blaze", "Ash"],
  bubbo: ["Splash", "Drip", "Marlo"],
  sprout: ["Clover", "Fern", "Moss"],
  zappy: ["Volt", "Jolt", "Spark"],
  lunix: ["Nebula", "Orion", "Vega"],
  drakeling: ["Ignis", "Scorch", "Rex"],
};
