import { useEffect, useRef, type ReactNode } from "react";
import { AnimatePresence, animate, motion, useInView, useMotionValue, useTransform, type HTMLMotionProps, type Variants } from "framer-motion";
import { cn } from "../utils/cn";

export const EASE = [0.22, 1, 0.36, 1] as const;
export const SPRING = { type: "spring", stiffness: 380, damping: 30, mass: 0.8 } as const;
export const SOFT_SPRING = { type: "spring", stiffness: 220, damping: 26, mass: 0.9 } as const;

export const stagger: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.06, delayChildren: 0.04 } },
};
export const rise: Variants = {
  hidden: { opacity: 0, y: 18, filter: "blur(6px)" },
  show: { opacity: 1, y: 0, filter: "blur(0px)", transition: { duration: 0.7, ease: EASE } },
};

/* ---------- Button ---------- */
type BtnProps = Omit<HTMLMotionProps<"button">, "children"> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  children?: ReactNode;
};
export function Button({ variant = "secondary", size = "md", className, children, ...p }: BtnProps) {
  const base =
    "relative inline-flex items-center justify-center gap-2 font-semibold select-none whitespace-nowrap rounded-full transition-colors duration-300 disabled:opacity-40 disabled:pointer-events-none";
  const sizes = { sm: "h-8 px-3.5 text-[13px]", md: "h-10 px-5 text-sm", lg: "h-12 px-7 text-[15px]" };
  const variants = {
    primary:
      "text-white bg-gradient-to-b from-brand-400 to-brand-600 shadow-[0_1px_0_rgba(255,255,255,0.35)_inset,0_10px_30px_-10px_rgba(123,124,255,0.8)] hover:from-brand-300 hover:to-brand-500",
    secondary: "text-ink bg-white/[0.07] hover:bg-white/[0.12] border border-white/[0.08]",
    ghost: "text-ink-2 hover:text-ink hover:bg-white/[0.06]",
    danger: "text-rose bg-rose/10 hover:bg-rose/20 border border-rose/20",
  };
  return (
    <motion.button
      whileHover={{ y: -1 }}
      whileTap={{ scale: 0.96 }}
      transition={SPRING}
      className={cn(base, sizes[size], variants[variant], className)}
      {...p}
    >
      {children}
    </motion.button>
  );
}

/* ---------- Segmented control with sliding pill ---------- */
export function Segmented<T extends string>({
  options, value, onChange, id, className, size = "md",
}: {
  options: { value: T; label: ReactNode }[];
  value: T;
  onChange: (v: T) => void;
  id: string;
  className?: string;
  size?: "sm" | "md";
}) {
  return (
    <div className={cn("relative inline-flex rounded-full bg-white/[0.05] p-1 border border-white/[0.06]", className)}>
      {options.map((o) => {
        const active = o.value === value;
        return (
          <button
            key={o.value}
            onClick={() => onChange(o.value)}
            className={cn(
              "relative z-10 rounded-full font-semibold transition-colors duration-300",
              size === "sm" ? "px-3 py-1 text-xs" : "px-4 py-1.5 text-[13px]",
              active ? "text-ink" : "text-ink-3 hover:text-ink-2"
            )}
          >
            {active && (
              <motion.span
                layoutId={`seg-${id}`}
                transition={SPRING}
                className="absolute inset-0 -z-10 rounded-full bg-white/[0.12] shadow-[0_1px_0_rgba(255,255,255,0.1)_inset,0_6px_14px_-6px_rgba(0,0,0,0.6)]"
              />
            )}
            {o.label}
          </button>
        );
      })}
    </div>
  );
}

/* ---------- Animated number ---------- */
export function AnimatedNumber({
  value, format = (n: number) => Math.round(n).toLocaleString(), className, duration = 1.1,
}: {
  value: number;
  format?: (n: number) => string;
  className?: string;
  duration?: number;
}) {
  const mv = useMotionValue(0);
  const text = useTransform(mv, (v) => format(v));
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: false });
  useEffect(() => {
    if (!inView) return;
    const c = animate(mv, value, { duration, ease: EASE });
    return () => c.stop();
  }, [value, inView, mv, duration]);
  return (
    <motion.span ref={ref} className={cn("num", className)}>
      {text}
    </motion.span>
  );
}

/* ---------- Progress bar ---------- */
export function Bar({ value, color = "var(--color-brand-500)", className, height = 6 }: { value: number; color?: string; className?: string; height?: number }) {
  return (
    <div className={cn("w-full overflow-hidden rounded-full bg-white/[0.07]", className)} style={{ height }}>
      <motion.div
        className="h-full rounded-full"
        style={{ background: color }}
        initial={false}
        animate={{ width: `${Math.max(0, Math.min(1, value)) * 100}%` }}
        transition={{ duration: 0.9, ease: EASE }}
      />
    </div>
  );
}

/* ---------- Ring ---------- */
export function Ring({
  value, size = 96, stroke = 8, color = "var(--color-brand-500)", children,
}: {
  value: number;
  size?: number;
  stroke?: number;
  color?: string;
  children?: ReactNode;
}) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c}
          initial={{ strokeDashoffset: c }}
          animate={{ strokeDashoffset: c * (1 - Math.max(0, Math.min(1, value))) }}
          transition={{ duration: 1.2, ease: EASE }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

/* ---------- Toggle ---------- */
export function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label={label}
      onClick={() => onChange(!on)}
      className={cn("relative h-[26px] w-[44px] rounded-full transition-colors duration-300", on ? "bg-brand-500" : "bg-white/[0.12]")}
    >
      <motion.span
        className="absolute top-[3px] h-5 w-5 rounded-full bg-white shadow-md"
        animate={{ left: on ? 21 : 3 }}
        transition={SPRING}
      />
    </button>
  );
}

/* ---------- Modal ---------- */
export function Modal({ open, onClose, children, className }: { open: boolean; onClose: () => void; children: ReactNode; className?: string }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [open, onClose]);
  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[80] grid place-items-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
        >
          <div className="absolute inset-0 bg-black/60 backdrop-blur-md" onClick={onClose} />
          <motion.div
            initial={{ opacity: 0, scale: 0.92, y: 24 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className={cn("glass relative w-full max-w-md rounded-[28px] p-6", className)}
          >
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ---------- Misc ---------- */
export function Panel({ className, children, ...p }: HTMLMotionProps<"div"> & { children?: ReactNode }) {
  return (
    <motion.div className={cn("panel", className)} {...p}>
      {children}
    </motion.div>
  );
}

export function Chip({ children, color, className }: { children: ReactNode; color?: string; className?: string }) {
  return (
    <span
      className={cn("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-semibold border", className)}
      style={color ? { color, borderColor: `${color}33`, background: `${color}14` } : { borderColor: "var(--hairline)", background: "rgba(255,255,255,0.04)" }}
    >
      {children}
    </span>
  );
}

export function SectionTitle({ title, action, sub }: { title: string; action?: ReactNode; sub?: string }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div>
        <h2 className="font-display text-[17px] font-bold tracking-tight text-ink">{title}</h2>
        {sub && <p className="mt-0.5 text-[13px] text-ink-3">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function Empty({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="grid place-items-center rounded-2xl border border-dashed border-white/10 px-6 py-10 text-center">
      <div className="font-display text-[15px] font-bold">{title}</div>
      <p className="mt-1 max-w-xs text-[13px] text-ink-3">{body}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}
