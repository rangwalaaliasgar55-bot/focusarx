import { motion } from "framer-motion";
import { cn } from "../utils/cn";

export function TaskCheck({ done, onToggle, color = "#7b7cff" }: { done: boolean; onToggle: () => void; color?: string }) {
  return (
    <motion.button
      onClick={onToggle}
      whileTap={{ scale: 0.8 }}
      aria-label={done ? "Mark as not done" : "Mark as done"}
      className={cn("relative grid h-[22px] w-[22px] shrink-0 place-items-center rounded-full border-[1.5px] transition-colors duration-300", done ? "border-transparent" : "border-white/25 hover:border-white/50")}
      style={{ background: done ? color : "transparent" }}
    >
      <motion.svg width="12" height="12" viewBox="0 0 12 12" fill="none">
        <motion.path
          d="M2.2 6.3 L4.9 9 L9.8 3.2"
          stroke="#0b0b0c"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={false}
          animate={{ pathLength: done ? 1 : 0, opacity: done ? 1 : 0 }}
          transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        />
      </motion.svg>
      {done && (
        <motion.span
          className="absolute inset-0 rounded-full"
          style={{ border: `2px solid ${color}` }}
          initial={{ scale: 1, opacity: 0.8 }}
          animate={{ scale: 2, opacity: 0 }}
          transition={{ duration: 0.6 }}
        />
      )}
    </motion.button>
  );
}
