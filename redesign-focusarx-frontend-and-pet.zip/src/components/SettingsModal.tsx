import { Minus, Plus } from "lucide-react";
import { useStore } from "../lib/store";
import { Button, Modal, Toggle } from "./ui";
import { useUI } from "../lib/ui";

function Stepper({ value, onChange, min, max, step = 1, suffix }: { value: number; onChange: (n: number) => void; min: number; max: number; step?: number; suffix: string }) {
  return (
    <div className="flex items-center gap-1 rounded-full border border-white/[0.07] bg-white/[0.04] p-0.5">
      <button aria-label="Decrease" onClick={() => onChange(Math.max(min, value - step))} className="grid h-7 w-7 place-items-center rounded-full text-ink-3 hover:bg-white/10 hover:text-ink"><Minus size={13} /></button>
      <span className="num w-14 text-center text-[13px] font-semibold">{value}{suffix}</span>
      <button aria-label="Increase" onClick={() => onChange(Math.min(max, value + step))} className="grid h-7 w-7 place-items-center rounded-full text-ink-3 hover:bg-white/10 hover:text-ink"><Plus size={13} /></button>
    </div>
  );
}

function Row({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 py-3">
      <div>
        <div className="text-[14px] font-semibold">{label}</div>
        {hint && <div className="text-[12px] text-ink-3">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

export function SettingsModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const s = useStore((x) => x.settings);
  const update = useStore((x) => x.updateSettings);
  const resetAll = useStore((x) => x.resetAll);
  const toast = useUI((u) => u.toast);
  return (
    <Modal open={open} onClose={onClose} className="max-w-[440px]">
      <div className="mb-2 flex items-center justify-between">
        <h2 className="font-display text-xl font-extrabold">Settings</h2>
        <Button size="sm" variant="ghost" onClick={onClose}>Done</Button>
      </div>
      <div className="divide-y divide-white/[0.06]">
        <Row label="Your name">
          <input className="field !w-40 !py-2 text-right" maxLength={16} value={s.name} onChange={(e) => update({ name: e.target.value })} />
        </Row>
        <Row label="Weekly goal" hint="Hours of focus per week">
          <Stepper value={s.weeklyGoalH} onChange={(n) => update({ weeklyGoalH: n })} min={1} max={60} suffix="h" />
        </Row>
        <Row label="Focus length">
          <Stepper value={s.focusMin} onChange={(n) => update({ focusMin: n })} min={5} max={120} step={5} suffix="m" />
        </Row>
        <Row label="Short break">
          <Stepper value={s.shortMin} onChange={(n) => update({ shortMin: n })} min={1} max={30} suffix="m" />
        </Row>
        <Row label="Long break">
          <Stepper value={s.longMin} onChange={(n) => update({ longMin: n })} min={5} max={60} step={5} suffix="m" />
        </Row>
        <Row label="Auto-start breaks" hint="Begin the break as soon as a session ends">
          <Toggle on={s.autoBreaks} onChange={(v) => update({ autoBreaks: v })} label="Auto-start breaks" />
        </Row>
        <Row label="Completion chime">
          <Toggle on={s.chime} onChange={(v) => update({ chime: v })} label="Completion chime" />
        </Row>
      </div>
      <div className="mt-4 flex items-center justify-between rounded-2xl bg-white/[0.03] p-3.5">
        <div className="text-[12.5px] text-ink-3">Everything lives in this browser.</div>
        <Button
          size="sm"
          variant="danger"
          onClick={() => {
            if (window.confirm("Erase all sessions, tasks and companions on this device?")) {
              localStorage.removeItem("focusarx-v1");
              resetAll();
              toast({ title: "Data erased", body: "Starting fresh." });
              onClose();
              setTimeout(() => window.location.reload(), 400);
            }
          }}
        >
          Reset data
        </Button>
      </div>
    </Modal>
  );
}
