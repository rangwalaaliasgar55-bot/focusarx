import { Suspense, useEffect, useImperativeHandle, useMemo, useRef, useState, type Ref, type RefObject } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Html, Sparkles, Stars } from "@react-three/drei";
import * as THREE from "three";
import { Pet3D, mkAnim, nowSec, type PetAnim } from "./Pet3D";
import { Particles, type ParticleAPI } from "./Particles";
import { StudioEnvironment, getGlowTexture } from "./PetStage";
import { ELEMENT_COLOR, SPECIES, type AccessoryId, type Move, type MoveElement, type SpeciesId } from "../../lib/pets";
import type { Side } from "../../lib/battle";
import { sfx } from "../../lib/sound";

export interface ImpactOpts {
  dmg: number;
  crit: boolean;
  eff: number;
  element: MoveElement;
  big: boolean;
}

export interface ArenaHandle {
  /** Plays the attacker's wind-up + projectile. Resolves at the moment of impact. */
  attack: (side: Side, move: Move) => Promise<void>;
  impact: (defender: Side, o: ImpactOpts) => void;
  miss: (defender: Side) => void;
  selfCast: (side: Side, kind: "heal" | "guard" | "boost", element: MoveElement) => void;
  setGuard: (side: Side, on: boolean) => void;
  faint: (side: Side) => void;
  victory: (side: Side) => void;
  heal: (side: Side, amount: number) => void;
}

const PLAYER_POS = new THREE.Vector3(-2.25, 0, 0.7);
const ENEMY_POS = new THREE.Vector3(2.25, 0, -0.7);
const PLAYER_YAW = 1.3;
const ENEMY_YAW = -0.92;
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
const clamp = THREE.MathUtils.clamp;
const easeOut = (k: number) => 1 - Math.pow(1 - clamp(k, 0, 1), 3);
const easeInOut = (k: number) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2);
const easeOutBack = (k: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  const x = clamp(k, 0, 1);
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};

interface FxState {
  lungeT0: number;
  recoilT0: number;
  recoil: number;
}

function ArenaPet({
  base, target, yaw, species, accessory, animRef, fx, shield, delay, scale = 1.32,
}: {
  base: THREE.Vector3; target: THREE.Vector3; yaw: number; species: SpeciesId; accessory?: AccessoryId | null;
  animRef: RefObject<PetAnim>; fx: RefObject<FxState>; shield: boolean; delay: number; scale?: number;
}) {
  const g = useRef<THREE.Group>(null);
  const born = useMemo(() => nowSec(), []);
  const dir = useMemo(() => target.clone().sub(base).setY(0).normalize(), [base, target]);
  const dist = useMemo(() => base.distanceTo(target) - 2.15, [base, target]);

  useFrame(() => {
    const grp = g.current;
    if (!grp) return;
    const now = nowSec();
    const f = fx.current!;
    const sp = easeOutBack((now - born - delay) / 0.8);
    let L = 0;
    const le = now - f.lungeT0;
    if (le >= 0 && le < 1.0) {
      if (le < 0.28) L = -0.4 * easeOut(le / 0.28);
      else if (le < 0.5) L = -0.4 + (dist + 0.4) * easeOut((le - 0.28) / 0.22);
      else if (le < 0.64) L = dist;
      else L = dist * (1 - easeInOut((le - 0.64) / 0.36));
    }
    const re = now - f.recoilT0;
    const R = re >= 0 && re < 0.9 ? f.recoil * 0.75 * Math.exp(-re * 4.2) * Math.min(1, re * 30) : 0;
    grp.position.set(base.x + dir.x * (L - R), 0, base.z + dir.z * (L - R));
    grp.rotation.y = yaw;
    grp.scale.setScalar(Math.max(0.0001, scale * sp));
  });

  return (
    <group ref={g} position={base.toArray()}>
      <Pet3D species={species} animRef={animRef} accessory={accessory} shield={shield} />
    </group>
  );
}

interface Proj {
  active: boolean;
  t0: number;
  dur: number;
  from: THREE.Vector3;
  to: THREE.Vector3;
  color: string;
  size: number;
  arc: number;
  swirl: boolean;
  done?: () => void;
}

function CameraRig({ shake, focusX, punch }: { shake: RefObject<number>; focusX: RefObject<number>; punch: RefObject<number> }) {
  const { camera, size } = useThree();
  const look = useMemo(() => new THREE.Vector3(0, 1.0, 0), []);
  const cam = camera as THREE.PerspectiveCamera;
  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const t = state.clock.elapsedTime;
    const aspect = size.width / size.height;
    const dist = clamp(9.3 * Math.max(1, 1.5 / aspect), 9.3, 22);
    const sh = shake.current!;
    shake.current = Math.max(0, sh - dt * 1.6);
    const bx = Math.sin(t * 0.25) * 0.7 + focusX.current! * 0.22;
    const target = new THREE.Vector3(bx + (Math.random() - 0.5) * sh, 3.1 + dist * 0.035 + Math.sin(t * 0.4) * 0.12 + (Math.random() - 0.5) * sh, dist);
    cam.position.lerp(target, 1 - Math.exp(-dt * 4));
    look.lerp(new THREE.Vector3(focusX.current! * 0.4, 1.0, 0), 1 - Math.exp(-dt * 4));
    cam.lookAt(look);
    punch.current = Math.max(0, punch.current! - dt * 2.2);
    cam.fov = 32 - punch.current! * 3.5;
    cam.updateProjectionMatrix();
  });
  return null;
}

interface Popup {
  id: number;
  side: Side;
  text: string;
  sub?: string;
  color: string;
  big: boolean;
}

function World({ handleRef, player, enemy, playerAcc }: { handleRef: Ref<ArenaHandle>; player: SpeciesId; enemy: SpeciesId; playerAcc?: AccessoryId | null }) {
  const tex = useMemo(() => getGlowTexture(), []);
  const particles = useRef<ParticleAPI>(null);
  const animP = useRef<PetAnim>(mkAnim("idle"));
  const animE = useRef<PetAnim>(mkAnim("idle"));
  const fxP = useRef<FxState>({ lungeT0: -99, recoilT0: -99, recoil: 1 });
  const fxE = useRef<FxState>({ lungeT0: -99, recoilT0: -99, recoil: 1 });
  const shake = useRef(0);
  const punch = useRef(0);
  const focusX = useRef(0);
  const [guard, setGuardState] = useState({ player: false, enemy: false });
  const [popups, setPopups] = useState<Popup[]>([]);
  const popId = useRef(0);

  const projs = useRef<Proj[]>(Array.from({ length: 3 }, () => ({ active: false, t0: 0, dur: 1, from: new THREE.Vector3(), to: new THREE.Vector3(), color: "#fff", size: 1, arc: 0, swirl: false })));
  const projMeshes = [useRef<THREE.Group>(null), useRef<THREE.Group>(null), useRef<THREE.Group>(null)];
  const projSprites = [useRef<THREE.Sprite>(null), useRef<THREE.Sprite>(null), useRef<THREE.Sprite>(null)];
  const rings = useRef<{ t0: number; scale: number }[]>(Array.from({ length: 5 }, () => ({ t0: -99, scale: 1 })));
  const ringMeshes = useRef<(THREE.Mesh | null)[]>([]);
  const ringIdx = useRef(0);
  const flash = useRef({ t0: -99, scale: 1, pos: new THREE.Vector3(), color: "#fff" });
  const flashSprite = useRef<THREE.Sprite>(null);
  const column = useRef({ t0: -99, pos: new THREE.Vector3(), color: "#fff" });
  const columnMesh = useRef<THREE.Mesh>(null);
  const crystals = useRef<THREE.Group>(null);

  const pos = (s: Side) => (s === "player" ? PLAYER_POS : ENEMY_POS);
  const anim = (s: Side) => (s === "player" ? animP : animE);
  const fxOf = (s: Side) => (s === "player" ? fxP : fxE);
  const chest = (s: Side, h = 1.1) => new THREE.Vector3(pos(s).x, h, pos(s).z);
  const other = (s: Side): Side => (s === "player" ? "enemy" : "player");

  const addRing = (at: THREE.Vector3, scale: number, color: string) => {
    const i = ringIdx.current++ % rings.current.length;
    rings.current[i] = { t0: nowSec(), scale };
    const m = ringMeshes.current[i];
    if (m) {
      m.position.set(at.x, 0.06, at.z);
      (m.material as THREE.MeshBasicMaterial).color.set(color);
    }
  };

  const pop = (side: Side, text: string, color: string, big = false, sub?: string) => {
    const id = popId.current++;
    setPopups((p) => [...p.slice(-5), { id, side, text, sub, color, big }]);
    setTimeout(() => setPopups((p) => p.filter((x) => x.id !== id)), 1500);
  };

  const launch = (from: THREE.Vector3, to: THREE.Vector3, color: string, size: number, dur: number, arc: number, swirl: boolean) =>
    new Promise<void>((resolve) => {
      const slot = projs.current.find((p) => !p.active) ?? projs.current[0];
      Object.assign(slot, { active: true, t0: nowSec(), dur, color, size, arc, swirl, done: resolve });
      slot.from.copy(from);
      slot.to.copy(to);
      const i = projs.current.indexOf(slot);
      const sp = projSprites[i].current;
      if (sp) (sp.material as THREE.SpriteMaterial).color.set(color);
    });

  useImperativeHandle(
    handleRef,
    () => ({
      attack: async (side, move) => {
        const def = other(side);
        const el = move.element;
        const color = ELEMENT_COLOR[el];
        const a = anim(side);
        focusX.current = pos(side).x;
        if (move.style === "melee") {
          a.current = mkAnim("attack");
          fxOf(side).current!.lungeT0 = nowSec();
          sfx("whoosh");
          particles.current?.emit({ pos: [pos(side).x, 0.1, pos(side).z], count: 10, color: "#ffffff", speed: 1.2, life: 0.5, size: 0.07, spread: 1 });
          await sleep(470);
          return;
        }
        // ranged: charge, then fire
        a.current = mkAnim("cast");
        sfx("cast");
        const hand = chest(side, 1.55);
        const charge = move.big ? 700 : 520;
        const steps = 8;
        for (let i = 0; i < steps; i++) {
          setTimeout(() => particles.current?.emit({ pos: hand.toArray() as [number, number, number], count: move.big ? 7 : 4, color, speed: -1.4, life: 0.45, size: 0.06, jitter: 1.2, spread: 1 }), (charge / steps) * i);
        }
        await sleep(charge);
        const from = chest(side, 1.35);
        const to = chest(def, 1.15);
        if (el === "electric") {
          // lightning column from the sky
          column.current = { t0: nowSec(), pos: new THREE.Vector3(to.x, 0, to.z), color };
          for (let i = 0; i < 26; i++) {
            const y = (i / 26) * 7;
            particles.current?.emit({ pos: [to.x + (Math.random() - 0.5) * 0.7, y, to.z + (Math.random() - 0.5) * 0.7], count: 2, color: "#fff7b0", speed: 0.6, life: 0.4, size: 0.1, spread: 1 });
          }
          sfx("crit");
          await sleep(180);
          return;
        }
        await launch(from, to, color, move.big ? 1.9 : 1.15, move.big ? 0.62 : 0.46, move.big ? 0.9 : 0.5, el === "nature" || el === "cosmic");
      },

      impact: (defender, o) => {
        const color = ELEMENT_COLOR[o.element];
        const at = chest(defender);
        const big = o.big || o.crit;
        anim(defender).current = mkAnim("hurt");
        const f = fxOf(defender).current!;
        f.recoilT0 = nowSec();
        f.recoil = (o.crit ? 1.5 : o.eff > 1 ? 1.2 : 0.85) * (o.big ? 1.4 : 1);
        particles.current?.emit({ pos: at.toArray() as [number, number, number], count: Math.round((big ? 70 : 38) * (o.eff > 1 ? 1.3 : 1)), color, speed: big ? 5 : 3.6, life: 0.9, size: big ? 0.11 : 0.08, gravity: 3, spread: 1 });
        particles.current?.emit({ pos: at.toArray() as [number, number, number], count: big ? 26 : 12, color: "#ffffff", speed: 4.4, life: 0.5, size: 0.06, spread: 1 });
        addRing(at, big ? 1.5 : 1, color);
        flash.current = { t0: nowSec(), scale: big ? 4.2 : 2.6, pos: at.clone(), color };
        const sp = flashSprite.current;
        if (sp) (sp.material as THREE.SpriteMaterial).color.set(color);
        shake.current = clamp(0.12 + o.dmg / 110 + (o.crit ? 0.18 : 0) + (o.big ? 0.15 : 0), 0.1, 0.65);
        punch.current = big ? 1 : 0.55;
        focusX.current = pos(defender).x;
        sfx(o.crit || o.big ? "crit" : "hit");
        pop(defender, `-${o.dmg}`, o.crit ? "#fbbf24" : "#ffffff", big, o.crit ? "Critical hit!" : o.eff > 1 ? "Super effective" : o.eff < 1 ? "Not very effective" : undefined);
      },

      miss: (defender) => {
        pop(defender, "Miss", "#8e9199", false, "Dodged");
        anim(defender).current = mkAnim("happy");
        const f = fxOf(defender).current!;
        f.recoilT0 = nowSec();
        f.recoil = -0.6;
        sfx("whoosh");
      },

      selfCast: (side, kind, element) => {
        const at = chest(side, 0.8);
        const color = kind === "heal" ? "#4ade80" : ELEMENT_COLOR[element];
        anim(side).current = mkAnim(kind === "heal" ? "heal" : kind === "guard" ? "guard" : "boost");
        particles.current?.emit({ pos: at.toArray() as [number, number, number], count: 40, color, speed: 1.8, life: 1.2, size: 0.07, gravity: -1.5, dir: [0, 1, 0], spread: 0.5, jitter: 1 });
        addRing(new THREE.Vector3(pos(side).x, 0, pos(side).z), 1.1, color);
        focusX.current = pos(side).x;
        sfx(kind === "heal" ? "heal" : "boost");
        if (kind !== "guard") setTimeout(() => (anim(side).current = mkAnim("idle")), 1300);
        else setTimeout(() => (anim(side).current = mkAnim("idle")), 900);
      },

      setGuard: (side, on) => setGuardState((g) => ({ ...g, [side]: on })),

      heal: (side, amount) => pop(side, `+${amount}`, "#4ade80", false),

      faint: (side) => {
        anim(side).current = mkAnim("faint");
        const at = chest(side, 0.7);
        particles.current?.emit({ pos: at.toArray() as [number, number, number], count: 36, color: "#9ca3af", speed: 1.4, life: 1.4, size: 0.1, gravity: -0.6, spread: 1, jitter: 0.6 });
        shake.current = 0.35;
      },

      victory: (side) => {
        anim(side).current = mkAnim("victory");
        const at = chest(side, 0.4);
        for (let i = 0; i < 4; i++)
          setTimeout(() => particles.current?.emit({ pos: at.toArray() as [number, number, number], count: 40, color: ["#fbbf24", "#7b7cff", "#34d399", "#fb7185"][i], speed: 4, life: 1.6, size: 0.08, gravity: 3, dir: [0, 1, 0], spread: 0.6 }), i * 260);
        focusX.current = pos(side).x;
      },
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  useEffect(() => {
    // entrance puff
    const t = setTimeout(() => {
      particles.current?.emit({ pos: [ENEMY_POS.x, 0.3, ENEMY_POS.z], count: 40, color: ELEMENT_COLOR[SPECIES[enemy].element], speed: 2.6, life: 1, size: 0.09, spread: 1, jitter: 0.8 });
      particles.current?.emit({ pos: [PLAYER_POS.x, 0.3, PLAYER_POS.z], count: 40, color: ELEMENT_COLOR[SPECIES[player].element], speed: 2.6, life: 1, size: 0.09, spread: 1, jitter: 0.8 });
    }, 400);
    return () => clearTimeout(t);
  }, [player, enemy]);

  useFrame((state) => {
    const now = nowSec();
    // projectiles
    projs.current.forEach((p, i) => {
      const grp = projMeshes[i].current;
      if (!grp) return;
      if (!p.active) {
        grp.visible = false;
        return;
      }
      const k = (now - p.t0) / p.dur;
      if (k >= 1) {
        p.active = false;
        grp.visible = false;
        p.done?.();
        return;
      }
      grp.visible = true;
      const e = easeInOut(Math.min(1, k * 1.05));
      const x = THREE.MathUtils.lerp(p.from.x, p.to.x, e);
      const z = THREE.MathUtils.lerp(p.from.z, p.to.z, e);
      let y = THREE.MathUtils.lerp(p.from.y, p.to.y, e) + Math.sin(k * Math.PI) * p.arc;
      let ox = 0;
      if (p.swirl) {
        ox = Math.cos(k * 26) * 0.22;
        y += Math.sin(k * 26) * 0.22;
      }
      grp.position.set(x + ox, y, z);
      const s = p.size * (1 + Math.sin(now * 30) * 0.08);
      grp.scale.setScalar(s);
      particles.current?.emit({ pos: [x + ox, y, z], count: p.size > 1.5 ? 4 : 2, color: p.color, speed: 0.5, life: 0.5, size: 0.08 * p.size, spread: 1, jitter: 0.15 * p.size });
    });
    // rings
    rings.current.forEach((r, i) => {
      const m = ringMeshes.current[i];
      if (!m) return;
      const k = (now - r.t0) / 0.7;
      if (k < 0 || k > 1) {
        m.visible = false;
        return;
      }
      m.visible = true;
      const s = (0.4 + easeOut(k) * 3.2) * r.scale;
      m.scale.set(s, s, 1);
      (m.material as THREE.MeshBasicMaterial).opacity = (1 - k) * 0.9;
    });
    // flash
    const fs = flashSprite.current;
    if (fs) {
      const k = (now - flash.current.t0) / 0.35;
      if (k < 0 || k > 1) fs.visible = false;
      else {
        fs.visible = true;
        fs.position.copy(flash.current.pos);
        const s = flash.current.scale * (0.5 + easeOut(k));
        fs.scale.set(s, s, 1);
        (fs.material as THREE.SpriteMaterial).opacity = 1 - k;
      }
    }
    // lightning column
    const cm = columnMesh.current;
    if (cm) {
      const k = (now - column.current.t0) / 0.45;
      if (k < 0 || k > 1) cm.visible = false;
      else {
        cm.visible = true;
        cm.position.set(column.current.pos.x, 3.5, column.current.pos.z);
        const flicker = Math.random() > 0.35 ? 1 : 0.35;
        cm.scale.set((1 - k) * flicker * 1.2 + 0.2, 1, (1 - k) * flicker * 1.2 + 0.2);
        (cm.material as THREE.MeshBasicMaterial).opacity = (1 - k) * flicker;
      }
    }
    if (crystals.current) {
      crystals.current.rotation.y = state.clock.elapsedTime * 0.05;
      crystals.current.children.forEach((c, i) => {
        c.position.y = 1.2 + (i % 3) * 0.9 + Math.sin(state.clock.elapsedTime * 0.6 + i) * 0.25;
        c.rotation.y += 0.004 + i * 0.0005;
        c.rotation.x += 0.003;
      });
    }
  });

  const pc = ELEMENT_COLOR[SPECIES[player].element];
  const ec = ELEMENT_COLOR[SPECIES[enemy].element];

  return (
    <>
      <color attach="background" args={["#07070c"]} />
      <fog attach="fog" args={["#07070c", 14, 34]} />
      <ambientLight intensity={0.45} />
      <directionalLight position={[3, 7, 6]} intensity={2.4} castShadow shadow-mapSize={[2048, 2048]} shadow-bias={-0.0003}>
        <orthographicCamera attach="shadow-camera" args={[-7, 7, 6, -6, 0.5, 22]} />
      </directionalLight>
      <pointLight position={[PLAYER_POS.x - 1.5, 2.4, PLAYER_POS.z + 1.4]} intensity={22} color={pc} distance={9} />
      <pointLight position={[ENEMY_POS.x + 1.5, 2.4, ENEMY_POS.z + 1.4]} intensity={22} color={ec} distance={9} />
      <StudioEnvironment />
      <Stars radius={60} depth={40} count={1800} factor={3.5} saturation={0} fade speed={0.6} />
      <Sparkles count={60} scale={[14, 5, 8]} size={2.5} speed={0.25} opacity={0.5} color="#b4b5ff" position={[0, 2.5, 0]} />

      {/* platform */}
      <group>
        <mesh position={[0, -0.2, 0]} receiveShadow>
          <cylinderGeometry args={[5, 5.3, 0.4, 96]} />
          <meshStandardMaterial color="#14151a" roughness={0.38} metalness={0.55} />
        </mesh>
        <mesh position={[0, 0.005, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
          <circleGeometry args={[4.9, 96]} />
          <meshStandardMaterial color="#1a1b22" roughness={0.5} metalness={0.4} />
        </mesh>
        {[4.75, 3.3, 1.6].map((r, i) => (
          <mesh key={r} position={[0, 0.012 + i * 0.001, 0]} rotation={[-Math.PI / 2, 0, 0]}>
            <ringGeometry args={[r - 0.025, r, 128]} />
            <meshBasicMaterial color={i === 1 ? "#7b7cff" : "#3a3b50"} transparent opacity={i === 1 ? 0.7 : 0.8} toneMapped={false} />
          </mesh>
        ))}
        {/* team pads */}
        {[
          { p: PLAYER_POS, c: pc },
          { p: ENEMY_POS, c: ec },
        ].map(({ p, c }, i) => (
          <group key={i} position={[p.x, 0.02, p.z]}>
            <mesh rotation={[-Math.PI / 2, 0, 0]}>
              <ringGeometry args={[1.05, 1.12, 64]} />
              <meshBasicMaterial color={c} toneMapped={false} />
            </mesh>
            <mesh rotation={[-Math.PI / 2, 0, 0]}>
              <circleGeometry args={[1.5, 48]} />
              <meshBasicMaterial map={tex} color={c} transparent opacity={0.45} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
            </mesh>
          </group>
        ))}
        {/* floating crystals */}
        <group ref={crystals}>
          {Array.from({ length: 9 }, (_, i) => {
            const a = (i / 9) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 6.4, 1.5, Math.sin(a) * 6.4 - 1]} scale={0.3 + (i % 3) * 0.14}>
                <octahedronGeometry args={[1, 0]} />
                <meshStandardMaterial color={i % 2 ? pc : ec} emissive={i % 2 ? pc : ec} emissiveIntensity={0.9} roughness={0.2} metalness={0.3} />
              </mesh>
            );
          })}
        </group>
      </group>

      <ArenaPet base={PLAYER_POS} target={ENEMY_POS} yaw={PLAYER_YAW} species={player} accessory={playerAcc} animRef={animP} fx={fxP} shield={guard.player} delay={0.1} />
      <ArenaPet base={ENEMY_POS} target={PLAYER_POS} yaw={ENEMY_YAW} species={enemy} animRef={animE} fx={fxE} shield={guard.enemy} delay={0.35} />

      {/* projectiles: glowing sprite + hard core */}
      {projMeshes.map((r, i) => (
        <group key={i} ref={r} visible={false}>
          <sprite ref={projSprites[i]} scale={[1.6, 1.6, 1]}>
            <spriteMaterial map={tex} transparent depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
          </sprite>
          <mesh>
            <icosahedronGeometry args={[0.2, 2]} />
            <meshBasicMaterial color="#ffffff" toneMapped={false} />
          </mesh>
        </group>
      ))}
      {/* shockwave rings */}
      {Array.from({ length: 5 }, (_, i) => (
        <mesh key={i} ref={(m) => { ringMeshes.current[i] = m; }} rotation={[-Math.PI / 2, 0, 0]} visible={false}>
          <ringGeometry args={[0.85, 1, 64]} />
          <meshBasicMaterial transparent depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
        </mesh>
      ))}
      <sprite ref={flashSprite} visible={false}>
        <spriteMaterial map={tex} transparent depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
      </sprite>
      <mesh ref={columnMesh} visible={false}>
        <cylinderGeometry args={[0.18, 0.28, 7, 12, 1, true]} />
        <meshBasicMaterial color="#fff7b0" transparent depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
      </mesh>

      <Particles apiRef={particles} max={900} />

      {popups.map((p) => (
        <Html key={p.id} position={[pos(p.side).x, 2.9, pos(p.side).z]} center zIndexRange={[30, 0]} style={{ pointerEvents: "none" }}>
          <div className="popup-float flex flex-col items-center whitespace-nowrap font-display font-extrabold" style={{ color: p.color }}>
            <span style={{ fontSize: p.big ? 44 : 32, textShadow: "0 4px 24px rgba(0,0,0,.7), 0 0 20px rgba(0,0,0,.5)", letterSpacing: "-0.03em" }}>{p.text}</span>
            {p.sub && <span className="text-[12px] font-bold uppercase tracking-widest text-white/80" style={{ textShadow: "0 2px 10px rgba(0,0,0,.8)" }}>{p.sub}</span>}
          </div>
        </Html>
      ))}

      <CameraRig shake={shake} focusX={focusX} punch={punch} />
    </>
  );
}

export function ArenaScene({ handleRef, player, enemy, playerAcc, className }: { handleRef: Ref<ArenaHandle>; player: SpeciesId; enemy: SpeciesId; playerAcc?: AccessoryId | null; className?: string }) {
  return (
    <div className={className}>
      <Canvas shadows dpr={[1, 1.75]} camera={{ position: [0, 3.4, 9.5], fov: 32, near: 0.1, far: 80 }} gl={{ antialias: true }}>
        <Suspense fallback={null}>
          <World handleRef={handleRef} player={player} enemy={enemy} playerAcc={playerAcc} />
        </Suspense>
      </Canvas>
    </div>
  );
}
