import { SPECIES, type SpeciesId } from "../../lib/pets";

/** Lightweight flat SVG portrait of a species — used in lists so we don't spin up extra WebGL contexts. */
export function PetAvatar({ species, size = 56, ring = false }: { species: SpeciesId; size?: number; ring?: boolean }) {
  const l = SPECIES[species].look;
  const id = `g-${species}`;
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={{ overflow: "visible" }}>
      <defs>
        <radialGradient id={id} cx="35%" cy="30%" r="80%">
          <stop offset="0%" stopColor={l.fur} stopOpacity="1" />
          <stop offset="100%" stopColor={l.fur} stopOpacity="0.78" />
        </radialGradient>
      </defs>
      {ring && <circle cx="50" cy="52" r="48" fill="none" stroke={l.fur} strokeOpacity="0.4" strokeWidth="2" />}
      {l.ears === "pointy" && (
        <>
          <path d="M18 44 L22 8 L46 26 Z" fill={l.fur} />
          <path d="M82 44 L78 8 L54 26 Z" fill={l.fur} />
          <path d="M24 34 L25 18 L37 27 Z" fill={l.inner} />
          <path d="M76 34 L75 18 L63 27 Z" fill={l.inner} />
          <path d="M22 8 L26 20 L18 18 Z" fill={l.earTip ?? l.fur} />
          <path d="M78 8 L74 20 L82 18 Z" fill={l.earTip ?? l.fur} />
        </>
      )}
      {l.ears === "long" && (
        <>
          <rect x="22" y="-6" width="18" height="48" rx="9" fill={l.fur} transform="rotate(-10 31 40)" />
          <rect x="60" y="-6" width="18" height="48" rx="9" fill={l.fur} transform="rotate(10 69 40)" />
          <rect x="26" y="0" width="9" height="34" rx="4.5" fill={l.inner} transform="rotate(-10 31 40)" />
          <rect x="65" y="0" width="9" height="34" rx="4.5" fill={l.inner} transform="rotate(10 69 40)" />
        </>
      )}
      {l.ears === "round" && (
        <>
          <circle cx="24" cy="26" r="13" fill={l.fur} />
          <circle cx="76" cy="26" r="13" fill={l.fur} />
          <circle cx="24" cy="27" r="7" fill={l.inner} />
          <circle cx="76" cy="27" r="7" fill={l.inner} />
        </>
      )}
      {l.extras.includes("horns") && (
        <>
          <path d="M30 28 L26 6 L42 22 Z" fill="#f6e6c4" />
          <path d="M70 28 L74 6 L58 22 Z" fill="#f6e6c4" />
        </>
      )}
      {l.extras.includes("gills") && (
        <g stroke={l.accent} strokeWidth="5" strokeLinecap="round">
          <path d="M14 46 L2 36" /><path d="M13 54 L0 54" /><path d="M14 62 L3 72" />
          <path d="M86 46 L98 36" /><path d="M87 54 L100 54" /><path d="M86 62 L97 72" />
        </g>
      )}
      {l.extras.includes("sprout") && (
        <g>
          <rect x="48.5" y="8" width="3" height="12" rx="1.5" fill="#3fbf5a" />
          <ellipse cx="42" cy="8" rx="9" ry="4.5" fill="#3fbf5a" transform="rotate(-25 42 8)" />
          <ellipse cx="58" cy="8" rx="9" ry="4.5" fill="#3fbf5a" transform="rotate(25 58 8)" />
        </g>
      )}
      <ellipse cx="50" cy="56" rx="42" ry="36" fill={`url(#${id})`} />
      <ellipse cx="50" cy="68" rx="20" ry="13" fill={l.muzzle ?? l.belly} opacity="0.95" />
      {l.extras.includes("star") && <path d="M50 24 L53 31 L60 32 L55 37 L56 44 L50 40 L44 44 L45 37 L40 32 L47 31 Z" fill="#ffe27a" />}
      <ellipse cx="34" cy="54" rx="5.5" ry="7.5" fill={l.eye} />
      <ellipse cx="66" cy="54" rx="5.5" ry="7.5" fill={l.eye} />
      <circle cx="36" cy="51" r="2" fill="#fff" />
      <circle cx="68" cy="51" r="2" fill="#fff" />
      <ellipse cx="24" cy="66" rx="6" ry="4" fill={l.cheek} opacity="0.7" />
      <ellipse cx="76" cy="66" rx="6" ry="4" fill={l.cheek} opacity="0.7" />
      <ellipse cx="50" cy="62" rx="3.2" ry="2.4" fill="#2a1c20" />
      <path d="M43 69 Q50 76 57 69" stroke="#2a1c20" strokeWidth="2.2" fill="none" strokeLinecap="round" />
    </svg>
  );
}
