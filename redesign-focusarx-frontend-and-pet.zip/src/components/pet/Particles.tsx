import { useEffect, useImperativeHandle, useMemo, useRef, type Ref } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

export interface EmitOpts {
  pos: [number, number, number];
  count: number;
  color: string;
  speed?: number;
  life?: number;
  size?: number;
  gravity?: number;
  /** velocity direction bias */
  dir?: [number, number, number];
  /** 0 = all along dir, 1 = fully spherical */
  spread?: number;
  /** random positional jitter */
  jitter?: number;
}
export interface ParticleAPI {
  emit: (o: EmitOpts) => void;
}

/** Pooled additive particle system: one draw call, zero allocations per frame. */
export function Particles({ apiRef, max = 700 }: { apiRef: Ref<ParticleAPI>; max?: number }) {
  const mesh = useRef<THREE.InstancedMesh>(null);
  const data = useMemo(
    () => ({
      pos: new Float32Array(max * 3),
      vel: new Float32Array(max * 3),
      life: new Float32Array(max),
      maxLife: new Float32Array(max),
      size: new Float32Array(max),
      grav: new Float32Array(max),
      head: 0,
      dummy: new THREE.Object3D(),
      color: new THREE.Color(),
    }),
    [max]
  );

  useEffect(() => {
    const m = mesh.current;
    if (!m) return;
    const c = new THREE.Color("#fff");
    for (let i = 0; i < max; i++) {
      m.setColorAt(i, c);
      data.dummy.scale.setScalar(0);
      data.dummy.updateMatrix();
      m.setMatrixAt(i, data.dummy.matrix);
    }
    m.instanceMatrix.needsUpdate = true;
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
  }, [max, data]);

  useImperativeHandle(
    apiRef,
    () => ({
      emit: (o) => {
        const m = mesh.current;
        if (!m) return;
        const col = data.color.set(o.color);
        const dir = o.dir ?? [0, 1, 0];
        const spread = o.spread ?? 1;
        const speed = o.speed ?? 3;
        const dl = Math.hypot(dir[0], dir[1], dir[2]) || 1;
        for (let n = 0; n < o.count; n++) {
          const i = data.head;
          data.head = (data.head + 1) % max;
          const j = o.jitter ?? 0.05;
          data.pos[i * 3] = o.pos[0] + (Math.random() - 0.5) * j;
          data.pos[i * 3 + 1] = o.pos[1] + (Math.random() - 0.5) * j;
          data.pos[i * 3 + 2] = o.pos[2] + (Math.random() - 0.5) * j;
          // random unit vector
          const u = Math.random() * 2 - 1;
          const a = Math.random() * Math.PI * 2;
          const s = Math.sqrt(1 - u * u);
          const rx = s * Math.cos(a);
          const ry = u;
          const rz = s * Math.sin(a);
          const sp = speed * (0.35 + Math.random() * 0.75);
          data.vel[i * 3] = (dir[0] / dl) * (1 - spread) * sp + rx * spread * sp + (dir[0] / dl) * sp * 0.4 * spread;
          data.vel[i * 3 + 1] = (dir[1] / dl) * (1 - spread) * sp + ry * spread * sp + (dir[1] / dl) * sp * 0.4 * spread;
          data.vel[i * 3 + 2] = (dir[2] / dl) * (1 - spread) * sp + rz * spread * sp + (dir[2] / dl) * sp * 0.4 * spread;
          const life = (o.life ?? 0.8) * (0.6 + Math.random() * 0.6);
          data.life[i] = life;
          data.maxLife[i] = life;
          data.size[i] = (o.size ?? 0.06) * (0.6 + Math.random() * 0.8);
          data.grav[i] = o.gravity ?? 0;
          m.setColorAt(i, col);
        }
        if (m.instanceColor) m.instanceColor.needsUpdate = true;
      },
    }),
    [data, max]
  );

  useFrame((_, delta) => {
    const m = mesh.current;
    if (!m) return;
    const dt = Math.min(delta, 0.05);
    const { pos, vel, life, maxLife, size, grav, dummy } = data;
    for (let i = 0; i < max; i++) {
      if (life[i] <= 0) continue;
      life[i] -= dt;
      if (life[i] <= 0) {
        dummy.scale.setScalar(0);
        dummy.position.set(0, -50, 0);
        dummy.updateMatrix();
        m.setMatrixAt(i, dummy.matrix);
        continue;
      }
      vel[i * 3 + 1] -= grav[i] * dt;
      const drag = 1 - 1.4 * dt;
      vel[i * 3] *= drag;
      vel[i * 3 + 1] *= drag;
      vel[i * 3 + 2] *= drag;
      pos[i * 3] += vel[i * 3] * dt;
      pos[i * 3 + 1] += vel[i * 3 + 1] * dt;
      pos[i * 3 + 2] += vel[i * 3 + 2] * dt;
      const k = life[i] / maxLife[i];
      dummy.position.set(pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]);
      dummy.scale.setScalar(size[i] * Math.pow(k, 0.6));
      dummy.updateMatrix();
      m.setMatrixAt(i, dummy.matrix);
    }
    m.instanceMatrix.needsUpdate = true;
  });

  return (
    <instancedMesh ref={mesh} args={[undefined, undefined, max]} frustumCulled={false}>
      <icosahedronGeometry args={[1, 1]} />
      <meshBasicMaterial transparent depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
    </instancedMesh>
  );
}
