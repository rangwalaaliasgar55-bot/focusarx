import { Suspense, useEffect, useMemo, type ReactNode, type Ref } from "react";
import { Canvas, useThree } from "@react-three/fiber";
import { ContactShadows, Environment, Lightformer, OrbitControls, Sparkles } from "@react-three/drei";
import * as THREE from "three";
import { Pet3D, type PetAnim } from "./Pet3D";
import { Particles, type ParticleAPI } from "./Particles";
import { ELEMENT_COLOR, SPECIES, type AccessoryId, type SpeciesId } from "../../lib/pets";

let glowTex: THREE.CanvasTexture | null = null;
export function getGlowTexture() {
  if (glowTex) return glowTex;
  const c = document.createElement("canvas");
  c.width = c.height = 256;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  grd.addColorStop(0, "rgba(255,255,255,0.95)");
  grd.addColorStop(0.35, "rgba(255,255,255,0.35)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 256, 256);
  glowTex = new THREE.CanvasTexture(c);
  glowTex.colorSpace = THREE.SRGBColorSpace;
  return glowTex;
}

export function StudioEnvironment() {
  return (
    <Environment resolution={256} frames={1}>
      <Lightformer form="rect" intensity={2.4} position={[0, 5, 4]} scale={[10, 4, 1]} />
      <Lightformer form="rect" intensity={1.4} position={[-6, 2, 1]} rotation-y={Math.PI / 2} scale={[8, 4, 1]} color="#b9bbff" />
      <Lightformer form="rect" intensity={1.2} position={[6, 1, -2]} rotation-y={-Math.PI / 2} scale={[8, 4, 1]} color="#ffd9b8" />
      <Lightformer form="ring" intensity={1.5} position={[0, 3, -6]} scale={6} color="#ffffff" />
    </Environment>
  );
}

export function Pedestal({ color, radius = 1.5 }: { color: string; radius?: number }) {
  const tex = useMemo(() => getGlowTexture(), []);
  return (
    <group>
      <mesh position={[0, -0.07, 0]} receiveShadow>
        <cylinderGeometry args={[radius, radius * 1.04, 0.14, 72]} />
        <meshStandardMaterial color="#17181c" roughness={0.35} metalness={0.5} />
      </mesh>
      <mesh position={[0, 0.002, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[radius * 0.93, radius * 0.97, 96]} />
        <meshBasicMaterial color={color} toneMapped={false} transparent opacity={0.9} />
      </mesh>
      <mesh position={[0, 0.004, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[radius * 0.92, 72]} />
        <meshBasicMaterial map={tex} color={color} transparent opacity={0.22} depthWrite={false} blending={THREE.AdditiveBlending} toneMapped={false} />
      </mesh>
    </group>
  );
}

function CameraAim({ target }: { target: [number, number, number] }) {
  const { camera } = useThree();
  useEffect(() => {
    camera.lookAt(target[0], target[1], target[2]);
    camera.updateProjectionMatrix();
  }, [camera, target]);
  return null;
}

interface StageProps {
  species: SpeciesId;
  anim?: PetAnim;
  accessory?: AccessoryId | null;
  mood?: "happy" | "hungry" | "sad";
  follow?: boolean;
  interactive?: boolean;
  onPetClick?: () => void;
  fxRef?: Ref<ParticleAPI>;
  className?: string;
  camera?: [number, number, number];
  target?: [number, number, number];
  fov?: number;
  petScale?: number;
  pedestal?: boolean;
  sparkles?: boolean;
  children?: ReactNode;
}

export function PetStage({
  species, anim, accessory, mood, follow, interactive, onPetClick, fxRef, className, camera = [0, 1.5, 5.6], target = [0, 0.82, 0], fov = 30,
  petScale = 1, pedestal = true, sparkles = true, children,
}: StageProps) {
  const color = ELEMENT_COLOR[SPECIES[species].element];
  return (
    <div className={className} style={{ touchAction: interactive ? "pan-y" : undefined }}>
      <Canvas shadows dpr={[1, 2]} camera={{ position: camera, fov }} gl={{ antialias: true, alpha: true }} style={{ background: "transparent" }}>
        <Suspense fallback={null}>
          <ambientLight intensity={0.5} />
          <directionalLight position={[3.5, 5.5, 4]} intensity={2.4} castShadow shadow-mapSize={[1024, 1024]} shadow-bias={-0.0004}>
            <orthographicCamera attach="shadow-camera" args={[-3, 3, 3, -3, 0.5, 14]} />
          </directionalLight>
          <directionalLight position={[-4, 2.5, -3]} intensity={1.8} color={color} />
          <pointLight position={[0, 1.2, 3]} intensity={6} color="#ffffff" distance={8} />
          <StudioEnvironment />
          <CameraAim target={target} />
          {pedestal && <Pedestal color={color} />}
          <group scale={petScale}>
            <Pet3D species={species} anim={anim} accessory={accessory} mood={mood} follow={follow} onClick={onPetClick} />
          </group>
          {pedestal && <ContactShadows position={[0, 0.01, 0]} opacity={0.55} scale={6} blur={2.6} far={2.4} color="#000" />}
          {sparkles && <Sparkles count={26} scale={[3.4, 2.6, 3.4]} size={2.4} speed={0.25} opacity={0.7} color={color} position={[0, 1.1, 0]} />}
          {fxRef && <Particles apiRef={fxRef} max={260} />}
          {children}
          {interactive && (
            <OrbitControls
              enablePan={false}
              enableZoom={false}
              target={target}
              minPolarAngle={Math.PI / 2.9}
              maxPolarAngle={Math.PI / 2.05}
              enableDamping
              dampingFactor={0.08}
              rotateSpeed={0.7}
            />
          )}
        </Suspense>
      </Canvas>
    </div>
  );
}
