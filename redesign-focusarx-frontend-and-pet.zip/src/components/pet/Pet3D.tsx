import { useMemo, useRef, type RefObject } from "react";
import { useFrame } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import * as THREE from "three";
import { ELEMENT_COLOR, SPECIES, type AccessoryId, type SpeciesId } from "../../lib/pets";

export type PetAnimName =
  | "idle" | "happy" | "eat" | "sleep" | "focus" | "attack" | "cast" | "hurt" | "faint"
  | "victory" | "guard" | "heal" | "sad" | "wave" | "boost";
export interface PetAnim {
  name: PetAnimName;
  t0: number;
}
export const nowSec = () => performance.now() / 1000;
export const mkAnim = (name: PetAnimName): PetAnim => ({ name, t0: nowSec() });

/* ---------- shared geometry (built once) ---------- */
const G = {
  sphere: new THREE.SphereGeometry(1, 48, 32),
  cone: new THREE.ConeGeometry(0.5, 1, 32),
  capsule: new THREE.CapsuleGeometry(0.5, 1, 10, 24),
  cyl: new THREE.CylinderGeometry(1, 1, 1, 32),
};

function makeExtrude(shape: THREE.Shape, depth: number, bevel = 0.012) {
  const g = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: bevel > 0, bevelThickness: bevel, bevelSize: bevel, bevelSegments: 3, curveSegments: 12 });
  g.translate(0, 0, -depth / 2);
  return g;
}

const boltGeo = (() => {
  const s = new THREE.Shape();
  s.moveTo(-0.12, 0);
  s.lineTo(0.12, 0.38);
  s.lineTo(0.0, 0.38);
  s.lineTo(0.26, 0.9);
  s.lineTo(-0.18, 0.42);
  s.lineTo(-0.02, 0.42);
  s.closePath();
  return makeExtrude(s, 0.07, 0.02);
})();

const wingGeo = (() => {
  const s = new THREE.Shape();
  s.moveTo(0, 0);
  s.bezierCurveTo(0.12, 0.3, 0.35, 0.5, 0.75, 0.46);
  s.lineTo(0.6, 0.28);
  s.lineTo(0.72, 0.1);
  s.lineTo(0.5, 0.02);
  s.lineTo(0.5, -0.2);
  s.lineTo(0.28, -0.06);
  s.lineTo(0.14, -0.2);
  s.closePath();
  return makeExtrude(s, 0.025, 0.008);
})();

const starGeo = (() => {
  const s = new THREE.Shape();
  for (let i = 0; i < 10; i++) {
    const r = i % 2 === 0 ? 1 : 0.45;
    const a = (i / 10) * Math.PI * 2 + Math.PI / 2;
    const x = Math.cos(a) * r;
    const y = Math.sin(a) * r;
    if (i === 0) s.moveTo(x, y);
    else s.lineTo(x, y);
  }
  s.closePath();
  return makeExtrude(s, 0.3, 0.05);
})();

const damp = THREE.MathUtils.damp;
const clamp = THREE.MathUtils.clamp;
const easeOut = (k: number) => 1 - Math.pow(1 - clamp(k, 0, 1), 3);

interface Pose {
  y: number; sx: number; sy: number; tiltX: number; tiltZ: number; yaw: number;
  hp: number; hy: number; aA: number; aB: number; tailS: number; tailA: number;
  eye: number; ear: number; mouth: number; glow: number; wing: number; lean: number;
}
const REST: Pose = {
  y: 0, sx: 1, sy: 1, tiltX: 0, tiltZ: 0, yaw: 0, hp: 0, hy: 0, aA: 0, aB: 0, tailS: 3, tailA: 0.35,
  eye: 1, ear: 0, mouth: 0, glow: 0, wing: 0.4, lean: 0,
};

export interface Pet3DProps {
  species: SpeciesId;
  anim?: PetAnim;
  animRef?: RefObject<PetAnim>;
  accessory?: AccessoryId | null;
  mood?: "happy" | "hungry" | "sad";
  follow?: boolean;
  shield?: boolean;
  scale?: number;
  onClick?: () => void;
  onPointerOver?: () => void;
  onPointerOut?: () => void;
}

export function Pet3D({ species, anim, animRef, accessory, mood = "happy", follow = false, shield = false, scale = 1, onClick, onPointerOver, onPointerOut }: Pet3DProps) {
  const sp = SPECIES[species];
  const look = sp.look;
  const elColor = ELEMENT_COLOR[sp.element];

  const mats = useMemo(() => {
    const white = new THREE.Color("#ffffff");
    const std = (color: string, o: THREE.MeshPhysicalMaterialParameters = {}) =>
      new THREE.MeshPhysicalMaterial({
        color, roughness: 0.74, metalness: 0, sheen: 1, sheenRoughness: 0.5,
        sheenColor: new THREE.Color(color).lerp(white, 0.6), ...o,
      });
    const fur = std(look.fur);
    const belly = std(look.belly);
    const accent = std(look.accent);
    const inner = std(look.inner);
    const muzzle = std(look.muzzle ?? look.belly);
    const earTip = std(look.earTip ?? look.fur);
    const wing = std(look.wing ?? look.accent, { side: THREE.DoubleSide, roughness: 0.55 });
    return {
      fur, belly, accent, inner, muzzle, earTip, wing,
      cheek: std(look.cheek, { sheen: 0, roughness: 0.9, transparent: true, opacity: 0.85 }),
      eye: new THREE.MeshPhysicalMaterial({ color: look.eye, roughness: 0.12, clearcoat: 1, clearcoatRoughness: 0.05 }),
      white: new THREE.MeshBasicMaterial({ color: "#ffffff", toneMapped: false }),
      nose: new THREE.MeshPhysicalMaterial({ color: "#2a1c20", roughness: 0.25, clearcoat: 1 }),
      glowable: [fur, belly, accent, inner, muzzle, earTip, wing],
      emissiveStar: new THREE.MeshBasicMaterial({ color: "#ffe27a", toneMapped: false }),
      bolt: new THREE.MeshStandardMaterial({ color: "#ffd23f", emissive: "#ffb800", emissiveIntensity: 0.9, roughness: 0.4 }),
      flameOuter: new THREE.MeshBasicMaterial({ color: "#ff7a1a", transparent: true, opacity: 0.92, toneMapped: false }),
      flameInner: new THREE.MeshBasicMaterial({ color: "#ffd45a", transparent: true, opacity: 0.95, toneMapped: false }),
      moon: new THREE.MeshStandardMaterial({ color: "#fff1b0", emissive: "#ffd966", emissiveIntensity: 1.1, roughness: 0.4 }),
      bubble: new THREE.MeshPhysicalMaterial({ color: "#bfeaff", transparent: true, opacity: 0.35, roughness: 0, transmission: 0.6, clearcoat: 1 }),
      orb: new THREE.MeshBasicMaterial({ color: "#ffe27a", toneMapped: false }),
      shield: new THREE.MeshBasicMaterial({ color: elColor, transparent: true, opacity: 0.16, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }),
      gold: new THREE.MeshStandardMaterial({ color: "#ffcf5a", metalness: 0.9, roughness: 0.28, emissive: "#4a3000", emissiveIntensity: 0.4 }),
      dark: new THREE.MeshStandardMaterial({ color: "#1b1b20", roughness: 0.4, metalness: 0.4 }),
      lens: new THREE.MeshPhysicalMaterial({ color: "#9fd5ff", transparent: true, opacity: 0.22, roughness: 0, clearcoat: 1 }),
      brand: new THREE.MeshStandardMaterial({ color: "#7b7cff", emissive: "#4f51d6", emissiveIntensity: 0.6, roughness: 0.35 }),
      red: new THREE.MeshPhysicalMaterial({ color: "#e5484d", roughness: 0.5, sheen: 1 }),
      party: new THREE.MeshPhysicalMaterial({ color: "#ff5fa2", roughness: 0.5, sheen: 1 }),
      yellow: new THREE.MeshStandardMaterial({ color: "#ffe066", roughness: 0.5 }),
      horn: new THREE.MeshPhysicalMaterial({ color: "#f6e6c4", roughness: 0.45, clearcoat: 0.4 }),
      leaf: std("#3fbf5a", { roughness: 0.55 }),
      gill: std(look.accent, { roughness: 0.6 }),
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [species]);

  const R = {
    root: useRef<THREE.Group>(null),
    head: useRef<THREE.Group>(null),
    armA: useRef<THREE.Group>(null),
    armB: useRef<THREE.Group>(null),
    tail: useRef<THREE.Group>(null),
    earA: useRef<THREE.Group>(null),
    earB: useRef<THREE.Group>(null),
    eyeA: useRef<THREE.Group>(null),
    eyeB: useRef<THREE.Group>(null),
    smile: useRef<THREE.Mesh>(null),
    mouth: useRef<THREE.Mesh>(null),
    wingA: useRef<THREE.Group>(null),
    wingB: useRef<THREE.Group>(null),
    flame: useRef<THREE.Group>(null),
    orbs: useRef<THREE.Group>(null),
    shield: useRef<THREE.Mesh>(null),
    book: useRef<THREE.Group>(null),
    sprout: useRef<THREE.Group>(null),
  };

  const cur = useRef<Pose>({ ...REST });
  const blink = useRef({ next: 1 + Math.random() * 2 });
  const glowColor = useMemo(() => new THREE.Color(), []);

  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05);
    const t = state.clock.elapsedTime;
    const now = nowSec();
    const a = animRef?.current ?? anim ?? { name: "idle" as PetAnimName, t0: now };
    const e = now - a.t0;
    const tg: Pose = { ...REST };
    let glowCol = elColor;
    let lambda = 14;
    let showBook = false;

    // base idle
    const br = Math.sin(t * 2.1);
    tg.y = 0.012 * br;
    tg.sy = 1 + 0.02 * br;
    tg.sx = 1 - 0.01 * br;
    tg.hy = Math.sin(t * 0.55) * 0.22;
    tg.hp = Math.sin(t * 0.7) * 0.05;
    tg.aA = Math.sin(t * 2) * 0.06;
    tg.aB = -Math.sin(t * 2) * 0.06;
    tg.wing = 0.35 + Math.sin(t * 2.4) * 0.08;
    if (follow) {
      tg.hy = clamp(state.pointer.x * 0.9, -0.85, 0.85);
      tg.hp = clamp(-state.pointer.y * 0.45, -0.35, 0.35);
      tg.yaw = clamp(state.pointer.x * 0.22, -0.3, 0.3);
    }
    if (mood !== "happy") {
      tg.hp += mood === "sad" ? 0.32 : 0.2;
      tg.sy -= 0.04;
      tg.tailA *= 0.25;
      tg.ear = mood === "sad" ? 0.55 : 0.3;
      tg.eye = 0.8;
    }

    switch (a.name) {
      case "happy":
      case "victory": {
        const dur = a.name === "victory" ? 3.2 : 2.2;
        if (e < dur) {
          const k = 1 - e / dur;
          const jump = Math.abs(Math.sin(e * 6.5)) * 0.34 * (0.35 + 0.65 * k);
          tg.y = jump;
          tg.sy = 0.92 + (jump / 0.34) * 0.2;
          tg.sx = 1.06 - (jump / 0.34) * 0.08;
          tg.aA = -2.4 + Math.sin(e * 14) * 0.35;
          tg.aB = -2.4 - Math.sin(e * 14) * 0.35;
          tg.eye = 0.3;
          tg.tailS = 16;
          tg.tailA = 0.8;
          tg.hp = -0.15;
          tg.wing = 0.9 + Math.sin(e * 22) * 0.4;
          tg.mouth = 0.6;
          tg.ear = -0.15;
          if (a.name === "victory") tg.yaw = easeOut(e / 1.1) * Math.PI * 2;
          lambda = 18;
        } else if (cur.current.yaw > 3) {
          // a full turn is the same orientation — snap instead of spinning back
          cur.current.yaw = 0;
        }
        break;
      }
      case "eat": {
        if (e < 1.9) {
          const c = Math.sin(e * 16);
          tg.hp = 0.32 + c * 0.14;
          tg.mouth = 0.5 + 0.5 * c;
          tg.sy = 1 + 0.025 * c;
          tg.eye = 0.65;
          tg.tailS = 9;
          tg.tailA = 0.6;
          tg.aA = -0.7;
          tg.aB = -0.7;
        }
        break;
      }
      case "sleep": {
        tg.eye = 0.04;
        tg.hp = 0.55;
        tg.hy = 0;
        tg.sy = 1 + 0.05 * Math.sin(t * 1.3);
        tg.y = -0.03;
        tg.tailA = 0.05;
        tg.tailS = 1;
        tg.aA = 0.1;
        tg.aB = 0.1;
        tg.ear = 0.45;
        tg.wing = 0.1;
        lambda = 5;
        break;
      }
      case "focus": {
        showBook = true;
        tg.hp = 0.2 + Math.sin(t * 0.6) * 0.03;
        tg.hy = Math.sin(t * 0.35) * 0.07;
        tg.eye = 0.82;
        tg.aA = -1.05;
        tg.aB = -1.05;
        tg.tailA = 0.22;
        tg.tailS = 2.2;
        tg.ear = 0.1;
        tg.wing = 0.25;
        lambda = 6;
        break;
      }
      case "attack": {
        if (e < 0.28) {
          const k = easeOut(e / 0.28);
          tg.tiltX = -0.42 * k;
          tg.sy = 1 - 0.14 * k;
          tg.hp = -0.1;
          tg.aA = 0.5 * k;
          tg.aB = 0.5 * k;
          lambda = 22;
        } else if (e < 0.62) {
          const k = easeOut((e - 0.28) / 0.2);
          tg.tiltX = -0.42 + 1.0 * k;
          tg.sy = 0.86 + 0.2 * k;
          tg.hp = 0.3 * k;
          tg.aA = -1.5 * k;
          tg.aB = -1.5 * k;
          tg.y = 0.28 * Math.sin(Math.min(1, (e - 0.28) / 0.34) * Math.PI);
          tg.mouth = 0.8;
          tg.eye = 0.55;
          lambda = 30;
        }
        break;
      }
      case "cast": {
        if (e < 0.5) {
          const k = easeOut(e / 0.5);
          tg.tiltX = -0.45 * k;
          tg.aA = -2.7 * k;
          tg.aB = -2.7 * k;
          tg.sy = 1 + 0.08 * k;
          tg.hp = -0.28 * k;
          tg.glow = k;
          tg.wing = 1.1;
          tg.y = 0.05 * k;
          lambda = 16;
        } else if (e < 1.05) {
          tg.tiltX = 0.32;
          tg.hp = 0.22;
          tg.aA = -1.4;
          tg.aB = -1.4;
          tg.mouth = 1;
          tg.glow = 1 - (e - 0.5) / 0.55;
          tg.eye = 0.6;
          lambda = 28;
        }
        break;
      }
      case "hurt": {
        const d = Math.exp(-e * 5);
        tg.tiltX = -0.5 * d;
        tg.yaw = Math.sin(e * 55) * 0.14 * d;
        tg.sy = 1 - 0.14 * d;
        tg.eye = 0.12;
        tg.hp = -0.25 * d;
        tg.aA = -0.9 * d;
        tg.aB = -0.9 * d;
        tg.glow = Math.pow(d, 0.6);
        tg.mouth = 0.7 * d;
        glowCol = "#ff4d4d";
        lambda = 34;
        break;
      }
      case "faint": {
        tg.tiltZ = easeOut(e / 0.7) * 1.5;
        tg.y = -0.03;
        tg.sy = 0.96;
        tg.eye = 0.03;
        tg.ear = 0.7;
        tg.tailA = 0.02;
        tg.hp = 0.25;
        tg.aA = 0.3;
        tg.aB = 0.3;
        tg.wing = 0.05;
        tg.glow = 0;
        lambda = 7;
        break;
      }
      case "guard": {
        tg.sy = 0.84;
        tg.sx = 1.08;
        tg.aA = -1.5;
        tg.aB = -1.5;
        tg.hp = 0.28;
        tg.eye = 0.5;
        tg.tailA = 0.1;
        tg.glow = 0.4 + Math.sin(t * 4) * 0.1;
        lambda = 12;
        break;
      }
      case "heal": {
        if (e < 1.4) {
          tg.y = Math.abs(Math.sin(e * 5)) * 0.14;
          tg.glow = 0.5 + 0.5 * Math.sin(e * 8);
          tg.eye = 0.4;
          tg.aA = -2.3;
          tg.aB = -2.3;
          tg.tailS = 10;
          glowCol = "#4ade80";
        }
        break;
      }
      case "boost": {
        if (e < 1.3) {
          tg.sy = 1.08 + Math.sin(e * 12) * 0.03;
          tg.aA = -2.5;
          tg.aB = -2.5;
          tg.glow = 0.5 + 0.5 * Math.sin(e * 10);
          tg.hp = -0.2;
          tg.wing = 1;
          glowCol = "#ffd166";
        }
        break;
      }
      case "wave": {
        if (e < 2.4) {
          tg.aA = -2.6 + Math.sin(e * 12) * 0.38;
          tg.eye = 0.55;
          tg.hy = 0.2;
          tg.mouth = 0.25;
          tg.tailS = 8;
          tg.tailA = 0.55;
        }
        break;
      }
      case "sad": {
        tg.hp = 0.42;
        tg.sy = 0.95;
        tg.tailA = 0.04;
        tg.ear = 0.7;
        tg.eye = 0.7;
        tg.hy = 0;
        break;
      }
      default:
        break;
    }

    const c = cur.current;
    (Object.keys(tg) as (keyof Pose)[]).forEach((k) => {
      c[k] = damp(c[k], tg[k], lambda, dt);
    });

    // blink
    let blinkOpen = 1;
    const b = blink.current;
    if (t > b.next) {
      const p = (t - b.next) / 0.16;
      if (p < 1) blinkOpen = 1 - Math.sin(p * Math.PI) * 0.95;
      else b.next = t + 2.2 + Math.random() * 3.2;
    }

    const root = R.root.current;
    if (root) {
      root.position.y = c.y;
      root.rotation.set(c.tiltX, c.yaw, c.tiltZ, "YXZ");
      root.scale.set(c.sx, c.sy, c.sx);
    }
    R.head.current?.rotation.set(c.hp, c.hy, 0);
    R.armA.current?.rotation.set(c.aA, 0, 0.25);
    R.armB.current?.rotation.set(c.aB, 0, -0.25);
    if (R.tail.current) R.tail.current.rotation.y = Math.sin(t * c.tailS) * c.tailA;
    const flick = Math.sin(t * 1.3) * 0.03;
    if (look.ears === "pointy") {
      R.earA.current?.rotation.set(0, 0, -0.38 - c.ear * 0.9 + flick);
      R.earB.current?.rotation.set(0, 0, 0.38 + c.ear * 0.9 - flick);
    } else if (look.ears === "long") {
      R.earA.current?.rotation.set(0.05, 0, -0.16 - c.ear * 1.1 + flick);
      R.earB.current?.rotation.set(0.05, 0, 0.16 + c.ear * 1.1 - flick);
    } else if (look.ears === "round") {
      R.earA.current?.rotation.set(0, 0, -0.3 - c.ear * 0.5);
      R.earB.current?.rotation.set(0, 0, 0.3 + c.ear * 0.5);
    }
    const eyeY = Math.max(0.05, c.eye * blinkOpen);
    R.eyeA.current?.scale.set(1, eyeY, 1);
    R.eyeB.current?.scale.set(1, eyeY, 1);
    if (R.mouth.current) R.mouth.current.scale.set(0.055, 0.001 + c.mouth * 0.06, 0.03);
    if (R.smile.current) R.smile.current.scale.y = Math.max(0.001, 1 - c.mouth * 1.6);
    const flap = Math.sin(t * (c.wing > 0.8 ? 18 : 3)) * 0.22 * c.wing;
    if (R.wingA.current) R.wingA.current.rotation.set(0, 0.7 - c.wing * 0.55, 0.25 + flap);
    if (R.wingB.current) R.wingB.current.rotation.set(0, -0.7 + c.wing * 0.55, -0.25 - flap);
    if (R.flame.current) {
      R.flame.current.scale.set(1 + 0.12 * Math.sin(t * 17), 1 + 0.28 * Math.sin(t * 23 + 1) + c.glow * 0.4, 1 + 0.12 * Math.cos(t * 19));
      R.flame.current.rotation.z = Math.sin(t * 6) * 0.1;
    }
    if (R.orbs.current) {
      R.orbs.current.rotation.y = t * 0.9;
      R.orbs.current.children.forEach((ch, i) => (ch.position.y = 0.95 + Math.sin(t * 1.6 + i * 2.1) * 0.12));
    }
    if (R.sprout.current) R.sprout.current.rotation.z = Math.sin(t * 2.2) * 0.12 + c.hp * 0.2;
    if (R.shield.current) {
      R.shield.current.visible = shield;
      const s = 1.95 + Math.sin(t * 3) * 0.04;
      R.shield.current.scale.set(s, s * 0.95, s);
    }
    if (R.book.current) R.book.current.visible = showBook;

    // emissive glow
    glowColor.set(glowCol);
    for (const m of mats.glowable) {
      m.emissive.copy(glowColor);
      m.emissiveIntensity = c.glow * 0.7;
    }
  });

  const [bx, by, bz] = look.body;
  const sleeping = (anim ?? animRef?.current)?.name === "sleep";

  return (
    <group scale={scale} onClick={onClick} onPointerOver={onPointerOver} onPointerOut={onPointerOut}>
      <group ref={R.root}>
        {/* feet */}
        {[-1, 1].map((s) => (
          <mesh key={s} geometry={G.sphere} material={mats.fur} position={[s * 0.25, 0.09, 0.14]} scale={[0.17, 0.1, 0.23]} castShadow />
        ))}
        {/* body */}
        <mesh geometry={G.sphere} material={mats.fur} position={[0, 0.52, 0]} scale={[0.5 * bx, 0.46 * by, 0.48 * bz]} castShadow />
        <mesh geometry={G.sphere} material={mats.belly} position={[0, 0.5, 0.33]} scale={[0.32, 0.33, 0.2]} />

        {/* arms */}
        <group ref={R.armA} position={[0.47 * bx, 0.72, 0.06]}>
          <mesh geometry={G.capsule} material={mats.fur} position={[0, -0.14, 0]} scale={[0.1, 0.15, 0.1]} castShadow />
        </group>
        <group ref={R.armB} position={[-0.47 * bx, 0.72, 0.06]}>
          <mesh geometry={G.capsule} material={mats.fur} position={[0, -0.14, 0]} scale={[0.1, 0.15, 0.1]} castShadow />
        </group>

        {/* study book */}
        <group ref={R.book} position={[0, 0.62, 0.52]} rotation={[-0.5, 0, 0]} visible={false}>
          <mesh material={mats.brand} position={[0, 0, -0.01]}>
            <boxGeometry args={[0.46, 0.34, 0.04]} />
          </mesh>
          <mesh material={mats.white} position={[0, 0, 0.015]}>
            <boxGeometry args={[0.42, 0.3, 0.02]} />
          </mesh>
          <mesh material={mats.dark} position={[0, 0, 0.026]}>
            <boxGeometry args={[0.012, 0.3, 0.004]} />
          </mesh>
        </group>

        {/* tail */}
        <group ref={R.tail} position={[0, 0.36, -0.4]}>
          {look.tail === "fluffy" && (
            <>
              <group rotation={[0.7, 0, 0]}>
                <mesh geometry={G.sphere} material={mats.fur} position={[0, 0, -0.3]} scale={[0.2, 0.2, 0.36]} castShadow />
                <mesh geometry={G.sphere} material={mats.accent} position={[0, 0, -0.6]} scale={[0.15, 0.15, 0.2]} />
              </group>
              {look.extras.includes("flame") && (
                <group ref={R.flame} position={[0, 0.5, -0.6]}>
                  <mesh geometry={G.cone} material={mats.flameOuter} scale={[0.26, 0.5, 0.26]} position={[0, 0.1, 0]} />
                  <mesh geometry={G.cone} material={mats.flameInner} scale={[0.14, 0.3, 0.14]} position={[0, 0.03, 0.01]} />
                </group>
              )}
            </>
          )}
          {look.tail === "bolt" && (
            <group rotation={[0, Math.PI / 2, 0]} position={[0, -0.02, -0.12]} scale={0.95}>
              <mesh geometry={boltGeo} material={mats.bolt} castShadow />
            </group>
          )}
          {look.tail === "fin" && (
            <group rotation={[0.35, 0, 0]}>
              <mesh geometry={G.sphere} material={mats.fur} position={[0, 0.02, -0.3]} scale={[0.05, 0.24, 0.32]} castShadow />
              <mesh geometry={G.sphere} material={mats.gill} position={[0, 0.02, -0.36]} scale={[0.056, 0.17, 0.2]} />
            </group>
          )}
          {look.tail === "dragon" && (
            <group rotation={[0.25, 0, 0]}>
              <mesh geometry={G.sphere} material={mats.fur} position={[0, 0, -0.15]} scale={[0.17, 0.17, 0.2]} castShadow />
              <mesh geometry={G.sphere} material={mats.fur} position={[0, 0.03, -0.36]} scale={[0.13, 0.13, 0.2]} castShadow />
              <mesh geometry={G.sphere} material={mats.fur} position={[0, 0.08, -0.55]} scale={[0.09, 0.09, 0.18]} castShadow />
              <mesh geometry={G.cone} material={mats.accent} position={[0, 0.12, -0.78]} rotation={[-Math.PI / 2, 0, 0]} scale={[0.22, 0.28, 0.05]} />
            </group>
          )}
          {look.tail === "moon" && (
            <group rotation={[0, Math.PI / 2, 0]} position={[0, 0.2, -0.22]}>
              <mesh material={mats.moon} rotation={[0, 0, 0.9]}>
                <torusGeometry args={[0.24, 0.06, 16, 40, 4.3]} />
              </mesh>
            </group>
          )}
          {look.tail === "ball" && <mesh geometry={G.sphere} material={mats.belly} position={[0, 0.1, -0.1]} scale={0.16} castShadow />}
        </group>

        {/* back extras */}
        {look.extras.includes("wings") && (
          <>
            <group ref={R.wingA} position={[0.22 * bx, 0.78, -0.32]} scale={species === "drakeling" ? 0.78 : 0.6}>
              <mesh geometry={wingGeo} material={mats.wing} castShadow />
            </group>
            <group ref={R.wingB} position={[-0.22 * bx, 0.78, -0.32]} scale={[species === "drakeling" ? -0.78 : -0.6, species === "drakeling" ? 0.78 : 0.6, species === "drakeling" ? 0.78 : 0.6]}>
              <mesh geometry={wingGeo} material={mats.wing} castShadow />
            </group>
          </>
        )}
        {look.extras.includes("spikes") &&
          [0.92, 0.78, 0.62].map((y, i) => (
            <mesh key={i} geometry={G.cone} material={mats.accent} position={[0, y, -0.3 - i * 0.07]} rotation={[-0.9 - i * 0.2, 0, 0]} scale={[0.1, 0.16 - i * 0.02, 0.1]} />
          ))}
        {look.extras.includes("orbs") && (
          <group ref={R.orbs}>
            {[0, 1, 2].map((i) => (
              <mesh key={i} geometry={G.sphere} material={mats.orb} scale={0.05 + i * 0.008} position={[Math.cos((i / 3) * Math.PI * 2) * 0.95, 0.95, Math.sin((i / 3) * Math.PI * 2) * 0.95]} />
            ))}
          </group>
        )}
        {look.extras.includes("bubbles") && (
          <group ref={R.orbs}>
            {[0, 1, 2, 3].map((i) => (
              <mesh key={i} geometry={G.sphere} material={mats.bubble} scale={0.07 + (i % 2) * 0.04} position={[Math.cos((i / 4) * Math.PI * 2) * 0.9, 0.95, Math.sin((i / 4) * Math.PI * 2) * 0.9]} />
            ))}
          </group>
        )}

        {/* head */}
        <group ref={R.head} position={[0, 0.86, 0.04]}>
          <mesh geometry={G.sphere} material={mats.fur} position={[0, 0.3, 0]} scale={[0.56, 0.47, 0.5]} castShadow />
          {(look.muzzle || look.ears === "pointy") && (
            <mesh geometry={G.sphere} material={mats.muzzle} position={[0, 0.19, 0.36]} scale={[0.2, 0.14, 0.15]} />
          )}
          {/* eyes */}
          {[1, -1].map((s) => (
            <group key={s} ref={s === 1 ? R.eyeA : R.eyeB} position={[0.2 * s, 0.34, 0.43]}>
              <mesh geometry={G.sphere} material={mats.eye} scale={[0.078, 0.1, 0.05]} />
              <mesh geometry={G.sphere} material={mats.white} position={[0.024 * s, 0.036, 0.04]} scale={0.026} />
              <mesh geometry={G.sphere} material={mats.white} position={[-0.02 * s, -0.03, 0.04]} scale={0.012} />
            </group>
          ))}
          {/* cheeks, nose, mouth */}
          {[1, -1].map((s) => (
            <mesh key={s} geometry={G.sphere} material={mats.cheek} position={[0.34 * s, 0.19, 0.34]} scale={[0.085, 0.055, 0.03]} rotation={[0, 0.5 * s, 0]} />
          ))}
          <mesh geometry={G.sphere} material={mats.nose} position={[0, 0.255, 0.49]} scale={[0.04, 0.03, 0.03]} />
          <mesh ref={R.smile} position={[0, 0.2, 0.485]} rotation={[0, 0, Math.PI]} scale={[1, 1, 1]}>
            <torusGeometry args={[0.05, 0.011, 8, 20, Math.PI]} />
            <meshStandardMaterial color="#2a1c20" roughness={0.5} />
          </mesh>
          <mesh ref={R.mouth} geometry={G.sphere} material={mats.nose} position={[0, 0.165, 0.485]} scale={[0.055, 0.001, 0.03]} />

          {/* ears */}
          {look.ears === "pointy" &&
            [1, -1].map((s) => (
              <group key={s} ref={s === 1 ? R.earA : R.earB} position={[0.3 * s, 0.66, -0.02]}>
                <mesh geometry={G.cone} material={mats.fur} position={[0, 0.2, 0]} scale={[0.36, 0.5, 0.2]} castShadow />
                <mesh geometry={G.cone} material={mats.inner} position={[0, 0.17, 0.045]} scale={[0.22, 0.34, 0.1]} />
                <mesh geometry={G.cone} material={mats.earTip} position={[0, 0.39, 0]} scale={[0.15, 0.17, 0.12]} />
              </group>
            ))}
          {look.ears === "long" &&
            [1, -1].map((s) => (
              <group key={s} ref={s === 1 ? R.earA : R.earB} position={[0.2 * s, 0.7, -0.04]}>
                <mesh geometry={G.capsule} material={mats.fur} position={[0, 0.3, 0]} scale={[0.12, 0.3, 0.075]} castShadow />
                <mesh geometry={G.capsule} material={mats.inner} position={[0, 0.3, 0.035]} scale={[0.07, 0.23, 0.04]} />
              </group>
            ))}
          {look.ears === "round" &&
            [1, -1].map((s) => (
              <group key={s} ref={s === 1 ? R.earA : R.earB} position={[0.34 * s, 0.62, -0.02]}>
                <mesh geometry={G.sphere} material={mats.fur} position={[0, 0.07, 0]} scale={[0.17, 0.2, 0.1]} castShadow />
                <mesh geometry={G.sphere} material={mats.inner} position={[0, 0.07, 0.05]} scale={[0.1, 0.13, 0.05]} />
              </group>
            ))}

          {/* species extras on head */}
          {look.extras.includes("cheekfluff") &&
            [1, -1].map((s) =>
              [0, 1].map((i) => (
                <mesh key={`${s}${i}`} geometry={G.cone} material={mats.accent} position={[0.53 * s, 0.2 - i * 0.07, 0.1 + i * 0.03]} rotation={[0, 0, -s * (Math.PI / 2 + 0.2 - i * 0.35)]} scale={[0.14, 0.22, 0.1]} />
              ))
            )}
          {look.extras.includes("gills") &&
            [1, -1].map((s) =>
              [0, 1, 2].map((i) => {
                const ang = 0.55 + i * 0.5;
                const dx = Math.sin(ang) * s;
                const dy = Math.cos(ang);
                return (
                  <group key={`${s}${i}`} position={[0.5 * s, 0.38 + (i - 1) * 0.04, -0.02]}>
                    <mesh geometry={G.capsule} material={mats.gill} position={[dx * 0.1, dy * 0.1, 0]} rotation={[0, 0, -s * ang]} scale={[0.028, 0.1, 0.028]} />
                    <mesh geometry={G.sphere} material={mats.gill} position={[dx * 0.21, dy * 0.21, 0]} scale={0.04} />
                  </group>
                );
              })
            )}
          {look.extras.includes("sprout") && (
            <group ref={R.sprout} position={[0, 0.74, 0.02]}>
              <mesh geometry={G.capsule} material={mats.leaf} position={[0, 0.09, 0]} scale={[0.028, 0.09, 0.028]} />
              {[1, -1].map((s) => (
                <mesh key={s} geometry={G.sphere} material={mats.leaf} position={[0.11 * s, 0.23, 0]} rotation={[0, 0, -s * 0.7]} scale={[0.14, 0.05, 0.08]} />
              ))}
            </group>
          )}
          {look.extras.includes("horns") &&
            [1, -1].map((s) => (
              <mesh key={s} geometry={G.cone} material={mats.horn} position={[0.22 * s, 0.74, -0.04]} rotation={[-0.25, 0, -s * 0.4]} scale={[0.1, 0.3, 0.1]} castShadow />
            ))}
          {look.extras.includes("star") && <mesh geometry={starGeo} material={mats.emissiveStar} position={[0, 0.56, 0.44]} scale={[0.07, 0.07, 0.07]} rotation={[-0.25, 0, 0]} />}

          {/* accessories */}
          {accessory === "headphones" && (
            <group position={[0, 0.3, 0]}>
              <mesh material={mats.dark} scale={[1, 0.84, 1.1]}>
                <torusGeometry args={[0.59, 0.034, 14, 56, Math.PI]} />
              </mesh>
              {[1, -1].map((s) => (
                <mesh key={s} material={mats.brand} position={[0.58 * s, 0, 0]} rotation={[0, 0, Math.PI / 2]} scale={[1, 1, 1]}>
                  <cylinderGeometry args={[0.16, 0.16, 0.12, 28]} />
                </mesh>
              ))}
            </group>
          )}
          {accessory === "partyhat" && (
            <group position={[0.05, 0.9, 0]} rotation={[0, 0, -0.12]}>
              <mesh geometry={G.cone} material={mats.party} scale={[0.46, 0.6, 0.46]} castShadow />
              {[0.14, 0.32].map((h) => (
                <mesh key={h} material={mats.yellow} position={[0, -0.3 + h, 0]} rotation={[Math.PI / 2, 0, 0]}>
                  <torusGeometry args={[0.23 * (1 - h / 0.6), 0.016, 8, 28]} />
                </mesh>
              ))}
              <mesh geometry={G.sphere} material={mats.yellow} position={[0, 0.32, 0]} scale={0.07} />
            </group>
          )}
          {accessory === "glasses" && (
            <group position={[0, 0.34, 0.5]}>
              {[1, -1].map((s) => (
                <group key={s} position={[0.2 * s, 0, 0]}>
                  <mesh material={mats.dark}>
                    <torusGeometry args={[0.105, 0.014, 10, 32]} />
                  </mesh>
                  <mesh material={mats.lens}>
                    <circleGeometry args={[0.1, 28]} />
                  </mesh>
                </group>
              ))}
              <mesh material={mats.dark} rotation={[0, 0, Math.PI / 2]}>
                <cylinderGeometry args={[0.012, 0.012, 0.12, 8]} />
              </mesh>
            </group>
          )}
          {accessory === "bowtie" && (
            <group position={[0, 0.0, 0.34]}>
              {[1, -1].map((s) => (
                <mesh key={s} geometry={G.cone} material={mats.red} position={[0.07 * s, 0, 0]} rotation={[0, 0, -s * Math.PI / 2]} scale={[0.2, 0.14, 0.12]} />
              ))}
              <mesh geometry={G.sphere} material={mats.red} scale={[0.04, 0.05, 0.05]} />
            </group>
          )}
          {accessory === "crown" && (
            <group position={[0, 0.78, 0]} rotation={[-0.05, 0, 0.06]}>
              <mesh material={mats.gold} position={[0, 0, 0]}>
                <cylinderGeometry args={[0.2, 0.17, 0.12, 24, 1, true]} />
              </mesh>
              <mesh material={mats.gold} position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
                <torusGeometry args={[0.19, 0.012, 8, 28]} />
              </mesh>
              {[0, 1, 2, 3, 4].map((i) => {
                const a = (i / 5) * Math.PI * 2;
                return <mesh key={i} geometry={G.cone} material={mats.gold} position={[Math.cos(a) * 0.185, 0.1, Math.sin(a) * 0.185]} scale={[0.08, 0.14, 0.08]} />;
              })}
              <mesh geometry={G.sphere} material={mats.brand} position={[0, 0.0, 0.2]} scale={0.03} />
            </group>
          )}
        </group>
      </group>

      {/* guard shield */}
      <mesh ref={R.shield} geometry={G.sphere} material={mats.shield} position={[0, 0.65, 0]} visible={false} />

      {sleeping && (
        <Html position={[0.55, 1.9, 0]} center zIndexRange={[5, 0]} style={{ pointerEvents: "none" }}>
          <div className="flex gap-1 font-display font-extrabold text-brand-300">
            {[0, 1, 2].map((i) => (
              <span key={i} className="inline-block animate-[zfloat_2.4s_ease-in-out_infinite]" style={{ animationDelay: `${i * 0.5}s`, fontSize: 14 + i * 5, opacity: 0 }}>
                z
              </span>
            ))}
          </div>
        </Html>
      )}
    </group>
  );
}
