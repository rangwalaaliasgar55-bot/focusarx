import { motion } from "framer-motion";
import { EASE } from "./ui";
import { cn } from "../utils/cn";
import { minutesLabel } from "../lib/format";

export interface BarDatum {
  label: string;
  value: number;
  tip: string;
  highlight?: boolean;
}

export function BarChart({ data, height = 180, color = "#7b7cff", goal, showEvery = 1, className }: { data: BarDatum[]; height?: number; color?: string; goal?: number; showEvery?: number; className?: string }) {
  const max = Math.max(goal ?? 0, ...data.map((d) => d.value), 1) * 1.12;
  return (
    <div className={cn("relative", className)}>
      <div className="relative flex items-end gap-[3px] sm:gap-1.5" style={{ height }}>
        {goal ? (
          <div className="pointer-events-none absolute inset-x-0 z-10 border-t border-dashed border-white/20" style={{ bottom: `${(goal / max) * 100}%` }}>
            <span className="absolute -top-5 right-0 rounded bg-surface-0/80 px-1.5 text-[10px] font-semibold text-ink-3">Goal {minutesLabel(goal)}</span>
          </div>
        ) : null}
        {data.map((d, i) => (
          <div key={i} className="group relative flex h-full flex-1 items-end">
            <motion.div
              className="w-full rounded-t-[7px] rounded-b-[3px]"
              style={{ background: d.highlight ? `linear-gradient(180deg, ${color}, ${color}99)` : `linear-gradient(180deg, ${color}66, ${color}22)`, transformOrigin: "bottom" }}
              initial={{ height: 0 }}
              whileInView={{ height: `${Math.max(d.value > 0 ? 3 : 0, (d.value / max) * 100)}%` }}
              viewport={{ once: true }}
              transition={{ duration: 0.9, delay: i * (data.length > 20 ? 0.008 : 0.04), ease: EASE }}
              whileHover={{ filter: "brightness(1.25)" }}
            />
            <div className="pointer-events-none absolute bottom-full left-1/2 z-20 mb-2 -translate-x-1/2 whitespace-nowrap rounded-lg bg-surface-4 px-2.5 py-1.5 text-[11px] font-semibold opacity-0 shadow-xl transition-opacity duration-200 group-hover:opacity-100">
              {d.tip}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-[3px] sm:gap-1.5">
        {data.map((d, i) => (
          <div key={i} className={cn("flex-1 text-center text-[10.5px] font-medium", d.highlight ? "text-ink" : "text-ink-4")}>
            {i % showEvery === 0 ? d.label : ""}
          </div>
        ))}
      </div>
    </div>
  );
}

export function Heatmap({ cols, color = "123,124,255" }: { cols: { ts: number; minutes: number; future: boolean }[][]; color?: string }) {
  const peak = Math.max(60, ...cols.flat().map((c) => c.minutes));
  const months: { i: number; label: string }[] = [];
  cols.forEach((c, i) => {
    const d = new Date(c[0].ts);
    if (i === 0 || d.getDate() <= 7) months.push({ i, label: d.toLocaleDateString(undefined, { month: "short" }) });
  });
  return (
    <div className="w-full">
      <div className="mb-1.5 flex gap-[3px] pl-0">
        {cols.map((_, i) => (
          <div key={i} className="flex-1 text-[10px] font-medium text-ink-4">{months.find((m) => m.i === i)?.label ?? ""}</div>
        ))}
      </div>
      <div className="flex gap-[3px]">
        {cols.map((col, ci) => (
          <div key={ci} className="flex flex-1 flex-col gap-[3px]">
            {col.map((c, ri) => {
              const a = c.minutes === 0 ? 0 : 0.18 + 0.82 * Math.min(1, c.minutes / peak);
              return (
                <motion.div
                  key={ri}
                  initial={{ opacity: 0, scale: 0.4 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: ci * 0.012 + ri * 0.008, duration: 0.5, ease: EASE }}
                  title={`${new Date(c.ts).toLocaleDateString(undefined, { month: "short", day: "numeric" })} · ${c.minutes ? minutesLabel(c.minutes) : "no focus"}`}
                  className={cn("aspect-square w-full rounded-[4px]", c.future && "opacity-0")}
                  style={{ background: c.minutes === 0 ? "rgba(255,255,255,0.05)" : `rgba(${color},${a})` }}
                />
              );
            })}
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center justify-end gap-1.5 text-[10.5px] text-ink-4">
        Less
        {[0.05, 0.25, 0.5, 0.75, 1].map((a, i) => (
          <span key={i} className="h-2.5 w-2.5 rounded-[3px]" style={{ background: i === 0 ? "rgba(255,255,255,0.05)" : `rgba(${color},${a})` }} />
        ))}
        More
      </div>
    </div>
  );
}
