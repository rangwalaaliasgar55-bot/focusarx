import { useEffect, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BarChart3, Coins, Flame, LayoutDashboard, ListChecks, MoreHorizontal, PawPrint, Settings, ShoppingBag, Swords, Target, Ticket, Timer, X } from "lucide-react";
import { SettingsModal } from "./SettingsModal";
import { cn } from "../utils/cn";
import { useStore, streakOf } from "../lib/store";
import { useUI, type Route } from "../lib/ui";
import { levelFromXp, clock } from "../lib/format";
import { sfx } from "../lib/sound";
import { AnimatedNumber, Bar, EASE, SPRING } from "./ui";

const NAV: { id: Route; label: string; icon: typeof Timer }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "focus", label: "Focus", icon: Timer },
  { id: "tasks", label: "Tasks", icon: ListChecks },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "companion", label: "Companion", icon: PawPrint },
  { id: "arena", label: "Arena", icon: Swords },
  { id: "shop", label: "Shop", icon: ShoppingBag },
  { id: "missions", label: "Missions", icon: Target },
];

export function LogoMark({ size = 30 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none">
      <defs>
        <linearGradient id="lm" x1="4" y1="2" x2="28" y2="30">
          <stop stopColor="#b4b5ff" />
          <stop offset="1" stopColor="#5a5cf0" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="10" fill="url(#lm)" />
      <circle cx="16" cy="16" r="8.2" stroke="#fff" strokeOpacity=".95" strokeWidth="2.2" />
      <circle cx="16" cy="16" r="3.2" fill="#fff" />
    </svg>
  );
}

function Wallet({ compact = false }: { compact?: boolean }) {
  const coins = useStore((s) => s.coins);
  const tickets = useStore((s) => s.tickets);
  const sessions = useStore((s) => s.sessions);
  const streak = streakOf(sessions);
  const pill = "flex items-center gap-1.5 rounded-full border border-white/[0.07] bg-white/[0.04] px-3 py-1.5 text-[13px] font-semibold";
  return (
    <div className="flex items-center gap-2">
      <div className={pill} title="Focus streak">
        <Flame size={15} className="text-ember" />
        <AnimatedNumber value={streak} duration={0.6} />
      </div>
      <div className={pill} title="Coins">
        <Coins size={15} className="text-volt" />
        <AnimatedNumber value={coins} duration={0.6} />
      </div>
      {!compact && (
        <div className={pill} title="Battle tickets">
          <Ticket size={15} className="text-nova" />
          <AnimatedNumber value={tickets} duration={0.6} />
        </div>
      )}
    </div>
  );
}

function MiniTimer({ go }: { go: (r: Route) => void }) {
  const t = useStore((s) => s.timer);
  const [, force] = useState(0);
  useEffect(() => {
    if (t.status !== "running") return;
    const id = setInterval(() => force((n) => n + 1), 500);
    return () => clearInterval(id);
  }, [t.status]);
  if (t.status === "idle") return null;
  const left = t.status === "running" && t.endAt ? (t.endAt - Date.now()) / 1000 : t.remaining;
  return (
    <motion.button
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      onClick={() => go("focus")}
      className="flex items-center gap-2 rounded-full border border-brand-500/30 bg-brand-500/10 px-3 py-1.5 text-[13px] font-semibold text-brand-300"
    >
      <span className={cn("h-2 w-2 rounded-full bg-brand-400", t.status === "running" && "animate-pulse")} />
      <span className="num">{clock(left)}</span>
    </motion.button>
  );
}

export function Shell({ route, go, children }: { route: Route; go: (r: Route) => void; children: ReactNode }) {
  const zen = useUI((s) => s.zen);
  const toasts = useUI((s) => s.toasts);
  const dismiss = useUI((s) => s.dismissToast);
  const xp = useStore((s) => s.xp);
  const name = useStore((s) => s.settings.name);
  const lv = levelFromXp(xp);
  const [more, setMore] = useState(false);
  const [settingsOpen, setSettings] = useState(false);
  const hideChrome = zen && route === "focus";
  const current = NAV.find((n) => n.id === route)!;

  return (
    <div className="relative flex h-full w-full overflow-hidden bg-surface-0">
      {/* sidebar */}
      <motion.aside
        initial={false}
        animate={{ width: hideChrome ? 0 : 248, opacity: hideChrome ? 0 : 1 }}
        transition={{ duration: 0.6, ease: EASE }}
        className="hidden shrink-0 overflow-hidden md:block"
      >
        <div className="flex h-full w-[248px] flex-col border-r border-white/[0.06] bg-surface-0 px-3 py-4">
          <button onClick={() => go("dashboard")} className="mb-6 flex items-center gap-3 px-3 py-1">
            <LogoMark />
            <span className="font-display text-[19px] font-extrabold tracking-tight">FocusArx</span>
          </button>
          <nav className="flex flex-1 flex-col gap-0.5">
            {NAV.map((n) => {
              const active = route === n.id;
              const Icon = n.icon;
              return (
                <button
                  key={n.id}
                  onClick={() => go(n.id)}
                  className={cn(
                    "group relative flex items-center gap-3 rounded-xl px-3 py-2.5 text-[14px] font-semibold transition-colors duration-300",
                    active ? "text-ink" : "text-ink-3 hover:text-ink-2"
                  )}
                >
                  {active && (
                    <motion.span layoutId="nav-pill" transition={SPRING} className="absolute inset-0 rounded-xl bg-white/[0.07] shadow-[0_1px_0_rgba(255,255,255,0.05)_inset]" />
                  )}
                  {active && <motion.span layoutId="nav-bar" transition={SPRING} className="absolute -left-3 top-2.5 bottom-2.5 w-[3px] rounded-r-full bg-brand-400" />}
                  <Icon size={18} className={cn("relative transition-transform duration-300 group-hover:scale-110", active && "text-brand-300")} strokeWidth={2.1} />
                  <span className="relative">{n.label}</span>
                </button>
              );
            })}
          </nav>
          <div className="panel-flat mt-3 p-3.5">
            <div className="flex items-center justify-between">
              <div>
                <div className="eyebrow">Level</div>
                <div className="font-display text-2xl font-extrabold leading-none mt-1">
                  <AnimatedNumber value={lv.level} duration={0.8} />
                </div>
              </div>
              <button onClick={() => setSettings(true)} aria-label="Open settings" className="group text-right">
                <div className="flex items-center justify-end gap-1.5 text-[13px] font-semibold">{name}<Settings size={13} className="text-ink-4 transition-transform duration-500 group-hover:rotate-90 group-hover:text-ink-2" /></div>
                <div className="num text-[11px] text-ink-3">
                  {Math.round(lv.into)} / {lv.need} XP
                </div>
              </button>
            </div>
            <Bar value={lv.pct} className="mt-3" height={5} />
          </div>
        </div>
      </motion.aside>

      <div className="relative flex min-w-0 flex-1 flex-col">
        {/* top bar */}
        <motion.header
          initial={false}
          animate={{ height: hideChrome ? 0 : 64, opacity: hideChrome ? 0 : 1 }}
          transition={{ duration: 0.5, ease: EASE }}
          className="z-30 shrink-0 overflow-hidden"
        >
          <div className="flex h-16 items-center justify-between px-5 md:px-8">
            <div className="flex items-center gap-3">
              <div className="md:hidden">
                <LogoMark size={28} />
              </div>
              <AnimatePresence mode="wait">
                <motion.h1
                  key={route}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.25, ease: EASE }}
                  className="font-display text-[17px] font-bold tracking-tight text-ink-2"
                >
                  {current.label}
                </motion.h1>
              </AnimatePresence>
              <AnimatePresence>{route !== "focus" && <MiniTimer go={go} />}</AnimatePresence>
            </div>
            <Wallet compact={false} />
          </div>
        </motion.header>

        <main className="relative min-h-0 flex-1">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={route}
              initial={{ opacity: 0, y: 18, scale: 0.992, filter: "blur(10px)" }}
              animate={{ opacity: 1, y: 0, scale: 1, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -10, scale: 0.996, filter: "blur(8px)" }}
              transition={{ duration: 0.42, ease: EASE }}
              className="scroll-y absolute inset-0 pb-[84px] md:pb-0"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* mobile nav */}
        <nav className={cn("fixed inset-x-3 bottom-3 z-40 md:hidden transition-transform duration-500", hideChrome && "translate-y-32")}>
          <div className="glass flex items-center justify-between rounded-[26px] p-1.5">
            {[NAV[0], NAV[1], NAV[2], NAV[4], NAV[5]].map((n) => {
              const Icon = n.icon;
              const active = route === n.id;
              return (
                <button key={n.id} onClick={() => go(n.id)} className={cn("relative flex flex-1 flex-col items-center gap-0.5 rounded-[20px] py-2 text-[10px] font-semibold", active ? "text-ink" : "text-ink-3")}>
                  {active && <motion.span layoutId="m-pill" transition={SPRING} className="absolute inset-0 rounded-[20px] bg-white/[0.1]" />}
                  <Icon size={20} className={cn("relative", active && "text-brand-300")} />
                  <span className="relative">{n.label}</span>
                </button>
              );
            })}
            <button onClick={() => setMore(true)} className="relative flex flex-1 flex-col items-center gap-0.5 rounded-[20px] py-2 text-[10px] font-semibold text-ink-3">
              <MoreHorizontal size={20} />
              <span>More</span>
            </button>
          </div>
        </nav>
        <AnimatePresence>
          {more && (
            <motion.div className="fixed inset-0 z-50 md:hidden" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setMore(false)} />
              <motion.div
                initial={{ y: 300 }} animate={{ y: 0 }} exit={{ y: 300 }}
                transition={{ type: "spring", stiffness: 320, damping: 32 }}
                className="glass absolute inset-x-3 bottom-3 rounded-[28px] p-4"
              >
                <div className="mb-3 flex items-center justify-between">
                  <div className="font-display font-bold">More</div>
                  <button onClick={() => setMore(false)} className="rounded-full bg-white/10 p-1.5"><X size={16} /></button>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[NAV[3], NAV[6], NAV[7]].map((n) => {
                    const Icon = n.icon;
                    return (
                      <button key={n.id} onClick={() => { go(n.id); setMore(false); }} className="flex flex-col items-center gap-2 rounded-2xl bg-white/[0.05] py-4 text-xs font-semibold">
                        <Icon size={22} className="text-brand-300" />
                        {n.label}
                      </button>
                    );
                  })}
                </div>
                <button onClick={() => { setMore(false); setSettings(true); }} className="mt-2 flex w-full items-center justify-center gap-2 rounded-2xl bg-white/[0.05] py-3 text-xs font-semibold">
                  <Settings size={16} className="text-brand-300" /> Settings
                </button>
                <div className="mt-4 flex justify-center"><Wallet /></div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <SettingsModal open={settingsOpen} onClose={() => setSettings(false)} />

      {/* toasts */}
      <div className="pointer-events-none fixed right-4 top-4 z-[90] flex w-[min(360px,calc(100vw-2rem))] flex-col gap-2">
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.button
              key={t.id}
              layout
              initial={{ opacity: 0, x: 60, scale: 0.9 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: 60, scale: 0.9 }}
              transition={{ type: "spring", stiffness: 340, damping: 30 }}
              onClick={() => dismiss(t.id)}
              className="glass pointer-events-auto rounded-2xl px-4 py-3 text-left"
            >
              <div className={cn("text-[13px] font-bold", t.tone === "success" && "text-leaf", t.tone === "warn" && "text-volt")}>{t.title}</div>
              {t.body && <div className="mt-0.5 text-[12.5px] text-ink-2">{t.body}</div>}
            </motion.button>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}

/** Global engine: completes timers even when you're on another page, keeps the tab title live. */
export function useGlobalEngine(route: Route) {
  const lastId = useStore((s) => s.lastResult?.id);
  useEffect(() => {
    const id = setInterval(() => {
      const s = useStore.getState();
      const t = s.timer;
      if (t.status === "running" && t.endAt && Date.now() >= t.endAt) s.completeTimer(false);
      s.decayPets();
    }, 500);
    useStore.getState().decayPets();
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      const t = useStore.getState().timer;
      if (t.status === "idle") {
        document.title = "FocusArx — Focus Timer, Deep Work & 3D Companions";
        return;
      }
      const left = t.status === "running" && t.endAt ? (t.endAt - Date.now()) / 1000 : t.remaining;
      document.title = `${clock(left)} · ${t.mode === "focus" ? "Focus" : "Break"} — FocusArx`;
    }, 500);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (!lastId) return;
    const s = useStore.getState();
    const r = s.lastResult!;
    if (s.settings.chime) sfx("chime");
    if (route !== "focus") {
      useUI.getState().toast({
        title: r.kind === "focus" ? "Focus session complete" : "Break is over",
        body: r.kind === "focus" ? `+${r.xp} XP · +${r.coins} coins · score ${r.score}` : "Ready for the next session?",
        tone: "success",
      });
    }
    if (r.kind === "focus" && s.settings.autoBreaks && !r.early) {
      setTimeout(() => useStore.getState().startTimer(), 1200);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastId]);
}
