/**
 * middleware/auth.ts — Express middleware for FocusARX
 *
 * requireAuth   — any authenticated user (USER or ADMIN)
 * requireAdmin  — ADMIN role only (case-insensitive comparison)
 */

import { Request, Response, NextFunction } from "express";
import { verifyToken } from "../routes/auth.js";

// Augment Request to carry decoded user
declare global {
  namespace Express {
    interface Request {
      user?: {
        userId: number;
        email: string;
        role: string; // always UPPERCASED
      };
    }
  }
}

// ─── requireAuth ─────────────────────────────────────────────────────────

export function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const authHeader = req.headers.authorization;

  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Authentication required" });
    return;
  }

  const token = authHeader.slice(7);
  const payload = verifyToken(token);

  if (!payload) {
    res.status(401).json({ error: "Invalid or expired token" });
    return;
  }

  // Normalise role to uppercase before attaching
  req.user = {
    userId: payload.userId,
    email: payload.email,
    role: (payload.role ?? "USER").toUpperCase(),
  };

  next();
}

// ─── requireAdmin ─────────────────────────────────────────────────────────

export function requireAdmin(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // First check that the user is authenticated at all
  requireAuth(req, res, () => {
    // ── FIX: safe case-insensitive comparison ──────────────────────────
    // Previously may have been: req.user.role === "ADMIN" (fails if stored as "admin")
    // Now: normalised to uppercase in requireAuth, so this is safe
    if (!req.user || req.user.role.toUpperCase() !== "ADMIN") {
      res.status(403).json({ error: "Admin access required" });
      return;
    }
    next();
  });
}
