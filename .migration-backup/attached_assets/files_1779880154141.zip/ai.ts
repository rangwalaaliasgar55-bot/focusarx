/**
 * ai.ts — /api/ai/roadmap
 * Upgraded route: accepts prompt override from client, returns structured JSON
 * Auth: requires valid JWT (any role)
 */

import { Router, Request, Response } from "express";
import Anthropic from "@anthropic-ai/sdk";
import { requireAuth } from "../middleware/auth.js";

const router = Router();

// Lazy-initialise client so the server starts even if ANTHROPIC_API_KEY is missing
let anthropic: Anthropic | null = null;
function getClient(): Anthropic {
  if (!anthropic) {
    if (!process.env.ANTHROPIC_API_KEY) {
      throw new Error("ANTHROPIC_API_KEY is not set");
    }
    anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  }
  return anthropic;
}

// ─── POST /api/ai/roadmap ──────────────────────────────────────────────────

router.post(
  "/roadmap",
  requireAuth,
  async (req: Request, res: Response): Promise<void> => {
    const { goal, dailyHours, skillLevel, prompt } = req.body as {
      goal?: string;
      dailyHours?: number;
      skillLevel?: string;
      prompt?: string;
    };

    if (!goal?.trim()) {
      res.status(400).json({ error: "goal is required" });
      return;
    }

    // Use client-provided prompt if given (allows the frontend to upgrade
    // the prompt without a backend deploy), else build a default one.
    const finalPrompt: string =
      prompt?.trim() ||
      buildDefaultPrompt(
        goal.trim(),
        Number(dailyHours) || 2,
        (skillLevel as "beginner" | "intermediate" | "advanced") || "beginner"
      );

    try {
      const client = getClient();

      const message = await client.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 4096,
        messages: [{ role: "user", content: finalPrompt }],
      });

      // Extract text content
      const raw = message.content
        .filter((b) => b.type === "text")
        .map((b) => (b as { type: "text"; text: string }).text)
        .join("");

      // Strip potential markdown fences
      const cleaned = raw
        .replace(/^```(?:json)?\s*/i, "")
        .replace(/\s*```\s*$/i, "")
        .trim();

      let parsed: unknown;
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        console.error("[ai/roadmap] JSON parse failed. Raw:", raw.slice(0, 500));
        res.status(502).json({
          error: "AI returned non-JSON response. Please try again.",
        });
        return;
      }

      res.json(parsed);
    } catch (err: unknown) {
      const e = err as Error;
      console.error("[ai/roadmap]", e.message);
      if (e.message.includes("ANTHROPIC_API_KEY")) {
        res.status(503).json({ error: "AI feature is not configured on this server." });
      } else {
        res.status(500).json({ error: e.message || "AI request failed" });
      }
    }
  }
);

export default router;

// ─── Default prompt (fallback if client doesn't supply one) ───────────────

function buildDefaultPrompt(
  goal: string,
  dailyHours: number,
  skill: "beginner" | "intermediate" | "advanced"
): string {
  return `You are an expert learning coach and curriculum designer.

Create a detailed, actionable Pomodoro study roadmap for:

Goal: ${goal}
Daily study time: ${dailyHours} hours
Current skill level: ${skill}

Return ONLY valid JSON matching exactly:
{
  "goal": string,
  "totalDays": number,
  "totalHours": number,
  "summary": string,
  "phases": [
    {
      "phase": number,
      "title": string,
      "goal": string,
      "topics": [
        {
          "id": string,
          "title": string,
          "description": string,
          "estimatedHours": number,
          "resources": string[],
          "pomodoroSessions": number,
          "day": number,
          "phase": number
        }
      ]
    }
  ]
}

3-4 phases, 3-5 topics each, matched to ${skill} level. No markdown. Only JSON.`;
}
