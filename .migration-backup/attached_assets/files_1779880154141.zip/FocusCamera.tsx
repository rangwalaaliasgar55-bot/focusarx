/**
 * FocusCamera.tsx — FocusARX
 *
 * Fixes:
 *  1. getUserMedia is now triggered by a user-gesture button (browser requirement)
 *  2. Proper async/await + error handling for stream init
 *  3. video.srcObject is set correctly after stream resolves
 *  4. Works on localhost (HTTP) in dev; HTTPS in prod (Vercel)
 *  5. Face detection: stub returns facePresent:true (MediaPipe needs GPU, see replit.md)
 *     Replace processCameraFrame() with real ML logic when GPU is available
 *
 * Props:
 *  onFocusScore(score: number) — called every `interval` ms with 0–100 score
 *  interval — ms between focus checks (default 5000)
 */

import React, {
  useRef,
  useState,
  useEffect,
  useCallback,
} from "react";

interface FocusCameraProps {
  onFocusScore?: (score: number) => void;
  interval?: number;
}

type CameraState =
  | "idle"       // not started
  | "requesting" // waiting for permission
  | "active"     // stream running
  | "denied"     // permission denied
  | "error";     // other error

// ─── Stub processor (replace with TensorFlow/MediaPipe when GPU available) ───
async function processCameraFrame(
  video: HTMLVideoElement
): Promise<{ facePresent: boolean; score: number }> {
  // Stub: always returns focused. See replit.md "Vision processor stubbed"
  void video; // suppress unused-var warning
  return { facePresent: true, score: 95 };
}

export function FocusCamera({
  onFocusScore,
  interval = 5000,
}: FocusCameraProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [cameraState, setCameraState] = useState<CameraState>("idle");
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [focusScore, setFocusScore] = useState<number | null>(null);
  const [facePresent, setFacePresent] = useState<boolean>(false);

  // ── Start camera ────────────────────────────────────────────
  const startCamera = useCallback(async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraState("error");
      setErrorMessage("Camera API not available in this browser.");
      return;
    }

    setCameraState("requesting");
    setErrorMessage("");

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "user",
        },
        audio: false,
      });

      streamRef.current = stream;

      // Set srcObject AFTER we have the stream
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {
          // Autoplay may be blocked; user will see the paused first frame
        });
      }

      setCameraState("active");

      // Start focus-check interval
      intervalRef.current = setInterval(async () => {
        if (!videoRef.current) return;
        try {
          const result = await processCameraFrame(videoRef.current);
          setFacePresent(result.facePresent);
          setFocusScore(result.score);
          onFocusScore?.(result.score);
        } catch {
          // Swallow individual frame errors silently
        }
      }, interval);
    } catch (err: unknown) {
      const e = err as DOMException;
      if (e.name === "NotAllowedError" || e.name === "PermissionDeniedError") {
        setCameraState("denied");
        setErrorMessage(
          "Camera permission denied. Please allow camera access in your browser settings."
        );
      } else if (e.name === "NotFoundError") {
        setCameraState("error");
        setErrorMessage("No camera found on this device.");
      } else {
        setCameraState("error");
        setErrorMessage(e.message || "Unknown camera error.");
      }
    }
  }, [interval, onFocusScore]);

  // ── Stop camera ─────────────────────────────────────────────
  const stopCamera = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraState("idle");
    setFocusScore(null);
    setFacePresent(false);
  }, []);

  // ── Cleanup on unmount ────────────────────────────────────
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, [stopCamera]);

  // ── Render ────────────────────────────────────────────────
  return (
    <div
      style={{
        background: "var(--bg-surface)",
        border: "1px solid var(--border)",
        borderRadius: "12px",
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        gap: 0,
      }}
    >
      {/* Video preview */}
      <div
        style={{
          position: "relative",
          aspectRatio: "4/3",
          background: "var(--bg-elevated)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <video
          ref={videoRef}
          muted
          playsInline
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            display: cameraState === "active" ? "block" : "none",
            transform: "scaleX(-1)", // mirror effect
          }}
        />

        {/* Idle / Error overlay */}
        {cameraState !== "active" && (
          <div
            style={{
              textAlign: "center",
              padding: "24px",
              color: "var(--text-muted)",
            }}
          >
            <div style={{ fontSize: "40px", marginBottom: "8px" }}>
              {cameraState === "denied"
                ? "🚫"
                : cameraState === "error"
                ? "⚠️"
                : cameraState === "requesting"
                ? "⏳"
                : "📷"}
            </div>
            <p
              style={{
                fontSize: "13px",
                color:
                  cameraState === "denied" || cameraState === "error"
                    ? "var(--danger)"
                    : "var(--text-muted)",
                maxWidth: "220px",
                lineHeight: 1.5,
              }}
            >
              {cameraState === "requesting"
                ? "Requesting camera access…"
                : errorMessage || "Camera off"}
            </p>
          </div>
        )}

        {/* Focus score badge (active) */}
        {cameraState === "active" && focusScore !== null && (
          <div
            style={{
              position: "absolute",
              top: "10px",
              right: "10px",
              background: facePresent
                ? "rgba(34,211,135,0.9)"
                : "rgba(239,68,68,0.9)",
              color: "#fff",
              fontSize: "12px",
              fontWeight: 700,
              padding: "3px 9px",
              borderRadius: "20px",
              backdropFilter: "blur(4px)",
            }}
          >
            {facePresent ? `✓ ${focusScore}%` : "No face detected"}
          </div>
        )}
      </div>

      {/* Controls */}
      <div
        style={{
          padding: "12px 14px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderTop: "1px solid var(--border-subtle)",
          gap: "10px",
        }}
      >
        <div>
          <p
            style={{
              fontSize: "13px",
              fontWeight: 600,
              color: "var(--text-primary)",
              margin: 0,
            }}
          >
            AI Focus Camera
          </p>
          <p
            style={{
              fontSize: "11px",
              color: "var(--text-muted)",
              margin: 0,
            }}
          >
            {cameraState === "active"
              ? `Monitoring every ${interval / 1000}s`
              : "Tracks your focus during sessions"}
          </p>
        </div>

        <button
          onClick={cameraState === "active" ? stopCamera : startCamera}
          disabled={cameraState === "requesting"}
          style={{
            padding: "7px 16px",
            borderRadius: "7px",
            border: "none",
            cursor: cameraState === "requesting" ? "wait" : "pointer",
            fontWeight: 600,
            fontSize: "13px",
            fontFamily: "inherit",
            background:
              cameraState === "active" ? "var(--danger)" : "var(--accent)",
            color: "#fff",
            opacity: cameraState === "requesting" ? 0.6 : 1,
            transition: "opacity 0.15s, transform 0.1s",
          }}
          onMouseDown={(e) =>
            ((e.currentTarget as HTMLButtonElement).style.transform = "scale(0.96)")
          }
          onMouseUp={(e) =>
            ((e.currentTarget as HTMLButtonElement).style.transform = "scale(1)")
          }
        >
          {cameraState === "active"
            ? "Stop"
            : cameraState === "requesting"
            ? "Starting…"
            : "Start Camera"}
        </button>
      </div>
    </div>
  );
}
