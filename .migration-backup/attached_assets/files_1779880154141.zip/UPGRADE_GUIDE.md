# FocusARX Upgrade Guide
## For Replit — copy/paste ready

---

## What's in this package

| File | What it fixes / adds |
|------|---------------------|
| `src/lib/theme.tsx` | Theme context (dark/light/system), localStorage persist |
| `src/styles/globals.css` | All CSS variables for both themes, base reset |
| `src/components/ThemeToggle.tsx` | Theme toggle button (dark→light→system cycle) |
| `src/components/AppShell.tsx` | TS7030 fix, responsive layout |
| `src/components/Sidebar.tsx` | Fixed desktop + mobile drawer, logo, X button, theme toggle |
| `src/components/FocusCamera.tsx` | AI camera rewrite — user-gesture init, proper stream handling |
| `src/pages/roadmap.tsx` | Upgraded UI — phases, progress tracking, structured prompts |
| `artifacts/api-server/src/routes/ai.ts` | Better Claude prompt, safe JSON parse |
| `artifacts/api-server/src/routes/auth.ts` | Role fix (case-insensitive), no dropped promises |
| `artifacts/api-server/src/middleware/auth.ts` | requireAuth + requireAdmin with safe role comparison |
| `vercel.json` | Correct output dir, maxDuration, CORS headers |

---

## Step-by-step Replit instructions

### 1. Copy the new files into your workspace

In Replit's Shell tab, run:

```bash
# From repo root
cp -r /path/to/upgrade/artifacts/focusarx/src/lib/theme.tsx \
       artifacts/focusarx/src/lib/theme.tsx

cp -r /path/to/upgrade/artifacts/focusarx/src/styles/globals.css \
       artifacts/focusarx/src/styles/globals.css

cp /path/to/upgrade/artifacts/focusarx/src/components/ThemeToggle.tsx \
   artifacts/focusarx/src/components/ThemeToggle.tsx

cp /path/to/upgrade/artifacts/focusarx/src/components/AppShell.tsx \
   artifacts/focusarx/src/components/AppShell.tsx

cp /path/to/upgrade/artifacts/focusarx/src/components/Sidebar.tsx \
   artifacts/focusarx/src/components/Sidebar.tsx

cp /path/to/upgrade/artifacts/focusarx/src/components/FocusCamera.tsx \
   artifacts/focusarx/src/components/FocusCamera.tsx

cp /path/to/upgrade/artifacts/focusarx/src/pages/roadmap.tsx \
   artifacts/focusarx/src/pages/roadmap.tsx

cp /path/to/upgrade/artifacts/api-server/src/routes/ai.ts \
   artifacts/api-server/src/routes/ai.ts

cp /path/to/upgrade/artifacts/api-server/src/routes/auth.ts \
   artifacts/api-server/src/routes/auth.ts

mkdir -p artifacts/api-server/src/middleware
cp /path/to/upgrade/artifacts/api-server/src/middleware/auth.ts \
   artifacts/api-server/src/middleware/auth.ts

cp /path/to/upgrade/vercel.json vercel.json
```

### 2. Wire up ThemeProvider in main.tsx / App.tsx

Open `artifacts/focusarx/src/main.tsx` (or wherever your root render is) and wrap with ThemeProvider:

```tsx
import { ThemeProvider } from "./lib/theme";
import "./styles/globals.css";   // ← add this import

// In your render:
<ThemeProvider>
  <App />
</ThemeProvider>
```

### 3. Import globals.css

In `artifacts/focusarx/src/main.tsx` at the top:
```tsx
import "./styles/globals.css";
```

Remove any old `@tailwind` import if you're switching to pure CSS variables (or keep Tailwind and use our CSS variables alongside it).

### 4. Update roadmap page route

In `artifacts/focusarx/src/App.tsx`, ensure the roadmap route uses the new component:
```tsx
import { RoadmapPage } from "./pages/roadmap";
// ...
<Route path="/roadmap" component={RoadmapPage} />
```

### 5. Update admin route to use requireAdmin middleware

In `artifacts/api-server/src/routes/admin.ts`, replace any inline auth check with:
```ts
import { requireAdmin } from "../middleware/auth.js";
router.get("/users", requireAdmin, async (req, res) => { ... });
```

### 6. Typecheck

```bash
pnpm run typecheck
```

Expected: 0 errors for the files in this package.

### 7. Dev run

```bash
# Terminal 1
pnpm --filter @workspace/api-server run dev

# Terminal 2
pnpm --filter @workspace/focusarx run dev
```

---

## Theme usage in components

```tsx
import { useTheme } from "../lib/theme";

function MyComponent() {
  const { resolved, setTheme, toggle } = useTheme();
  // resolved === "dark" | "light"
  // All colours via CSS var: style={{ color: "var(--text-primary)" }}
}
```

CSS variables available everywhere (no import needed):
- `--bg`, `--bg-surface`, `--bg-elevated`, `--bg-hover`
- `--text-primary`, `--text-secondary`, `--text-muted`
- `--accent`, `--accent-glow`, `--accent-dim`
- `--border`, `--border-subtle`
- `--success`, `--warning`, `--danger`, `--info`
- `--shadow-sm`, `--shadow-md`, `--shadow-lg`

---

## AI Camera — what was fixed

| Issue | Root cause | Fix |
|-------|-----------|-----|
| Camera doesn't start | `getUserMedia` called on mount without user gesture | Moved to button `onClick` handler |
| Video black / frozen | `video.srcObject` set before stream resolved | Now set in `.then()` / after `await` |
| Crash on `play()` | Promise not awaited | Added `await video.play().catch(() => {})` |
| No error shown | Catch block was empty | Full error UI with type-specific messages |

---

## ADMIN role fix — what was changed

Old code (broken):
```ts
if (user.role === "admin") { ... }  // fails if DB stores "ADMIN" or "Admin"
```

New code (fixed in auth.ts, middleware/auth.ts):
```ts
role: (user.role ?? "USER").toUpperCase(),  // normalise on JWT sign
// ...
if (req.user.role.toUpperCase() !== "ADMIN") { ... }  // normalise on check
```

This means:
- Roles stored as `"admin"`, `"Admin"`, or `"ADMIN"` all work correctly
- JWT always stores `"ADMIN"` (uppercase) so frontend role checks are consistent

---

## Vercel — what changed in vercel.json

Added `maxDuration: 30` to prevent cold-start timeouts on AI roadmap calls.
Added explicit `/api/(.*)` → `/api/index.js` rewrite before the SPA catch-all.
Added CORS headers for `/api/*` responses.

---

## Commit checklist

- [ ] `pnpm run typecheck` → 0 errors
- [ ] `pnpm run build` → builds without errors  
- [ ] Camera starts only on button click (not on page load)
- [ ] Dark theme loads by default; toggle cycles dark→light→system
- [ ] ADMIN user can reach /admin without 403
- [ ] AI roadmap returns structured phases with progress dots
- [ ] `git add -A && git commit -m "feat: dark theme, camera fix, roadmap upgrade, auth role fix"`
- [ ] `git push origin main` → Vercel auto-deploys
