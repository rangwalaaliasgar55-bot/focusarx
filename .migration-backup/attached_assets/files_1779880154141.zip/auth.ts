/**
 * auth.ts — Authentication routes
 *
 * Fixes:
 *  1. Role comparison is now case-insensitive: role.toUpperCase() === "ADMIN"
 *  2. All async paths have await + try/catch (no dropped promises)
 *  3. Clear 401/403 separation (auth vs permission)
 *  4. Passwords hashed with bcryptjs (10 rounds)
 *  5. JWT signed with AUTH_SECRET env var (falls back to dev secret with warning)
 */

import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import { db } from "@workspace/db";
import { users } from "@workspace/db/schema";
import { eq } from "drizzle-orm";

const router = Router();

// ─── JWT helpers ──────────────────────────────────────────────────────────

const JWT_SECRET: string = (() => {
  const s = process.env.AUTH_SECRET;
  if (!s) {
    console.warn(
      "[auth] AUTH_SECRET not set — using insecure dev fallback. Set it in production!"
    );
    return "focusarx-dev-secret-change-me";
  }
  return s;
})();

const JWT_EXPIRY = "7d";

function signToken(payload: {
  userId: number;
  email: string;
  role: string;
}): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: JWT_EXPIRY });
}

function verifyToken(
  token: string
): { userId: number; email: string; role: string } | null {
  try {
    return jwt.verify(token, JWT_SECRET) as {
      userId: number;
      email: string;
      role: string;
    };
  } catch {
    return null;
  }
}

// ─── POST /auth/register ─────────────────────────────────────────────────

router.post("/register", async (req: Request, res: Response): Promise<void> => {
  const { email, password, name } = req.body as {
    email?: string;
    password?: string;
    name?: string;
  };

  if (!email?.trim() || !password) {
    res.status(400).json({ error: "email and password are required" });
    return;
  }

  try {
    // Check for existing user
    const existing = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase().trim()))
      .limit(1);

    if (existing.length > 0) {
      res.status(409).json({ error: "An account with this email already exists" });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const [newUser] = await db
      .insert(users)
      .values({
        email: email.toLowerCase().trim(),
        name: name?.trim() || null,
        passwordHash,
        role: "USER", // always USER on self-register
        isGuest: false,
      })
      .returning();

    const token = signToken({
      userId: newUser.id,
      email: newUser.email,
      role: newUser.role,
    });

    res.status(201).json({
      token,
      user: {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        role: newUser.role,
      },
    });
  } catch (err: unknown) {
    console.error("[auth/register]", err);
    res.status(500).json({ error: "Registration failed" });
  }
});

// ─── POST /auth/login ─────────────────────────────────────────────────────

router.post("/login", async (req: Request, res: Response): Promise<void> => {
  const { email, password } = req.body as {
    email?: string;
    password?: string;
  };

  if (!email?.trim() || !password) {
    res.status(400).json({ error: "email and password are required" });
    return;
  }

  try {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.email, email.toLowerCase().trim()))
      .limit(1);

    if (!user) {
      // Generic message to prevent user enumeration
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }

    if (!user.passwordHash) {
      // Guest account or OAuth user — no password
      res.status(401).json({
        error: "This account does not have a password. Try another login method.",
      });
      return;
    }

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) {
      res.status(401).json({ error: "Invalid email or password" });
      return;
    }

    const token = signToken({
      userId: user.id,
      email: user.email,
      // ── FIX: normalise role to uppercase before signing ──────────────
      role: (user.role ?? "USER").toUpperCase(),
    });

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        // ── FIX: return normalised role ──────────────────────────────
        role: (user.role ?? "USER").toUpperCase(),
      },
    });
  } catch (err: unknown) {
    console.error("[auth/login]", err);
    res.status(500).json({ error: "Login failed" });
  }
});

// ─── POST /auth/guest ─────────────────────────────────────────────────────

router.post("/guest", async (req: Request, res: Response): Promise<void> => {
  const { guestId } = req.body as { guestId?: string };
  const id = guestId?.trim() || uuidv4();

  try {
    // Upsert: if guest already exists, return their token
    const existing = await db
      .select()
      .from(users)
      .where(eq(users.guestId, id))
      .limit(1);

    const guestUser =
      existing[0] ??
      (
        await db
          .insert(users)
          .values({
            email: `guest-${id}@focusarx.internal`,
            name: "Guest",
            passwordHash: null,
            role: "USER",
            isGuest: true,
            guestId: id,
          })
          .returning()
      )[0];

    const token = signToken({
      userId: guestUser.id,
      email: guestUser.email,
      role: (guestUser.role ?? "USER").toUpperCase(),
    });

    res.json({
      token,
      guestId: id,
      user: {
        id: guestUser.id,
        email: guestUser.email,
        name: guestUser.name,
        role: (guestUser.role ?? "USER").toUpperCase(),
      },
    });
  } catch (err: unknown) {
    console.error("[auth/guest]", err);
    res.status(500).json({ error: "Guest login failed" });
  }
});

// ─── GET /auth/session ────────────────────────────────────────────────────

router.get("/session", async (req: Request, res: Response): Promise<void> => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    res.status(401).json({ error: "No token provided" });
    return;
  }

  const token = authHeader.slice(7);
  const payload = verifyToken(token);

  if (!payload) {
    res.status(401).json({ error: "Invalid or expired token" });
    return;
  }

  try {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.id, payload.userId))
      .limit(1);

    if (!user) {
      res.status(401).json({ error: "User not found" });
      return;
    }

    res.json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        // ── FIX: always normalise role casing on session check ────────
        role: (user.role ?? "USER").toUpperCase(),
        isGuest: user.isGuest,
      },
    });
  } catch (err: unknown) {
    console.error("[auth/session]", err);
    res.status(500).json({ error: "Session check failed" });
  }
});

export default router;
export { verifyToken, JWT_SECRET };
