/**
 * AppShell.tsx — FocusARX
 *
 * Fixes:
 *  - TS7030: every map/conditional branch now explicitly returns JSX or null
 *  - Responsive: sidebar fixed on desktop, absolute slide-out on mobile (<768px)
 *  - Theme-aware via CSS variables
 */

import React, { useState, useCallback } from "react";
import { Sidebar } from "./Sidebar";

interface AppShellProps {
  children: React.ReactNode;
}

export function AppShell({ children }: AppShellProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const openSidebar = useCallback(() => setSidebarOpen(true), []);
  const closeSidebar = useCallback(() => setSidebarOpen(false), []);

  return (
    <div
      style={{
        display: "flex",
        minHeight: "100vh",
        background: "var(--bg)",
        position: "relative",
      }}
    >
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onClose={closeSidebar} />

      {/* Main content area */}
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          minWidth: 0,
          // On desktop, account for fixed sidebar width
          marginLeft: "var(--sidebar-width, 240px)",
        }}
        className="app-shell-main"
      >
        {/* Mobile top bar */}
        <header
          style={{
            display: "none",
            alignItems: "center",
            gap: "12px",
            padding: "0 16px",
            height: "var(--header-height, 56px)",
            background: "var(--bg-surface)",
            borderBottom: "1px solid var(--border)",
            position: "sticky",
            top: 0,
            zIndex: 40,
          }}
          className="mobile-header"
        >
          <button
            onClick={openSidebar}
            aria-label="Open navigation"
            style={{
              background: "none",
              border: "none",
              color: "var(--text-primary)",
              cursor: "pointer",
              padding: "6px",
              display: "flex",
              flexDirection: "column",
              gap: "4px",
            }}
          >
            {/* Hamburger icon — TS7030 safe: no conditional, just 3 spans */}
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                style={{
                  display: "block",
                  width: "20px",
                  height: "2px",
                  background: "var(--text-primary)",
                  borderRadius: "1px",
                  // TS7030 fix: every map iteration returns JSX, never undefined
                }}
              />
            ))}
          </button>

          <img
            src="/logo.png"
            alt="FocusARX"
            style={{ height: "28px", width: "auto" }}
            onError={(e) => {
              // Graceful fallback if logo.png is missing
              (e.currentTarget as HTMLImageElement).style.display = "none";
            }}
          />
          <span
            style={{
              fontWeight: 700,
              fontSize: "16px",
              letterSpacing: "-0.02em",
              color: "var(--text-primary)",
            }}
          >
            FocusARX
          </span>
        </header>

        {/* Page content */}
        <main
          style={{
            flex: 1,
            padding: "24px",
            overflowY: "auto",
          }}
        >
          {children}
        </main>
      </div>

      {/* Inline responsive styles */}
      <style>{`
        @media (max-width: 767px) {
          .app-shell-main {
            margin-left: 0 !important;
          }
          .mobile-header {
            display: flex !important;
          }
        }
      `}</style>
    </div>
  );
}
