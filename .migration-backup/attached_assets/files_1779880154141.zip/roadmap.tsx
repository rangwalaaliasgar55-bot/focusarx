/**
 * RoadmapPage.tsx — FocusARX AI Study Roadmap
 *
 * Upgrades:
 *  1. Improved Claude prompt → structured JSON with phases, topics, resources
 *  2. Visual interactive roadmap (SVG-free, pure CSS node tree)
 *  3. Per-node progress tracking (stored in localStorage)
 *  4. Skill level + daily hours form
 *  5. Full dark-theme awareness via CSS variables
 */

import React, { useState, useCallback, useEffect } from "react";

// ─── Types ──────────────────────────────────────────────────────────────────

interface RoadmapTopic {
  id: string;
  title: string;
  description: string;
  estimatedHours: number;
  resources: string[];
  pomodoroSessions: number;
  day: number;
  phase: number;
}

interface RoadmapPhase {
  phase: number;
  title: string;
  goal: string;
  topics: RoadmapTopic[];
}

interface RoadmapData {
  goal: string;
  totalDays: number;
  totalHours: number;
  summary: string;
  phases: RoadmapPhase[];
}

type SkillLevel = "beginner" | "intermediate" | "advanced";

// ─── Storage helpers ─────────────────────────────────────────────────────────

const PROGRESS_KEY = "focusarx-roadmap-progress";

function loadProgress(): Record<string, boolean> {
  try {
    return JSON.parse(localStorage.getItem(PROGRESS_KEY) || "{}");
  } catch {
    return {};
  }
}

function saveProgress(p: Record<string, boolean>) {
  try {
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(p));
  } catch {}
}

// ─── Claude Prompt ───────────────────────────────────────────────────────────

function buildPrompt(goal: string, dailyHours: number, skill: SkillLevel): string {
  return `You are an expert learning coach and curriculum designer.

Create a detailed, actionable Pomodoro study roadmap for the following:

Goal: ${goal}
Daily study time: ${dailyHours} hours
Current skill level: ${skill}

Return ONLY valid JSON (no markdown, no preamble, no explanation) matching this exact TypeScript type:

{
  "goal": string,
  "totalDays": number,
  "totalHours": number,
  "summary": string (2-3 sentences),
  "phases": [
    {
      "phase": number (1-based),
      "title": string,
      "goal": string (what learner achieves by end of phase),
      "topics": [
        {
          "id": string (unique, e.g. "p1-t1"),
          "title": string,
          "description": string (1-2 sentences, practical),
          "estimatedHours": number,
          "resources": string[] (2-3 specific resource titles or URLs),
          "pomodoroSessions": number (25-min sessions needed),
          "day": number (which day to study this),
          "phase": number
        }
      ]
    }
  ]
}

Rules:
- Phases: 3-4 phases (Foundation → Core Skills → Advanced → Mastery)
- Topics per phase: 3-5 practical, concrete topics
- Match difficulty ramp to skill level "${skill}"
- Keep daily workload ≤ ${dailyHours} hours
- Resources: name real books, courses, docs (e.g. "MDN Web Docs", "CS50 on edX")
- pomodoroSessions = ceil(estimatedHours * 60 / 25)
- Return ONLY the JSON object, nothing else`;
}

// ─── Components ──────────────────────────────────────────────────────────────

function TopicCard({
  topic,
  completed,
  onToggle,
}: {
  topic: RoadmapTopic;
  completed: boolean;
  onToggle: () => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div
      style={{
        background: completed ? "var(--accent-dim)" : "var(--bg-elevated)",
        border: `1px solid ${completed ? "var(--accent-glow)" : "var(--border)"}`,
        borderRadius: "10px",
        padding: "14px 16px",
        cursor: "pointer",
        transition: "all 0.15s ease",
        opacity: completed ? 0.85 : 1,
      }}
    >
      {/* Header row */}
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          gap: "10px",
        }}
        onClick={onToggle}
      >
        {/* Checkbox */}
        <div
          style={{
            width: "20px",
            height: "20px",
            borderRadius: "50%",
            border: `2px solid ${completed ? "var(--accent)" : "var(--border)"}`,
            background: completed ? "var(--accent)" : "transparent",
            flexShrink: 0,
            marginTop: "1px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#fff",
            fontSize: "11px",
            transition: "all 0.15s",
          }}
        >
          {completed ? "✓" : ""}
        </div>

        {/* Title + meta */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "baseline",
              gap: "8px",
              flexWrap: "wrap",
            }}
          >
            <span
              style={{
                fontWeight: 600,
                fontSize: "14px",
                color: completed ? "var(--text-secondary)" : "var(--text-primary)",
                textDecoration: completed ? "line-through" : "none",
              }}
            >
              {topic.title}
            </span>
            <div style={{ display: "flex", gap: "6px", flexShrink: 0 }}>
              <span
                style={{
                  fontSize: "11px",
                  background: "var(--bg-hover)",
                  color: "var(--text-muted)",
                  padding: "2px 7px",
                  borderRadius: "20px",
                  border: "1px solid var(--border)",
                }}
              >
                Day {topic.day}
              </span>
              <span
                style={{
                  fontSize: "11px",
                  background: "var(--accent-dim)",
                  color: "var(--accent)",
                  padding: "2px 7px",
                  borderRadius: "20px",
                }}
              >
                🍅 {topic.pomodoroSessions}
              </span>
            </div>
          </div>
          <p
            style={{
              fontSize: "12px",
              color: "var(--text-muted)",
              margin: "4px 0 0",
              lineHeight: 1.5,
            }}
          >
            {topic.description}
          </p>
        </div>

        {/* Expand toggle */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setExpanded((x) => !x);
          }}
          style={{
            background: "none",
            border: "none",
            color: "var(--text-muted)",
            cursor: "pointer",
            padding: "2px",
            fontSize: "12px",
            flexShrink: 0,
          }}
        >
          {expanded ? "▲" : "▼"}
        </button>
      </div>

      {/* Expanded resources */}
      {expanded && topic.resources.length > 0 && (
        <div
          style={{
            marginTop: "12px",
            paddingTop: "12px",
            borderTop: "1px solid var(--border-subtle)",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <p
            style={{
              fontSize: "11px",
              fontWeight: 700,
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              color: "var(--text-muted)",
              marginBottom: "6px",
            }}
          >
            Resources
          </p>
          {topic.resources.map((r, i) => (
            <div
              key={i}
              style={{
                fontSize: "12px",
                color: "var(--text-secondary)",
                padding: "3px 0",
                display: "flex",
                alignItems: "center",
                gap: "6px",
              }}
            >
              <span style={{ color: "var(--accent)", fontSize: "10px" }}>▸</span>
              {r}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PhaseSection({
  phase,
  progress,
  onToggleTopic,
}: {
  phase: RoadmapPhase;
  progress: Record<string, boolean>;
  onToggleTopic: (id: string) => void;
}) {
  const completed = phase.topics.filter((t) => progress[t.id]).length;
  const total = phase.topics.length;
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div
      style={{
        background: "var(--bg-surface)",
        border: "1px solid var(--border)",
        borderRadius: "14px",
        overflow: "hidden",
      }}
    >
      {/* Phase header */}
      <div
        style={{
          padding: "16px 20px",
          borderBottom: "1px solid var(--border-subtle)",
          background: "var(--bg-elevated)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            marginBottom: "8px",
            flexWrap: "wrap",
            gap: "8px",
          }}
        >
          <div>
            <span
              style={{
                fontSize: "11px",
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.1em",
                color: "var(--accent)",
              }}
            >
              Phase {phase.phase}
            </span>
            <h3
              style={{
                margin: "2px 0 0",
                fontSize: "16px",
                fontWeight: 700,
                color: "var(--text-primary)",
              }}
            >
              {phase.title}
            </h3>
          </div>
          <span
            style={{
              fontSize: "13px",
              fontWeight: 700,
              color: pct === 100 ? "var(--success)" : "var(--text-secondary)",
            }}
          >
            {completed}/{total} done
          </span>
        </div>

        {/* Progress bar */}
        <div
          style={{
            height: "4px",
            background: "var(--border)",
            borderRadius: "2px",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              height: "100%",
              width: `${pct}%`,
              background: pct === 100 ? "var(--success)" : "var(--accent)",
              borderRadius: "2px",
              transition: "width 0.3s ease",
            }}
          />
        </div>

        <p
          style={{
            margin: "8px 0 0",
            fontSize: "12px",
            color: "var(--text-muted)",
          }}
        >
          {phase.goal}
        </p>
      </div>

      {/* Topics */}
      <div
        style={{
          padding: "14px",
          display: "flex",
          flexDirection: "column",
          gap: "8px",
        }}
      >
        {phase.topics.map((topic) => (
          <TopicCard
            key={topic.id}
            topic={topic}
            completed={!!progress[topic.id]}
            onToggle={() => onToggleTopic(topic.id)}
          />
        ))}
      </div>
    </div>
  );
}

// ─── Main Page ───────────────────────────────────────────────────────────────

export function RoadmapPage() {
  const [goal, setGoal] = useState("");
  const [dailyHours, setDailyHours] = useState(2);
  const [skillLevel, setSkillLevel] = useState<SkillLevel>("beginner");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [roadmap, setRoadmap] = useState<RoadmapData | null>(null);
  const [progress, setProgress] = useState<Record<string, boolean>>(loadProgress);

  // Persist progress whenever it changes
  useEffect(() => {
    saveProgress(progress);
  }, [progress]);

  const toggleTopic = useCallback((id: string) => {
    setProgress((prev) => ({ ...prev, [id]: !prev[id] }));
  }, []);

  const generateRoadmap = useCallback(async () => {
    if (!goal.trim()) return;
    setLoading(true);
    setError(null);
    setRoadmap(null);

    try {
      const res = await fetch("/api/ai/roadmap", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          goal: goal.trim(),
          dailyHours,
          skillLevel,
          // Pass the improved prompt via the API route
          prompt: buildPrompt(goal.trim(), dailyHours, skillLevel),
        }),
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body?.error || `API error ${res.status}`);
      }

      const data: RoadmapData = await res.json();

      // Validate the shape
      if (!data.phases || !Array.isArray(data.phases)) {
        throw new Error("Invalid roadmap response from AI.");
      }

      setRoadmap(data);
    } catch (err: unknown) {
      setError((err as Error).message || "Failed to generate roadmap.");
    } finally {
      setLoading(false);
    }
  }, [goal, dailyHours, skillLevel]);

  // Overall progress
  const allTopics = roadmap?.phases.flatMap((p) => p.topics) ?? [];
  const completedCount = allTopics.filter((t) => progress[t.id]).length;
  const overallPct =
    allTopics.length > 0 ? Math.round((completedCount / allTopics.length) * 100) : 0;

  return (
    <div style={{ maxWidth: "760px", margin: "0 auto", padding: "0 0 40px" }}>
      {/* Page header */}
      <div style={{ marginBottom: "28px" }}>
        <h1
          style={{
            fontSize: "24px",
            fontWeight: 800,
            color: "var(--text-primary)",
            letterSpacing: "-0.03em",
            margin: "0 0 6px",
          }}
        >
          ✦ AI Study Roadmap
        </h1>
        <p style={{ color: "var(--text-muted)", fontSize: "14px", margin: 0 }}>
          Describe your learning goal and get a personalised Pomodoro plan.
        </p>
      </div>

      {/* Form */}
      <div
        style={{
          background: "var(--bg-surface)",
          border: "1px solid var(--border)",
          borderRadius: "14px",
          padding: "20px",
          marginBottom: "24px",
          display: "flex",
          flexDirection: "column",
          gap: "16px",
        }}
      >
        {/* Goal input */}
        <div>
          <label
            style={{
              display: "block",
              fontSize: "13px",
              fontWeight: 600,
              color: "var(--text-secondary)",
              marginBottom: "6px",
            }}
          >
            What do you want to learn?
          </label>
          <textarea
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="e.g. Learn React with TypeScript and build a full-stack app"
            rows={2}
            style={{
              width: "100%",
              padding: "10px 12px",
              background: "var(--bg-elevated)",
              border: "1px solid var(--border)",
              borderRadius: "8px",
              color: "var(--text-primary)",
              fontSize: "14px",
              fontFamily: "inherit",
              resize: "vertical",
              outline: "none",
              boxSizing: "border-box",
            }}
            onFocus={(e) =>
              (e.currentTarget.style.borderColor = "var(--accent)")
            }
            onBlur={(e) =>
              (e.currentTarget.style.borderColor = "var(--border)")
            }
          />
        </div>

        {/* Daily hours + skill level */}
        <div style={{ display: "flex", gap: "14px", flexWrap: "wrap" }}>
          <div style={{ flex: "1 1 140px" }}>
            <label
              style={{
                display: "block",
                fontSize: "13px",
                fontWeight: 600,
                color: "var(--text-secondary)",
                marginBottom: "6px",
              }}
            >
              Daily study hours
            </label>
            <input
              type="number"
              min={0.5}
              max={12}
              step={0.5}
              value={dailyHours}
              onChange={(e) => setDailyHours(Number(e.target.value))}
              style={{
                width: "100%",
                padding: "9px 12px",
                background: "var(--bg-elevated)",
                border: "1px solid var(--border)",
                borderRadius: "8px",
                color: "var(--text-primary)",
                fontSize: "14px",
                fontFamily: "inherit",
                outline: "none",
                boxSizing: "border-box",
              }}
            />
          </div>

          <div style={{ flex: "1 1 180px" }}>
            <label
              style={{
                display: "block",
                fontSize: "13px",
                fontWeight: 600,
                color: "var(--text-secondary)",
                marginBottom: "6px",
              }}
            >
              Current skill level
            </label>
            <select
              value={skillLevel}
              onChange={(e) => setSkillLevel(e.target.value as SkillLevel)}
              style={{
                width: "100%",
                padding: "9px 12px",
                background: "var(--bg-elevated)",
                border: "1px solid var(--border)",
                borderRadius: "8px",
                color: "var(--text-primary)",
                fontSize: "14px",
                fontFamily: "inherit",
                outline: "none",
                cursor: "pointer",
                boxSizing: "border-box",
              }}
            >
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
        </div>

        {/* Submit */}
        <button
          onClick={generateRoadmap}
          disabled={loading || !goal.trim()}
          style={{
            padding: "10px 20px",
            borderRadius: "8px",
            border: "none",
            background:
              loading || !goal.trim() ? "var(--bg-elevated)" : "var(--accent)",
            color:
              loading || !goal.trim() ? "var(--text-muted)" : "#fff",
            fontSize: "14px",
            fontWeight: 700,
            fontFamily: "inherit",
            cursor: loading || !goal.trim() ? "not-allowed" : "pointer",
            alignSelf: "flex-start",
            transition: "all 0.15s",
          }}
        >
          {loading ? "Generating…" : "✦ Generate Roadmap"}
        </button>

        {error && (
          <p
            style={{
              color: "var(--danger)",
              fontSize: "13px",
              margin: 0,
              padding: "8px 12px",
              background: "rgba(239,68,68,0.1)",
              borderRadius: "6px",
              border: "1px solid rgba(239,68,68,0.2)",
            }}
          >
            {error}
          </p>
        )}
      </div>

      {/* Loading skeleton */}
      {loading && (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: "16px",
          }}
        >
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              style={{
                height: "120px",
                background: "var(--bg-surface)",
                border: "1px solid var(--border)",
                borderRadius: "14px",
                opacity: 0.6,
                animation: "pulse 1.5s ease-in-out infinite",
              }}
            />
          ))}
          <style>{`@keyframes pulse { 0%,100%{opacity:.4} 50%{opacity:.8} }`}</style>
        </div>
      )}

      {/* Roadmap output */}
      {roadmap && !loading && (
        <div>
          {/* Summary card */}
          <div
            style={{
              background: "var(--bg-surface)",
              border: "1px solid var(--border)",
              borderRadius: "14px",
              padding: "18px 20px",
              marginBottom: "20px",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
                flexWrap: "wrap",
                gap: "12px",
                marginBottom: "12px",
              }}
            >
              <div>
                <h2
                  style={{
                    fontSize: "16px",
                    fontWeight: 800,
                    color: "var(--text-primary)",
                    margin: "0 0 4px",
                  }}
                >
                  {roadmap.goal}
                </h2>
                <p
                  style={{
                    fontSize: "13px",
                    color: "var(--text-muted)",
                    margin: 0,
                  }}
                >
                  {roadmap.summary}
                </p>
              </div>
              <div style={{ display: "flex", gap: "10px", flexShrink: 0 }}>
                <div
                  style={{
                    textAlign: "center",
                    padding: "8px 14px",
                    background: "var(--bg-elevated)",
                    borderRadius: "8px",
                    border: "1px solid var(--border)",
                  }}
                >
                  <div
                    style={{
                      fontSize: "20px",
                      fontWeight: 800,
                      color: "var(--accent)",
                    }}
                  >
                    {roadmap.totalDays}
                  </div>
                  <div style={{ fontSize: "11px", color: "var(--text-muted)" }}>
                    days
                  </div>
                </div>
                <div
                  style={{
                    textAlign: "center",
                    padding: "8px 14px",
                    background: "var(--bg-elevated)",
                    borderRadius: "8px",
                    border: "1px solid var(--border)",
                  }}
                >
                  <div
                    style={{
                      fontSize: "20px",
                      fontWeight: 800,
                      color: "var(--success)",
                    }}
                  >
                    {roadmap.totalHours}h
                  </div>
                  <div style={{ fontSize: "11px", color: "var(--text-muted)" }}>
                    total
                  </div>
                </div>
              </div>
            </div>

            {/* Overall progress bar */}
            <div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  fontSize: "12px",
                  color: "var(--text-muted)",
                  marginBottom: "5px",
                }}
              >
                <span>Overall progress</span>
                <span style={{ fontWeight: 700, color: "var(--text-primary)" }}>
                  {overallPct}%
                </span>
              </div>
              <div
                style={{
                  height: "6px",
                  background: "var(--border)",
                  borderRadius: "3px",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    height: "100%",
                    width: `${overallPct}%`,
                    background:
                      overallPct === 100 ? "var(--success)" : "var(--accent)",
                    borderRadius: "3px",
                    transition: "width 0.4s ease",
                  }}
                />
              </div>
            </div>
          </div>

          {/* Phases */}
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            {roadmap.phases.map((phase) => (
              <PhaseSection
                key={phase.phase}
                phase={phase}
                progress={progress}
                onToggleTopic={toggleTopic}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
