/**
 * ThemeToggle.tsx
 * A three-state toggle: dark → light → system → dark
 * Drop it in the sidebar or header.
 */

import React from "react";
import { useTheme, ThemeMode } from "../lib/theme";

const ICONS: Record<ThemeMode, string> = {
  dark:   "🌙",
  light:  "☀️",
  system: "💻",
};
const LABELS: Record<ThemeMode, string> = {
  dark:   "Dark",
  light:  "Light",
  system: "System",
};
const NEXT: Record<ThemeMode, ThemeMode> = {
  dark:   "light",
  light:  "system",
  system: "dark",
};

export function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const { theme, setTheme } = useTheme();

  return (
    <button
      onClick={() => setTheme(NEXT[theme])}
      title={`Theme: ${LABELS[theme]} — click to switch`}
      style={{
        display: "flex",
        alignItems: "center",
        gap: compact ? 0 : "8px",
        padding: compact ? "6px" : "6px 12px",
        background: "var(--bg-elevated)",
        border: "1px solid var(--border)",
        borderRadius: "8px",
        color: "var(--text-secondary)",
        fontSize: "13px",
        fontFamily: "inherit",
        cursor: "pointer",
        whiteSpace: "nowrap",
        userSelect: "none",
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--accent)";
        (e.currentTarget as HTMLButtonElement).style.color = "var(--text-primary)";
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLButtonElement).style.borderColor = "var(--border)";
        (e.currentTarget as HTMLButtonElement).style.color = "var(--text-secondary)";
      }}
    >
      <span style={{ fontSize: "15px", lineHeight: 1 }}>{ICONS[theme]}</span>
      {!compact && <span>{LABELS[theme]}</span>}
    </button>
  );
}
