/**
 * Sidebar.tsx — FocusARX
 *
 * Desktop: fixed left panel (240px)
 * Mobile (<768px): absolute slide-out drawer with backdrop + X close button
 * Logo: /logo.png
 * Theme toggle: included at bottom
 */

import React from "react";
import { Link, useRoute } from "wouter";
import { ThemeToggle } from "./ThemeToggle";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

interface NavItem {
  href: string;
  label: string;
  icon: string;
}

const NAV_ITEMS: NavItem[] = [
  { href: "/dashboard", label: "Dashboard",  icon: "◈" },
  { href: "/timer",     label: "Timer",       icon: "◎" },
  { href: "/roadmap",   label: "AI Roadmap",  icon: "✦" },
  { href: "/tasks",     label: "Tasks",       icon: "▣" },
  { href: "/admin",     label: "Admin",       icon: "⬡" },
];

function NavLink({ href, label, icon }: NavItem) {
  const [active] = useRoute(href);
  return (
    <Link href={href}>
      <a
        style={{
          display: "flex",
          alignItems: "center",
          gap: "10px",
          padding: "9px 14px",
          borderRadius: "8px",
          textDecoration: "none",
          fontSize: "14px",
          fontWeight: active ? 600 : 400,
          color: active ? "var(--accent)" : "var(--text-secondary)",
          background: active ? "var(--accent-dim)" : "transparent",
          border: "1px solid",
          borderColor: active ? "var(--accent-glow)" : "transparent",
          transition: "all 0.15s ease",
        }}
        onMouseEnter={(e) => {
          if (!active) {
            e.currentTarget.style.background = "var(--bg-hover)";
            e.currentTarget.style.color = "var(--text-primary)";
          }
        }}
        onMouseLeave={(e) => {
          if (!active) {
            e.currentTarget.style.background = "transparent";
            e.currentTarget.style.color = "var(--text-secondary)";
          }
        }}
      >
        <span
          style={{
            fontSize: "16px",
            width: "20px",
            textAlign: "center",
            flexShrink: 0,
            color: active ? "var(--accent)" : "var(--text-muted)",
          }}
        >
          {icon}
        </span>
        {label}
      </a>
    </Link>
  );
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  return (
    <>
      {/* ── Backdrop (mobile only) ─────────────────────────── */}
      <div
        onClick={onClose}
        aria-hidden="true"
        style={{
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.6)",
          backdropFilter: "blur(2px)",
          zIndex: 49,
          display: "none", // toggled by CSS class + mobile media query
          opacity: isOpen ? 1 : 0,
          pointerEvents: isOpen ? "auto" : "none",
          transition: "opacity 0.2s ease",
        }}
        className={`sidebar-backdrop ${isOpen ? "open" : ""}`}
      />

      {/* ── Sidebar Panel ─────────────────────────────────── */}
      <aside
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          width: "var(--sidebar-width, 240px)",
          height: "100vh",
          background: "var(--bg-surface)",
          borderRight: "1px solid var(--border)",
          display: "flex",
          flexDirection: "column",
          zIndex: 50,
          overflowY: "auto",
          // Desktop: always visible; Mobile: slide in/out via transform
          transform: "translateX(0)",
        }}
        className={`sidebar-panel ${isOpen ? "sidebar-open" : ""}`}
      >
        {/* Header */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "16px 16px 12px",
            borderBottom: "1px solid var(--border-subtle)",
            minHeight: "var(--header-height, 56px)",
          }}
        >
          {/* Logo + Wordmark */}
          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <img
              src="/logo.png"
              alt="FocusARX logo"
              width={32}
              height={32}
              style={{ borderRadius: "6px", objectFit: "contain" }}
              onError={(e) => {
                // Fallback: show coloured circle if logo.png missing
                const img = e.currentTarget as HTMLImageElement;
                img.style.display = "none";
                const fallback = img.nextSibling as HTMLElement | null;
                if (fallback) fallback.style.display = "flex";
              }}
            />
            {/* Fallback logo placeholder (hidden by default) */}
            <div
              style={{
                display: "none",
                width: 32,
                height: 32,
                borderRadius: "6px",
                background: "var(--accent)",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
                fontWeight: 800,
                fontSize: "14px",
              }}
            >
              F
            </div>
            <span
              style={{
                fontWeight: 800,
                fontSize: "15px",
                letterSpacing: "-0.03em",
                color: "var(--text-primary)",
              }}
            >
              FocusARX
            </span>
          </div>

          {/* X close button — visible on mobile only */}
          <button
            onClick={onClose}
            aria-label="Close sidebar"
            className="sidebar-close-btn"
            style={{
              display: "none", // shown via CSS on mobile
              background: "none",
              border: "1px solid var(--border)",
              borderRadius: "6px",
              color: "var(--text-secondary)",
              cursor: "pointer",
              padding: "4px 8px",
              fontSize: "16px",
              lineHeight: 1,
            }}
          >
            ✕
          </button>
        </div>

        {/* Navigation */}
        <nav
          style={{
            flex: 1,
            padding: "12px 10px",
            display: "flex",
            flexDirection: "column",
            gap: "2px",
          }}
        >
          {NAV_ITEMS.map((item): React.ReactElement => (
            // TS7030 fix: explicit return type, every iteration returns JSX
            <NavLink key={item.href} {...item} />
          ))}
        </nav>

        {/* Footer: theme toggle */}
        <div
          style={{
            padding: "12px 10px 20px",
            borderTop: "1px solid var(--border-subtle)",
          }}
        >
          <ThemeToggle />
        </div>
      </aside>

      {/* ── Responsive Styles ─────────────────────────────── */}
      <style>{`
        @media (max-width: 767px) {
          .sidebar-panel {
            transform: translateX(-100%);
            transition: transform 0.25s cubic-bezier(0.4, 0, 0.2, 1);
          }
          .sidebar-panel.sidebar-open {
            transform: translateX(0);
          }
          .sidebar-backdrop {
            display: block !important;
          }
          .sidebar-close-btn {
            display: block !important;
          }
        }
      `}</style>
    </>
  );
}
