export type PType =
  | "normal" | "fire" | "water" | "grass" | "electric"
  | "psychic" | "ghost" | "dragon" | "dark" | "fighting";

export type Rarity = "common" | "uncommon" | "rare" | "epic" | "legendary";
export type Species = "cat" | "fox" | "bunny" | "dragon" | "owl" | "slime" | "penguin" | "panda";

export interface Palette { body: string; belly: string; accent: string; eye?: string }

export interface PetDef {
  id: string;
  name: string;
  kind: "critter" | "mon";
  species?: Species;
  palette?: Palette;
  dex?: number;
  showdown?: string;
  type: PType;
  rarity: Rarity;
  price: number;
  starter?: boolean;
  blurb: string;
  build: "balanced" | "attacker" | "tank" | "speedy";
}

export const RARITY: Record<Rarity, { label: string; color: string; base: number }> = {
  common: { label: "Common", color: "#9aa0ad", base: 270 },
  uncommon: { label: "Uncommon", color: "#4fe0b5", base: 330 },
  rare: { label: "Rare", color: "#6cb6ff", base: 400 },
  epic: { label: "Epic", color: "#a98bff", base: 470 },
  legendary: { label: "Legendary", color: "#ffc857", base: 560 },
};

export const RARITY_PRICE: Record<Rarity, number> = {
  common: 200, uncommon: 500, rare: 1100, epic: 2200, legendary: 4500,
};

export const TYPE_COLOR: Record<PType, string> = {
  normal: "#b9b3a6", fire: "#ff7a45", water: "#5aa8ff", grass: "#6fd36a",
  electric: "#ffd83d", psychic: "#ff7fb0", ghost: "#8a76d6", dragon: "#6f7dff",
  dark: "#7a6a62", fighting: "#e0674a",
};

const mon = (
  id: string, name: string, dex: number, type: PType, rarity: Rarity,
  build: PetDef["build"], blurb: string, starter = false, showdown?: string,
): PetDef => ({
  id, name, kind: "mon", dex, showdown: showdown ?? id, type, rarity,
  price: starter ? 0 : RARITY_PRICE[rarity], starter, blurb, build,
});

const critter = (
  id: string, name: string, species: Species, palette: Palette, type: PType,
  rarity: Rarity, build: PetDef["build"], blurb: string, starter = false,
): PetDef => ({
  id, name, kind: "critter", species, palette, type, rarity,
  price: starter ? 0 : RARITY_PRICE[rarity], starter, blurb, build,
});

export const PETS: PetDef[] = [
  // ——— Starters
  critter("mochi", "Mochi", "cat", { body: "#f4d9b8", belly: "#fff5e8", accent: "#ff9a76" }, "normal", "common", "balanced", "A sleepy cat who purrs louder the longer you focus.", true),
  mon("pikachu", "Pikachu", 25, "electric", "uncommon", "speedy", "Charges up on every uninterrupted minute.", true),
  mon("charmander", "Charmander", 4, "fire", "uncommon", "attacker", "Its tail flame burns brighter with your streak.", true),
  mon("squirtle", "Squirtle", 7, "water", "uncommon", "tank", "Calm under pressure. A great deep-work partner.", true),
  mon("bulbasaur", "Bulbasaur", 1, "grass", "uncommon", "balanced", "Grows a little every time you finish a session.", true),
  mon("eevee", "Eevee", 133, "normal", "uncommon", "balanced", "Adaptable and curious. Loves a fresh to-do list.", true),

  // ——— Original 3D companions
  critter("ember", "Ember", "fox", { body: "#ff8a4c", belly: "#ffe9d2", accent: "#4a2a1f" }, "fire", "common", "attacker", "A fox kit with a tail that glows when you hit flow."),
  critter("clover", "Clover", "bunny", { body: "#f5f2ec", belly: "#ffffff", accent: "#ffb3c1" }, "grass", "common", "speedy", "Hops around the timer whenever a break begins."),
  critter("gloop", "Gloop", "slime", { body: "#6fd6c4", belly: "#c9fff3", accent: "#2b8f83" }, "water", "common", "tank", "Wobbly, squishy and impossible to distract."),
  critter("hoot", "Hoot", "owl", { body: "#b69a7c", belly: "#f1e4d0", accent: "#ffcc4d" }, "psychic", "uncommon", "balanced", "Night-owl energy. Best at late-evening sessions."),
  critter("waddle", "Waddle", "penguin", { body: "#3b4a63", belly: "#f6f9ff", accent: "#ffb347" }, "water", "uncommon", "tank", "Slides into every break with style."),
  critter("bamboo", "Bamboo", "panda", { body: "#2b2d33", belly: "#f6f4ef", accent: "#6fd36a" }, "fighting", "uncommon", "attacker", "Chill until it is time to throw hands."),
  critter("ziggy", "Ziggy", "dragon", { body: "#7f6bff", belly: "#e1dbff", accent: "#ffc857" }, "dragon", "rare", "attacker", "A pocket dragon that hoards your focus minutes."),
  critter("nova", "Nova", "fox", { body: "#9ad7ff", belly: "#f3fbff", accent: "#3f6fd8" }, "psychic", "epic", "speedy", "A frost-furred fox from the quiet side of the sky."),
  critter("onyx", "Onyx", "cat", { body: "#2c2a35", belly: "#55506a", accent: "#ffd23f" }, "dark", "rare", "speedy", "Slips through distractions without a sound."),

  // ——— Pokémon partners
  mon("magikarp", "Magikarp", 129, "water", "common", "balanced", "Splashes now. Believe in the long game."),
  mon("jigglypuff", "Jigglypuff", 39, "normal", "common", "tank", "Sings you to sleep after a hard session."),
  mon("psyduck", "Psyduck", 54, "water", "common", "balanced", "Headache-proof as long as you take breaks."),
  mon("meowth", "Meowth", 52, "normal", "common", "speedy", "Coin collector. Boosts your payouts in spirit."),
  mon("vulpix", "Vulpix", 37, "fire", "uncommon", "speedy", "Six tails, zero distractions."),
  mon("cubone", "Cubone", 104, "fighting", "uncommon", "tank", "Quiet, loyal and ready for another round."),
  mon("piplup", "Piplup", 393, "water", "uncommon", "balanced", "Proud, tiny, and always on time."),
  mon("togepi", "Togepi", 175, "psychic", "uncommon", "balanced", "Brings good luck to every start button."),
  mon("gengar", "Gengar", 94, "ghost", "rare", "attacker", "Haunts procrastination until it leaves."),
  mon("lucario", "Lucario", 448, "fighting", "rare", "attacker", "Reads your focus aura and keeps pace."),
  mon("umbreon", "Umbreon", 197, "dark", "rare", "tank", "The calm of a 2 a.m. study session."),
  mon("snorlax", "Snorlax", 143, "normal", "rare", "tank", "Immovable. Nothing gets past this wall."),
  mon("lapras", "Lapras", 131, "water", "rare", "tank", "Carries you across long study sessions."),
  mon("gyarados", "Gyarados", 130, "water", "epic", "attacker", "Proof that patience turns into power."),
  mon("charizard", "Charizard", 6, "fire", "epic", "attacker", "Burns through your to-do list."),
  mon("dragonite", "Dragonite", 149, "dragon", "epic", "balanced", "Delivers results, rain or shine."),
  mon("mew", "Mew", 151, "psychic", "legendary", "speedy", "Rare. Playful. Appears for the truly consistent."),
  mon("mewtwo", "Mewtwo", 150, "psychic", "legendary", "attacker", "Pure, concentrated focus."),
  mon("rayquaza", "Rayquaza", 384, "dragon", "legendary", "attacker", "Rules the sky above your longest streaks."),
];

export const PET_MAP: Record<string, PetDef> = Object.fromEntries(PETS.map((p) => [p.id, p]));
export const STARTERS = PETS.filter((p) => p.starter);

// ——— Images ———
export const artwork = (dex: number) =>
  `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${dex}.png`;
export const showdownFront = (n: string) => `https://play.pokemonshowdown.com/sprites/ani/${n}.gif`;
export const showdownBack = (n: string) => `https://play.pokemonshowdown.com/sprites/ani-back/${n}.gif`;
export const staticSprite = (dex: number) =>
  `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${dex}.png`;

// ——— Bond levels ———
export const MAX_LEVEL = 20;
export const xpForLevel = (lvl: number) => lvl * 100;

export const LEVEL_UNLOCKS: Record<number, string> = {
  2: "Pet reacts to taps",
  3: "Focus-cheer animation",
  5: "+5% coins on sessions",
  7: "Victory dance",
  10: "+10% coins on sessions",
  12: "Battle: Recover refills 1 PP",
  15: "+15% coins on sessions",
  18: "Battle: critical hits +5%",
  20: "Master bond — golden aura",
};

export const coinBonusForLevel = (lvl: number) => (lvl >= 15 ? 0.15 : lvl >= 10 ? 0.1 : lvl >= 5 ? 0.05 : 0);

// ——— Battle ———
export type MoveKind = "attack" | "heal";
export interface Move {
  id: string; name: string; type: PType; power: number; acc: number; pp: number; kind: MoveKind; fx: string;
}

const TYPE_MOVES: Record<PType, [string, string]> = {
  normal: ["Quick Tap", "Body Slam"],
  fire: ["Ember", "Flame Burst"],
  water: ["Splash Jet", "Tidal Crash"],
  grass: ["Leaf Flick", "Solar Bloom"],
  electric: ["Zap", "Thunder Rush"],
  psychic: ["Mind Pulse", "Mind Break"],
  ghost: ["Shadow Poke", "Night Haunt"],
  dragon: ["Dragon Claw", "Draco Burst"],
  dark: ["Sneak Bite", "Dark Pulse"],
  fighting: ["Chop", "Close Combat"],
};

export function movesFor(type: PType): Move[] {
  const [weak, strong] = TYPE_MOVES[type];
  const m: Move[] = [
    { id: `${type}-w`, name: weak, type, power: 42, acc: 100, pp: 15, kind: "attack", fx: type },
    { id: `${type}-s`, name: strong, type, power: 88, acc: 85, pp: 6, kind: "attack", fx: type },
  ];
  if (type !== "normal") {
    m.push({ id: "tackle", name: "Tackle", type: "normal", power: 48, acc: 100, pp: 12, kind: "attack", fx: "normal" });
  } else {
    m.push({ id: "swift", name: "Swift", type: "normal", power: 58, acc: 95, pp: 8, kind: "attack", fx: "normal" });
  }
  m.push({ id: "recover", name: "Recover", type: "normal", power: 0, acc: 100, pp: 3, kind: "heal", fx: "heal" });
  return m;
}

const CHART: Partial<Record<PType, Partial<Record<PType, number>>>> = {
  fire: { grass: 2, water: 0.5, fire: 0.5, dragon: 0.5 },
  water: { fire: 2, grass: 0.5, water: 0.5, dragon: 0.5 },
  grass: { water: 2, fire: 0.5, grass: 0.5, dragon: 0.5 },
  electric: { water: 2, grass: 0.5, electric: 0.5, dragon: 0.5 },
  psychic: { fighting: 2, psychic: 0.5, dark: 0.5 },
  ghost: { psychic: 2, ghost: 2, dark: 0.5, normal: 0.5 },
  dragon: { dragon: 2 },
  dark: { psychic: 2, ghost: 2, fighting: 0.5, dark: 0.5 },
  fighting: { normal: 2, dark: 2, ghost: 0.5, psychic: 0.5 },
  normal: { ghost: 0.5 },
};
export const effectiveness = (atk: PType, def: PType) => CHART[atk]?.[def] ?? 1;

export interface Stats { hp: number; atk: number; def: number; spd: number }

const BUILDS: Record<PetDef["build"], [number, number, number, number]> = {
  balanced: [0.26, 0.25, 0.25, 0.24],
  attacker: [0.22, 0.32, 0.2, 0.26],
  tank: [0.32, 0.2, 0.32, 0.16],
  speedy: [0.22, 0.26, 0.2, 0.32],
};

export function statsFor(def: PetDef, level: number): Stats {
  const bst = RARITY[def.rarity].base;
  const [h, a, d, s] = BUILDS[def.build];
  return {
    hp: Math.round(bst * h * 0.8 + level * 5 + 40),
    atk: Math.round(bst * a * 0.55 + level * 1.5 + 12),
    def: Math.round(bst * d * 0.55 + level * 1.3 + 12),
    spd: Math.round(bst * s * 0.55 + level * 1.0 + 10),
  };
}

export function power(def: PetDef, level: number) {
  const s = statsFor(def, level);
  return s.hp / 4 + s.atk + s.def + s.spd;
}

// ——— Arena ladder ———
export interface ArenaStage {
  id: number; name: string; blurb: string; foes: string[]; level: number; energy: number; coins: number; xp: number;
}
export const ARENA: ArenaStage[] = [
  { id: 1, name: "Meadow Cup", blurb: "A friendly warm-up on soft grass.", foes: ["magikarp", "meowth", "clover"], level: 3, energy: 10, coins: 40, xp: 30 },
  { id: 2, name: "Lantern Cup", blurb: "Evening matches under paper lanterns.", foes: ["vulpix", "hoot", "togepi"], level: 6, energy: 12, coins: 70, xp: 45 },
  { id: 3, name: "Tidewall Cup", blurb: "Slippery stones and splashy rivals.", foes: ["lapras", "piplup", "waddle"], level: 9, energy: 14, coins: 110, xp: 60 },
  { id: 4, name: "Stormgate Cup", blurb: "Sparks fly above the old gate.", foes: ["lucario", "gengar", "onyx"], level: 12, energy: 16, coins: 160, xp: 80 },
  { id: 5, name: "Skyfall Cup", blurb: "Only the dragons are left up here.", foes: ["dragonite", "gyarados", "charizard"], level: 16, energy: 20, coins: 260, xp: 110 },
  { id: 6, name: "Mythic Cup", blurb: "Legends step into the ring.", foes: ["mew", "mewtwo", "rayquaza"], level: 20, energy: 25, coins: 420, xp: 160 },
];

// ——— Care ———
export const FEED_COST = 15;
