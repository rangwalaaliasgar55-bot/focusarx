import { useSyncExternalStore } from "react";

const get = () => (window.location.hash.replace(/^#/, "") || "/").split("?")[0];
const sub = (cb: () => void) => { window.addEventListener("hashchange", cb); return () => window.removeEventListener("hashchange", cb); };

export const useRoute = () => useSyncExternalStore(sub, get, () => "/");
export const go = (path: string) => { window.location.hash = path; window.scrollTo({ top: 0 }); };
export const hrefOf = (path: string) => `#${path}`;
