// Tiny WebAudio engine — no audio files, everything is synthesised in the browser.

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let current: { stop: () => void; id: string } | null = null;
let noiseBuffers: Record<string, AudioBuffer> = {};

function ac() {
  if (!ctx) {
    const C = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new C();
    master = ctx.createGain();
    master.gain.value = 0.5;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function noise(kind: "white" | "brown" | "pink") {
  const c = ac();
  if (noiseBuffers[kind]) return noiseBuffers[kind];
  const len = c.sampleRate * 4;
  const buf = c.createBuffer(1, len, c.sampleRate);
  const d = buf.getChannelData(0);
  let last = 0, b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < len; i++) {
    const w = Math.random() * 2 - 1;
    if (kind === "white") d[i] = w * 0.5;
    else if (kind === "brown") { last = (last + 0.02 * w) / 1.02; d[i] = last * 3.2; }
    else { b0 = 0.99765 * b0 + w * 0.099046; b1 = 0.963 * b1 + w * 0.2965164; b2 = 0.57 * b2 + w * 1.0526913; d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.11; }
  }
  noiseBuffers[kind] = buf;
  return buf;
}

export const SOUNDS: { id: string; label: string; hint: string }[] = [
  { id: "off", label: "Silence", hint: "No ambient sound" },
  { id: "rain", label: "Rain", hint: "Soft steady rainfall" },
  { id: "brown", label: "Deep Hum", hint: "Brown noise, warm and low" },
  { id: "ocean", label: "Ocean", hint: "Slow rolling waves" },
  { id: "wind", label: "Wind", hint: "Breezy and airy" },
  { id: "fire", label: "Fireplace", hint: "Crackling embers" },
  { id: "white", label: "Static", hint: "White noise masking" },
];

function loop(buf: AudioBuffer, dest: AudioNode, filters: BiquadFilterNode[] = []) {
  const c = ac();
  const src = c.createBufferSource();
  src.buffer = buf; src.loop = true;
  let node: AudioNode = src;
  for (const f of filters) { node.connect(f); node = f; }
  node.connect(dest);
  src.start();
  return src;
}

export function setVolume(v: number) {
  ac();
  if (master) master.gain.setTargetAtTime(Math.max(0, Math.min(1, v)), ac().currentTime, 0.05);
}

export function stopAmbient() {
  current?.stop();
  current = null;
}

export function playAmbient(id: string, volume = 0.5) {
  if (current?.id === id) { setVolume(volume); return; }
  stopAmbient();
  if (id === "off") return;
  const c = ac();
  setVolume(volume);
  const out = c.createGain();
  out.gain.value = 0;
  out.gain.linearRampToValueAtTime(1, c.currentTime + 1.5);
  out.connect(master!);
  const stops: (() => void)[] = [];
  const f = (type: BiquadFilterType, freq: number, q = 0.7) => { const n = c.createBiquadFilter(); n.type = type; n.frequency.value = freq; n.Q.value = q; return n; };
  const lfo = (target: AudioParam, rate: number, depth: number) => {
    const o = c.createOscillator(); const g = c.createGain();
    o.frequency.value = rate; g.gain.value = depth;
    o.connect(g); g.connect(target); o.start(); stops.push(() => o.stop());
  };

  if (id === "rain") {
    const a = loop(noise("white"), out, [f("highpass", 600), f("lowpass", 7000)]);
    const g2 = c.createGain(); g2.gain.value = 0.5; g2.connect(out);
    const b = loop(noise("pink"), g2, [f("bandpass", 1800, 0.5)]);
    stops.push(() => a.stop(), () => b.stop());
  } else if (id === "brown") {
    const a = loop(noise("brown"), out, [f("lowpass", 900)]);
    stops.push(() => a.stop());
  } else if (id === "ocean") {
    const g = c.createGain(); g.gain.value = 0.55; g.connect(out);
    const a = loop(noise("brown"), g, [f("lowpass", 700)]);
    lfo(g.gain, 0.09, 0.4);
    const b = loop(noise("pink"), (() => { const x = c.createGain(); x.gain.value = 0.18; x.connect(out); lfo(x.gain, 0.09, 0.15); return x; })(), [f("bandpass", 2400, 0.4)]);
    stops.push(() => a.stop(), () => b.stop());
  } else if (id === "wind") {
    const bp = f("bandpass", 600, 0.9);
    lfo(bp.frequency, 0.13, 350);
    const a = loop(noise("pink"), out, [bp]);
    stops.push(() => a.stop());
  } else if (id === "fire") {
    const a = loop(noise("brown"), out, [f("lowpass", 420)]);
    stops.push(() => a.stop());
    const crackle = () => {
      const o = c.createBufferSource(); o.buffer = noise("white");
      const g = c.createGain(); const hp = f("highpass", 2200 + Math.random() * 3000);
      const t = c.currentTime;
      g.gain.setValueAtTime(0.25 + Math.random() * 0.4, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.03 + Math.random() * 0.05);
      o.connect(hp); hp.connect(g); g.connect(out); o.start(t, Math.random() * 3, 0.1);
    };
    const iv = window.setInterval(() => { if (Math.random() < 0.8) crackle(); if (Math.random() < 0.3) setTimeout(crackle, 40); }, 180);
    stops.push(() => clearInterval(iv));
  } else {
    const a = loop(noise("white"), out, [f("lowpass", 9000)]);
    stops.push(() => a.stop());
  }

  current = {
    id,
    stop: () => {
      const t = c.currentTime;
      out.gain.cancelScheduledValues(t);
      out.gain.setTargetAtTime(0, t, 0.25);
      setTimeout(() => { stops.forEach((s) => { try { s(); } catch { /* already stopped */ } }); out.disconnect(); }, 900);
    },
  };
}

// ——— One-shot effects ———
function tone(freq: number, start: number, dur: number, type: OscillatorType = "sine", vol = 0.25, slideTo?: number) {
  const c = ac();
  const o = c.createOscillator(); const g = c.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, c.currentTime + start);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, c.currentTime + start + dur);
  g.gain.setValueAtTime(0.0001, c.currentTime + start);
  g.gain.exponentialRampToValueAtTime(vol, c.currentTime + start + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + start + dur);
  o.connect(g); g.connect(c.destination);
  o.start(c.currentTime + start); o.stop(c.currentTime + start + dur + 0.05);
}

export const sfx = {
  chime() { [659, 784, 988, 1319].forEach((f, i) => tone(f, i * 0.16, 0.9, "sine", 0.22)); },
  breakChime() { [988, 784, 659].forEach((f, i) => tone(f, i * 0.18, 0.7, "triangle", 0.2)); },
  click() { tone(520, 0, 0.07, "triangle", 0.12); },
  start() { tone(392, 0, 0.12, "triangle", 0.18); tone(587, 0.09, 0.18, "triangle", 0.18); },
  coin() { tone(988, 0, 0.08, "square", 0.08); tone(1319, 0.07, 0.2, "square", 0.08); },
  hit() { tone(180, 0, 0.18, "sawtooth", 0.2, 60); },
  crit() { tone(240, 0, 0.12, "sawtooth", 0.22, 90); tone(900, 0.04, 0.2, "square", 0.1, 200); },
  miss() { tone(500, 0, 0.18, "sine", 0.1, 250); },
  heal() { [523, 659, 784].forEach((f, i) => tone(f, i * 0.08, 0.3, "sine", 0.16)); },
  win() { [523, 659, 784, 1046, 784, 1046, 1319].forEach((f, i) => tone(f, i * 0.12, 0.35, "triangle", 0.2)); },
  lose() { [392, 330, 262, 196].forEach((f, i) => tone(f, i * 0.2, 0.5, "triangle", 0.18)); },
  levelUp() { [440, 554, 659, 880].forEach((f, i) => tone(f, i * 0.09, 0.4, "square", 0.1)); },
};
