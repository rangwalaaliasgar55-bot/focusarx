import { useSyncExternalStore } from "react";
import { PET_MAP, MAX_LEVEL, xpForLevel, coinBonusForLevel, FEED_COST, ARENA } from "./pets";

// ───────────────────────── Types ─────────────────────────
export type Mode = "focus" | "short" | "long";

export interface OwnedPet {
  id: string; level: number; xp: number; fed: number; joy: number; at: number; nickname?: string; since: number;
}
export interface Session {
  id: string; at: number; minutes: number; planned: number; score: number; task?: string; pet: string; paused: number; early: boolean;
}
export interface Task {
  id: string; title: string; done: boolean; est: number; spent: number; created: number; priority: "low" | "mid" | "high"; doneAt?: number;
}
export interface TimerState {
  mode: Mode; status: "idle" | "running" | "paused"; planned: number; remaining: number;
  endsAt: number | null; pauses: number; cycle: number; taskId: string | null;
}
export interface Daily {
  date: string; focusMin: number; sessions: number; tasksDone: number; wins: number; fed: number; played: number; claimed: string[];
}
export interface Settings {
  focus: number; short: number; long: number; longEvery: number; autoBreak: boolean; face: string;
  sound: string; volume: number; dailyGoal: number; notify: boolean; chime: boolean;
}
export interface State {
  v: 1;
  onboarded: boolean; name: string; coins: number; xp: number; energy: number; lastEnergyAt: number;
  pets: Record<string, OwnedPet>; active: string;
  sessions: Session[]; tasks: Task[];
  streak: { count: number; best: number; last: string; freezes: number };
  checkin: { last: string; day: number };
  daily: Daily;
  achievements: string[];
  chests: { week: string; claimed: boolean };
  arena: { cleared: number; wins: number; losses: number };
  timer: TimerState;
  settings: Settings;
  joined: number;
}

export interface Reward {
  minutes: number; planned: number; score: number; coins: number; xp: number; energy: number; petXp: number;
  petName: string; petId: string; petLevelUp: boolean; petLevel: number; streak: number; early: boolean;
  newAchievements: string[]; accountLevelUp: boolean; accountLevel: number; task?: string; coinBonus: number;
}

// ───────────────────────── Date helpers ─────────────────────────
export const pad = (n: number) => String(n).padStart(2, "0");
export const dateKey = (t: number | Date = Date.now()) => {
  const d = typeof t === "number" ? new Date(t) : t;
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
export const addDays = (key: string, n: number) => {
  const [y, m, d] = key.split("-").map(Number);
  return dateKey(new Date(y, m - 1, d + n, 12));
};
export const weekKey = (t: number = Date.now()) => {
  const d = new Date(t);
  const diff = (d.getDay() + 6) % 7;
  return dateKey(new Date(d.getFullYear(), d.getMonth(), d.getDate() - diff, 12));
};
export const accountLevel = (xp: number) => Math.floor(Math.sqrt(Math.max(0, xp) / 50)) + 1;
export const accountLevelFloor = (lvl: number) => 50 * (lvl - 1) ** 2;
export const uid = () => Math.random().toString(36).slice(2, 10);
export const WEEK_GOAL = 300;

// ───────────────────────── Defaults ─────────────────────────
const defaultSettings: Settings = {
  focus: 25, short: 5, long: 15, longEvery: 4, autoBreak: false, face: "aurora",
  sound: "off", volume: 0.5, dailyGoal: 90, notify: false, chime: true,
};
const blankDaily = (date = dateKey()): Daily => ({
  date, focusMin: 0, sessions: 0, tasksDone: 0, wins: 0, fed: 0, played: 0, claimed: [],
});

export function freshState(): State {
  return {
    v: 1, onboarded: false, name: "", coins: 120, xp: 0, energy: 40, lastEnergyAt: Date.now(),
    pets: {}, active: "",
    sessions: [], tasks: [],
    streak: { count: 0, best: 0, last: "", freezes: 1 },
    checkin: { last: "", day: 0 },
    daily: blankDaily(),
    achievements: [],
    chests: { week: weekKey(), claimed: false },
    arena: { cleared: 0, wins: 0, losses: 0 },
    timer: { mode: "focus", status: "idle", planned: 25 * 60000, remaining: 25 * 60000, endsAt: null, pauses: 0, cycle: 1, taskId: null },
    settings: defaultSettings,
    joined: Date.now(),
  };
}

const KEY = "focusarx.v1";
function load(): State {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const s = JSON.parse(raw) as State;
      const base = freshState();
      const merged: State = { ...base, ...s, settings: { ...base.settings, ...s.settings }, timer: { ...base.timer, ...s.timer } };
      return rollover(merged);
    }
  } catch { /* ignore */ }
  return freshState();
}

function rollover(s: State): State {
  const today = dateKey();
  if (s.daily.date !== today) s.daily = blankDaily(today);
  const wk = weekKey();
  if (s.chests.week !== wk) s.chests = { week: wk, claimed: false };
  return s;
}

// ───────────────────────── Store ─────────────────────────
let state: State = load();
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());
const subscribe = (l: () => void) => { listeners.add(l); return () => { listeners.delete(l); }; };
const persist = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* quota */ } };

export function mutate(fn: (s: State) => void) {
  const next = structuredClone(state);
  rollover(next);
  fn(next);
  state = next;
  persist();
  emit();
}
export const getState = () => state;
export function useStore(): State { return useSyncExternalStore(subscribe, () => state); }

// ───────────────────────── UI store (ephemeral) ─────────────────────────
export interface Toast { id: string; text: string; tone: "ok" | "warn" | "info" | "coin" }
interface UI { result: Reward | null; toasts: Toast[]; checkinOpen: boolean }
let ui: UI = { result: null, toasts: [], checkinOpen: false };
const uiListeners = new Set<() => void>();
const uiSub = (l: () => void) => { uiListeners.add(l); return () => { uiListeners.delete(l); }; };
const setUi = (patch: Partial<UI>) => { ui = { ...ui, ...patch }; uiListeners.forEach((l) => l()); };
export const useUI = () => useSyncExternalStore(uiSub, () => ui);
export const closeResult = () => setUi({ result: null });
export const setCheckinOpen = (open: boolean) => setUi({ checkinOpen: open });
export function toast(text: string, tone: Toast["tone"] = "ok") {
  const t: Toast = { id: uid(), text, tone };
  setUi({ toasts: [...ui.toasts, t].slice(-4) });
  setTimeout(() => setUi({ toasts: ui.toasts.filter((x) => x.id !== t.id) }), 3200);
}

// ───────────────────────── Derived ─────────────────────────
export const todayKey = () => dateKey();

export function petStatus(p: OwnedPet, now = Date.now()) {
  const h = Math.max(0, (now - p.at) / 3600000);
  return {
    fed: Math.max(0, Math.round(p.fed - h * 2.4)),
    joy: Math.max(0, Math.round(p.joy - h * 1.8)),
  };
}
export function petMood(p: OwnedPet | undefined, now = Date.now()) {
  if (!p) return { label: "Away", tone: "mute" as const, bonus: 0, fed: 0, joy: 0 };
  const { fed, joy } = petStatus(p, now);
  const avg = (fed + joy) / 2;
  if (avg >= 70) return { label: "Thriving", tone: "mint" as const, bonus: 0.2, fed, joy };
  if (avg >= 40) return { label: "Content", tone: "gold" as const, bonus: 0.08, fed, joy };
  if (avg >= 15) return { label: "Lonely", tone: "ember" as const, bonus: 0, fed, joy };
  return { label: "Missing you", tone: "rose" as const, bonus: 0, fed, joy };
}

export function effectiveStreak(s: State) {
  const today = dateKey();
  const { last, count, freezes } = s.streak;
  if (!last) return { count: 0, atRisk: false, usedFreeze: false };
  if (last === today) return { count, atRisk: false, usedFreeze: false };
  if (last === addDays(today, -1)) return { count, atRisk: true, usedFreeze: false };
  if (last === addDays(today, -2) && freezes > 0) return { count, atRisk: true, usedFreeze: true };
  return { count: 0, atRisk: false, usedFreeze: false };
}

export const minutesByDay = (s: State) => {
  const m: Record<string, number> = {};
  for (const x of s.sessions) { const k = dateKey(x.at); m[k] = (m[k] ?? 0) + x.minutes; }
  return m;
};
export const totalMinutes = (s: State) => s.sessions.reduce((a, x) => a + x.minutes, 0);
export const weekMinutes = (s: State) => {
  const wk = weekKey();
  return s.sessions.filter((x) => weekKey(x.at) === wk).reduce((a, x) => a + x.minutes, 0);
};

// ───────────────────────── Pet helpers ─────────────────────────
function addPetXp(p: OwnedPet, xp: number) {
  let up = false;
  p.xp += xp;
  while (p.level < MAX_LEVEL && p.xp >= xpForLevel(p.level)) {
    p.xp -= xpForLevel(p.level);
    p.level++;
    up = true;
  }
  if (p.level >= MAX_LEVEL) p.xp = Math.min(p.xp, xpForLevel(MAX_LEVEL));
  return up;
}
const newPet = (id: string): OwnedPet => ({ id, level: 1, xp: 0, fed: 70, joy: 70, at: Date.now(), since: Date.now() });

// ───────────────────────── Achievements ─────────────────────────
export interface Achievement {
  id: string; title: string; desc: string; coins: number; check: (s: State) => boolean; progress?: (s: State) => [number, number];
}
const hours = (s: State) => totalMinutes(s) / 60;
export const ACHIEVEMENTS: Achievement[] = [
  { id: "first", title: "First Spark", desc: "Complete your first focus session", coins: 30, check: (s) => s.sessions.length >= 1, progress: (s) => [Math.min(1, s.sessions.length), 1] },
  { id: "ten", title: "Getting Warm", desc: "Complete 10 sessions", coins: 80, check: (s) => s.sessions.length >= 10, progress: (s) => [Math.min(10, s.sessions.length), 10] },
  { id: "fifty", title: "In the Groove", desc: "Complete 50 sessions", coins: 300, check: (s) => s.sessions.length >= 50, progress: (s) => [Math.min(50, s.sessions.length), 50] },
  { id: "h10", title: "Ten Hour Club", desc: "Focus for 10 hours in total", coins: 150, check: (s) => hours(s) >= 10, progress: (s) => [Math.min(10, Math.floor(hours(s))), 10] },
  { id: "h50", title: "Deep Diver", desc: "Focus for 50 hours in total", coins: 600, check: (s) => hours(s) >= 50, progress: (s) => [Math.min(50, Math.floor(hours(s))), 50] },
  { id: "streak3", title: "Three in a Row", desc: "Reach a 3-day streak", coins: 60, check: (s) => s.streak.best >= 3, progress: (s) => [Math.min(3, s.streak.best), 3] },
  { id: "streak7", title: "Full Week", desc: "Reach a 7-day streak", coins: 200, check: (s) => s.streak.best >= 7, progress: (s) => [Math.min(7, s.streak.best), 7] },
  { id: "streak30", title: "Unbreakable", desc: "Reach a 30-day streak", coins: 1000, check: (s) => s.streak.best >= 30, progress: (s) => [Math.min(30, s.streak.best), 30] },
  { id: "pets3", title: "Small Zoo", desc: "Own 3 companions", coins: 80, check: (s) => Object.keys(s.pets).length >= 3, progress: (s) => [Math.min(3, Object.keys(s.pets).length), 3] },
  { id: "pets10", title: "Collector", desc: "Own 10 companions", coins: 400, check: (s) => Object.keys(s.pets).length >= 10, progress: (s) => [Math.min(10, Object.keys(s.pets).length), 10] },
  { id: "legend", title: "Legend Bound", desc: "Own a legendary companion", coins: 300, check: (s) => Object.keys(s.pets).some((id) => PET_MAP[id]?.rarity === "legendary") },
  { id: "bond10", title: "Best Friends", desc: "Reach bond level 10 with any pet", coins: 250, check: (s) => Object.values(s.pets).some((p) => p.level >= 10), progress: (s) => [Math.min(10, Math.max(0, ...Object.values(s.pets).map((p) => p.level))), 10] },
  { id: "win5", title: "Arena Regular", desc: "Win 5 arena battles", coins: 120, check: (s) => s.arena.wins >= 5, progress: (s) => [Math.min(5, s.arena.wins), 5] },
  { id: "win25", title: "Arena Veteran", desc: "Win 25 arena battles", coins: 500, check: (s) => s.arena.wins >= 25, progress: (s) => [Math.min(25, s.arena.wins), 25] },
  { id: "mythic", title: "Mythic Champion", desc: "Clear the Mythic Cup", coins: 800, check: (s) => s.arena.cleared >= ARENA.length },
  { id: "long", title: "Marathon", desc: "Complete a single session of 60+ minutes", coins: 200, check: (s) => s.sessions.some((x) => x.minutes >= 60 && !x.early) },
  { id: "owl", title: "Night Owl", desc: "Finish a session after 10 p.m.", coins: 50, check: (s) => s.sessions.some((x) => new Date(x.at).getHours() >= 22) },
  { id: "lark", title: "Early Bird", desc: "Finish a session before 7 a.m.", coins: 50, check: (s) => s.sessions.some((x) => new Date(x.at).getHours() < 7) },
  { id: "tasks20", title: "Task Slayer", desc: "Complete 20 tasks", coins: 150, check: (s) => s.tasks.filter((t) => t.done).length >= 20, progress: (s) => [Math.min(20, s.tasks.filter((t) => t.done).length), 20] },
];

function unlockAchievements(s: State): string[] {
  const out: string[] = [];
  for (const a of ACHIEVEMENTS) if (!s.achievements.includes(a.id) && a.check(s)) { s.achievements.push(a.id); s.coins += a.coins; out.push(a.title); }
  return out;
}

// ───────────────────────── Missions ─────────────────────────
export interface Mission { id: string; title: string; desc: string; coins: number; energy: number; goal: number; value: (d: Daily) => number }
export const MISSIONS: Mission[] = [
  { id: "m-25", title: "Warm-up", desc: "Focus for 25 minutes today", coins: 30, energy: 5, goal: 25, value: (d) => d.focusMin },
  { id: "m-2s", title: "Double Down", desc: "Complete 2 focus sessions", coins: 40, energy: 8, goal: 2, value: (d) => d.sessions },
  { id: "m-60", title: "Deep Dive", desc: "Focus for 60 minutes today", coins: 80, energy: 10, goal: 60, value: (d) => d.focusMin },
  { id: "m-t", title: "Clear the Deck", desc: "Finish 2 tasks", coins: 30, energy: 5, goal: 2, value: (d) => d.tasksDone },
  { id: "m-care", title: "Pet Parent", desc: "Feed and play with your companion", coins: 25, energy: 5, goal: 2, value: (d) => Math.min(1, d.fed) + Math.min(1, d.played) },
  { id: "m-win", title: "Arena Rookie", desc: "Win a battle in the Arena", coins: 50, energy: 0, goal: 1, value: (d) => d.wins },
];

export const CHECKIN_REWARDS: { label: string; coins: number; energy: number; freeze?: boolean }[] = [
  { label: "20 coins", coins: 20, energy: 0 },
  { label: "30 coins", coins: 30, energy: 0 },
  { label: "20 energy", coins: 0, energy: 20 },
  { label: "50 coins", coins: 50, energy: 0 },
  { label: "40 energy", coins: 0, energy: 40 },
  { label: "80 coins", coins: 80, energy: 0 },
  { label: "Streak freeze + 150", coins: 150, energy: 0, freeze: true },
];

// ───────────────────────── Actions ─────────────────────────
export const actions = {
  finishOnboarding(name: string, starter: string, goal: number) {
    mutate((s) => {
      s.onboarded = true; s.name = name.trim() || "Focuser";
      s.pets[starter] = newPet(starter); s.active = starter;
      s.settings.dailyGoal = goal;
      s.coins += 100;
    });
  },
  updateSettings(patch: Partial<Settings>) {
    mutate((s) => {
      s.settings = { ...s.settings, ...patch };
      if (s.timer.status === "idle") {
        const ms = (s.timer.mode === "focus" ? s.settings.focus : s.timer.mode === "short" ? s.settings.short : s.settings.long) * 60000;
        s.timer.planned = ms; s.timer.remaining = ms;
      }
    });
  },
  rename(name: string) { mutate((s) => { s.name = name; }); },

  // ——— Timer ———
  setMode(mode: Mode) {
    mutate((s) => {
      const min = mode === "focus" ? s.settings.focus : mode === "short" ? s.settings.short : s.settings.long;
      s.timer = { ...s.timer, mode, status: "idle", planned: min * 60000, remaining: min * 60000, endsAt: null, pauses: 0 };
    });
  },
  setMinutes(min: number) {
    mutate((s) => {
      const m = Math.max(1, Math.min(180, Math.round(min)));
      if (s.timer.mode === "focus") s.settings.focus = m; else if (s.timer.mode === "short") s.settings.short = m; else s.settings.long = m;
      if (s.timer.status === "idle") { s.timer.planned = m * 60000; s.timer.remaining = m * 60000; }
    });
  },
  start() {
    mutate((s) => {
      if (s.timer.status === "running") return;
      s.timer.status = "running";
      s.timer.endsAt = Date.now() + s.timer.remaining;
    });
  },
  pause() {
    mutate((s) => {
      if (s.timer.status !== "running" || !s.timer.endsAt) return;
      s.timer.remaining = Math.max(0, s.timer.endsAt - Date.now());
      s.timer.status = "paused"; s.timer.endsAt = null; s.timer.pauses += 1;
    });
  },
  resetTimer() {
    mutate((s) => {
      const t = s.timer;
      const min = t.mode === "focus" ? s.settings.focus : t.mode === "short" ? s.settings.short : s.settings.long;
      s.timer = { ...t, status: "idle", planned: min * 60000, remaining: min * 60000, endsAt: null, pauses: 0 };
    });
  },
  setTask(id: string | null) { mutate((s) => { s.timer.taskId = id; }); },

  /** Called when the clock hits zero, or when the user ends a focus session early. */
  completeTimer(early = false): Reward | null {
    let reward: Reward | null = null;
    mutate((s) => {
      const t = s.timer;
      const now = Date.now();
      if (t.mode !== "focus") {
        // break finished → back to focus
        const cycle = t.mode === "long" ? 1 : t.cycle;
        const ms = s.settings.focus * 60000;
        s.timer = { ...t, mode: "focus", status: s.settings.autoBreak && !early ? "running" : "idle", planned: ms, remaining: ms, endsAt: s.settings.autoBreak && !early ? now + ms : null, pauses: 0, cycle };
        return;
      }
      const remaining = t.status === "running" && t.endsAt ? Math.max(0, t.endsAt - now) : t.remaining;
      const doneMs = early ? t.planned - remaining : t.planned;
      const minutes = Math.max(0, Math.round(doneMs / 60000));
      const planned = Math.round(t.planned / 60000);
      const nextMode: Mode = t.cycle % s.settings.longEvery === 0 ? "long" : "short";
      const nextMin = nextMode === "long" ? s.settings.long : s.settings.short;
      const resetNext = () => {
        s.timer = {
          ...t, mode: nextMode, status: s.settings.autoBreak && !early ? "running" : "idle", planned: nextMin * 60000, remaining: nextMin * 60000,
          endsAt: s.settings.autoBreak && !early ? now + nextMin * 60000 : null, pauses: 0, cycle: early ? t.cycle : t.cycle + 1,
        };
      };
      if (minutes < 1) { resetNext(); if (early) s.timer = { ...s.timer, mode: "focus", planned: s.settings.focus * 60000, remaining: s.settings.focus * 60000, status: "idle", endsAt: null, cycle: t.cycle }; return; }

      // score
      const ratio = Math.min(1, minutes / Math.max(1, planned));
      const score = Math.max(10, Math.round(ratio * 75 + Math.max(0, 25 - t.pauses * 8) * (early ? 0.4 : 1)));

      // streak (≥5 min counts)
      const today = dateKey(now);
      if (minutes >= 5) {
        const es = effectiveStreak(s);
        if (s.streak.last !== today) {
          if (es.usedFreeze) s.streak.freezes -= 1;
          s.streak.count = es.count + 1;
          s.streak.last = today;
          s.streak.best = Math.max(s.streak.best, s.streak.count);
        }
      }

      const pet = s.pets[s.active];
      const mood = petMood(pet, now);
      const lvlBonus = pet ? coinBonusForLevel(pet.level) : 0;
      const streakBonus = Math.min(s.streak.count, 10) * 0.02;
      const bonus = mood.bonus + lvlBonus + streakBonus;
      const coins = Math.round(minutes * 1.2 * (0.6 + (score / 100) * 0.4) * (1 + bonus));
      const xp = Math.round(minutes * 2 * (score / 100 + 0.5));
      const energy = Math.min(minutes, 60);
      const petXp = minutes * 2;

      const oldLvl = accountLevel(s.xp);
      s.coins += coins; s.xp += xp;
      s.energy = Math.min(100, s.energy + energy);
      let petLevelUp = false;
      if (pet) { petLevelUp = addPetXp(pet, petXp); pet.joy = Math.min(100, petStatus(pet, now).joy + 6); pet.fed = petStatus(pet, now).fed; pet.at = now; }

      const task = t.taskId ? s.tasks.find((x) => x.id === t.taskId) : undefined;
      if (task) task.spent += 1;

      s.sessions.push({ id: uid(), at: now, minutes, planned, score, task: task?.title, pet: s.active, paused: t.pauses, early });
      if (s.sessions.length > 1500) s.sessions = s.sessions.slice(-1500);
      s.daily.focusMin += minutes; s.daily.sessions += 1;

      const newAch = unlockAchievements(s);
      const newLvl = accountLevel(s.xp);
      reward = {
        minutes, planned, score, coins, xp, energy, petXp, petName: pet ? (pet.nickname ?? PET_MAP[pet.id].name) : "", petId: s.active, petLevelUp,
        petLevel: pet?.level ?? 1, streak: s.streak.count, early, newAchievements: newAch, accountLevelUp: newLvl > oldLvl, accountLevel: newLvl,
        task: task?.title, coinBonus: Math.round(bonus * 100),
      };
      resetNext();
      if (early) s.timer = { ...s.timer, mode: "focus", planned: s.settings.focus * 60000, remaining: s.settings.focus * 60000, status: "idle", endsAt: null, cycle: t.cycle };
    });
    if (reward) setUi({ result: reward });
    return reward;
  },

  // ——— Tasks ———
  addTask(title: string, est = 1, priority: Task["priority"] = "mid") {
    if (!title.trim()) return;
    mutate((s) => { s.tasks.unshift({ id: uid(), title: title.trim(), done: false, est, spent: 0, created: Date.now(), priority }); });
  },
  toggleTask(id: string) {
    let done = false;
    mutate((s) => {
      const t = s.tasks.find((x) => x.id === id);
      if (!t) return;
      t.done = !t.done; t.doneAt = t.done ? Date.now() : undefined;
      if (t.done) { s.daily.tasksDone += 1; s.coins += 5; s.xp += 10; done = true; if (s.timer.taskId === id) s.timer.taskId = null; unlockAchievements(s); }
    });
    if (done) toast("Task done · +5 coins", "coin");
  },
  removeTask(id: string) { mutate((s) => { s.tasks = s.tasks.filter((x) => x.id !== id); if (s.timer.taskId === id) s.timer.taskId = null; }); },

  // ——— Pets ———
  buyPet(id: string): boolean {
    let ok = false;
    mutate((s) => {
      const def = PET_MAP[id];
      if (!def || s.pets[id] || s.coins < def.price) return;
      s.coins -= def.price; s.pets[id] = newPet(id); ok = true;
      if (!s.active) s.active = id;
      unlockAchievements(s);
    });
    return ok;
  },
  setActive(id: string) { mutate((s) => { if (s.pets[id]) s.active = id; }); },
  nickname(id: string, name: string) { mutate((s) => { if (s.pets[id]) s.pets[id].nickname = name.trim().slice(0, 14) || undefined; }); },
  feed(id: string): boolean {
    let ok = false;
    mutate((s) => {
      const p = s.pets[id];
      if (!p || s.coins < FEED_COST) return;
      const st = petStatus(p);
      s.coins -= FEED_COST;
      p.fed = Math.min(100, st.fed + 35); p.joy = st.joy; p.at = Date.now();
      addPetXp(p, 15); s.daily.fed += 1; ok = true;
    });
    return ok;
  },
  play(id: string) {
    mutate((s) => {
      const p = s.pets[id];
      if (!p) return;
      const st = petStatus(p);
      p.joy = Math.min(100, st.joy + 18); p.fed = st.fed; p.at = Date.now();
      addPetXp(p, 6); s.daily.played += 1;
    });
  },
  tapPet(id: string) {
    mutate((s) => {
      const p = s.pets[id];
      if (!p) return;
      const st = petStatus(p);
      p.joy = Math.min(100, st.joy + 1); p.fed = st.fed; p.at = Date.now();
    });
  },

  // ——— Retention ———
  claimCheckin() {
    mutate((s) => {
      const today = dateKey();
      if (s.checkin.last === today) return;
      const consecutive = s.checkin.last === addDays(today, -1);
      const day = consecutive ? (s.checkin.day % 7) : 0;
      const r = CHECKIN_REWARDS[day];
      s.coins += r.coins; s.energy = Math.min(100, s.energy + r.energy);
      if (r.freeze) s.streak.freezes += 1;
      s.checkin = { last: today, day: day + 1 };
    });
  },
  claimMission(id: string) {
    mutate((s) => {
      const m = MISSIONS.find((x) => x.id === id);
      if (!m || s.daily.claimed.includes(id) || m.value(s.daily) < m.goal) return;
      s.daily.claimed.push(id); s.coins += m.coins; s.energy = Math.min(100, s.energy + m.energy);
    });
  },
  claimChest() {
    mutate((s) => {
      if (s.chests.claimed || weekMinutes(s) < WEEK_GOAL) return;
      s.chests.claimed = true; s.coins += 250; s.streak.freezes += 1;
    });
  },
  buyFreeze() {
    let ok = false;
    mutate((s) => { if (s.coins >= 150 && s.streak.freezes < 3) { s.coins -= 150; s.streak.freezes += 1; ok = true; } });
    return ok;
  },

  // ——— Arena ———
  spendEnergy(n: number): boolean {
    let ok = false;
    mutate((s) => { if (s.energy >= n) { s.energy -= n; ok = true; } });
    return ok;
  },
  battleResult(stageId: number, win: boolean, petId: string) {
    mutate((s) => {
      const stage = ARENA.find((a) => a.id === stageId);
      if (!stage) return;
      if (win) {
        s.arena.wins += 1; s.daily.wins += 1;
        s.arena.cleared = Math.max(s.arena.cleared, stageId);
        const first = s.arena.cleared === stageId && !s.achievements.includes(`stage-${stageId}`);
        s.coins += stage.coins + (first ? stage.coins : 0); s.xp += stage.xp;
        if (first) s.achievements.push(`stage-${stageId}`);
        const p = s.pets[petId];
        if (p) addPetXp(p, stage.xp);
        unlockAchievements(s);
      } else {
        s.arena.losses += 1;
        s.coins += 8;
        const p = s.pets[petId];
        if (p) addPetXp(p, 8);
      }
    });
  },

  // ——— Data ———
  loadDemo() {
    mutate((s) => {
      const now = Date.now();
      const sess: Session[] = [];
      const ids = Object.keys(s.pets);
      for (let d = 34; d >= 0; d--) {
        const skip = (d * 7 + 3) % 5 === 0;
        if (skip && d !== 0) continue;
        const n = 1 + ((d * 5) % 4);
        for (let i = 0; i < n; i++) {
          const hour = [8, 10, 14, 16, 20, 21][(d + i * 2) % 6];
          const at = new Date(now - d * 86400000); at.setHours(hour, 10 + i * 7, 0, 0);
          if (at.getTime() > now) continue;
          const planned = [25, 25, 45, 50, 25, 30][(d + i) % 6];
          sess.push({ id: uid(), at: at.getTime(), minutes: planned, planned, score: 70 + ((d * 13 + i * 7) % 30), pet: s.active || ids[0] || "mochi", paused: i % 3 === 0 ? 1 : 0, early: false });
        }
      }
      s.sessions = sess;
      let streak = 0; const today = dateKey();
      const days = new Set(sess.map((x) => dateKey(x.at)));
      for (let d = 0; d < 40; d++) { if (days.has(addDays(today, -d))) streak++; else break; }
      s.streak.count = streak; s.streak.best = Math.max(streak, 9); s.streak.last = days.has(today) ? today : s.streak.last;
      s.xp = Math.max(s.xp, sess.reduce((a, x) => a + x.minutes, 0) * 2);
      s.coins += 400;
      s.daily.focusMin = sess.filter((x) => dateKey(x.at) === today).reduce((a, x) => a + x.minutes, 0);
      s.daily.sessions = sess.filter((x) => dateKey(x.at) === today).length;
    });
  },
  resetAll() {
    state = freshState();
    persist();
    emit();
  },
};
