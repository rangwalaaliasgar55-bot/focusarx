import { useMemo } from "react";
import { ArrowRight, Check, Coins, Flame, Gift, Play, ShieldCheck, Swords, Trophy, Zap, Clock, Sparkles } from "lucide-react";
import Pet3D from "../components/three/Pet3D";
import { Bar, Btn, Card, Eyebrow, Ring, fmtMin } from "../components/ui";
import {
  MISSIONS, WEEK_GOAL, accountLevel, accountLevelFloor, actions, addDays, dateKey, effectiveStreak, minutesByDay, petMood,
  setCheckinOpen, todayKey, useStore, weekMinutes, toast,
} from "../lib/store";
import { PET_MAP } from "../lib/pets";
import { go } from "../lib/router";
import { cn } from "../utils/cn";
import { sfx } from "../lib/audio";

function greeting() {
  const h = new Date().getHours();
  return h < 5 ? "Burning the midnight oil" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

export default function Dashboard() {
  const s = useStore();
  const st = effectiveStreak(s);
  const lvl = accountLevel(s.xp);
  const floor = accountLevelFloor(lvl), next = accountLevelFloor(lvl + 1);
  const pet = s.pets[s.active] ? PET_MAP[s.active] : null;
  const owned = s.pets[s.active];
  const mood = petMood(owned);
  const today = s.daily.focusMin;
  const goal = s.settings.dailyGoal;
  const byDay = useMemo(() => minutesByDay(s), [s.sessions]); // eslint-disable-line
  const week = useMemo(() => {
    const t = todayKey();
    return Array.from({ length: 7 }, (_, i) => { const k = addDays(t, i - 6); const d = new Date(k + "T12:00:00"); return { k, min: byDay[k] ?? 0, label: d.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 1), today: k === t }; });
  }, [byDay]);
  const maxDay = Math.max(60, ...week.map((w) => w.min));
  const wMin = weekMinutes(s);
  const canCheckin = s.checkin.last !== todayKey();
  const openTasks = s.tasks.filter((t) => !t.done).slice(0, 4);
  const recent = [...s.sessions].reverse().slice(0, 5);
  const missions = MISSIONS.slice(0, 4);
  const claimable = MISSIONS.filter((m) => m.value(s.daily) >= m.goal && !s.daily.claimed.includes(m.id)).length;

  const nudge = st.atRisk
    ? `Your ${st.count}-day streak ends tonight. One short session keeps it alive${st.usedFreeze ? " (a streak freeze will cover yesterday)" : ""}.`
    : today === 0 ? "Nothing logged yet today. A single 25-minute block is a great start." : today >= goal ? "Daily goal smashed. Anything extra is bonus XP." : `${goal - today} more minutes to hit today's goal.`;

  const quick = (m: number) => { actions.setMode("focus"); actions.setMinutes(m); go("/focus"); };

  return (
    <div className="mx-auto max-w-6xl px-4 pb-32 pt-8 sm:px-8 lg:pb-16">
      <div className="mb-8">
        <Eyebrow className="mb-2 text-ember">{greeting()}</Eyebrow>
        <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">{s.name || "Focuser"}, <span className="text-mute">ready to focus?</span></h1>
        <p className="mt-3 max-w-2xl text-[15px] text-mute">{nudge}</p>
      </div>

      {canCheckin && (
        <button onClick={() => setCheckinOpen(true)} className="group mb-6 flex w-full items-center gap-4 rounded-2xl border border-ember/30 bg-gradient-to-r from-ember/15 to-transparent p-4 text-left transition hover:border-ember/60 cursor-pointer">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-ember text-ink-950"><Gift size={20} /></span>
          <span className="flex-1"><span className="block font-bold">Your daily reward is waiting</span><span className="text-sm text-mute">Day {(s.checkin.day % 7) + 1} of 7 — keep the chain going for a streak freeze.</span></span>
          <ArrowRight size={18} className="text-ember transition group-hover:translate-x-1" />
        </button>
      )}

      <div className="grid gap-5 lg:grid-cols-[1.25fr_1fr]">
        {/* Today */}
        <Card className="relative overflow-hidden p-6 sm:p-8">
          <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-ember/10 blur-3xl" />
          <div className="relative flex flex-wrap items-center gap-8">
            <Ring value={today / goal} size={168} stroke={12} color="var(--color-ember)">
              <div className="text-center"><div className="font-display text-4xl font-extrabold tabular leading-none">{fmtMin(today)}</div><div className="mt-1 text-xs text-mute">of {fmtMin(goal)}</div></div>
            </Ring>
            <div className="min-w-[220px] flex-1">
              <Eyebrow>Today</Eyebrow>
              <div className="mb-4 mt-1 font-display text-2xl font-bold">{today >= goal ? "Goal complete" : "Start a session"}</div>
              <Btn size="lg" className="w-full" onClick={() => { actions.setMode("focus"); go("/focus"); }}><Play size={18} fill="currentColor" /> Open timer</Btn>
              <div className="mt-3 flex gap-2">
                {[15, 25, 45].map((m) => <button key={m} onClick={() => quick(m)} className="h-9 flex-1 rounded-lg bg-white/6 text-[13px] font-semibold text-mute transition hover:bg-white/12 hover:text-bone cursor-pointer">{m}m</button>)}
              </div>
            </div>
          </div>
          <div className="relative mt-8 flex items-end justify-between gap-2">
            {week.map((w) => (
              <div key={w.k} className="flex flex-1 flex-col items-center gap-2">
                <div className="flex h-20 w-full items-end justify-center">
                  <div className={cn("w-full max-w-[34px] rounded-lg transition-all duration-700", w.today ? "bg-ember" : w.min ? "bg-white/25" : "bg-white/7")} style={{ height: `${Math.max(6, (w.min / maxDay) * 100)}%` }} title={`${w.min} min`} />
                </div>
                <span className={cn("text-[11px] font-semibold", w.today ? "text-ember" : "text-dim")}>{w.label}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Companion */}
        <Card className="relative overflow-hidden p-0">
          <div className="relative h-[330px]" style={{ background: "radial-gradient(ellipse at 50% 70%, rgba(255,122,69,0.2), transparent 65%)" }}>
            {pet && <Pet3D pet={pet} stage={false} className="h-full w-full" mood={mood.joy > 60 ? "happy" : "idle"} onTap={() => { if (owned) actions.tapPet(owned.id); }} aura={owned?.level === 20} />}
            <div className="pointer-events-none absolute left-5 top-4 text-[11px] font-semibold uppercase tracking-[0.16em] text-dim">Your companion</div>
          </div>
          <div className="border-t border-white/6 p-5">
            <div className="flex items-center justify-between">
              <div><div className="font-display text-xl font-bold">{owned?.nickname ?? pet?.name}</div><div className="text-sm text-mute">Bond Lv {owned?.level} · <span className={cn(mood.tone === "mint" ? "text-mint" : mood.tone === "gold" ? "text-gold" : mood.tone === "rose" ? "text-rose" : "text-ember")}>{mood.label}</span></div></div>
              <Btn variant="soft" size="sm" onClick={() => go("/pets")}>Visit</Btn>
            </div>
            {mood.fed < 40 || mood.joy < 40 ? (
              <div className="mt-4 flex items-center justify-between gap-3 rounded-xl bg-rose/10 p-3 text-sm text-rose">
                <span>{owned?.nickname ?? pet?.name} is {mood.fed < mood.joy ? "hungry" : "lonely"}.</span>
                <Btn size="sm" variant="danger" onClick={() => { if (mood.fed < mood.joy) { if (actions.feed(s.active)) { sfx.coin(); toast("Fed! Yum."); } else toast("Not enough coins", "warn"); } else { actions.play(s.active); toast("Played together!"); } }}>{mood.fed < mood.joy ? "Feed" : "Play"}</Btn>
              </div>
            ) : (
              <div className="mt-4 grid grid-cols-2 gap-4 text-[11px] text-mute">
                <div><div className="mb-1 flex justify-between"><span>Fed</span><span>{mood.fed}</span></div><Bar value={mood.fed} color="var(--color-gold)" h={5} /></div>
                <div><div className="mb-1 flex justify-between"><span>Joy</span><span>{mood.joy}</span></div><Bar value={mood.joy} color="var(--color-mint)" h={5} /></div>
              </div>
            )}
          </div>
        </Card>
      </div>

      {/* Stat row */}
      <div className="mt-5 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="p-5">
          <div className="flex items-center gap-2 text-sm text-mute"><Flame size={16} className="text-ember" /> Streak</div>
          <div className="mt-2 font-display text-4xl font-extrabold tabular">{st.count}<span className="ml-1 text-base font-semibold text-dim">days</span></div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-mute"><ShieldCheck size={13} className="text-sky" /> {s.streak.freezes} freeze{s.streak.freezes === 1 ? "" : "s"} · best {s.streak.best}</div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 text-sm text-mute"><Clock size={16} className="text-mint" /> This week</div>
          <div className="mt-2 font-display text-4xl font-extrabold tabular">{fmtMin(wMin)}</div>
          <Bar value={wMin} max={WEEK_GOAL} color="var(--color-mint)" className="mt-3" h={6} />
          <div className="mt-1.5 text-xs text-mute">{wMin >= WEEK_GOAL ? (s.chests.claimed ? "Weekly chest opened" : "Chest ready!") : `${WEEK_GOAL - wMin} min to the weekly chest`}</div>
          {wMin >= WEEK_GOAL && !s.chests.claimed && <Btn size="sm" className="mt-2 w-full" onClick={() => { actions.claimChest(); sfx.win(); toast("+250 coins and a streak freeze", "coin"); }}><Gift size={14} /> Open chest</Btn>}
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 text-sm text-mute"><Sparkles size={16} className="text-violet" /> Level</div>
          <div className="mt-2 font-display text-4xl font-extrabold tabular">{lvl}</div>
          <Bar value={s.xp - floor} max={next - floor} color="var(--color-violet)" className="mt-3" h={6} />
          <div className="mt-1.5 text-xs text-mute">{next - s.xp} XP to level {lvl + 1}</div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-2 text-sm text-mute"><Coins size={16} className="text-gold" /> Wallet</div>
          <div className="mt-2 font-display text-4xl font-extrabold tabular">{s.coins.toLocaleString()}</div>
          <div className="mt-2 flex items-center gap-1.5 text-xs text-mute"><Zap size={13} className="text-mint" /> {s.energy} arena energy</div>
        </Card>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-3">
        {/* Missions */}
        <Card className="lg:col-span-1">
          <div className="mb-4 flex items-center justify-between"><Eyebrow>Daily missions</Eyebrow>{claimable > 0 && <span className="rounded-full bg-ember px-2 py-0.5 text-[10px] font-bold text-ink-950">{claimable} ready</span>}</div>
          <div className="flex flex-col gap-3">
            {missions.map((m) => {
              const v = Math.min(m.goal, m.value(s.daily)); const done = v >= m.goal; const claimed = s.daily.claimed.includes(m.id);
              return (
                <div key={m.id} className="flex items-center gap-3">
                  <div className={cn("grid h-9 w-9 shrink-0 place-items-center rounded-xl", claimed ? "bg-mint text-ink-950" : done ? "bg-ember text-ink-950" : "bg-white/6 text-dim")}>{claimed ? <Check size={16} strokeWidth={3} /> : <Trophy size={15} />}</div>
                  <div className="min-w-0 flex-1"><div className="truncate text-sm font-semibold">{m.title}</div><Bar value={v} max={m.goal} h={4} className="mt-1.5" color={claimed ? "var(--color-mint)" : "var(--color-ember)"} /></div>
                  {done && !claimed ? <Btn size="sm" onClick={() => { actions.claimMission(m.id); sfx.coin(); toast(`+${m.coins} coins`, "coin"); }}>Claim</Btn> : <span className="flex w-12 items-center justify-end gap-1 text-xs text-gold"><Coins size={11} />{m.coins}</span>}
                </div>
              );
            })}
          </div>
          <Btn variant="ghost" size="sm" className="mt-4 w-full" onClick={() => go("/missions")}>All missions <ArrowRight size={14} /></Btn>
        </Card>

        {/* Tasks */}
        <Card>
          <div className="mb-4 flex items-center justify-between"><Eyebrow>Up next</Eyebrow><button onClick={() => go("/tasks")} className="text-xs font-semibold text-ember cursor-pointer">Manage</button></div>
          {openTasks.length ? (
            <div className="flex flex-col gap-2">
              {openTasks.map((t) => (
                <div key={t.id} className="flex items-center gap-3 rounded-xl bg-white/3 px-3 py-2.5">
                  <button aria-label="Complete" onClick={() => actions.toggleTask(t.id)} className="grid h-5 w-5 shrink-0 place-items-center rounded-full border border-white/25 transition hover:border-mint hover:bg-mint/20 cursor-pointer" />
                  <span className="min-w-0 flex-1 truncate text-sm">{t.title}</span>
                  <button aria-label="Focus on this" onClick={() => { actions.setTask(t.id); go("/focus"); }} className="text-dim transition hover:text-ember cursor-pointer"><Play size={14} fill="currentColor" /></button>
                </div>
              ))}
            </div>
          ) : (
            <div className="rounded-xl border border-dashed border-white/10 p-6 text-center text-sm text-mute">Nothing queued. <button className="font-semibold text-ember cursor-pointer" onClick={() => go("/tasks")}>Add a task</button> to attach to your next session.</div>
          )}
        </Card>

        {/* Arena + recent */}
        <div className="flex flex-col gap-5">
          <button onClick={() => go("/arena")} className="group relative overflow-hidden rounded-3xl border border-white/10 p-5 text-left transition hover:border-ember/50 cursor-pointer" style={{ background: "linear-gradient(135deg, rgba(79,224,181,0.14), rgba(108,182,255,0.06) 60%, transparent)" }}>
            <div className="flex items-center gap-2 text-sm text-mute"><Swords size={16} className="text-mint" /> Arena</div>
            <div className="mt-2 font-display text-xl font-bold">{s.energy >= 10 ? "Your squad is ready" : "Recharge to battle"}</div>
            <div className="mt-1 text-sm text-mute">{s.arena.wins} wins · Cup {Math.min(s.arena.cleared + 1, 6)} next</div>
            <ArrowRight size={18} className="absolute bottom-5 right-5 text-mint transition group-hover:translate-x-1" />
          </button>
          <Card className="flex-1">
            <Eyebrow className="mb-3">Recent sessions</Eyebrow>
            {recent.length ? recent.map((r) => (
              <div key={r.id} className="flex items-center justify-between border-b border-white/5 py-2 text-sm last:border-0">
                <div className="min-w-0"><div className="truncate font-medium">{r.task ?? "Focus session"}</div><div className="text-xs text-dim">{dateKey(r.at) === todayKey() ? "Today" : new Date(r.at).toLocaleDateString(undefined, { month: "short", day: "numeric" })} · score {r.score}</div></div>
                <span className="font-semibold tabular">{r.minutes}m</span>
              </div>
            )) : <div className="py-3 text-sm text-mute">Your finished sessions will show up here.</div>}
          </Card>
        </div>
      </div>
    </div>
  );
}
