import { useCallback, useEffect, useState } from "react";
import { Play, Pause, RotateCcw, Maximize2, X, Minus, Plus, Palette, Volume2, Flag, SkipForward, Plus as PlusIcon, Check, Heart } from "lucide-react";
import { actions, petMood, useStore, type Mode } from "../lib/store";
import { PET_MAP } from "../lib/pets";
import { cn } from "../utils/cn";
import TimerFace, { ACCENT, FACES, MODE_LABEL } from "../components/faces";
import Pet3D from "../components/three/Pet3D";
import { Bar, Btn, Card, Eyebrow, Modal, Seg } from "../components/ui";
import { SOUNDS, sfx, setVolume } from "../lib/audio";
import { go } from "../lib/router";

function useNow(active: boolean) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!active) { setNow(Date.now()); return; }
    const id = setInterval(() => setNow(Date.now()), 250);
    return () => clearInterval(id);
  }, [active]);
  return now;
}

const FACE_W: Record<string, number> = { hourglass: 96, garden: 96, flip: 190, segment: 210, trail: 230 };

const LINES = {
  idle: ["Ready when you are.", "Pick one thing. Just one.", "We start small, then it snowballs.", "Phone away? Let's go."],
  running: ["Deep breath. You've got this.", "Staying quiet so you can think.", "One minute at a time.", "Look at that streak building."],
  paused: ["Take a moment. I'll wait.", "Back when you're ready.", "No rush. Still counts."],
  brk: ["Stretch! Drink some water.", "Look at something far away.", "Well earned. Rest up."],
};

export default function Focus() {
  const s = useStore();
  const t = s.timer;
  const running = t.status === "running";
  const now = useNow(running);
  const ms = running && t.endsAt ? Math.max(0, t.endsAt - now) : t.remaining;
  const acc = ACCENT[t.mode];
  const pet = s.pets[s.active] ? PET_MAP[s.active] : null;
  const owned = s.pets[s.active];
  const mood = petMood(owned);
  const [zen, setZen] = useState(false);
  const [picker, setPicker] = useState(false);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const [newTask, setNewTask] = useState("");
  const [line, setLine] = useState(0);
  const [bubble, setBubble] = useState<string | null>(null);

  const openTasks = s.tasks.filter((x) => !x.done);
  const task = s.tasks.find((x) => x.id === t.taskId);
  const label = t.mode === "focus" ? (task?.title ?? "") : t.mode === "short" ? "Step away from the screen" : "Take a proper break";
  const elapsedMin = Math.floor((t.planned - ms) / 60000);
  const isBreak = t.mode !== "focus";
  const petMoodState = t.status === "idle" ? "idle" : isBreak ? "happy" : "idle";

  const toggle = useCallback(() => {
    if (running) { actions.pause(); sfx.click(); }
    else {
      actions.start(); sfx.start();
      if (s.settings.notify && "Notification" in window && Notification.permission === "default") void Notification.requestPermission();
    }
  }, [running, s.settings.notify]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT")) return;
      if (e.code === "Space") { e.preventDefault(); toggle(); }
      else if (e.key === "r" || e.key === "R") { actions.resetTimer(); }
      else if (e.key === "f" || e.key === "F") setZen((z) => !z);
      else if (e.key === "1") actions.setMode("focus");
      else if (e.key === "2") actions.setMode("short");
      else if (e.key === "3") actions.setMode("long");
      else if (e.key === "Escape") setZen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle]);

  useEffect(() => { const id = setInterval(() => setLine((l) => l + 1), 9000); return () => clearInterval(id); }, []);

  useEffect(() => {
    if (zen) { document.body.style.overflow = "hidden"; return () => { document.body.style.overflow = ""; }; }
  }, [zen]);

  const lines = t.status === "idle" ? LINES.idle : t.status === "paused" ? LINES.paused : isBreak ? LINES.brk : LINES.running;
  const speech = bubble ?? lines[line % lines.length];
  const dur = Math.round(t.planned / 60000);

  const tap = () => {
    if (!owned) return;
    actions.tapPet(owned.id);
    setBubble(["Hehe, that tickles!", "Focus time, human.", "More pats later!", "I believe in you."][Math.floor(Math.random() * 4)]);
    setTimeout(() => setBubble(null), 2200);
  };

  const faceEl = (
    <TimerFace face={s.settings.face} ms={ms} total={t.planned} running={running} mode={t.mode} petId={s.active} label={label} />
  );

  const controls = (
    <div className="flex items-center justify-center gap-3 sm:gap-4">
      <Btn variant="soft" className="h-12 w-12 rounded-full p-0" onClick={() => { actions.resetTimer(); sfx.click(); }} aria-label="Reset"><RotateCcw size={18} /></Btn>
      <button onClick={toggle} aria-label={running ? "Pause" : "Start"}
        className="group relative grid h-20 w-20 place-items-center rounded-full text-ink-950 transition active:scale-95 cursor-pointer sm:h-24 sm:w-24"
        style={{ background: acc, boxShadow: `0 14px 40px -10px ${acc}, inset 0 -4px 12px rgba(0,0,0,0.15), inset 0 3px 8px rgba(255,255,255,0.35)` }}>
        {running && <span className="absolute inset-0 rounded-full" style={{ boxShadow: `0 0 0 0 ${acc}`, animation: "pulse-soft 2.2s infinite", border: `2px solid ${acc}` }} />}
        {running ? <Pause size={32} fill="currentColor" /> : <Play size={34} fill="currentColor" className="ml-1" />}
      </button>
      {isBreak ? (
        <Btn variant="soft" className="h-12 rounded-full px-5" onClick={() => { actions.completeTimer(true); sfx.click(); }}><SkipForward size={16} /> Skip</Btn>
      ) : (
        <Btn variant="soft" className="h-12 rounded-full px-5" disabled={t.status === "idle"} onClick={() => (elapsedMin >= 1 ? setConfirmEnd(true) : actions.resetTimer())}><Flag size={16} /> Finish</Btn>
      )}
    </div>
  );

  return (
    <div className="mx-auto max-w-[1280px] px-4 pb-32 pt-6 sm:px-8 lg:pb-12">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <Seg<Mode> value={t.mode} onChange={(m) => { actions.setMode(m); }} options={[{ id: "focus", label: "Focus" }, { id: "short", label: "Short break" }, { id: "long", label: "Long break" }]} />
        <div className="flex items-center gap-2">
          <Btn variant="soft" size="sm" onClick={() => setPicker(true)}><Palette size={14} /> {FACES.find((f) => f.id === s.settings.face)?.name}</Btn>
          <Btn variant="soft" size="sm" onClick={() => setZen(true)}><Maximize2 size={14} /> Zen</Btn>
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
        {/* Stage */}
        <div className="relative overflow-hidden rounded-[32px] border border-white/7 px-4 py-10 sm:px-10 sm:py-14" style={{ background: `radial-gradient(ellipse at 50% 0%, ${acc}1c, transparent 60%), linear-gradient(180deg, #13161c, #0e1014)` }}>
          <div className="grain absolute inset-0" />
          <div className="relative">{faceEl}</div>
          <div className="relative mt-8">{controls}</div>

          {t.status === "idle" && !isBreak && (
            <div className="relative mt-8 flex flex-wrap items-center justify-center gap-2">
              {[15, 25, 45, 60, 90].map((m) => (
                <button key={m} onClick={() => actions.setMinutes(m)} className={cn("h-9 rounded-full px-4 text-[13px] font-semibold transition cursor-pointer", dur === m ? "bg-bone text-ink-950" : "bg-white/6 text-mute hover:bg-white/12 hover:text-bone")}>{m} min</button>
              ))}
              <div className="ml-1 flex items-center rounded-full bg-white/6">
                <button aria-label="Less" onClick={() => actions.setMinutes(dur - 5)} className="grid h-9 w-9 place-items-center rounded-full text-mute hover:text-bone cursor-pointer"><Minus size={14} /></button>
                <span className="w-12 text-center text-[13px] font-semibold tabular">{dur}m</span>
                <button aria-label="More" onClick={() => actions.setMinutes(dur + 5)} className="grid h-9 w-9 place-items-center rounded-full text-mute hover:text-bone cursor-pointer"><Plus size={14} /></button>
              </div>
            </div>
          )}
          {t.status === "idle" && isBreak && (
            <div className="relative mt-8 flex items-center justify-center gap-2 text-sm text-mute">
              <Heart size={14} className="text-mint" /> Break time — your pet is recharging too.
            </div>
          )}
          <div className="relative mt-8 hidden text-center text-xs text-dim sm:block">
            <kbd className="rounded bg-white/8 px-1.5 py-0.5 font-mono">Space</kbd> start / pause · <kbd className="rounded bg-white/8 px-1.5 py-0.5 font-mono">R</kbd> reset · <kbd className="rounded bg-white/8 px-1.5 py-0.5 font-mono">F</kbd> zen · <kbd className="rounded bg-white/8 px-1.5 py-0.5 font-mono">1 2 3</kbd> modes
          </div>
        </div>

        {/* Side */}
        <div className="flex flex-col gap-4">
          {/* Companion */}
          <Card className="overflow-hidden p-0">
            <div className="relative h-[270px]" style={{ background: `radial-gradient(ellipse at 50% 80%, ${acc}22, transparent 65%)` }}>
              {pet && <Pet3D pet={pet} stage={false} mood={petMoodState} onTap={tap} className="h-full w-full" aura={owned?.level === 20} />}
              <div className="absolute left-4 right-4 top-3 flex justify-center">
                <div className="surface-solid max-w-full truncate rounded-full px-3.5 py-1.5 text-[13px] text-bone shadow-xl" key={speech} style={{ animation: "pop .35s both" }}>{speech}</div>
              </div>
            </div>
            <div className="border-t border-white/6 p-4">
              <div className="flex items-center justify-between">
                <div><div className="font-bold">{owned?.nickname ?? pet?.name}</div><div className="text-xs text-mute">Lvl {owned?.level} · {mood.label}{mood.bonus > 0 ? ` · +${Math.round(mood.bonus * 100)}% coins` : ""}</div></div>
                <Btn size="sm" variant="soft" onClick={() => go("/pets")}>Manage</Btn>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-3 text-[11px] text-mute">
                <div><div className="mb-1 flex justify-between"><span>Fed</span><span>{mood.fed}</span></div><Bar value={mood.fed} color="var(--color-gold)" h={5} /></div>
                <div><div className="mb-1 flex justify-between"><span>Joy</span><span>{mood.joy}</span></div><Bar value={mood.joy} color="var(--color-mint)" h={5} /></div>
              </div>
            </div>
          </Card>

          {/* Task */}
          <Card>
            <Eyebrow className="mb-3">Working on</Eyebrow>
            <div className="flex flex-col gap-1.5">
              {openTasks.slice(0, 4).map((x) => (
                <button key={x.id} onClick={() => actions.setTask(t.taskId === x.id ? null : x.id)}
                  className={cn("flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left text-sm transition cursor-pointer", t.taskId === x.id ? "border-ember/50 bg-ember/10" : "border-white/6 bg-white/3 hover:bg-white/6")}>
                  <span className={cn("grid h-5 w-5 shrink-0 place-items-center rounded-full border", t.taskId === x.id ? "border-ember bg-ember text-ink-950" : "border-white/20")}>{t.taskId === x.id && <Check size={12} strokeWidth={3} />}</span>
                  <span className="min-w-0 flex-1 truncate">{x.title}</span>
                  <span className="text-xs text-dim">{x.spent}/{x.est}</span>
                </button>
              ))}
              {openTasks.length === 0 && <div className="py-2 text-sm text-mute">No open tasks. Add one — it makes sessions stick.</div>}
            </div>
            <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (!newTask.trim()) return; actions.addTask(newTask); setNewTask(""); }}>
              <input value={newTask} onChange={(e) => setNewTask(e.target.value)} placeholder="Add a task…" className="h-10 min-w-0 flex-1 rounded-xl border border-white/8 bg-white/4 px-3 text-sm outline-none placeholder:text-dim focus:border-ember/50" />
              <Btn variant="soft" className="w-10 px-0" aria-label="Add"><PlusIcon size={16} /></Btn>
            </form>
          </Card>

          {/* Sound */}
          <Card>
            <div className="mb-3 flex items-center justify-between"><Eyebrow>Ambient sound</Eyebrow><Volume2 size={14} className="text-dim" /></div>
            <div className="grid grid-cols-3 gap-2">
              {SOUNDS.map((x) => (
                <button key={x.id} title={x.hint} onClick={() => { actions.updateSettings({ sound: x.id }); sfx.click(); }}
                  className={cn("h-10 rounded-xl border text-[12.5px] font-semibold transition cursor-pointer", s.settings.sound === x.id ? "border-bone bg-bone text-ink-950" : "border-white/8 bg-white/4 text-mute hover:text-bone")}>{x.label}</button>
              ))}
            </div>
            <input type="range" min={0} max={1} step={0.01} value={s.settings.volume} className="mt-3 w-full"
              onChange={(e) => { const v = Number(e.target.value); setVolume(v); actions.updateSettings({ volume: v }); }} aria-label="Volume" />
            <p className="mt-1 text-[11px] text-dim">Plays while the timer runs. Generated on-device, no downloads.</p>
          </Card>

          {/* Cycle */}
          <Card className="flex items-center justify-between">
            <div>
              <Eyebrow>Cycle</Eyebrow>
              <div className="mt-1 text-sm text-mute">Long break after {s.settings.longEvery} focus sessions</div>
            </div>
            <div className="flex gap-1.5">
              {Array.from({ length: s.settings.longEvery }).map((_, i) => (
                <span key={i} className="h-3 w-3 rounded-full" style={{ background: i < (t.mode === "focus" ? (t.cycle - 1) % s.settings.longEvery : (t.cycle - 1) % s.settings.longEvery === 0 ? s.settings.longEvery : (t.cycle - 1) % s.settings.longEvery) ? acc : "rgba(255,255,255,0.12)" }} />
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Face picker */}
      <Modal open={picker} onClose={() => setPicker(false)} className="max-w-3xl">
        <h2 className="font-display text-2xl font-extrabold">Timer faces</h2>
        <p className="mb-5 mt-1 text-sm text-mute">Choose how your time looks. Changes apply instantly.</p>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {FACES.map((f) => {
            const on = s.settings.face === f.id;
            return (
              <button key={f.id} onClick={() => { actions.updateSettings({ face: f.id }); sfx.click(); }}
                className={cn("group flex flex-col overflow-hidden rounded-2xl border text-left transition cursor-pointer", on ? "border-ember bg-ember/8" : "border-white/8 bg-white/3 hover:border-white/20")}>
                <div className="pointer-events-none flex h-44 items-center justify-center overflow-hidden bg-ink-950/60">
                  <div style={{ width: FACE_W[f.id] ?? 170 }}>
                    <TimerFace face={f.id} ms={t.mode === "focus" ? 16 * 60000 : 3 * 60000} total={t.mode === "focus" ? 25 * 60000 : 5 * 60000} running={false} mode={t.mode} petId={s.active} label="" preview />
                  </div>
                </div>
                <div className="p-3"><div className="flex items-center justify-between text-sm font-bold">{f.name}{on && <Check size={14} className="text-ember" />}</div><div className="mt-0.5 text-xs text-mute">{f.desc}</div></div>
              </button>
            );
          })}
        </div>
      </Modal>

      {/* Finish early */}
      <Modal open={confirmEnd} onClose={() => setConfirmEnd(false)} className="max-w-sm">
        <h2 className="font-display text-xl font-extrabold">End this session now?</h2>
        <p className="mt-2 text-sm text-mute">You focused for {elapsedMin} minute{elapsedMin === 1 ? "" : "s"}. We'll bank that time, but early finishes score lower than full sessions.</p>
        <div className="mt-5 flex gap-2"><Btn className="flex-1" onClick={() => { setConfirmEnd(false); actions.completeTimer(true); }}>Bank {elapsedMin} min</Btn><Btn variant="soft" className="flex-1" onClick={() => setConfirmEnd(false)}>Keep going</Btn></div>
        <button className="mt-3 w-full text-center text-xs text-dim hover:text-rose cursor-pointer" onClick={() => { setConfirmEnd(false); actions.resetTimer(); }}>Discard session instead</button>
      </Modal>

      {/* Zen mode */}
      {zen && (
        <div className="fixed inset-0 z-[75] flex flex-col items-center justify-center overflow-y-auto" style={{ background: `radial-gradient(ellipse at 50% 30%, ${acc}22, #08090b 65%)`, animation: "pop .3s both" }}>
          <button onClick={() => setZen(false)} className="absolute right-5 top-5 z-10 grid h-11 w-11 place-items-center rounded-full bg-white/8 text-bone hover:bg-white/15 cursor-pointer" aria-label="Exit zen mode"><X size={18} /></button>
          <div className="absolute left-5 top-5 text-xs font-semibold uppercase tracking-[0.2em] text-dim">{MODE_LABEL[t.mode]}</div>
          <div className="w-full max-w-[min(90vw,70vh)] px-4">{faceEl}</div>
          <div className="mt-8">{controls}</div>
          {pet && (
            <div className="pointer-events-none absolute bottom-0 right-0 hidden h-[260px] w-[260px] sm:block">
              <Pet3D pet={pet} stage={false} mood={petMoodState} interactive={false} className="h-full w-full" />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
