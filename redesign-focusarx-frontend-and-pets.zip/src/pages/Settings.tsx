import { useState, type ReactNode } from "react";
import { Bell, Database, RotateCcw, Trash2 } from "lucide-react";
import { actions, toast, useStore } from "../lib/store";
import { Btn, Card, Eyebrow, Modal, PageHead } from "../components/ui";
import { cn } from "../utils/cn";
import { go } from "../lib/router";

function Row({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-white/5 py-4 last:border-0">
      <div className="min-w-0"><div className="text-[15px] font-semibold">{label}</div>{hint && <div className="mt-0.5 text-[13px] text-mute">{hint}</div>}</div>
      <div className="shrink-0">{children}</div>
    </div>
  );
}
function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)} className={cn("relative h-7 w-12 rounded-full transition cursor-pointer", on ? "bg-ember" : "bg-white/12")}>
      <span className={cn("absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all", on ? "left-6" : "left-1")} />
    </button>
  );
}
function Num({ v, set, min, max, unit }: { v: number; set: (n: number) => void; min: number; max: number; unit?: string }) {
  return (
    <div className="flex items-center rounded-xl bg-white/6">
      <button aria-label="Decrease" onClick={() => set(Math.max(min, v - 1))} className="h-9 w-9 text-mute hover:text-bone cursor-pointer">−</button>
      <span className="w-14 text-center text-sm font-semibold tabular">{v}{unit}</span>
      <button aria-label="Increase" onClick={() => set(Math.min(max, v + 1))} className="h-9 w-9 text-mute hover:text-bone cursor-pointer">+</button>
    </div>
  );
}

export default function Settings() {
  const s = useStore();
  const [reset, setReset] = useState(false);
  const st = s.settings;
  const up = actions.updateSettings;

  return (
    <div className="mx-auto max-w-2xl px-4 pb-32 pt-8 sm:px-8 lg:pb-16">
      <PageHead eyebrow="Settings" title="Make it yours" />

      <Card className="mb-5">
        <Eyebrow className="mb-1">Profile</Eyebrow>
        <Row label="Display name"><input value={s.name} onChange={(e) => actions.rename(e.target.value.slice(0, 20))} className="h-10 w-44 rounded-xl border border-white/8 bg-white/5 px-3 text-sm outline-none focus:border-ember/50" /></Row>
        <Row label="Daily goal" hint="Minutes of focus you want to hit each day"><Num v={st.dailyGoal} set={(n) => up({ dailyGoal: n })} min={10} max={480} unit="m" /></Row>
      </Card>

      <Card className="mb-5">
        <Eyebrow className="mb-1">Timer</Eyebrow>
        <Row label="Focus length"><Num v={st.focus} set={(n) => up({ focus: n })} min={1} max={180} unit="m" /></Row>
        <Row label="Short break"><Num v={st.short} set={(n) => up({ short: n })} min={1} max={60} unit="m" /></Row>
        <Row label="Long break"><Num v={st.long} set={(n) => up({ long: n })} min={1} max={90} unit="m" /></Row>
        <Row label="Long break every" hint="Number of focus sessions"><Num v={st.longEvery} set={(n) => up({ longEvery: n })} min={2} max={8} /></Row>
        <Row label="Auto-start breaks" hint="Roll straight into the break when focus ends"><Toggle on={st.autoBreak} onChange={(v) => up({ autoBreak: v })} label="Auto-start breaks" /></Row>
        <Row label="Finish chime"><Toggle on={st.chime} onChange={(v) => up({ chime: v })} label="Finish chime" /></Row>
        <Row label="Desktop notifications" hint="Get pinged when a session ends in a background tab">
          <Toggle on={st.notify} label="Notifications" onChange={(v) => {
            up({ notify: v });
            if (v && "Notification" in window && Notification.permission === "default") void Notification.requestPermission();
            if (v) toast("Notifications on", "info");
          }} />
        </Row>
        <div className="mt-2 flex items-center gap-2 text-xs text-dim"><Bell size={12} /> Timing is deadline-based, so background tabs and sleep never skew it.</div>
      </Card>

      <Card>
        <Eyebrow className="mb-1">Data</Eyebrow>
        <Row label="Load sample data" hint="Fills analytics with 5 weeks of example sessions"><Btn variant="soft" size="sm" onClick={() => { actions.loadDemo(); toast("Sample data loaded"); go("/analytics"); }}><Database size={14} /> Load</Btn></Row>
        <Row label="Reset everything" hint="Deletes pets, sessions, tasks and progress from this device"><Btn variant="danger" size="sm" onClick={() => setReset(true)}><Trash2 size={14} /> Reset</Btn></Row>
        <p className="mt-3 text-xs text-dim">All progress is stored in this browser only. Clearing site data removes it.</p>
      </Card>

      <Modal open={reset} onClose={() => setReset(false)} className="max-w-sm">
        <h2 className="font-display text-xl font-extrabold">Reset all progress?</h2>
        <p className="mt-2 text-sm text-mute">This can't be undone. You'll start again from the welcome screen.</p>
        <div className="mt-5 flex gap-2"><Btn variant="danger" className="flex-1" onClick={() => { actions.resetAll(); setReset(false); go("/"); }}><RotateCcw size={14} /> Yes, reset</Btn><Btn variant="soft" className="flex-1" onClick={() => setReset(false)}>Cancel</Btn></div>
      </Modal>
    </div>
  );
}
