import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Coins, Heart, Lock, Moon, Pencil, Search, Sparkles, Utensils, Gamepad2, Star } from "lucide-react";
import Pet3D from "../components/three/Pet3D";
import { PetPortrait } from "../components/PetImg";
import { Bar, Btn, Card, Eyebrow, PageHead, RarityTag, Seg, TypeBadge } from "../components/ui";
import { actions, petMood, toast, useStore } from "../lib/store";
import { FEED_COST, LEVEL_UNLOCKS, MAX_LEVEL, movesFor, PETS, PET_MAP, RARITY, TYPE_COLOR, statsFor, xpForLevel, type Rarity } from "../lib/pets";
import { cn } from "../utils/cn";
import { sfx } from "../lib/audio";
import type { CritterMood } from "../components/three/critter";

type Filter = "all" | "owned" | "locked";

export default function Pets() {
  const s = useStore();
  const [sel, setSel] = useState(s.active || PETS[0].id);
  const [mood, setMood] = useState<CritterMood>("idle");
  const [filter, setFilter] = useState<Filter>("all");
  const [kind, setKind] = useState<"all" | "critter" | "mon">("all");
  const [rar, setRar] = useState<Rarity | "all">("all");
  const [q, setQ] = useState("");
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState("");
  const stageRef = useRef<HTMLDivElement>(null);
  const moodTimer = useRef<number>(0);

  const def = PET_MAP[sel] ?? PETS[0];
  const owned = s.pets[def.id];
  const m = petMood(owned);
  const level = owned?.level ?? 1;
  const stats = statsFor(def, level);
  const moves = movesFor(def.type);
  const col = TYPE_COLOR[def.type];

  useEffect(() => { setEditing(false); setMood("idle"); }, [sel]);

  const flash = (md: CritterMood, ms = 2800) => {
    setMood(md);
    window.clearTimeout(moodTimer.current);
    moodTimer.current = window.setTimeout(() => setMood("idle"), ms);
  };

  const list = useMemo(() => PETS.filter((p) => {
    if (filter === "owned" && !s.pets[p.id]) return false;
    if (filter === "locked" && s.pets[p.id]) return false;
    if (kind !== "all" && p.kind !== kind) return false;
    if (rar !== "all" && p.rarity !== rar) return false;
    if (q && !p.name.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  }), [filter, kind, rar, q, s.pets]);

  const pick = (id: string) => { setSel(id); sfx.click(); stageRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }); };

  const buy = () => {
    if (actions.buyPet(def.id)) { sfx.win(); flash("cheer", 3500); toast(`${def.name} joined your team!`, "coin"); }
    else toast(`You need ${def.price - s.coins} more coins`, "warn");
  };

  const ownedCount = Object.keys(s.pets).length;

  return (
    <div className="mx-auto max-w-7xl px-4 pb-32 pt-8 sm:px-8 lg:pb-16">
      <PageHead eyebrow="Companions" title="Your 3D companions" sub="Raise them, bond with them and take them into the Arena. A happy pet earns you more coins on every session."
        right={<div className="flex items-center gap-2 text-sm text-mute"><Star size={14} className="text-gold" /> {ownedCount} / {PETS.length} collected</div>} />

      {/* Showcase */}
      <div ref={stageRef} className="grid scroll-mt-24 gap-5 lg:grid-cols-[1.35fr_1fr]">
        <div className="relative min-h-[460px] overflow-hidden rounded-[32px] border border-white/7 sm:min-h-[580px]"
          style={{ background: `radial-gradient(ellipse at 50% 38%, ${col}33, transparent 62%), radial-gradient(ellipse at 50% 100%, ${col}18, transparent 50%), linear-gradient(180deg,#14171e,#0d0f13)` }}>
          <div className="grain absolute inset-0" />
          <Pet3D key={`aura-${level === MAX_LEVEL && !!owned}`} pet={def} mood={mood} aura={level === MAX_LEVEL && !!owned} onTap={() => { if (owned) actions.tapPet(def.id); }} className="absolute inset-0" />
          <div className="pointer-events-none absolute left-5 top-5 flex flex-wrap items-center gap-2">
            <TypeBadge type={def.type} className="bg-ink-950/70" />
            <span className="rounded-full bg-ink-950/70 px-2 py-0.5"><RarityTag rarity={def.rarity} /></span>
            <span className="rounded-full bg-ink-950/70 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-mute">{def.kind === "mon" ? "Pokémon partner" : "Original 3D"}</span>
          </div>
          <div className="pointer-events-none absolute inset-x-0 bottom-4 text-center text-xs text-dim">Drag to rotate · tap to pet · move your cursor to be watched</div>
          {!owned && (
            <div className="absolute right-5 top-5 flex items-center gap-1.5 rounded-full bg-ink-950/80 px-3 py-1.5 text-xs font-semibold text-mute"><Lock size={12} /> Preview</div>
          )}
        </div>

        <div className="flex flex-col gap-4">
          <Card className="p-6">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                {editing && owned ? (
                  <form className="flex items-center gap-2" onSubmit={(e) => { e.preventDefault(); actions.nickname(def.id, name); setEditing(false); }}>
                    <input autoFocus value={name} onChange={(e) => setName(e.target.value)} maxLength={14} className="h-10 w-44 rounded-xl border border-ember/50 bg-white/5 px-3 font-display text-xl font-bold outline-none" />
                    <Btn size="sm" aria-label="Save"><Check size={14} /></Btn>
                  </form>
                ) : (
                  <h2 className="flex items-center gap-2 font-display text-3xl font-extrabold">
                    <span className="truncate">{owned?.nickname ?? def.name}</span>
                    {owned && <button onClick={() => { setName(owned.nickname ?? def.name); setEditing(true); }} aria-label="Rename" className="text-dim hover:text-bone cursor-pointer"><Pencil size={15} /></button>}
                  </h2>
                )}
                <p className="mt-1.5 text-[15px] leading-relaxed text-mute">{def.blurb}</p>
              </div>
              {owned && (
                <div className="shrink-0 rounded-2xl bg-white/6 px-3 py-2 text-center"><div className="text-[10px] font-bold uppercase tracking-wider text-dim">Bond</div><div className="font-display text-2xl font-extrabold">{owned.level}</div></div>
              )}
            </div>

            {owned ? (
              <>
                <div className="mt-5">
                  <div className="mb-1.5 flex justify-between text-xs text-mute"><span>{owned.level >= MAX_LEVEL ? "Max bond reached" : "Bond XP"}</span><span className="tabular">{owned.level >= MAX_LEVEL ? "MAX" : `${owned.xp} / ${xpForLevel(owned.level)}`}</span></div>
                  <Bar value={owned.level >= MAX_LEVEL ? 1 : owned.xp} max={owned.level >= MAX_LEVEL ? 1 : xpForLevel(owned.level)} color={col} h={10} />
                </div>
                <div className="mt-5 grid grid-cols-2 gap-4 text-xs text-mute">
                  <div><div className="mb-1.5 flex justify-between"><span>Hunger</span><span className="tabular">{m.fed}%</span></div><Bar value={m.fed} color="var(--color-gold)" h={6} /></div>
                  <div><div className="mb-1.5 flex justify-between"><span>Happiness</span><span className="tabular">{m.joy}%</span></div><Bar value={m.joy} color="var(--color-mint)" h={6} /></div>
                </div>
                <div className="mt-3 text-xs text-mute">Mood: <b className="text-bone">{m.label}</b>{m.bonus > 0 && <> · <span className="text-mint">+{Math.round(m.bonus * 100)}% session coins</span></>}</div>
                <div className="mt-5 grid grid-cols-3 gap-2">
                  <Btn variant="soft" onClick={() => { if (actions.feed(def.id)) { sfx.coin(); flash("happy"); } else toast("Not enough coins", "warn"); }}><Utensils size={15} /> Feed <span className="flex items-center gap-0.5 text-xs text-gold"><Coins size={11} />{FEED_COST}</span></Btn>
                  <Btn variant="soft" onClick={() => { actions.play(def.id); sfx.heal(); flash("cheer"); }}><Gamepad2 size={15} /> Play</Btn>
                  <Btn variant="soft" onClick={() => setMood(mood === "sleep" ? "idle" : "sleep")}><Moon size={15} /> {mood === "sleep" ? "Wake" : "Nap"}</Btn>
                </div>
                <div className="mt-2">
                  {s.active === def.id
                    ? <div className="flex h-10 items-center justify-center gap-2 rounded-xl border border-mint/25 bg-mint/10 text-sm font-semibold text-mint"><Heart size={14} fill="currentColor" /> Active focus companion</div>
                    : <Btn className="w-full" onClick={() => { actions.setActive(def.id); toast(`${def.name} is now your focus buddy`); }}>Set as focus companion</Btn>}
                </div>
              </>
            ) : (
              <div className="mt-6">
                <Btn size="lg" className="w-full" onClick={buy} disabled={s.coins < def.price}>
                  <Sparkles size={18} /> Adopt for <span className="flex items-center gap-1"><Coins size={15} />{def.price.toLocaleString()}</span>
                </Btn>
                {s.coins < def.price && <p className="mt-2 text-center text-xs text-mute">Focus {Math.ceil((def.price - s.coins) / 1.4)} more minutes to afford this one.</p>}
              </div>
            )}
          </Card>

          <Card>
            <Eyebrow className="mb-3">Battle stats · Lv {level}</Eyebrow>
            <div className="grid gap-2.5">
              {([["HP", stats.hp, 200], ["Attack", stats.atk, 130], ["Defense", stats.def, 130], ["Speed", stats.spd, 110]] as [string, number, number][]).map(([l, v, mx]) => (
                <div key={l} className="flex items-center gap-3 text-xs"><span className="w-14 text-mute">{l}</span><Bar value={v} max={mx} color={col} h={6} className="flex-1" /><span className="w-8 text-right font-semibold tabular">{v}</span></div>
              ))}
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {moves.map((mv) => (
                <div key={mv.id} className="rounded-xl border border-white/6 bg-white/3 px-3 py-2">
                  <div className="flex items-center justify-between"><span className="text-[13px] font-semibold">{mv.name}</span><span className="h-2 w-2 rounded-full" style={{ background: TYPE_COLOR[mv.type] }} /></div>
                  <div className="text-[11px] text-dim">{mv.kind === "heal" ? "Restores 35% HP" : `Power ${mv.power} · Acc ${mv.acc}%`} · PP {mv.pp}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Bond ladder */}
      {owned && (
        <Card className="mt-5">
          <Eyebrow className="mb-3">Bond rewards</Eyebrow>
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {Object.entries(LEVEL_UNLOCKS).map(([lv, txt]) => {
              const done = owned.level >= Number(lv);
              return (
                <div key={lv} className={cn("flex items-center gap-3 rounded-xl border px-3 py-2.5 text-sm", done ? "border-mint/25 bg-mint/8" : "border-white/6 bg-white/3 opacity-70")}>
                  <span className={cn("grid h-7 w-7 shrink-0 place-items-center rounded-lg text-xs font-bold", done ? "bg-mint text-ink-950" : "bg-white/8 text-mute")}>{done ? <Check size={14} strokeWidth={3} /> : lv}</span>
                  <div><div className="text-[11px] font-semibold uppercase tracking-wider text-dim">Level {lv}</div><div>{txt}</div></div>
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {/* Collection */}
      <div className="mb-4 mt-12 flex flex-wrap items-end justify-between gap-4">
        <div><Eyebrow className="mb-1 text-ember">Collection</Eyebrow><h2 className="font-display text-2xl font-extrabold">All companions</h2></div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-dim" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search" className="h-10 w-40 rounded-xl border border-white/8 bg-white/4 pl-9 pr-3 text-sm outline-none placeholder:text-dim focus:border-ember/50" /></div>
          <Seg<Filter> value={filter} onChange={setFilter} options={[{ id: "all", label: "All" }, { id: "owned", label: "Owned" }, { id: "locked", label: "Locked" }]} />
        </div>
      </div>
      <div className="mb-5 flex flex-wrap gap-2">
        {([["all", "Everyone"], ["critter", "Original 3D"], ["mon", "Pokémon"]] as const).map(([id, l]) => (
          <button key={id} onClick={() => setKind(id)} className={cn("h-8 rounded-full px-3.5 text-xs font-semibold transition cursor-pointer", kind === id ? "bg-bone text-ink-950" : "bg-white/6 text-mute hover:text-bone")}>{l}</button>
        ))}
        <span className="mx-1 w-px bg-white/10" />
        {(["all", "common", "uncommon", "rare", "epic", "legendary"] as const).map((r) => (
          <button key={r} onClick={() => setRar(r)} className={cn("h-8 rounded-full px-3.5 text-xs font-semibold capitalize transition cursor-pointer", rar === r ? "text-ink-950" : "bg-white/6 text-mute hover:text-bone")} style={rar === r ? { background: r === "all" ? "#f3eee6" : RARITY[r].color } : undefined}>{r}</button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        {list.map((p) => {
          const o = s.pets[p.id];
          const on = sel === p.id;
          return (
            <button key={p.id} onClick={() => pick(p.id)}
              className={cn("group relative flex flex-col overflow-hidden rounded-2xl border text-left transition-all cursor-pointer hover:-translate-y-1", on ? "border-ember bg-ember/6" : "border-white/7 bg-white/3 hover:border-white/20")}>
              <div className="relative grid aspect-square place-items-center" style={{ background: `radial-gradient(circle at 50% 60%, ${TYPE_COLOR[p.type]}30, transparent 70%)` }}>
                <div className={cn("transition-transform duration-300 group-hover:scale-110", !o && "opacity-90")}>
                  <PetPortrait def={p} size={128} className={cn("drop-shadow-[0_10px_16px_rgba(0,0,0,0.5)]", !o && "saturate-[0.55]")} />
                </div>
                {o ? <span className="absolute right-2 top-2 rounded-full bg-mint px-2 py-0.5 text-[10px] font-bold text-ink-950">Lv {o.level}</span> : <span className="absolute right-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-ink-950/70 text-mute"><Lock size={11} /></span>}
                {s.active === p.id && <span className="absolute left-2 top-2 grid h-6 w-6 place-items-center rounded-full bg-ember text-ink-950"><Heart size={11} fill="currentColor" /></span>}
              </div>
              <div className="p-3">
                <div className="flex items-center justify-between gap-2"><span className="truncate text-sm font-bold">{o?.nickname ?? p.name}</span><RarityTag rarity={p.rarity} /></div>
                <div className="mt-1.5 flex items-center justify-between"><TypeBadge type={p.type} />{!o && <span className="flex items-center gap-1 text-xs font-semibold text-gold"><Coins size={11} />{p.price || "Free"}</span>}</div>
              </div>
            </button>
          );
        })}
      </div>
      {list.length === 0 && <div className="py-16 text-center text-mute">No companions match those filters.</div>}
    </div>
  );
}
