import { Check, Coins, Gift, Lock, Trophy, Zap } from "lucide-react";
import { ACHIEVEMENTS, CHECKIN_REWARDS, MISSIONS, WEEK_GOAL, actions, addDays, setCheckinOpen, toast, todayKey, useStore, weekMinutes } from "../lib/store";
import { Bar, Btn, Card, Eyebrow, PageHead, fmtMin } from "../components/ui";
import { cn } from "../utils/cn";
import { sfx } from "../lib/audio";

export default function Missions() {
  const s = useStore();
  const wMin = weekMinutes(s);
  const canCheckin = s.checkin.last !== todayKey();
  const chainAlive = s.checkin.last === todayKey() || s.checkin.last === addDays(todayKey(), -1);
  const claimedCount = !chainAlive ? 0 : s.checkin.last === todayKey() ? ((s.checkin.day - 1) % 7) + 1 : s.checkin.day % 7;
  const doneCount = s.achievements.filter((a) => ACHIEVEMENTS.some((x) => x.id === a)).length;

  return (
    <div className="mx-auto max-w-5xl px-4 pb-32 pt-8 sm:px-8 lg:pb-16">
      <PageHead eyebrow="Missions" title="Small wins, every day" sub="Missions reset at midnight. Achievements are forever. Both pay out coins you can spend on new companions." />

      <div className="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
        <Card>
          <div className="mb-4 flex items-center justify-between"><Eyebrow>Today's missions</Eyebrow><span className="text-xs text-dim">{s.daily.claimed.length}/{MISSIONS.length} claimed</span></div>
          <div className="flex flex-col gap-3">
            {MISSIONS.map((m) => {
              const v = Math.min(m.goal, m.value(s.daily)); const done = v >= m.goal; const claimed = s.daily.claimed.includes(m.id);
              return (
                <div key={m.id} className={cn("flex items-center gap-4 rounded-2xl border p-4 transition", claimed ? "border-mint/20 bg-mint/6" : done ? "border-ember/40 bg-ember/8" : "border-white/6 bg-white/3")}>
                  <div className={cn("grid h-11 w-11 shrink-0 place-items-center rounded-xl", claimed ? "bg-mint text-ink-950" : done ? "bg-ember text-ink-950" : "bg-white/7 text-mute")}>{claimed ? <Check size={20} strokeWidth={3} /> : <Trophy size={18} />}</div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2"><span className="font-semibold">{m.title}</span><span className="text-xs tabular text-dim">{v}/{m.goal}</span></div>
                    <div className="mb-2 text-[13px] text-mute">{m.desc}</div>
                    <Bar value={v} max={m.goal} h={5} color={claimed ? "var(--color-mint)" : "var(--color-ember)"} />
                  </div>
                  <div className="flex w-[84px] shrink-0 flex-col items-end gap-1.5">
                    {done && !claimed ? <Btn size="sm" onClick={() => { actions.claimMission(m.id); sfx.coin(); toast(`+${m.coins} coins${m.energy ? ` · +${m.energy} energy` : ""}`, "coin"); }}>Claim</Btn> : claimed ? <span className="text-xs font-semibold text-mint">Claimed</span> : null}
                    <span className="flex items-center gap-1 text-xs text-gold"><Coins size={11} />{m.coins}{m.energy > 0 && <><Zap size={11} className="ml-1 text-mint" /><span className="text-mint">{m.energy}</span></>}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <div className="flex flex-col gap-5">
          <Card>
            <div className="mb-3 flex items-center justify-between"><Eyebrow>Weekly chest</Eyebrow><span className="text-xs text-dim">Resets Monday</span></div>
            <div className="flex items-center gap-4">
              <div className={cn("grid h-16 w-16 place-items-center rounded-2xl", wMin >= WEEK_GOAL && !s.chests.claimed ? "bg-gold text-ink-950 animate-pulse-soft" : "bg-white/7 text-mute")}><Gift size={28} /></div>
              <div className="flex-1"><div className="font-display text-2xl font-extrabold tabular">{fmtMin(wMin)}<span className="text-sm text-dim"> / {fmtMin(WEEK_GOAL)}</span></div><Bar value={wMin} max={WEEK_GOAL} color="var(--color-gold)" className="mt-2" h={7} /></div>
            </div>
            <p className="mt-3 text-sm text-mute">250 coins + a streak freeze when you hit {fmtMin(WEEK_GOAL)} this week.</p>
            <Btn className="mt-3 w-full" disabled={wMin < WEEK_GOAL || s.chests.claimed} onClick={() => { actions.claimChest(); sfx.win(); toast("Chest opened: +250 coins, +1 freeze", "coin"); }}>{s.chests.claimed ? "Opened this week" : wMin >= WEEK_GOAL ? "Open chest" : "Keep focusing"}</Btn>
          </Card>

          <Card>
            <div className="mb-3 flex items-center justify-between"><Eyebrow>Daily check-in</Eyebrow>{canCheckin ? <span className="rounded-full bg-ember px-2 py-0.5 text-[10px] font-bold text-ink-950">Ready</span> : <span className="text-xs text-mint">Done today</span>}</div>
            <div className="grid grid-cols-7 gap-1.5">
              {CHECKIN_REWARDS.map((r, i) => {
                const claimedDay = i < claimedCount;
                const isNext = i === claimedCount && canCheckin;
                return (
                  <div key={i} className={cn("flex aspect-[3/4] flex-col items-center justify-center rounded-xl border text-[10px] font-semibold", claimedDay ? "border-mint/30 bg-mint/10 text-mint" : isNext ? "border-ember bg-ember/10 text-ember" : "border-white/8 text-dim")}>
                    <span className="text-[9px] uppercase opacity-70">D{i + 1}</span>
                    {r.freeze ? <Gift size={14} /> : r.coins ? <Coins size={14} /> : <Zap size={14} />}
                  </div>
                );
              })}
            </div>
            <Btn variant="soft" className="mt-3 w-full" onClick={() => setCheckinOpen(true)}>{canCheckin ? "Claim today's reward" : "View rewards"}</Btn>
          </Card>
        </div>
      </div>

      <div className="mb-4 mt-12 flex items-end justify-between"><div><Eyebrow className="mb-1 text-ember">Achievements</Eyebrow><h2 className="font-display text-2xl font-extrabold">{doneCount} of {ACHIEVEMENTS.length} unlocked</h2></div></div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {ACHIEVEMENTS.map((a) => {
          const got = s.achievements.includes(a.id);
          const pr = a.progress?.(s);
          return (
            <div key={a.id} className={cn("flex items-start gap-3 rounded-2xl border p-4", got ? "border-gold/30 bg-gold/6" : "border-white/6 bg-white/3")}>
              <div className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-xl", got ? "bg-gold text-ink-950" : "bg-white/7 text-dim")}>{got ? <Trophy size={18} /> : <Lock size={16} />}</div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2"><span className={cn("font-semibold", !got && "text-mute")}>{a.title}</span><span className="flex items-center gap-1 text-xs text-gold"><Coins size={11} />{a.coins}</span></div>
                <div className="text-[13px] text-mute">{a.desc}</div>
                {pr && !got && <div className="mt-2 flex items-center gap-2"><Bar value={pr[0]} max={pr[1]} h={4} className="flex-1" color="var(--color-gold)" /><span className="text-[11px] tabular text-dim">{pr[0]}/{pr[1]}</span></div>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
