import { useState } from "react";
import { ArrowLeft, ArrowRight, Check } from "lucide-react";
import { Logo } from "../components/Layout";
import Pet3D from "../components/three/Pet3D";
import { PetPortrait } from "../components/PetImg";
import { Btn, TypeBadge } from "../components/ui";
import { STARTERS, PET_MAP, RARITY } from "../lib/pets";
import { actions } from "../lib/store";
import { go } from "../lib/router";
import { cn } from "../utils/cn";

const GOALS = [{ m: 30, l: "Light", d: "30 min a day" }, { m: 60, l: "Steady", d: "1 hour a day" }, { m: 90, l: "Serious", d: "1.5 hours a day" }, { m: 180, l: "Deep work", d: "3 hours a day" }];

export default function Start() {
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [goal, setGoal] = useState(60);
  const [pick, setPick] = useState("mochi");
  const def = PET_MAP[pick];

  const finish = () => { actions.finishOnboarding(name, pick, goal); go("/dashboard"); };

  return (
    <div className="flex min-h-screen flex-col bg-ink-950">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-5 sm:px-8">
        <button onClick={() => go("/")} className="cursor-pointer"><Logo /></button>
        <div className="flex items-center gap-2">{[0, 1].map((i) => <span key={i} className={cn("h-1.5 w-10 rounded-full transition", i <= step ? "bg-ember" : "bg-white/12")} />)}</div>
      </div>

      <div className="mx-auto grid w-full max-w-6xl flex-1 items-center gap-8 px-5 pb-10 sm:px-8 lg:grid-cols-2">
        {step === 0 ? (
          <>
            <div style={{ animation: "rise .5s both" }}>
              <div className="mb-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-ember">Step 1 of 2</div>
              <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">Let's set you up.</h1>
              <p className="mt-3 max-w-md text-mute">No account. We just need a name and a goal that feels doable.</p>
              <label className="mt-8 block text-sm font-semibold">What should we call you?</label>
              <input value={name} onChange={(e) => setName(e.target.value.slice(0, 20))} autoFocus placeholder="Your name" className="mt-2 h-14 w-full max-w-md rounded-2xl border border-white/10 bg-white/5 px-5 text-lg outline-none placeholder:text-dim focus:border-ember/60" />
              <div className="mt-8 text-sm font-semibold">Daily focus goal</div>
              <div className="mt-2 grid max-w-md grid-cols-2 gap-2">
                {GOALS.map((g) => (
                  <button key={g.m} onClick={() => setGoal(g.m)} className={cn("rounded-2xl border p-4 text-left transition cursor-pointer", goal === g.m ? "border-ember bg-ember/10" : "border-white/8 bg-white/3 hover:border-white/20")}>
                    <div className="font-bold">{g.l}</div><div className="text-sm text-mute">{g.d}</div>
                  </button>
                ))}
              </div>
              <Btn size="lg" className="mt-8" onClick={() => setStep(1)}>Choose your companion <ArrowRight size={18} /></Btn>
            </div>
            <div className="relative hidden h-[520px] overflow-hidden rounded-[36px] border border-white/8 lg:block" style={{ background: "linear-gradient(180deg,#171a22,#0e1014)" }}>
              <Pet3D pet={PET_MAP.mochi} className="absolute inset-0" />
              <div className="absolute inset-x-0 bottom-5 text-center text-sm text-mute">Someone is excited to meet you.</div>
            </div>
          </>
        ) : (
          <>
            <div className="relative order-2 h-[420px] overflow-hidden rounded-[36px] border border-white/8 sm:h-[520px] lg:order-1" style={{ background: "linear-gradient(180deg,#171a22,#0e1014)" }}>
              <div className="grain absolute inset-0" />
              <Pet3D pet={def} className="absolute inset-0" />
              <div className="absolute left-5 top-5 flex items-center gap-2"><TypeBadge type={def.type} className="bg-ink-950/70" /><span className="rounded-full bg-ink-950/70 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider" style={{ color: RARITY[def.rarity].color }}>{def.rarity}</span></div>
            </div>
            <div className="order-1 lg:order-2" style={{ animation: "rise .5s both" }}>
              <div className="mb-3 text-[11px] font-semibold uppercase tracking-[0.16em] text-ember">Step 2 of 2</div>
              <h1 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">Pick your starter.</h1>
              <p className="mt-3 max-w-md text-mute">They'll sit with you through every session. You can collect the rest later with coins.</p>
              <div className="mt-6 grid grid-cols-3 gap-2.5">
                {STARTERS.map((p) => (
                  <button key={p.id} onClick={() => setPick(p.id)} className={cn("relative flex flex-col items-center rounded-2xl border p-3 transition cursor-pointer", pick === p.id ? "border-ember bg-ember/10" : "border-white/8 bg-white/3 hover:border-white/20")}>
                    {pick === p.id && <span className="absolute right-2 top-2 grid h-5 w-5 place-items-center rounded-full bg-ember text-ink-950"><Check size={12} strokeWidth={3} /></span>}
                    <PetPortrait def={p} size={84} />
                    <div className="mt-1 text-sm font-bold">{p.name}</div>
                  </button>
                ))}
              </div>
              <p className="mt-4 min-h-[44px] text-[15px] text-mute"><b className="text-bone">{def.name}:</b> {def.blurb}</p>
              <div className="mt-4 flex gap-2">
                <Btn variant="soft" size="lg" onClick={() => setStep(0)}><ArrowLeft size={18} /></Btn>
                <Btn size="lg" className="flex-1" onClick={finish}>Start with {def.name} <span className="rounded-full bg-ink-950/15 px-2 py-0.5 text-xs">+100 coins</span></Btn>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
