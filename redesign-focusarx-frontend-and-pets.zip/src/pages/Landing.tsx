import { useEffect, useState } from "react";
import { ArrowRight, Check, ChevronDown, Flame, Gift, Heart, Shield, Swords, Target, Timer, Zap } from "lucide-react";
import { Logo } from "../components/Layout";
import Pet3D from "../components/three/Pet3D";
import TimerFace from "../components/faces";
import { PetPortrait, BattleSprite } from "../components/PetImg";
import { Btn, Eyebrow, TypeBadge } from "../components/ui";
import { PETS, PET_MAP, RARITY } from "../lib/pets";
import { go } from "../lib/router";
import { cn } from "../utils/cn";

const SHOWCASE = ["mochi", "pikachu", "ember", "charmander", "ziggy", "eevee", "hoot", "mew"];

function DemoFace({ face, w = "100%" }: { face: string; w?: string }) {
  const [t, setT] = useState(0.35);
  useEffect(() => { const id = setInterval(() => setT((x) => (x >= 0.98 ? 0.04 : x + 0.004)), 120); return () => clearInterval(id); }, []);
  const total = 25 * 60000;
  return <div style={{ width: w }} className="pointer-events-none"><TimerFace face={face} ms={total * (1 - t)} total={total} running mode="focus" petId="pikachu" label="Revise thermodynamics" /></div>;
}

const FAQ = [
  ["Do I need an account?", "No. The timer, pets, tasks and Arena all work instantly. Your progress is saved on this device, so there is nothing to sign up for."],
  ["Is it really free?", "Yes. Every timer face, every companion and every Arena cup is earned by focusing — there is nothing to buy with money."],
  ["What is the Focus Score?", "A 0–100 rating per session based on completion and how often you paused. It rewards deep, uninterrupted work, not just hours logged."],
  ["How do pets help me focus?", "Your companion earns bond XP for every minute you focus, gets hungry and lonely if you disappear, and gives bonus coins when it's happy. Looking after it becomes a reason to show up."],
  ["Where does my data go?", "Nowhere. Sessions, tasks and pets live in your browser's local storage. Nothing is uploaded."],
];

export default function Landing() {
  const [pick, setPick] = useState("mochi");
  const [open, setOpen] = useState<number | null>(0);
  const def = PET_MAP[pick];
  const start = () => go("/start");

  return (
    <div className="min-h-screen overflow-x-hidden bg-ink-950">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b border-white/6 bg-ink-950/80 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 sm:px-8">
          <Logo />
          <nav className="hidden items-center gap-8 text-sm font-medium text-mute md:flex">
            {[["#companions", "Companions"], ["#faces", "Timer faces"], ["#arena", "Arena"], ["#faq", "FAQ"]].map(([h, l]) => <a key={h} href={h} onClick={(e) => { e.preventDefault(); document.querySelector(h)?.scrollIntoView({ behavior: "smooth" }); }} className="transition hover:text-bone">{l}</a>)}
          </nav>
          <Btn onClick={start}>Start free <ArrowRight size={15} /></Btn>
        </div>
      </header>

      {/* Hero */}
      <section className="relative">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[700px]" style={{ background: "radial-gradient(ellipse 60% 60% at 75% 30%, rgba(255,122,69,0.16), transparent 70%), radial-gradient(ellipse 40% 50% at 10% 20%, rgba(79,224,181,0.07), transparent 70%)" }} />
        <div className="relative mx-auto grid max-w-7xl items-center gap-6 px-5 pb-16 pt-12 sm:px-8 lg:grid-cols-[1fr_1.05fr] lg:pt-16">
          <div>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-[13px] font-medium text-mute"><span className="h-1.5 w-1.5 rounded-full bg-mint" /> Free forever · No account needed</div>
            <h1 className="font-display text-[44px] font-extrabold leading-[1.02] sm:text-6xl lg:text-[76px]">Focus for real.<br /><span className="text-ember">Raise a pet</span> while you do.</h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-mute">FocusArx is a Pomodoro timer with 3D companions, Pokémon partners, streaks and pet battles. Every minute you stay on task feeds your pet, fills your energy and builds a streak worth protecting.</p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Btn size="lg" onClick={start}>Start your first session <ArrowRight size={18} /></Btn>
              <Btn size="lg" variant="soft" onClick={() => document.querySelector("#companions")?.scrollIntoView({ behavior: "smooth" })}>Meet the companions</Btn>
            </div>
            <ul className="mt-8 grid max-w-md grid-cols-2 gap-x-6 gap-y-2.5 text-sm text-mute">
              {["Works offline, no sign-up", "7 timer faces", `${PETS.length} companions to collect`, "Private — data stays with you"].map((x) => <li key={x} className="flex items-center gap-2"><Check size={15} className="text-mint" strokeWidth={3} />{x}</li>)}
            </ul>
          </div>

          <div>
            <div className="relative h-[460px] overflow-hidden rounded-[36px] border border-white/8 sm:h-[560px]" style={{ background: "linear-gradient(180deg,#171a22,#0e1014)" }}>
              <div className="grain absolute inset-0" />
              <Pet3D pet={def} className="absolute inset-0" />
              <div className="absolute left-5 top-5 flex items-center gap-2"><TypeBadge type={def.type} className="bg-ink-950/70" /><span className="rounded-full bg-ink-950/70 px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider" style={{ color: RARITY[def.rarity].color }}>{RARITY[def.rarity].label}</span></div>
              <div className="absolute right-5 top-5 text-right"><div className="font-display text-2xl font-extrabold">{def.name}</div><div className="text-[11px] text-dim">Drag to rotate · tap to poke</div></div>
              <div className="absolute inset-x-0 bottom-4 flex justify-center gap-2 px-3">
                {SHOWCASE.map((id) => (
                  <button key={id} onClick={() => setPick(id)} aria-label={PET_MAP[id].name} className={cn("grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border bg-ink-900/80 backdrop-blur transition cursor-pointer sm:h-14 sm:w-14", pick === id ? "border-ember scale-110" : "border-white/10 hover:border-white/30")}>
                    <PetPortrait def={PET_MAP[id]} size={48} className="scale-125" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-y border-white/6 bg-white/[0.02]">
        <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-5 py-8 sm:px-8 md:grid-cols-4">
          {[["7", "timer faces"], [String(PETS.length), "companions"], ["6", "arena cups"], ["19", "achievements"]].map(([n, l]) => (
            <div key={l}><div className="font-display text-4xl font-extrabold">{n}</div><div className="text-sm text-mute">{l}</div></div>
          ))}
        </div>
      </section>

      {/* How it works */}
      <section className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
        <Eyebrow className="mb-3 text-ember">How it works</Eyebrow>
        <h2 className="max-w-2xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">A focus loop that gives you a reason to come back.</h2>
        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {[
            { i: Heart, t: "Pick a companion", d: "Start with a Pokémon partner or one of our original 3D pets. They watch you work and react as the timer runs.", c: "text-rose" },
            { i: Timer, t: "Focus on one thing", d: "Choose a task and a length. The timer is deadline-based, so locked phones and background tabs never skew it.", c: "text-ember" },
            { i: Zap, t: "Earn, care, battle", d: "Minutes become coins, bond XP and arena energy. Feed your pet, protect your streak, climb the Arena.", c: "text-mint" },
          ].map((x, i) => (
            <div key={x.t} className="surface relative p-7">
              <span className="absolute right-6 top-5 font-display text-6xl font-extrabold text-white/5">{i + 1}</span>
              <x.i size={26} className={x.c} />
              <h3 className="mt-5 font-display text-xl font-bold">{x.t}</h3>
              <p className="mt-2 leading-relaxed text-mute">{x.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Companions */}
      <section id="companions" className="scroll-mt-20 bg-white/[0.02] py-24">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div><Eyebrow className="mb-3 text-ember">Companions</Eyebrow><h2 className="max-w-2xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">Real 3D pets. Real Pokémon partners.</h2><p className="mt-4 max-w-xl text-lg text-mute">Ten original creatures built in 3D that look at you, blink, wag and hop. Plus 24 Pokémon with their own types and moves.</p></div>
            <Btn variant="soft" onClick={start}>Choose yours <ArrowRight size={15} /></Btn>
          </div>
          <div className="mt-12 grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-8">
            {PETS.filter((p) => !p.starter || p.id === "mochi" || p.kind === "mon").slice(0, 16).map((p) => (
              <button key={p.id} onClick={() => { setPick(p.id); window.scrollTo({ top: 0, behavior: "smooth" }); }} className="group relative flex flex-col items-center rounded-2xl border border-white/7 bg-white/3 p-3 transition hover:-translate-y-1 hover:border-white/20 cursor-pointer">
                <PetPortrait def={p} size={92} className="transition-transform group-hover:scale-110" />
                <div className="mt-1 text-sm font-bold">{p.name}</div>
                <div className="text-[10px] font-bold uppercase tracking-wider" style={{ color: RARITY[p.rarity].color }}>{p.rarity}</div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Faces */}
      <section id="faces" className="mx-auto max-w-7xl scroll-mt-20 px-5 py-24 sm:px-8">
        <Eyebrow className="mb-3 text-ember">Timer faces</Eyebrow>
        <h2 className="max-w-2xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">The prettiest timer you'll actually keep open.</h2>
        <div className="mt-12 grid gap-5 md:grid-cols-2">
          {[["aurora", "Aurora", "A glowing ring with a live tick scale."], ["flip", "Flip", "A mechanical split-flap clock."], ["hourglass", "Hourglass", "Real falling sand."], ["trail", "Companion Trail", "Your pet walks to the finish flag."]].map(([id, n, d]) => (
            <div key={id} className="surface overflow-hidden p-0">
              <div className="flex h-[320px] items-center justify-center overflow-hidden px-6 py-6" style={{ background: "radial-gradient(ellipse at 50% 0%, rgba(255,122,69,0.12), transparent 65%), #0f1115" }}>
                <DemoFace face={id} w={id === "hourglass" ? "170px" : id === "flip" ? "420px" : id === "trail" ? "520px" : "260px"} />
              </div>
              <div className="flex items-center justify-between border-t border-white/6 p-5"><div><div className="font-display text-lg font-bold">{n}</div><div className="text-sm text-mute">{d}</div></div></div>
            </div>
          ))}
        </div>
        <p className="mt-6 text-center text-sm text-mute">…plus Orbit, Segment and Garden. Switch any time in one tap.</p>
      </section>

      {/* Arena */}
      <section id="arena" className="relative scroll-mt-20 overflow-hidden bg-white/[0.02] py-24">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-2">
          <div>
            <Eyebrow className="mb-3 text-ember">The Arena</Eyebrow>
            <h2 className="font-display text-4xl font-extrabold leading-tight sm:text-5xl">Turn focus minutes into battle energy.</h2>
            <p className="mt-4 text-lg leading-relaxed text-mute">Every minute you focus charges your Arena energy. Spend it on turn-based 3v3 battles with type matchups, limited-PP moves, crits and a six-cup ladder.</p>
            <ul className="mt-6 grid gap-3 text-mute">
              {[[Swords, "Type advantages that actually matter"], [Shield, "Squad of three — switch when one faints"], [Target, "Six cups from Meadow to Mythic"]].map(([I, t]) => { const Ic = I as typeof Swords; return <li key={t as string} className="flex items-center gap-3"><span className="grid h-8 w-8 place-items-center rounded-lg bg-mint/12 text-mint"><Ic size={16} /></span>{t as string}</li>; })}
            </ul>
            <Btn className="mt-8" size="lg" onClick={start}>Try the Arena <ArrowRight size={18} /></Btn>
          </div>
          <div className="relative aspect-[16/11] overflow-hidden rounded-[32px] border border-white/10" style={{ background: "linear-gradient(180deg,#2b4a3a 0%,#16261e 62%)" }}>
            <div className="absolute inset-x-0 top-[44%] h-[56%]" style={{ background: "linear-gradient(180deg,#4d7a5255,#16261e)" }} />
            <div className="absolute left-[8%] top-[68%] h-[16%] w-[36%] rounded-[100%] border border-white/10 bg-[#4d7a52]/60" />
            <div className="absolute right-[8%] top-[34%] h-[11%] w-[30%] rounded-[100%] border border-white/10 bg-[#4d7a52]/60" />
            <div className="absolute right-[12%] top-[34%] -translate-y-full"><BattleSprite def={PET_MAP.charmander} side="front" scale={2} /></div>
            <div className="absolute left-[14%] top-[84%] -translate-y-full"><BattleSprite def={PET_MAP.pikachu} side="back" scale={2.4} /></div>
            <div className="absolute left-3 top-3 w-40 rounded-2xl bg-ink-950/85 p-3"><div className="flex justify-between text-sm font-bold"><span>Charmander</span><span className="text-xs text-mute">Lv 8</span></div><div className="mt-2 h-2 rounded-full bg-white/10"><div className="h-full w-[62%] rounded-full bg-mint" /></div></div>
            <div className="absolute bottom-3 right-3 w-44 rounded-2xl bg-ink-950/85 p-3"><div className="flex justify-between text-sm font-bold"><span>Pikachu</span><span className="text-xs text-mute">Lv 9</span></div><div className="mt-2 h-2 rounded-full bg-white/10"><div className="h-full w-[88%] rounded-full bg-mint" /></div></div>
          </div>
        </div>
      </section>

      {/* Retention */}
      <section className="mx-auto max-w-7xl px-5 py-24 sm:px-8">
        <Eyebrow className="mb-3 text-ember">Built for consistency</Eyebrow>
        <h2 className="max-w-3xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">Habits stick when showing up feels good.</h2>
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { i: Flame, t: "Streaks with freezes", d: "Miss a day and a freeze quietly covers you. Earn more from weekly chests.", c: "text-ember" },
            { i: Gift, t: "Daily rewards", d: "A seven-day check-in calendar ending in a streak freeze and a big coin payout.", c: "text-gold" },
            { i: Heart, t: "A pet that misses you", d: "Hunger and happiness drift while you're away. A thriving pet earns up to +20% coins.", c: "text-rose" },
            { i: Target, t: "Daily missions", d: "Six small goals reset every midnight and pay out coins and energy.", c: "text-mint" },
            { i: Timer, t: "Focus Score", d: "Each session is scored 0–100, so deep work beats distracted hours.", c: "text-sky" },
            { i: Shield, t: "Private by design", d: "Everything stays in your browser. No tracking, no sign-up wall.", c: "text-violet" },
          ].map((x) => (
            <div key={x.t} className="surface p-6 transition hover:-translate-y-1"><x.i size={24} className={x.c} /><h3 className="mt-4 font-display text-lg font-bold">{x.t}</h3><p className="mt-1.5 leading-relaxed text-mute">{x.d}</p></div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="mx-auto max-w-3xl scroll-mt-20 px-5 pb-24 sm:px-8">
        <h2 className="mb-8 text-center font-display text-4xl font-extrabold">Questions</h2>
        <div className="flex flex-col gap-2">
          {FAQ.map(([q, a], i) => (
            <div key={q} className="surface overflow-hidden p-0">
              <button className="flex w-full items-center justify-between gap-4 p-5 text-left font-semibold cursor-pointer" onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i}>{q}<ChevronDown size={18} className={cn("shrink-0 text-mute transition", open === i && "rotate-180")} /></button>
              {open === i && <p className="px-5 pb-5 leading-relaxed text-mute">{a}</p>}
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-5 pb-24 sm:px-8">
        <div className="relative overflow-hidden rounded-[36px] border border-ember/25 px-8 py-16 text-center" style={{ background: "radial-gradient(ellipse at 50% 0%, rgba(255,122,69,0.25), transparent 70%), #14110f" }}>
          <h2 className="mx-auto max-w-2xl font-display text-4xl font-extrabold leading-tight sm:text-5xl">Your companion is waiting for the first session.</h2>
          <p className="mx-auto mt-4 max-w-lg text-lg text-mute">Takes 30 seconds to set up. No account, no card.</p>
          <Btn size="lg" className="mt-8" onClick={start}>Start focusing free <ArrowRight size={18} /></Btn>
        </div>
      </section>

      <footer className="border-t border-white/6 py-10">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-5 text-sm text-dim sm:px-8"><Logo size={22} /><span>Pokémon names and artwork belong to their respective owners. Fan-made companion feature.</span></div>
      </footer>
    </div>
  );
}
