import { useState } from "react";
import { Check, ListChecks, Minus, Play, Plus, Trash2 } from "lucide-react";
import { actions, useStore } from "../lib/store";
import { Btn, Card, Empty, PageHead, Seg } from "../components/ui";
import { go } from "../lib/router";
import { cn } from "../utils/cn";

type P = "low" | "mid" | "high";
const PRI: Record<P, { label: string; color: string }> = { low: { label: "Low", color: "#6cb6ff" }, mid: { label: "Medium", color: "#ffc857" }, high: { label: "High", color: "#ff6b81" } };

export default function Tasks() {
  const s = useStore();
  const [title, setTitle] = useState("");
  const [est, setEst] = useState(2);
  const [pri, setPri] = useState<P>("mid");
  const [tab, setTab] = useState<"open" | "done">("open");

  const open = s.tasks.filter((t) => !t.done).sort((a, b) => ["high", "mid", "low"].indexOf(a.priority) - ["high", "mid", "low"].indexOf(b.priority));
  const done = s.tasks.filter((t) => t.done);
  const list = tab === "open" ? open : done;

  return (
    <div className="mx-auto max-w-3xl px-4 pb-32 pt-8 sm:px-8 lg:pb-16">
      <PageHead eyebrow="Tasks" title="What are you working on?" sub="Break work into focus blocks. Attach a task to a session and its progress updates by itself." />

      <Card className="mb-6">
        <form onSubmit={(e) => { e.preventDefault(); actions.addTask(title, est, pri); setTitle(""); }} className="flex flex-col gap-3">
          <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Finish chapter 4 notes" className="h-12 rounded-xl border border-white/8 bg-white/4 px-4 text-[15px] outline-none placeholder:text-dim focus:border-ember/50" />
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center rounded-xl bg-white/5">
              <button type="button" aria-label="Fewer blocks" onClick={() => setEst(Math.max(1, est - 1))} className="grid h-10 w-10 place-items-center text-mute hover:text-bone cursor-pointer"><Minus size={14} /></button>
              <span className="w-24 text-center text-sm font-semibold">{est} block{est > 1 ? "s" : ""}</span>
              <button type="button" aria-label="More blocks" onClick={() => setEst(Math.min(12, est + 1))} className="grid h-10 w-10 place-items-center text-mute hover:text-bone cursor-pointer"><Plus size={14} /></button>
            </div>
            <div className="flex gap-1.5">
              {(Object.keys(PRI) as P[]).map((p) => (
                <button type="button" key={p} onClick={() => setPri(p)} className={cn("h-10 rounded-xl border px-3.5 text-[13px] font-semibold transition cursor-pointer", pri === p ? "text-ink-950" : "border-white/8 text-mute hover:text-bone")} style={pri === p ? { background: PRI[p].color, borderColor: PRI[p].color } : undefined}>{PRI[p].label}</button>
              ))}
            </div>
            <Btn className="ml-auto" disabled={!title.trim()}><Plus size={16} /> Add task</Btn>
          </div>
        </form>
      </Card>

      <div className="mb-4 flex items-center justify-between">
        <Seg value={tab} onChange={setTab} options={[{ id: "open", label: `Open · ${open.length}` }, { id: "done", label: `Done · ${done.length}` }]} />
        <span className="text-xs text-dim">+5 coins per completed task</span>
      </div>

      {list.length === 0 ? (
        <Empty icon={<ListChecks size={22} />} title={tab === "open" ? "A clean slate" : "Nothing finished yet"} sub={tab === "open" ? "Add your first task above. Small and specific works best." : "Completed tasks land here."} />
      ) : (
        <div className="flex flex-col gap-2">
          {list.map((t) => (
            <div key={t.id} className="group surface flex items-center gap-3 p-3.5 pr-4" style={{ animation: "rise .3s both" }}>
              <button aria-label={t.done ? "Mark open" : "Complete"} onClick={() => actions.toggleTask(t.id)}
                className={cn("grid h-7 w-7 shrink-0 place-items-center rounded-full border-2 transition cursor-pointer", t.done ? "border-mint bg-mint text-ink-950" : "border-white/25 hover:border-mint")}>{t.done && <Check size={14} strokeWidth={3} />}</button>
              <div className="min-w-0 flex-1">
                <div className={cn("truncate text-[15px] font-medium", t.done && "text-dim line-through")}>{t.title}</div>
                <div className="mt-1.5 flex items-center gap-3">
                  <div className="flex gap-1">{Array.from({ length: t.est }).map((_, i) => <span key={i} className="h-1.5 w-4 rounded-full" style={{ background: i < t.spent ? "var(--color-ember)" : "rgba(255,255,255,0.12)" }} />)}</div>
                  <span className="text-xs text-dim">{t.spent}/{t.est} blocks</span>
                  <span className="flex items-center gap-1 text-[11px] font-semibold" style={{ color: PRI[t.priority].color }}><span className="h-1.5 w-1.5 rounded-full" style={{ background: PRI[t.priority].color }} />{PRI[t.priority].label}</span>
                </div>
              </div>
              {!t.done && <Btn size="sm" variant="soft" onClick={() => { actions.setTask(t.id); go("/focus"); }}><Play size={13} fill="currentColor" /> Focus</Btn>}
              <button aria-label="Delete" onClick={() => actions.removeTask(t.id)} className="text-dim opacity-0 transition hover:text-rose group-hover:opacity-100 focus:opacity-100 cursor-pointer max-sm:opacity-100"><Trash2 size={16} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
