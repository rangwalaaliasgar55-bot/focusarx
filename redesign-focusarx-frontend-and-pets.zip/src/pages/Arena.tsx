import { useEffect, useMemo, useReducer, useRef, useState } from "react";
import { ArrowLeft, Check, Coins, Lock, Shield, Swords, Timer, Trophy, Zap, RefreshCw, LogOut } from "lucide-react";
import { actions, toast, useStore } from "../lib/store";
import {
  ARENA, PET_MAP, TYPE_COLOR, effectiveness, movesFor, power, statsFor,
  type ArenaStage, type Move, type PetDef, type Stats,
} from "../lib/pets";
import { BattleSprite, PetPortrait } from "../components/PetImg";
import { Bar, Btn, Card, Confetti, Eyebrow, PageHead, TypeBadge } from "../components/ui";
import { cn } from "../utils/cn";
import { sfx } from "../lib/audio";
import { go } from "../lib/router";

// ───────────────────────── Engine types ─────────────────────────
interface Fighter {
  id: string; def: PetDef; level: number; stats: Stats; hp: number; maxHp: number; moves: Move[]; pp: number[]; name: string;
}
const make = (id: string, level: number, nick?: string): Fighter => {
  const def = PET_MAP[id];
  const stats = statsFor(def, level);
  const moves = movesFor(def.type);
  return { id, def, level, stats, hp: stats.hp, maxHp: stats.hp, moves, pp: moves.map((m) => m.pp), name: nick ?? def.name };
};

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));
const BG: Record<number, [string, string, string]> = {
  1: ["#2b4a3a", "#16261e", "#4d7a52"], 2: ["#4a2f2b", "#1e1414", "#8a4a35"], 3: ["#1f3a52", "#101c28", "#2c6a8f"],
  4: ["#3a3158", "#16122a", "#5a4aa0"], 5: ["#2a3f55", "#0e1621", "#4f7fa8"], 6: ["#4a3a1f", "#1a1408", "#c79b3b"],
};

type Anim = "" | "lunge" | "hit" | "faint" | "heal" | "enter";
interface BState {
  stage: ArenaStage; team: Fighter[]; cur: number; foes: Fighter[]; foeIdx: number;
  msg: string; busy: boolean; phase: "intro" | "choose" | "switch" | "won" | "lost";
  anim: { p: Anim; f: Anim }; proj: { from: "p" | "f"; color: string; key: number } | null;
  floats: { id: number; side: "p" | "f"; text: string; tone: string }[]; flash: boolean; turn: number;
}

// ───────────────────────── Hub ─────────────────────────
export default function Arena() {
  const s = useStore();
  const ownedIds = Object.keys(s.pets);
  const sorted = useMemo(() => [...ownedIds].sort((a, b) => power(PET_MAP[b], s.pets[b].level) - power(PET_MAP[a], s.pets[a].level)), [ownedIds.join(","), s.pets]); // eslint-disable-line
  const [team, setTeam] = useState<string[]>([]);
  const [fight, setFight] = useState<ArenaStage | null>(null);
  const [round, setRound] = useState(0);
  const defaultTeam = useMemo(() => {
    const first = s.active && s.pets[s.active] ? [s.active] : [];
    return [...first, ...sorted.filter((x) => x !== s.active)].slice(0, 3);
  }, [sorted, s.active, s.pets]);
  const squad = team.length ? team.filter((t) => s.pets[t]) : defaultTeam;

  const toggle = (id: string) => {
    const base = squad;
    if (base.includes(id)) { if (base.length > 1) setTeam(base.filter((x) => x !== id)); }
    else if (base.length < 3) setTeam([...base, id]);
    else toast("Your squad is full (3 max)", "warn");
  };

  const enter = (stage: ArenaStage) => {
    if (!squad.length) return;
    if (!actions.spendEnergy(stage.energy)) { toast("Not enough energy — finish a focus session first", "warn"); return; }
    setFight(stage);
  };

  if (fight) {
    return <Battle key={round} stage={fight} squad={squad} onExit={() => setFight(null)} onRetry={() => { if (actions.spendEnergy(fight.energy)) { setRound((r) => r + 1); } else { toast("Not enough energy for a rematch", "warn"); setFight(null); } }} />;
  }

  return (
    <div className="mx-auto max-w-6xl px-4 pb-32 pt-8 sm:px-8 lg:pb-16">
      <PageHead eyebrow="Arena" title="Focus Arena" sub="Your focus minutes become energy. Spend it to battle through six cups with a squad of three companions."
        right={
          <div className="surface flex items-center gap-4 px-5 py-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-mint/15 text-mint"><Zap size={20} /></div>
            <div><div className="font-display text-2xl font-extrabold tabular leading-none">{s.energy}<span className="text-sm text-dim"> / 100</span></div><div className="text-xs text-mute">Arena energy</div></div>
            <Btn size="sm" variant="soft" onClick={() => go("/focus")}><Timer size={14} /> Recharge</Btn>
          </div>
        } />

      {/* Squad */}
      <Card className="mb-8">
        <div className="mb-4 flex items-center justify-between"><Eyebrow>Your squad · {squad.length}/3</Eyebrow><span className="text-xs text-dim">Tap to add or remove</span></div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">
          {sorted.map((id) => {
            const d = PET_MAP[id]; const o = s.pets[id]; const idx = squad.indexOf(id);
            return (
              <button key={id} onClick={() => toggle(id)} className={cn("relative flex flex-col items-center rounded-2xl border p-3 transition cursor-pointer", idx >= 0 ? "border-ember bg-ember/8" : "border-white/7 bg-white/3 hover:border-white/20")}>
                {idx >= 0 && <span className="absolute left-2 top-2 grid h-5 w-5 place-items-center rounded-full bg-ember text-[11px] font-bold text-ink-950">{idx + 1}</span>}
                <PetPortrait def={d} size={84} />
                <div className="mt-1 max-w-full truncate text-[13px] font-bold">{o.nickname ?? d.name}</div>
                <div className="text-[11px] text-mute">Lv {o.level} · PWR {Math.round(power(d, o.level))}</div>
                <TypeBadge type={d.type} className="mt-1.5" />
              </button>
            );
          })}
        </div>
      </Card>

      {/* Ladder */}
      <Eyebrow className="mb-3">The ladder</Eyebrow>
      <div className="grid gap-4 md:grid-cols-2">
        {ARENA.map((st) => {
          const locked = st.id > s.arena.cleared + 1;
          const done = s.arena.cleared >= st.id;
          const [c1, , c3] = BG[st.id];
          const lead = squad[0] ? Math.round(power(PET_MAP[squad[0]], s.pets[squad[0]].level)) : 0;
          const foePow = Math.round(power(PET_MAP[st.foes[1]], st.level + 1));
          const diff = lead / foePow;
          return (
            <div key={st.id} className={cn("relative overflow-hidden rounded-3xl border p-5", locked ? "border-white/6 opacity-60" : "border-white/10")} style={{ background: `linear-gradient(135deg, ${c1}55, transparent 65%), #14171d` }}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-[11px] font-bold uppercase tracking-[0.16em]" style={{ color: c3 }}>Cup {st.id}</div>
                  <h3 className="font-display text-2xl font-extrabold">{st.name}</h3>
                  <p className="mt-1 text-sm text-mute">{st.blurb}</p>
                </div>
                {done ? <span className="grid h-9 w-9 place-items-center rounded-full bg-mint text-ink-950"><Check size={18} strokeWidth={3} /></span> : locked ? <Lock size={18} className="text-dim" /> : null}
              </div>
              <div className="mt-4 flex items-center -space-x-2">
                {st.foes.map((f) => <div key={f} className="grid h-12 w-12 place-items-center overflow-hidden rounded-full border-2 border-ink-900 bg-ink-800"><PetPortrait def={PET_MAP[f]} size={44} className="scale-125" /></div>)}
                <span className="pl-4 text-xs text-mute">Foes Lv {st.level}–{st.level + 2}</span>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-sm">
                <span className="flex items-center gap-1.5 text-mint"><Zap size={14} />{st.energy}</span>
                <span className="flex items-center gap-1.5 text-gold"><Coins size={14} />{st.coins}{!done && <span className="text-xs text-dim">(+{st.coins} first clear)</span>}</span>
                {!locked && <span className={cn("text-xs font-semibold", diff > 1.15 ? "text-mint" : diff > 0.85 ? "text-gold" : "text-rose")}>{diff > 1.15 ? "Favoured" : diff > 0.85 ? "Even match" : "Tough"}</span>}
              </div>
              <Btn className="mt-5 w-full" variant={locked ? "soft" : "primary"} disabled={locked || !squad.length} onClick={() => enter(st)}>
                {locked ? <><Lock size={15} /> Clear Cup {st.id - 1} first</> : <><Swords size={16} /> {done ? "Fight again" : "Enter cup"}</>}
              </Btn>
            </div>
          );
        })}
      </div>
      <div className="mt-6 flex flex-wrap gap-6 text-sm text-mute">
        <span className="flex items-center gap-2"><Trophy size={15} className="text-gold" /> {s.arena.wins} wins</span>
        <span className="flex items-center gap-2"><Shield size={15} /> {s.arena.losses} losses</span>
        <span>Tip: Water beats Fire, Fire beats Grass, Grass beats Water. Electric shocks Water. Psychic, Ghost and Dark play their own game.</span>
      </div>
    </div>
  );
}

// ───────────────────────── Battle ─────────────────────────
function Battle({ stage, squad, onExit, onRetry }: { stage: ArenaStage; squad: string[]; onExit: () => void; onRetry: () => void }) {
  const store = useStore();
  const [, force] = useReducer((x: number) => x + 1, 0);
  const alive = useRef(true);
  const B = useRef<BState | null>(null);
  const fid = useRef(1);
  const result = useRef<{ coins: number; xp: number; first: boolean } | null>(null);

  if (!B.current) {
    const team = squad.map((id) => make(id, store.pets[id].level, store.pets[id].nickname));
    const foes = stage.foes.map((id, i) => make(id, stage.level + i));
    B.current = { stage, team, cur: 0, foes, foeIdx: 0, msg: "", busy: true, phase: "intro", anim: { p: "enter", f: "enter" }, proj: null, floats: [], flash: false, turn: 0 };
  }
  const b = B.current;
  const upd = () => { if (alive.current) force(); };
  const say = async (text: string, ms = 950) => { b.msg = text; upd(); await sleep(ms); };
  const setAnim = (side: "p" | "f", a: Anim, ms = 500) => { b.anim[side] = a; upd(); return sleep(ms).then(() => { if (a !== "faint" && b.anim[side] === a) b.anim[side] = ""; upd(); }); };
  const float = (side: "p" | "f", text: string, tone: string) => {
    const id = fid.current++; b.floats.push({ id, side, text, tone }); upd();
    setTimeout(() => { b.floats = b.floats.filter((f) => f.id !== id); upd(); }, 1100);
  };

  const me = () => b.team[b.cur];
  const foe = () => b.foes[b.foeIdx];

  useEffect(() => {
    alive.current = true;
    (async () => {
      await sleep(500);
      await say(`${stage.name} — Round 1!`, 1100);
      await say(`${foe().name} wants to battle!`, 1100);
      await say(`Go, ${me().name}!`, 800);
      b.anim = { p: "", f: "" }; b.phase = "choose"; b.busy = false; b.msg = `What will ${me().name} do?`; upd();
    })();
    return () => { alive.current = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ——— damage
  function calc(att: Fighter, def: Fighter, mv: Move, isPlayer: boolean) {
    const eff = effectiveness(mv.type, def.def.type);
    const stab = mv.type === att.def.type ? 1.25 : 1;
    const critChance = 0.06 + (isPlayer && att.level >= 18 ? 0.05 : 0);
    const crit = Math.random() < critChance;
    const base = ((mv.power * att.stats.atk) / def.stats.def) * 0.55 + 5;
    const dmg = Math.max(1, Math.round(base * stab * eff * (0.88 + Math.random() * 0.12) * (crit ? 1.5 : 1)));
    return { dmg, eff, crit };
  }

  async function act(attSide: "p" | "f", mi: number) {
    const att = attSide === "p" ? me() : foe();
    const def = attSide === "p" ? foe() : me();
    const dSide = attSide === "p" ? "f" : "p";
    const mv = att.moves[mi];
    att.pp[mi] = Math.max(0, att.pp[mi] - 1);
    await say(`${attSide === "f" ? "Foe " : ""}${att.name} used ${mv.name}!`, 700);
    if (mv.kind === "heal") {
      const amt = Math.round(att.maxHp * 0.35);
      att.hp = Math.min(att.maxHp, att.hp + amt);
      sfx.heal(); float(attSide, `+${amt}`, "#4fe0b5");
      await setAnim(attSide, "heal", 700); await sleep(200);
      return;
    }
    b.anim[attSide] = "lunge"; upd();
    await sleep(180);
    if (Math.random() * 100 > mv.acc) {
      sfx.miss(); float(dSide, "Miss", "#9aa0ad");
      await say(`${att.name}'s attack missed!`, 800);
      b.anim[attSide] = ""; upd();
      return;
    }
    b.proj = { from: attSide, color: TYPE_COLOR[mv.type], key: fid.current++ }; upd();
    await sleep(330);
    b.proj = null;
    const { dmg, eff, crit } = calc(att, def, mv, attSide === "p");
    crit ? sfx.crit() : sfx.hit();
    def.hp = Math.max(0, def.hp - dmg);
    b.flash = true; float(dSide, `-${dmg}`, crit ? "#ffc857" : eff > 1 ? "#ff6b81" : "#f3eee6");
    b.anim[attSide] = ""; void setAnim(dSide, "hit", 520); upd();
    setTimeout(() => { b.flash = false; upd(); }, 180);
    await sleep(520);
    if (crit) await say("A critical hit!", 750);
    if (eff > 1) await say("It's super effective!", 850);
    else if (eff < 1) await say("It's not very effective…", 850);
  }

  function foePick(): number {
    const f = foe(), p = me();
    const opts = f.moves.map((m, i) => ({ m, i })).filter((x) => f.pp[x.i] > 0);
    if (!opts.length) return 2;
    if (f.hp / f.maxHp < 0.3) { const h = opts.find((o) => o.m.kind === "heal"); if (h && Math.random() < 0.55) return h.i; }
    const scored = opts.filter((o) => o.m.kind === "attack").map((o) => ({ i: o.i, s: o.m.power * (o.m.acc / 100) * effectiveness(o.m.type, p.def.type) * (o.m.type === f.def.type ? 1.25 : 1) }));
    if (!scored.length) return opts[0].i;
    if (Math.random() < 0.22) return scored[Math.floor(Math.random() * scored.length)].i;
    return scored.sort((a, c) => c.s - a.s)[0].i;
  }

  async function afterFaint(side: "p" | "f"): Promise<"continue" | "end"> {
    if (side === "f") {
      await setAnim("f", "faint", 700); b.anim.f = "faint";
      await say(`Foe ${foe().name} fainted!`, 1000);
      if (b.foeIdx + 1 >= b.foes.length) { await win(); return "end"; }
      b.foeIdx++; b.anim.f = "enter"; sfx.click();
      await say(`Foe sends out ${foe().name}!`, 1000); b.anim.f = ""; upd();
      return "continue";
    }
    await setAnim("p", "faint", 700); b.anim.p = "faint";
    await say(`${me().name} fainted!`, 1000);
    const next = b.team.findIndex((x) => x.hp > 0);
    if (next < 0) { await lose(); return "end"; }
    b.phase = "switch"; b.busy = false; b.msg = "Choose your next companion"; upd();
    return "end";
  }

  async function win() {
    b.phase = "won"; b.msg = "You won the match!"; sfx.win();
    const first = store.arena.cleared < stage.id;
    result.current = { coins: stage.coins + (first ? stage.coins : 0), xp: stage.xp, first };
    actions.battleResult(stage.id, true, squad[0]);
    upd();
  }
  async function lose() {
    b.phase = "lost"; b.msg = "You blacked out…"; sfx.lose();
    actions.battleResult(stage.id, false, squad[0]);
    upd();
  }

  async function turn(mi: number) {
    if (b.busy || b.phase !== "choose") return;
    b.busy = true; b.turn++; upd();
    const fi = foePick();
    const pm = me().moves[mi];
    const fm = foe().moves[fi];
    const pFirst = pm.kind === "heal" ? false : fm.kind === "heal" ? true : me().stats.spd * (0.9 + Math.random() * 0.2) >= foe().stats.spd * (0.9 + Math.random() * 0.2);
    const order: ("p" | "f")[] = pFirst ? ["p", "f"] : ["f", "p"];
    for (const side of order) {
      if (!alive.current) return;
      if (me().hp <= 0 || foe().hp <= 0) break;
      await act(side, side === "p" ? mi : fi);
      if (foe().hp <= 0) { const r = await afterFaint("f"); if (r === "end") return; break; }
      if (me().hp <= 0) { const r = await afterFaint("p"); if (r === "end") return; break; }
    }
    if (!alive.current) return;
    b.phase = "choose"; b.busy = false; b.msg = `What will ${me().name} do?`; upd();
  }

  async function switchTo(i: number, forced = false) {
    if (b.busy && !forced) return;
    if (b.team[i].hp <= 0 || (i === b.cur && !forced)) return;
    b.busy = true; b.phase = "choose"; upd();
    if (!forced) await say(`Come back, ${me().name}!`, 700);
    b.cur = i; b.anim.p = "enter"; upd(); sfx.click();
    await say(`Go, ${me().name}!`, 800); b.anim.p = ""; upd();
    if (!forced) {
      // switching costs the turn
      const fi = foePick();
      await act("f", fi);
      if (me().hp <= 0) { const r = await afterFaint("p"); if (r === "end") return; }
    }
    b.phase = "choose"; b.busy = false; b.msg = `What will ${me().name} do?`; upd();
  }

  const p = me(), f = foe();
  const [c1, c2, c3] = BG[stage.id];
  const hpColor = (x: Fighter) => (x.hp / x.maxHp > 0.5 ? "var(--color-mint)" : x.hp / x.maxHp > 0.2 ? "var(--color-gold)" : "var(--color-rose)");
  const animStyle = (side: "p" | "f"): React.CSSProperties => {
    const a = b.anim[side];
    if (a === "lunge") return { animation: `${side === "p" ? "lunge-right" : "lunge-left"} .45s ease-in-out` };
    if (a === "hit") return { animation: "hit-blink .5s linear" };
    if (a === "faint") return { animation: "faint .7s ease-in forwards" };
    if (a === "heal") return { animation: "heal-glow .7s ease-in-out" };
    if (a === "enter") return { animation: `${side === "p" ? "enter-left" : "enter-right"} .6s cubic-bezier(.2,.9,.3,1) both` };
    return {};
  };
  const foeEff = (m: Move) => (m.kind === "attack" ? effectiveness(m.type, f.def.type) : 1);
  const small = typeof window !== "undefined" && window.innerWidth < 640;

  const panel = (x: Fighter, side: "p" | "f") => (
    <div className={cn("surface-solid w-full rounded-2xl p-3 shadow-xl", side === "p" ? "self-end" : "")} style={{ background: "rgba(14,16,20,0.88)", backdropFilter: "blur(8px)" }}>
      <div className="flex items-center justify-between gap-2"><span className="truncate text-sm font-bold">{x.name}</span><span className="text-[11px] font-semibold text-mute">Lv {x.level}</span></div>
      <div className="mb-2 mt-1"><TypeBadge type={x.def.type} /></div>
      <Bar value={x.hp} max={x.maxHp} color={hpColor(x)} h={8} />
      {side === "p" && <div className="mt-1 text-right text-[11px] tabular text-mute">{x.hp} / {x.maxHp}</div>}
    </div>
  );

  return (
    <div className="mx-auto max-w-4xl px-3 pb-32 pt-4 sm:px-6 lg:pb-12">
      {b.phase === "won" && <Confetti />}
      <div className="mb-3 flex items-center justify-between">
        <button onClick={onExit} className="flex items-center gap-1.5 text-sm text-mute hover:text-bone cursor-pointer"><ArrowLeft size={16} /> Leave arena</button>
        <div className="text-xs font-semibold uppercase tracking-[0.16em] text-dim">{stage.name} · Foe {b.foeIdx + 1}/{b.foes.length}</div>
        <div className="flex gap-1.5">{b.team.map((t, i) => <span key={i} className={cn("h-2.5 w-2.5 rounded-full", t.hp > 0 ? "bg-mint" : "bg-rose/60", i === b.cur && "ring-2 ring-bone/60")} />)}</div>
      </div>

      {/* Field */}
      <div className="relative aspect-[16/11] w-full overflow-hidden rounded-[28px] border border-white/10 sm:aspect-[16/9]" style={{ background: `linear-gradient(180deg, ${c1} 0%, ${c2} 62%, ${c2} 100%)` }}>
        <div className="absolute inset-x-0 top-[44%] h-[56%]" style={{ background: `linear-gradient(180deg, ${c3}55, ${c2})` }} />
        <div className="absolute -left-[10%] top-[28%] h-[36%] w-[60%] rounded-[100%] opacity-40" style={{ background: c3 }} />
        <div className="absolute -right-[10%] top-[22%] h-[40%] w-[60%] rounded-[100%] opacity-30" style={{ background: c3 }} />
        <div className="absolute left-[8%] top-[68%] h-[16%] w-[36%] rounded-[100%] border border-white/10" style={{ background: `radial-gradient(ellipse, ${c3}aa, ${c3}33)` }} />
        <div className="absolute right-[8%] top-[34%] h-[11%] w-[30%] rounded-[100%] border border-white/10" style={{ background: `radial-gradient(ellipse, ${c3}aa, ${c3}33)` }} />
        <div className={cn("pointer-events-none absolute inset-0 bg-white transition-opacity duration-150", b.flash ? "opacity-25" : "opacity-0")} />

        {/* foe */}
        <div className="absolute right-[10%] top-[34%] -translate-y-full" style={{ ...animStyle("f"), left: "auto" }}>
          <div className="relative flex items-end justify-center" style={{ width: "clamp(110px, 24vw, 200px)", height: "clamp(110px, 24vw, 200px)" }}>
            <BattleSprite def={f.def} side="front" scale={small ? 1.25 : 2} size={small ? 100 : 150} className="object-contain object-bottom" key={f.id + b.foeIdx} />
            {b.floats.filter((x) => x.side === "f").map((x) => <span key={x.id} className="absolute -top-2 left-1/2 -translate-x-1/2 font-display text-2xl font-extrabold" style={{ color: x.tone, animation: "float-up 1.1s ease-out forwards", textShadow: "0 2px 8px #000" }}>{x.text}</span>)}
          </div>
        </div>
        {/* player */}
        <div className="absolute left-[12%] top-[80%] -translate-y-full" style={animStyle("p")}>
          <div className="relative flex items-end justify-center" style={{ width: "clamp(130px, 30vw, 250px)", height: "clamp(130px, 30vw, 250px)" }}>
            <BattleSprite def={p.def} side="back" scale={small ? 1.5 : 2.4} size={small ? 120 : 190} className="object-contain object-bottom" key={p.id + b.cur} />
            {b.floats.filter((x) => x.side === "p").map((x) => <span key={x.id} className="absolute -top-2 left-1/2 -translate-x-1/2 font-display text-2xl font-extrabold" style={{ color: x.tone, animation: "float-up 1.1s ease-out forwards", textShadow: "0 2px 8px #000" }}>{x.text}</span>)}
          </div>
        </div>
        {/* projectile */}
        {b.proj && <div key={b.proj.key} className="pointer-events-none absolute h-9 w-9 rounded-full" style={{ background: `radial-gradient(circle, #fff, ${b.proj.color} 55%, transparent 72%)`, boxShadow: `0 0 30px ${b.proj.color}`, animation: `${b.proj.from === "p" ? "shoot-up" : "shoot-down"} .34s ease-in forwards` }} />}

        {/* panels */}
        <div className="absolute left-3 top-3 w-[46%] max-w-[260px] sm:w-[34%]">{panel(f, "f")}</div>
        <div className="absolute bottom-3 right-3 w-[46%] max-w-[260px] sm:w-[34%]">{panel(p, "p")}</div>
      </div>

      {/* Message */}
      <div className="surface-solid mt-3 flex min-h-[64px] items-center rounded-2xl px-5 py-3 text-[15px] font-medium" key={b.msg} style={{ animation: "rise .25s both" }}>{b.msg || "…"}</div>

      {/* Controls */}
      {(b.phase === "choose" || b.phase === "intro") && (
        <div className="mt-3 grid gap-2">
          <div className="grid grid-cols-2 gap-2">
            {p.moves.map((m, i) => {
              const e = foeEff(m); const out = p.pp[i] <= 0;
              return (
                <button key={m.id} disabled={b.busy || out} onClick={() => void turn(i)}
                  className="group relative overflow-hidden rounded-2xl border border-white/10 bg-ink-800 p-3.5 text-left transition hover:border-white/30 hover:bg-ink-700 active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none cursor-pointer">
                  <span className="absolute inset-y-0 left-0 w-1.5" style={{ background: m.kind === "heal" ? "#4fe0b5" : TYPE_COLOR[m.type] }} />
                  <div className="flex items-center justify-between pl-2"><span className="text-[15px] font-bold">{m.name}</span>{e > 1 && <span className="rounded-full bg-mint/20 px-2 py-0.5 text-[10px] font-bold text-mint">×2</span>}{e < 1 && <span className="rounded-full bg-rose/20 px-2 py-0.5 text-[10px] font-bold text-rose">×½</span>}</div>
                  <div className="mt-1 flex items-center justify-between pl-2 text-[11px] text-mute"><span className="capitalize">{m.kind === "heal" ? "Heal 35%" : `${m.type} · ${m.power}`}</span><span className="tabular">PP {p.pp[i]}/{m.pp}</span></div>
                </button>
              );
            })}
          </div>
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {b.team.map((t, i) => (
              <button key={i} disabled={b.busy || t.hp <= 0 || i === b.cur} onClick={() => void switchTo(i)}
                className={cn("flex min-w-[150px] flex-1 items-center gap-2 rounded-xl border px-2.5 py-2 text-left text-xs transition disabled:pointer-events-none cursor-pointer", i === b.cur ? "border-ember/50 bg-ember/8" : t.hp > 0 ? "border-white/10 bg-white/4 hover:bg-white/8" : "border-white/5 bg-white/2 opacity-40")}>
                <PetPortrait def={t.def} size={34} />
                <div className="min-w-0 flex-1"><div className="flex items-center justify-between"><span className="truncate font-semibold">{t.name}</span><RefreshCw size={11} className="text-dim" /></div><Bar value={t.hp} max={t.maxHp} color={hpColor(t)} h={4} className="mt-1" /></div>
              </button>
            ))}
          </div>
        </div>
      )}

      {b.phase === "switch" && (
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          {b.team.map((t, i) => (
            <button key={i} disabled={t.hp <= 0} onClick={() => void switchTo(i, true)} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-ink-800 p-3 text-left transition hover:border-ember/50 disabled:opacity-30 disabled:pointer-events-none cursor-pointer">
              <PetPortrait def={t.def} size={48} /><div className="flex-1"><div className="text-sm font-bold">{t.name}</div><Bar value={t.hp} max={t.maxHp} color={hpColor(t)} h={5} className="mt-1.5" /></div>
            </button>
          ))}
        </div>
      )}

      {(b.phase === "won" || b.phase === "lost") && (
        <div className="surface-solid mt-3 rounded-3xl p-6 text-center" style={{ animation: "pop .4s both" }}>
          <div className="mb-1 font-display text-3xl font-extrabold">{b.phase === "won" ? "Victory!" : "Defeated"}</div>
          {b.phase === "won" && result.current ? (
            <div className="mb-5 mt-2 flex flex-wrap items-center justify-center gap-5 text-sm">
              <span className="flex items-center gap-1.5 font-semibold text-gold"><Coins size={16} />+{result.current.coins}</span>
              <span className="flex items-center gap-1.5 font-semibold text-sky"><Zap size={16} />+{result.current.xp} bond XP</span>
              {result.current.first && <span className="rounded-full bg-gold/15 px-3 py-1 text-xs font-bold text-gold">First clear bonus</span>}
            </div>
          ) : (
            <p className="mb-5 mt-2 text-sm text-mute">Raise bond levels, feed your pets and pick type matchups. You earned 8 coins for trying.</p>
          )}
          <div className="flex flex-wrap justify-center gap-2">
            <Btn onClick={onRetry}><Swords size={16} /> Rematch <span className="flex items-center text-xs opacity-70"><Zap size={11} />{stage.energy}</span></Btn>
            {b.phase === "won" && stage.id < ARENA.length && <Btn variant="mint" onClick={onExit}>Next cup</Btn>}
            <Btn variant="soft" onClick={onExit}><LogOut size={15} /> Back to arena</Btn>
          </div>
        </div>
      )}
    </div>
  );
}
