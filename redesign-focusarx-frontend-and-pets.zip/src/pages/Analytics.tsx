import { useMemo } from "react";
import { BarChart3, Clock, Flame, Target, TrendingUp } from "lucide-react";
import { actions, addDays, dateKey, minutesByDay, todayKey, totalMinutes, useStore } from "../lib/store";
import { Btn, Card, Empty, Eyebrow, PageHead, fmtMin } from "../components/ui";
import { cn } from "../utils/cn";

const DOW = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

export default function Analytics() {
  const s = useStore();
  const byDay = useMemo(() => minutesByDay(s), [s.sessions]); // eslint-disable-line
  const total = totalMinutes(s);

  const data = useMemo(() => {
    const hours = new Array(24).fill(0);
    const dow = new Array(7).fill(0);
    for (const x of s.sessions) { const d = new Date(x.at); hours[d.getHours()] += x.minutes; dow[(d.getDay() + 6) % 7] += x.minutes; }
    const peakH = hours.indexOf(Math.max(...hours));
    const peakD = dow.indexOf(Math.max(...dow));
    const avg = s.sessions.length ? Math.round(s.sessions.reduce((a, x) => a + x.score, 0) / s.sessions.length) : 0;
    const activeDays = Object.keys(byDay).length;
    const best = Math.max(0, ...Object.values(byDay));
    const t = todayKey();
    const last30 = Array.from({ length: 30 }, (_, i) => byDay[addDays(t, i - 29)] ?? 0);
    const consistency = Math.round((last30.filter((x) => x > 0).length / 30) * 100);
    return { hours, dow, peakH, peakD, avg, activeDays, best, last30, consistency };
  }, [s.sessions, byDay]);

  // heatmap — 18 weeks ending this week
  const heat = useMemo(() => {
    const t = todayKey();
    const todayDow = (new Date(t + "T12:00:00").getDay() + 6) % 7;
    const start = addDays(t, -(17 * 7 + todayDow));
    const cols: { k: string; min: number; future: boolean }[][] = [];
    for (let w = 0; w < 18; w++) cols.push(Array.from({ length: 7 }, (_, d) => { const k = addDays(start, w * 7 + d); return { k, min: byDay[k] ?? 0, future: k > t }; }));
    return cols;
  }, [byDay]);

  if (!s.sessions.length) {
    return (
      <div className="mx-auto max-w-3xl px-4 pb-32 pt-8 sm:px-8 lg:pb-16">
        <PageHead eyebrow="Analytics" title="Your focus, in numbers" />
        <Empty icon={<BarChart3 size={22} />} title="No sessions to analyse yet" sub="Finish your first session and your patterns appear here: peak hours, best weekdays, and a day-by-day heatmap. Want to preview the page first?"
          action={<div className="flex gap-2"><Btn onClick={() => { window.location.hash = "/focus"; }}>Start a session</Btn><Btn variant="soft" onClick={() => actions.loadDemo()}>Load sample data</Btn></div>} />
      </div>
    );
  }

  const maxH = Math.max(1, ...data.hours), maxD = Math.max(1, ...data.dow), max30 = Math.max(30, ...data.last30);
  const hLabel = (h: number) => `${h % 12 === 0 ? 12 : h % 12}${h < 12 ? "am" : "pm"}`;
  const heatColor = (m: number) => (m === 0 ? "rgba(255,255,255,0.05)" : m < 30 ? "rgba(255,122,69,0.3)" : m < 60 ? "rgba(255,122,69,0.55)" : m < 120 ? "rgba(255,122,69,0.8)" : "#ff7a45");

  return (
    <div className="mx-auto max-w-6xl px-4 pb-32 pt-8 sm:px-8 lg:pb-16">
      <PageHead eyebrow="Analytics" title="Your focus, in numbers" sub="Everything here is computed from your own sessions, stored on this device." />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { l: "Total focus", v: fmtMin(total), i: Clock, c: "text-ember", sub: `${s.sessions.length} sessions` },
          { l: "Avg. focus score", v: String(data.avg), i: Target, c: "text-mint", sub: "out of 100" },
          { l: "Best day", v: fmtMin(data.best), i: TrendingUp, c: "text-sky", sub: `${data.activeDays} active days` },
          { l: "Consistency", v: `${data.consistency}%`, i: Flame, c: "text-gold", sub: "of the last 30 days" },
        ].map((x) => (
          <Card key={x.l} className="p-5"><div className="flex items-center gap-2 text-sm text-mute"><x.i size={16} className={x.c} /> {x.l}</div><div className="mt-2 font-display text-4xl font-extrabold tabular">{x.v}</div><div className="mt-1 text-xs text-dim">{x.sub}</div></Card>
        ))}
      </div>

      <Card className="mt-5">
        <div className="mb-4 flex items-center justify-between"><Eyebrow>Last 18 weeks</Eyebrow><div className="flex items-center gap-1.5 text-[11px] text-dim">Less {[0, 20, 45, 90, 150].map((m) => <span key={m} className="h-3 w-3 rounded-[3px]" style={{ background: heatColor(m) }} />)} More</div></div>
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          <div className="flex flex-col justify-between py-0.5 pr-1 text-[10px] text-dim">{DOW.map((d, i) => <span key={d} className="h-[18px] leading-[18px]" style={{ visibility: i % 2 ? "hidden" : "visible" }}>{d}</span>)}</div>
          {heat.map((col, i) => (
            <div key={i} className="flex flex-col gap-1">
              {col.map((c) => <div key={c.k} title={`${c.k}: ${c.min} min`} className={cn("h-[18px] w-[18px] rounded-[4px] transition hover:scale-125", c.k === todayKey() && "ring-1 ring-bone/70")} style={{ background: c.future ? "transparent" : heatColor(c.min) }} />)}
            </div>
          ))}
        </div>
      </Card>

      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        <Card>
          <div className="mb-1 flex items-center justify-between"><Eyebrow>Focus DNA · by hour</Eyebrow></div>
          <p className="mb-5 text-sm text-mute">Your brain is sharpest around <b className="text-bone">{hLabel(data.peakH)}</b>. Schedule the hardest work there.</p>
          <div className="flex h-40 items-end gap-[3px]">
            {data.hours.map((m, h) => (
              <div key={h} className="group relative flex flex-1 flex-col items-center justify-end" style={{ height: "100%" }}>
                <div className={cn("w-full rounded-t-[4px] transition-all", h === data.peakH ? "bg-ember" : "bg-white/20 group-hover:bg-white/40")} style={{ height: `${Math.max(m ? 5 : 2, (m / maxH) * 100)}%`, opacity: m ? 1 : 0.4 }} />
                <span className="pointer-events-none absolute -top-6 rounded bg-ink-700 px-1.5 py-0.5 text-[10px] opacity-0 group-hover:opacity-100">{hLabel(h)} · {m}m</span>
              </div>
            ))}
          </div>
          <div className="mt-2 flex justify-between text-[10px] text-dim"><span>12am</span><span>6am</span><span>12pm</span><span>6pm</span><span>11pm</span></div>
        </Card>

        <Card>
          <Eyebrow>By weekday</Eyebrow>
          <p className="mb-5 mt-1 text-sm text-mute">Strongest day: <b className="text-bone">{["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"][data.peakD]}</b>.</p>
          <div className="flex flex-col gap-2.5">
            {DOW.map((d, i) => (
              <div key={d} className="flex items-center gap-3 text-xs"><span className="w-8 text-mute">{d}</span>
                <div className="h-6 flex-1 overflow-hidden rounded-lg bg-white/5"><div className={cn("h-full rounded-lg transition-all duration-700", i === data.peakD ? "bg-mint" : "bg-white/25")} style={{ width: `${(data.dow[i] / maxD) * 100}%` }} /></div>
                <span className="w-12 text-right font-semibold tabular">{fmtMin(data.dow[i])}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card className="mt-5">
        <Eyebrow className="mb-4">Last 30 days</Eyebrow>
        <div className="flex h-36 items-end gap-1">
          {data.last30.map((m, i) => {
            const k = addDays(todayKey(), i - 29);
            return <div key={k} title={`${k}: ${m}m`} className={cn("flex-1 rounded-t-[4px] transition-all hover:opacity-80", k === todayKey() ? "bg-ember" : m ? "bg-white/35" : "bg-white/8")} style={{ height: `${Math.max(3, (m / max30) * 100)}%` }} />;
          })}
        </div>
        <div className="mt-2 flex justify-between text-[10px] text-dim"><span>{new Date(addDays(todayKey(), -29) + "T12:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" })}</span><span>Today</span></div>
      </Card>

      <Card className="mt-5">
        <Eyebrow className="mb-3">Recent sessions</Eyebrow>
        <div className="divide-y divide-white/5">
          {[...s.sessions].reverse().slice(0, 8).map((r) => (
            <div key={r.id} className="flex items-center justify-between py-3 text-sm">
              <div><div className="font-medium">{r.task ?? "Focus session"}</div><div className="text-xs text-dim">{dateKey(r.at) === todayKey() ? "Today" : new Date(r.at).toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })} · {new Date(r.at).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}{r.early ? " · ended early" : ""}</div></div>
              <div className="flex items-center gap-4"><span className="rounded-full bg-white/6 px-2.5 py-0.5 text-xs font-semibold text-mute">score {r.score}</span><span className="w-12 text-right font-semibold tabular">{r.minutes}m</span></div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
