import { useEffect } from "react";
import { actions, getState, setCheckinOpen, toast, todayKey, useStore } from "./lib/store";
import { useRoute, go } from "./lib/router";
import Layout from "./components/Layout";
import { CheckinModal, ResultModal } from "./components/Modals";
import { Toasts, fmtClock } from "./components/ui";
import { playAmbient, sfx, stopAmbient } from "./lib/audio";
import Landing from "./pages/Landing";
import Start from "./pages/Start";
import Dashboard from "./pages/Dashboard";
import Focus from "./pages/Focus";
import Tasks from "./pages/Tasks";
import Pets from "./pages/Pets";
import Arena from "./pages/Arena";
import Missions from "./pages/Missions";
import Analytics from "./pages/Analytics";
import Settings from "./pages/Settings";

const PAGES: Record<string, () => React.ReactElement> = {
  "/dashboard": Dashboard, "/focus": Focus, "/tasks": Tasks, "/pets": Pets,
  "/arena": Arena, "/missions": Missions, "/analytics": Analytics, "/settings": Settings,
};

export default function App() {
  const s = useStore();
  const route = useRoute();
  const onboarded = s.onboarded;

  // Route guard
  useEffect(() => {
    if (!onboarded && route !== "/" && route !== "/start") go("/");
    else if (onboarded && (route === "/" || route === "/start" || !PAGES[route])) go("/dashboard");
  }, [route, onboarded]);

  // Surface the daily reward once per browser session
  useEffect(() => {
    if (!onboarded || route !== "/dashboard") return;
    if (sessionStorage.getItem("fx.checkin-shown")) return;
    sessionStorage.setItem("fx.checkin-shown", "1");
    if (getState().checkin.last !== todayKey()) setTimeout(() => setCheckinOpen(true), 700);
  }, [onboarded, route]);

  // Global clock: completes the timer from any page, even in a background tab
  useEffect(() => {
    if (!onboarded) return;
    const check = () => {
      const t = getState().timer;
      if (t.status === "running" && t.endsAt && Date.now() >= t.endsAt) {
        const wasFocus = t.mode === "focus";
        const reward = actions.completeTimer(false);
        const st = getState().settings;
        if (st.chime) (wasFocus ? sfx.chime : sfx.breakChime)();
        if (st.notify && "Notification" in window && Notification.permission === "granted") {
          new Notification(wasFocus ? "Focus session complete" : "Break is over", { body: wasFocus ? `Nice — ${reward?.minutes ?? ""} minutes banked.` : "Ready for the next round?" });
        }
        if (!wasFocus) toast("Break over — ready when you are", "info");
      }
    };
    check();
    const id = setInterval(check, 500);
    document.addEventListener("visibilitychange", check);
    return () => { clearInterval(id); document.removeEventListener("visibilitychange", check); };
  }, [onboarded]);

  // Ambient sound follows the timer
  const { status, mode } = s.timer;
  useEffect(() => {
    if (status === "running" && s.settings.sound !== "off") playAmbient(s.settings.sound, s.settings.volume);
    else stopAmbient();
  }, [status, mode, s.settings.sound, s.settings.volume]);

  // Tab title
  useEffect(() => {
    if (status !== "running") { document.title = "FocusArx — Focus Timer with 3D Pet Companions"; return; }
    const tick = () => {
      const t = getState().timer;
      if (t.endsAt) document.title = `${fmtClock(t.endsAt - Date.now())} · ${t.mode === "focus" ? "Focus" : "Break"} — FocusArx`;
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [status]);

  if (!onboarded) {
    return route === "/start" ? <Start /> : <Landing />;
  }

  const Page = PAGES[route];
  return (
    <>
      <Layout>{Page ? <Page /> : null}</Layout>
      <ResultModal />
      <CheckinModal />
      <Toasts />
    </>
  );
}
