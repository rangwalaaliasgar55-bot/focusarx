import { useEffect, useState } from "react";
import * as THREE from "three";
import { artwork, showdownBack, showdownFront, type PetDef } from "../lib/pets";
import { createCritter } from "./three/critter";
import { setupLights } from "./three/subject";
import { webglOk } from "./three/Pet3D";

// ——— Offscreen snapshotter for original 3D critters ———
let snapRenderer: THREE.WebGLRenderer | null = null;
let snapScene: THREE.Scene | null = null;
let snapCam: THREE.PerspectiveCamera | null = null;
const cache = new Map<string, string>();
const pending = new Map<string, Promise<string>>();

function ensure() {
  if (snapRenderer) return;
  const c = document.createElement("canvas");
  snapRenderer = new THREE.WebGLRenderer({ canvas: c, antialias: true, alpha: true, preserveDrawingBuffer: true });
  snapRenderer.setSize(360, 360, false);
  snapRenderer.setPixelRatio(1);
  snapRenderer.setClearColor(0x000000, 0);
  snapRenderer.toneMapping = THREE.ACESFilmicToneMapping;
  snapRenderer.outputColorSpace = THREE.SRGBColorSpace;
  snapScene = new THREE.Scene();
  setupLights(snapScene, snapRenderer);
  snapCam = new THREE.PerspectiveCamera(28, 1, 0.1, 50);
  snapCam.position.set(0, 2.0, 9.8);
  snapCam.lookAt(0, 1.7, 0);
}

export function snapshot(def: PetDef, view: "front" | "back"): Promise<string> {
  const key = `${def.id}:${view}`;
  const hit = cache.get(key);
  if (hit) return Promise.resolve(hit);
  const p = pending.get(key);
  if (p) return p;
  const job = new Promise<string>((resolve) => {
    // yield to the browser so lists paint first
    setTimeout(() => {
      try {
        ensure();
        const crit = createCritter(def.species!, def.palette!);
        crit.root.scale.setScalar(1.15);
        crit.root.rotation.y = view === "back" ? Math.PI : 0.18;
        snapScene!.add(crit.root);
        crit.tick(1.2, 0.016, { lx: 0, ly: 0, mood: "idle" });
        snapRenderer!.render(snapScene!, snapCam!);
        const url = snapRenderer!.domElement.toDataURL("image/png");
        snapScene!.remove(crit.root);
        crit.dispose();
        cache.set(key, url);
        resolve(url);
      } catch { resolve(""); }
    }, 0);
  });
  pending.set(key, job);
  return job;
}

export function usePetSrc(def: PetDef, view: "front" | "back" = "front"): string {
  const [src, setSrc] = useState(() => (def.kind === "mon" ? artwork(def.dex!) : cache.get(`${def.id}:${view}`) ?? ""));
  useEffect(() => {
    let alive = true;
    if (def.kind === "mon") { setSrc(artwork(def.dex!)); return; }
    if (!webglOk()) { setSrc(""); return; }
    snapshot(def, view).then((u) => { if (alive) setSrc(u); });
    return () => { alive = false; };
  }, [def, view]);
  return src;
}

/** Static portrait — official artwork for Pokémon, 3D render for original critters. */
export function PetPortrait({ def, className = "", size = 96 }: { def: PetDef; className?: string; size?: number }) {
  const src = usePetSrc(def);
  return src ? (
    <img src={src} alt={def.name} width={size} height={size} loading="lazy" draggable={false} className={`object-contain select-none ${className}`} />
  ) : (
    <div className={`animate-pulse rounded-full bg-white/5 ${className}`} style={{ width: size, height: size }} />
  );
}

/** Battle sprite — animated showdown sprites for Pokémon, 3D snapshots for critters. */
export function BattleSprite({ def, side, className = "", scale = 0, size = 150 }: { def: PetDef; side: "front" | "back"; className?: string; scale?: number; size?: number }) {
  const snap = usePetSrc(def, side);
  const [failed, setFailed] = useState(false);
  const [dim, setDim] = useState<{ w: number; h: number } | null>(null);
  useEffect(() => { setFailed(false); setDim(null); }, [def.id, side]);
  if (def.kind === "mon" && !failed) {
    // Animated sprites come in many native sizes; scale them up uniformly so they sit well on the field.
    const style = scale && dim ? { width: dim.w * scale, height: dim.h * scale } : undefined;
    return (
      <img
        src={side === "front" ? showdownFront(def.showdown!) : showdownBack(def.showdown!)}
        alt={def.name}
        draggable={false}
        onLoad={(e) => setDim({ w: e.currentTarget.naturalWidth, h: e.currentTarget.naturalHeight })}
        onError={() => setFailed(true)}
        className={`select-none ${scale ? "max-w-none" : ""} ${className}`}
        style={{ ...style, visibility: scale && !dim ? "hidden" : "visible" }}
      />
    );
  }
  const src = def.kind === "mon" ? artwork(def.dex!) : snap;
  return src ? <img src={src} alt={def.name} draggable={false} className={`select-none object-contain ${className}`} style={scale ? { width: size, height: size, maxWidth: "none", animation: "float 3.6s ease-in-out infinite" } : { animation: "float 3.6s ease-in-out infinite" }} /> : <div className={className} style={scale ? { width: size, height: size } : undefined} />;
}
