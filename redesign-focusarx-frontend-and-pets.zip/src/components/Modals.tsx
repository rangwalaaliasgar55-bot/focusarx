import { useEffect } from "react";
import { Coins, Flame, Gift, Heart, Swords, Trophy, Zap, Sparkles } from "lucide-react";
import { CHECKIN_REWARDS, actions, addDays, closeResult, setCheckinOpen, todayKey, useStore, useUI, toast } from "../lib/store";
import { Btn, Confetti, Modal, Ring } from "./ui";
import Pet3D from "./three/Pet3D";
import { PET_MAP } from "../lib/pets";
import { go } from "../lib/router";
import { cn } from "../utils/cn";
import { sfx } from "../lib/audio";

export function ResultModal() {
  const { result: r } = useUI();
  useEffect(() => { if (r) { sfx.coin(); if (r.petLevelUp || r.accountLevelUp) setTimeout(() => sfx.levelUp(), 500); } }, [r]);
  if (!r) return null;
  const pet = PET_MAP[r.petId];
  const stat = (icon: React.ReactNode, label: string, value: string, color: string) => (
    <div className="rounded-2xl border border-white/7 bg-white/4 p-3.5 text-center">
      <div className={cn("mx-auto mb-1.5 grid h-8 w-8 place-items-center rounded-lg", color)}>{icon}</div>
      <div className="font-display text-xl font-extrabold tabular">{value}</div>
      <div className="text-[11px] text-mute">{label}</div>
    </div>
  );
  return (
    <>
      {!r.early && <Confetti />}
      <Modal open onClose={closeResult} className="max-w-md overflow-hidden p-0" hideClose>
        <div className="relative">
          <div className="relative h-52" style={{ background: "radial-gradient(ellipse at 50% 80%, rgba(255,122,69,0.3), transparent 70%)" }}>
            {pet && <Pet3D pet={pet} stage={false} mood="cheer" interactive={false} className="h-full w-full" />}
          </div>
          <div className="px-6 pb-6">
            <div className="text-center">
              <h2 className="font-display text-3xl font-extrabold">{r.early ? "Session banked" : "Session complete!"}</h2>
              <p className="mt-1 text-[15px] text-mute">{r.minutes} minutes{r.task ? ` on “${r.task}”` : ""}{r.petName ? ` with ${r.petName}` : ""}</p>
            </div>
            <div className="my-5 flex items-center justify-center gap-5">
              <Ring value={r.score / 100} size={84} stroke={8} color="var(--color-mint)"><div className="text-center"><div className="font-display text-2xl font-extrabold leading-none">{r.score}</div><div className="text-[9px] uppercase tracking-wider text-dim">score</div></div></Ring>
              <div className="text-sm text-mute">
                <div className="flex items-center gap-2"><Flame size={15} className="text-ember" /> <b className="text-bone">{r.streak}</b> day streak</div>
                {r.coinBonus > 0 && <div className="mt-1.5 flex items-center gap-2"><Sparkles size={15} className="text-gold" /> +{r.coinBonus}% bonus applied</div>}
              </div>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {stat(<Coins size={16} />, "Coins", `+${r.coins}`, "bg-gold/15 text-gold")}
              {stat(<Sparkles size={16} />, "XP", `+${r.xp}`, "bg-violet/15 text-violet")}
              {stat(<Zap size={16} />, "Energy", `+${r.energy}`, "bg-mint/15 text-mint")}
              {stat(<Heart size={16} />, "Bond", `+${r.petXp}`, "bg-rose/15 text-rose")}
            </div>
            {(r.petLevelUp || r.accountLevelUp || r.newAchievements.length > 0) && (
              <div className="mt-4 flex flex-col gap-2">
                {r.petLevelUp && <div className="flex items-center gap-2 rounded-xl bg-rose/10 px-3.5 py-2.5 text-sm font-semibold text-rose"><Heart size={15} fill="currentColor" /> {r.petName} reached bond level {r.petLevel}!</div>}
                {r.accountLevelUp && <div className="flex items-center gap-2 rounded-xl bg-violet/10 px-3.5 py-2.5 text-sm font-semibold text-violet"><Sparkles size={15} /> You reached level {r.accountLevel}!</div>}
                {r.newAchievements.map((a) => <div key={a} className="flex items-center gap-2 rounded-xl bg-gold/10 px-3.5 py-2.5 text-sm font-semibold text-gold"><Trophy size={15} /> Achievement: {a}</div>)}
              </div>
            )}
            <div className="mt-5 grid grid-cols-2 gap-2">
              <Btn variant="soft" onClick={() => { closeResult(); go("/arena"); }}><Swords size={16} /> Use energy</Btn>
              <Btn onClick={closeResult}>Continue</Btn>
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
}

export function CheckinModal() {
  const { checkinOpen } = useUI();
  const s = useStore();
  const can = s.checkin.last !== todayKey();
  const alive = s.checkin.last === todayKey() || s.checkin.last === addDays(todayKey(), -1);
  const claimed = !alive ? 0 : s.checkin.last === todayKey() ? ((s.checkin.day - 1) % 7) + 1 : s.checkin.day % 7;
  const close = () => setCheckinOpen(false);
  return (
    <Modal open={checkinOpen} onClose={close} className="max-w-md">
      <div className="mb-1 grid h-12 w-12 place-items-center rounded-2xl bg-ember text-ink-950"><Gift size={24} /></div>
      <h2 className="mt-3 font-display text-2xl font-extrabold">Daily reward</h2>
      <p className="mt-1 text-sm text-mute">{can ? (claimed === 0 && s.checkin.last ? "Your chain reset — start a new one today." : "Come back every day. Day 7 gives a streak freeze.") : "Claimed. Come back tomorrow to keep the chain."}</p>
      <div className="mt-5 grid grid-cols-4 gap-2">
        {CHECKIN_REWARDS.map((r, i) => {
          const done = i < claimed, next = i === claimed && can;
          return (
            <div key={i} className={cn("flex aspect-square flex-col items-center justify-center gap-1 rounded-2xl border p-1 text-center", i === 6 && "col-span-1", done ? "border-mint/30 bg-mint/10 text-mint" : next ? "border-ember bg-ember/10 text-ember" : "border-white/8 text-dim")}>
              <span className="text-[10px] font-bold uppercase opacity-70">Day {i + 1}</span>
              {r.freeze ? <Gift size={18} /> : r.coins ? <Coins size={18} /> : <Zap size={18} />}
              <span className="text-[10px] font-semibold leading-tight">{r.label}</span>
            </div>
          );
        })}
      </div>
      <Btn size="lg" className="mt-6 w-full" disabled={!can} onClick={() => { actions.claimCheckin(); sfx.win(); toast("Reward claimed!", "coin"); close(); }}>{can ? "Claim today's reward" : "Already claimed"}</Btn>
    </Modal>
  );
}
