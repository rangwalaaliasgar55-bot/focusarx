import * as THREE from "three";
import type { Palette, Species } from "../../lib/pets";

export type CritterMood = "idle" | "happy" | "sleep" | "cheer";
export interface CritterCtl { lx: number; ly: number; mood: CritterMood }
export interface Critter {
  root: THREE.Group;
  tick: (t: number, dt: number, c: CritterCtl) => void;
  hop: () => void;
  dispose: () => void;
}

const UNIT = new THREE.SphereGeometry(1, 40, 28);
const toy = (color: string, extra: Partial<THREE.MeshPhysicalMaterialParameters> = {}) =>
  new THREE.MeshPhysicalMaterial({
    color, roughness: 0.52, metalness: 0, clearcoat: 0.35, clearcoatRoughness: 0.45,
    sheen: 0.6, sheenRoughness: 0.5, sheenColor: new THREE.Color(color).lerp(new THREE.Color("#ffffff"), 0.6), ...extra,
  });

export function createCritter(species: Species, pal: Palette): Critter {
  const mats: THREE.Material[] = [];
  const geos: THREE.BufferGeometry[] = [];
  const track = <T extends THREE.BufferGeometry>(g: T) => { geos.push(g); return g; };
  const M = (c: string, e?: Partial<THREE.MeshPhysicalMaterialParameters>) => { const m = toy(c, e); mats.push(m); return m; };

  const isPanda = species === "panda";
  const main = M(isPanda ? pal.belly : pal.body);
  const light = M(isPanda ? pal.belly : pal.belly);
  const limb = M(isPanda ? pal.body : pal.body);
  const accent = M(pal.accent);
  const pink = M("#ff9db1", { sheen: 0.2 });
  const dark = M("#17151d", { roughness: 0.12, clearcoat: 1, clearcoatRoughness: 0.08, sheen: 0 });
  const white = new THREE.MeshBasicMaterial({ color: "#ffffff" }); mats.push(white);
  const eyeWhite = M("#ffffff", { roughness: 0.2, clearcoat: 1 });

  const root = new THREE.Group();
  const bob = new THREE.Group(); root.add(bob);

  const ell = (mat: THREE.Material, sx: number, sy: number, sz: number, x: number, y: number, z: number, parent: THREE.Object3D = bob) => {
    const m = new THREE.Mesh(UNIT, mat); m.scale.set(sx, sy, sz); m.position.set(x, y, z); parent.add(m); return m;
  };
  const cone = (mat: THREE.Material, r: number, h: number, seg = 24) => {
    const g = track(new THREE.ConeGeometry(r, h, seg, 1)); const m = new THREE.Mesh(g, mat); return m;
  };

  type Dim = [number, number, number];
  const cfg: Record<Species, { head: Dim; headY: number; body?: Dim; bodyY?: number; arms?: boolean }> = {
    cat: { head: [0.98, 0.86, 0.88], headY: 1.58, body: [0.7, 0.66, 0.62], bodyY: 0.72, arms: true },
    fox: { head: [0.98, 0.82, 0.9], headY: 1.58, body: [0.68, 0.64, 0.6], bodyY: 0.72, arms: true },
    bunny: { head: [0.88, 0.82, 0.82], headY: 1.55, body: [0.7, 0.68, 0.62], bodyY: 0.72, arms: true },
    dragon: { head: [0.92, 0.84, 0.86], headY: 1.6, body: [0.72, 0.68, 0.64], bodyY: 0.74, arms: true },
    panda: { head: [1.02, 0.88, 0.9], headY: 1.6, body: [0.78, 0.7, 0.68], bodyY: 0.74, arms: true },
    owl: { head: [1.02, 1.08, 0.92], headY: 1.15 },
    penguin: { head: [0.9, 1.18, 0.86], headY: 1.2 },
    slime: { head: [1.12, 0.92, 1.02], headY: 0.92 },
  };
  const c = cfg[species];
  const [hx, hy, hz] = c.head;

  // ——— Body / head
  const head = new THREE.Group(); head.position.set(0, c.headY, c.body ? 0.04 : 0); bob.add(head);
  const headMat = species === "slime"
    ? M(pal.body, { transmission: 0, transparent: true, opacity: 0.92, roughness: 0.15, clearcoat: 1, clearcoatRoughness: 0.1, sheen: 0 })
    : main;
  ell(headMat, hx, hy, hz, 0, 0, 0, head);
  const fz = (x: number, y: number) => hz * Math.sqrt(Math.max(0.02, 1 - (x / hx) ** 2 - (y / hy) ** 2));

  let bodyMesh: THREE.Mesh | null = null;
  if (c.body) {
    const [bx, by, bz] = c.body;
    bodyMesh = ell(main, bx, by, bz, 0, c.bodyY!, 0);
    ell(species === "bunny" || species === "cat" || species === "fox" || species === "dragon" || isPanda ? light : light, bx * 0.68, by * 0.76, 0.3, 0, c.bodyY! - 0.02, bz * 0.74);
  }

  // ——— Face
  const eyes = new THREE.Group(); head.add(eyes);
  const bigEyes = species === "owl";
  const eyeX = hx * (bigEyes ? 0.42 : species === "penguin" ? 0.38 : 0.37);
  const eyeY = hy * (bigEyes ? 0.12 : species === "penguin" ? 0.28 : 0.04);
  const es = bigEyes ? 0.2 : species === "slime" ? 0.15 : 0.115;
  for (const sx of [-1, 1]) {
    const g = new THREE.Group();
    const px = sx * eyeX;
    g.position.set(px, eyeY, fz(px, eyeY) - 0.03);
    if (bigEyes) { ell(eyeWhite, 0.34, 0.34, 0.1, 0, 0, 0, g).position.z = -0.02; const ring = new THREE.Mesh(track(new THREE.TorusGeometry(0.34, 0.035, 12, 40)), accent); ring.position.z = 0.02; g.add(ring); }
    if (species === "penguin") ell(light, 0.3, 0.32, 0.1, 0, -0.02, -0.02, g);
    if (isPanda) { const p = ell(limb, 0.27, 0.34, 0.1, 0, -0.03, -0.03, g); p.rotation.z = sx * 0.45; }
    ell(dark, es, es * 1.28, es * 0.55, 0, 0, bigEyes ? 0.06 : 0.02, g);
    ell(white, es * 0.32, es * 0.32, es * 0.2, es * 0.32, es * 0.42, bigEyes ? 0.1 : 0.06, g);
    ell(white, es * 0.15, es * 0.15, es * 0.1, -es * 0.3, -es * 0.4, bigEyes ? 0.1 : 0.06, g);
    eyes.add(g);
  }
  // cheeks
  if (species !== "slime") for (const sx of [-1, 1]) {
    const px = sx * hx * 0.64, py = -hy * 0.2;
    const m = ell(pink, 0.15, 0.09, 0.04, px, py, fz(px, py) - 0.04, head);
    m.material = pink; m.lookAt(new THREE.Vector3(px * 2, py * 1.2, fz(px, py) * 2)); m.material.transparent = true; (m.material as THREE.MeshPhysicalMaterial).opacity = 0.75;
  } else for (const sx of [-1, 1]) {
    ell(pink, 0.16, 0.09, 0.04, sx * hx * 0.66, -hy * 0.18, fz(sx * hx * 0.66, -hy * 0.18) - 0.05, head);
  }
  // nose + mouth
  const noseY = -hy * (species === "fox" || species === "dragon" ? 0.24 : 0.17);
  if (species !== "owl" && species !== "penguin") {
    const n = ell(species === "fox" || isPanda ? dark : pink, 0.055, 0.04, 0.04, 0, noseY, fz(0, noseY) - 0.01, head);
    n.rotation.x = 0.2;
  }
  const mouthY = species === "owl" || species === "penguin" ? -hy * 0.3 : noseY - 0.1;
  if (species !== "owl" && species !== "penguin") for (const sx of [-1, 1]) {
    const m = new THREE.Mesh(track(new THREE.TorusGeometry(0.05, 0.011, 8, 18, Math.PI)), dark);
    m.rotation.z = Math.PI; m.position.set(sx * 0.05, mouthY, fz(sx * 0.05, mouthY) + 0.005); head.add(m);
  }

  // ——— Limbs
  const arms: THREE.Group[] = [];
  const feet: THREE.Mesh[] = [];
  if (c.body) {
    const [bx] = c.body;
    for (const sx of [-1, 1]) {
      const p = new THREE.Group(); p.position.set(sx * bx * 0.96, c.bodyY! + 0.16, 0.1); bob.add(p);
      ell(isPanda || species === "fox" ? limb : main, 0.15, 0.28, 0.15, sx * 0.04, -0.2, 0, p);
      p.rotation.z = sx * 0.22; arms.push(p);
      feet.push(ell(isPanda || species === "fox" ? limb : main, 0.25, 0.14, 0.34, sx * 0.32, 0.13, 0.26, root));
    }
  }
  // ——— Species extras
  const ears: { g: THREE.Group; base: number; side: number }[] = [];
  const tailPivot = new THREE.Group(); bob.add(tailPivot);
  const wings: { g: THREE.Group; side: number }[] = [];
  let wobble = false;

  const tube = (pts: THREE.Vector3[], r: number, mat: THREE.Material, parent: THREE.Object3D, taper = false) => {
    const curve = new THREE.CatmullRomCurve3(pts);
    const g = track(new THREE.TubeGeometry(curve, 28, r, 12, false));
    if (taper) {
      const pos = g.attributes.position; const seg = 28 + 1; const rad = 12 + 1;
      for (let i = 0; i < seg; i++) {
        const center = curve.getPoint(i / (seg - 1)); const k = 1 - (i / (seg - 1)) * 0.75;
        for (let j = 0; j < rad; j++) {
          const idx = i * rad + j;
          pos.setXYZ(idx, center.x + (pos.getX(idx) - center.x) * k, center.y + (pos.getY(idx) - center.y) * k, center.z + (pos.getZ(idx) - center.z) * k);
        }
      }
      pos.needsUpdate = true; g.computeVertexNormals();
    }
    const m = new THREE.Mesh(g, mat); parent.add(m);
    const end = pts[pts.length - 1];
    if (!taper) ell(mat, r, r, r, end.x, end.y, end.z, parent);
    return m;
  };

  if (species === "cat") {
    for (const sx of [-1, 1]) {
      const g = new THREE.Group(); g.position.set(sx * hx * 0.58, hy * 0.72, 0); head.add(g);
      const o = cone(main, 0.3, 0.58, 4); o.position.y = 0.2; o.rotation.y = Math.PI / 4; g.add(o);
      const i = cone(pink, 0.18, 0.4, 4); i.position.set(0, 0.16, 0.07); i.rotation.y = Math.PI / 4; g.add(i);
      g.rotation.z = -sx * 0.4; ears.push({ g, base: -sx * 0.4, side: sx });
      for (let k = 0; k < 3; k++) {
        const w = new THREE.Mesh(track(new THREE.CylinderGeometry(0.006, 0.006, 0.42, 6)), white);
        w.rotation.z = Math.PI / 2 + sx * (k - 1) * 0.16; w.position.set(sx * (hx * 0.72 + 0.2), -hy * 0.2 + (k - 1) * -0.05, fz(hx * 0.6, 0) * 0.6);
        head.add(w);
      }
    }
    for (let k = -1; k <= 1; k++) { const s = ell(accent, 0.035, 0.12, 0.02, k * 0.13, hy * 0.78, fz(k * 0.13, hy * 0.78) - 0.02, head); s.rotation.z = -k * 0.25; s.rotation.x = -0.5; }
    tailPivot.position.set(0, 0.45, -0.5);
    tube([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0.15, -0.35), new THREE.Vector3(0.12, 0.55, -0.5), new THREE.Vector3(0.34, 0.95, -0.38)], 0.1, main, tailPivot);
  }
  if (species === "fox") {
    for (const sx of [-1, 1]) {
      const g = new THREE.Group(); g.position.set(sx * hx * 0.56, hy * 0.7, 0); head.add(g);
      const o = cone(main, 0.34, 0.8, 4); o.position.y = 0.26; o.rotation.y = Math.PI / 4; g.add(o);
      const t = cone(limb, 0.15, 0.3, 4); t.position.y = 0.62; t.rotation.y = Math.PI / 4; g.add(t);
      const i = cone(light, 0.2, 0.46, 4); i.position.set(0, 0.2, 0.08); i.rotation.y = Math.PI / 4; g.add(i);
      g.rotation.z = -sx * 0.28; ears.push({ g, base: -sx * 0.28, side: sx });
      const px = sx * hx * 0.66, py = -hy * 0.32;
      const cheek = ell(light, 0.36, 0.2, 0.3, px, py, fz(px, py) - 0.12, head); cheek.rotation.z = sx * -0.45;
    }
    ell(light, 0.34, 0.24, 0.26, 0, -hy * 0.3, fz(0, -hy * 0.3) - 0.12, head);
    tailPivot.position.set(0, 0.5, -0.55);
    const t = ell(main, 0.34, 0.34, 0.9, 0, 0.35, -0.55, tailPivot); t.rotation.x = -0.9;
    const tip = ell(light, 0.3, 0.3, 0.38, 0, 0.78, -1.08, tailPivot); tip.rotation.x = -0.9;
  }
  if (species === "bunny") {
    for (const sx of [-1, 1]) {
      const g = new THREE.Group(); g.position.set(sx * hx * 0.36, hy * 0.7, -0.02); head.add(g);
      const o = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.17, 0.78, 8, 20)), main); o.position.y = 0.52; g.add(o);
      const i = new THREE.Mesh(track(new THREE.CapsuleGeometry(0.09, 0.6, 8, 16)), pink); i.position.set(0, 0.5, 0.1); i.scale.z = 0.5; g.add(i);
      g.rotation.z = -sx * 0.16; ears.push({ g, base: -sx * 0.16, side: sx });
    }
    tailPivot.position.set(0, 0.5, -0.55); ell(light, 0.24, 0.24, 0.24, 0, 0, 0, tailPivot);
  }
  if (species === "dragon") {
    for (const sx of [-1, 1]) {
      const h = cone(accent, 0.12, 0.5, 16); h.position.set(sx * hx * 0.42, hy * 0.78, -0.05); h.rotation.set(-0.4, 0, -sx * 0.35); head.add(h);
      const px = 0, py = -hy * 0.2;
      void px; void py;
      ell(dark, 0.025, 0.025, 0.02, sx * 0.1, -hy * 0.22, fz(0, -hy * 0.22) + 0.03, head);
      // wing
      const wg = new THREE.Group(); wg.position.set(sx * 0.42, c.bodyY! + 0.28, -0.42); bob.add(wg);
      const s = new THREE.Shape(); s.moveTo(0, 0); s.bezierCurveTo(0.3, 0.55, 0.9, 0.85, 1.25, 0.65); s.bezierCurveTo(1.1, 0.4, 1.15, 0.3, 1.0, 0.05);
      s.bezierCurveTo(0.85, 0.2, 0.75, 0.15, 0.62, -0.1); s.bezierCurveTo(0.45, 0.05, 0.3, 0.0, 0.15, -0.25); s.lineTo(0, 0);
      const wgGeo = track(new THREE.ExtrudeGeometry(s, { depth: 0.035, bevelEnabled: false }));
      const wm = new THREE.Mesh(wgGeo, new THREE.MeshStandardMaterial({ color: pal.accent, roughness: 0.6, side: THREE.DoubleSide })); mats.push(wm.material as THREE.Material);
      wm.scale.set(sx * 0.62, 0.62, 1); wg.add(wm); wg.rotation.y = sx * 0.5;
      wings.push({ g: wg, side: sx });
    }
    for (let k = 0; k < 3; k++) { const sp = cone(accent, 0.09 - k * 0.012, 0.3, 12); sp.position.set(0, hy * 0.85 - k * 0.0, -0.15 - k * 0.24); sp.rotation.x = -0.9 - k * 0.2; head.add(sp); }
    ell(light, 0.4, 0.28, 0.3, 0, -hy * 0.25, fz(0, -hy * 0.25) - 0.13, head);
    tailPivot.position.set(0, 0.5, -0.5);
    tube([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 0.0, -0.45), new THREE.Vector3(0.18, 0.12, -0.9), new THREE.Vector3(0.45, 0.35, -1.2)], 0.16, main, tailPivot, true);
    const sp = cone(accent, 0.14, 0.34, 4); sp.position.set(0.5, 0.4, -1.28); sp.rotation.set(-1.2, 0, -0.4); tailPivot.add(sp);
  }
  if (species === "owl") {
    for (const sx of [-1, 1]) {
      const g = new THREE.Group(); g.position.set(sx * hx * 0.6, hy * 0.78, 0); head.add(g);
      const o = cone(limb, 0.22, 0.5, 4); o.position.y = 0.2; o.rotation.y = Math.PI / 4; g.add(o);
      g.rotation.z = -sx * 0.5; ears.push({ g, base: -sx * 0.5, side: sx });
      const wg = new THREE.Group(); wg.position.set(sx * hx * 0.94, -0.1, 0); head.add(wg);
      const w = ell(limb, 0.16, 0.62, 0.4, sx * 0.05, -0.32, 0, wg); w.rotation.z = sx * 0.1;
      wg.rotation.z = sx * 0.15; wings.push({ g: wg, side: sx });
      ell(accent, 0.22, 0.1, 0.3, sx * 0.34, -hy - 0.0 + 0.02, 0.28, head);
    }
    ell(light, 0.62, 0.78, 0.4, 0, -hy * 0.32, hz * 0.58, head);
    const beak = cone(accent, 0.09, 0.2, 4); beak.rotation.set(Math.PI / 2, 0, Math.PI / 4); beak.position.set(0, -hy * 0.12, fz(0, -hy * 0.12) + 0.04); head.add(beak);
    tailPivot.position.set(0, -hy * 0.7, -hz * 0.8); ell(limb, 0.3, 0.1, 0.4, 0, 0, -0.1, tailPivot);
    for (let k = -2; k <= 2; k++) ell(accent, 0.09, 0.05, 0.03, k * 0.14, -hy * 0.15 - Math.abs(k) * 0.05, fz(k * 0.14, -hy * 0.15) + 0.14, head);
  }
  if (species === "penguin") {
    ell(light, 0.68, 0.9, 0.45, 0, -hy * 0.16, hz * 0.66, head);
    const beak = cone(accent, 0.1, 0.24, 4); beak.rotation.set(Math.PI / 2, 0, Math.PI / 4); beak.position.set(0, -hy * 0.02, fz(0, -hy * 0.02) + 0.08); beak.scale.y = 1.2; head.add(beak);
    for (const sx of [-1, 1]) {
      const wg = new THREE.Group(); wg.position.set(sx * hx * 0.92, -0.05, 0); head.add(wg);
      const f = ell(main, 0.12, 0.52, 0.28, sx * 0.04, -0.3, 0, wg); f.rotation.z = sx * 0.1;
      wg.rotation.z = sx * 0.35; wings.push({ g: wg, side: sx });
      feet.push(ell(accent, 0.26, 0.09, 0.4, sx * 0.34, 0.09 - c.headY + 0.0 + (c.headY), 0.3, root));
      feet[feet.length - 1].position.y = 0.09;
    }
    for (const sx of [-1, 1]) ell(pink, 0.12, 0.07, 0.03, sx * hx * 0.6, -hy * 0.1, fz(sx * hx * 0.6, -hy * 0.1) - 0.02, head);
    tailPivot.position.set(0, -hy * 0.7, -hz * 0.85); ell(main, 0.16, 0.1, 0.3, 0, 0, 0, tailPivot);
    for (let k = 0; k < 3; k++) { const t = ell(accent, 0.03, 0.12, 0.02, (k - 1) * 0.09, hy * 0.92, 0.1, head); t.rotation.z = (k - 1) * -0.3; }
  }
  if (species === "slime") {
    wobble = true;
    ell(light, 0.3, 0.3, 0.28, 0.2, -0.18, -0.2, head);
    const drop = cone(headMat, 0.2, 0.5, 20); drop.position.set(0.05, hy + 0.12, 0); drop.rotation.z = -0.15; head.add(drop);
    ell(headMat, 0.12, 0.12, 0.12, 0.09, hy + 0.37, 0, head);
    for (const [x, y, r] of [[-0.55, -0.45, 0.07], [0.5, -0.5, 0.05], [0.1, -0.55, 0.04]] as [number, number, number][]) ell(light, r, r, r, x, y, fz(x, y) - 0.08, head);
    ell(headMat, 1.3, 0.12, 1.15, 0, -hy + 0.02, 0, head);
  }
  if (isPanda) {
    for (const sx of [-1, 1]) {
      const g = new THREE.Group(); g.position.set(sx * hx * 0.7, hy * 0.72, -0.05); head.add(g);
      ell(limb, 0.3, 0.3, 0.2, 0, 0.12, 0, g);
      ell(light, 0.12, 0.12, 0.05, 0, 0.12, 0.17, g).material = pink;
      g.rotation.z = -sx * 0.3; ears.push({ g, base: -sx * 0.3, side: sx });
    }
    ell(light, 0.3, 0.22, 0.24, 0, -hy * 0.22, fz(0, -hy * 0.22) - 0.12, head);
    tailPivot.position.set(0, 0.5, -0.6); ell(light, 0.2, 0.2, 0.2, 0, 0, 0, tailPivot);
    // bamboo leaf
    const leaf = ell(accent, 0.07, 0.2, 0.02, 0.0, 0, 0, bob); leaf.position.set(0.92, c.bodyY! - 0.1, 0.52); leaf.rotation.z = -0.5;
  }
  void bodyMesh;

  // ——— Animation
  let blinkT = 2 + Math.random() * 3, blink = 0;
  let hopT = 0;
  let lx = 0, ly = 0;
  const tickFn = (t: number, dt: number, ctl: CritterCtl) => {
    const asleep = ctl.mood === "sleep", happy = ctl.mood === "happy" || ctl.mood === "cheer", cheer = ctl.mood === "cheer";
    lx += (ctl.lx - lx) * Math.min(1, dt * 6); ly += (ctl.ly - ly) * Math.min(1, dt * 6);
    const breath = Math.sin(t * (asleep ? 1.1 : 2.1));
    // hop
    let hopY = 0, sq = 0;
    if (hopT > 0) { hopT += dt / 0.75; if (hopT >= 1) hopT = 0; else { hopY = Math.sin(Math.PI * hopT) * 0.85; sq = hopT < 0.12 ? -hopT * 1.6 : hopT > 0.88 ? -(1 - hopT) * 1.6 : 0.08; } }
    if (cheer && hopT === 0 && Math.sin(t * 3.4) > 0.995) hopT = 0.0001;
    bob.position.y = (asleep ? -0.05 : Math.sin(t * 1.7) * 0.03) + hopY;
    const sy = 1 + breath * (asleep ? 0.02 : 0.016) + sq; const sxz = 1 - (sy - 1) * 0.55;
    bob.scale.set(sxz, sy, sxz);
    // head
    const tiltDown = asleep ? 0.38 : 0;
    head.rotation.y += ((asleep ? 0.12 : lx * 0.55) - head.rotation.y) * Math.min(1, dt * 8);
    head.rotation.x += ((asleep ? tiltDown : -ly * 0.3 + (cheer ? Math.sin(t * 6) * 0.06 : 0)) - head.rotation.x) * Math.min(1, dt * 8);
    head.rotation.z = Math.sin(t * 0.9) * 0.025 + (asleep ? 0.08 : lx * -0.06);
    // eyes
    blinkT -= dt; if (blinkT < 0) { blink = 1; blinkT = 2.2 + Math.random() * 3.5; }
    let closed = 0;
    if (blink > 0) { blink -= dt * 7; closed = Math.sin(Math.max(0, blink) * Math.PI); }
    const eyeScale = asleep ? 0.08 : happy ? Math.max(0.22, 1 - closed * 0.9 - (cheer ? 0.55 : 0.1)) : 1 - closed * 0.95;
    eyes.scale.y += (eyeScale - eyes.scale.y) * Math.min(1, dt * 18);
    eyes.position.x = lx * 0.05; eyes.position.y = ly * 0.03;
    // ears
    for (const e of ears) {
      const tw = Math.sin(t * 0.7 + e.side) > 0.97 ? Math.sin(t * 40) * 0.08 : 0;
      e.g.rotation.z = e.base + tw + (asleep ? -e.side * -0.2 : 0) + (happy ? e.side * -0.06 : 0);
    }
    // tail
    const wag = asleep ? 0.05 : happy ? 0.55 : 0.2;
    tailPivot.rotation.y = Math.sin(t * (happy ? 7 : 2.6)) * wag;
    tailPivot.rotation.z = Math.sin(t * (happy ? 5 : 1.6) + 1) * wag * 0.35;
    // arms / wings
    arms.forEach((a, i) => {
      const side = i === 0 ? -1 : 1;
      a.rotation.z = side * 0.22 + (cheer ? side * -(1.9 + Math.sin(t * 9) * 0.35) : Math.sin(t * 1.7 + i) * 0.04 * side);
    });
    wings.forEach((w) => {
      const flap = cheer ? Math.sin(t * 14) * 0.45 : happy ? Math.sin(t * 8) * 0.18 : Math.sin(t * 2.4) * 0.05;
      if (species === "dragon") w.g.rotation.y = w.side * (0.5 + flap * 0.6);
      else w.g.rotation.z = w.side * (species === "penguin" ? 0.35 : 0.15) + w.side * flap;
    });
    if (wobble) {
      const w = Math.sin(t * 3.2) * 0.035 + (hopT > 0 ? 0.08 : 0);
      head.scale.set(1 + w, 1 - w, 1 + w);
    }
    feet.forEach((f) => { f.scale.y = 1 + (hopT > 0 ? -0.2 : 0); });
  };

  return {
    root,
    tick: tickFn,
    hop: () => { if (hopT === 0) hopT = 0.0001; },
    dispose: () => { mats.forEach((m) => m.dispose()); geos.splice(0).forEach((g) => g.dispose()); },
  };
}
