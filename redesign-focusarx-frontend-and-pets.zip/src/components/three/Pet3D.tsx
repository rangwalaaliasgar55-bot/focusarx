import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { RARITY, TYPE_COLOR, type PetDef } from "../../lib/pets";
import { createSubject, radialTexture, setupLights, type Subject } from "./subject";
import type { CritterMood } from "./critter";

interface Props {
  pet: PetDef;
  mood?: CritterMood;
  className?: string;
  interactive?: boolean;
  stage?: boolean; // pedestal + rings
  aura?: boolean;
  onTap?: () => void;
}

export function webglOk() {
  try {
    const c = document.createElement("canvas");
    return !!(c.getContext("webgl2") || c.getContext("webgl"));
  } catch { return false; }
}

export default function Pet3D({ pet, mood = "idle", className = "", interactive = true, stage = true, aura = false, onTap }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const moodRef = useRef<CritterMood>(mood);
  const tapRef = useRef(onTap);
  const subjectRef = useRef<Subject | null>(null);
  const ctxRef = useRef<{ scene: THREE.Scene; stageColor: (c: string, rc: string) => void } | null>(null);
  const [ok] = useState(webglOk);
  moodRef.current = mood;
  tapRef.current = onTap;

  // Scene (once per mount)
  useEffect(() => {
    const el = host.current;
    if (!el || !ok) return;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.domElement.style.cssText = "width:100%;height:100%;display:block;touch-action:pan-y;";
    el.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(30, 1, 0.1, 100);
    const disposeLights = setupLights(scene, renderer);

    const cleanups: (() => void)[] = [];
    const disposables: { dispose: () => void }[] = [];
    const rig = new THREE.Group(); scene.add(rig);

    // Stage ———
    let pad: THREE.Mesh | null = null, halo: THREE.Mesh | null = null, ring: THREE.Mesh | null = null, dots: THREE.Group | null = null;
    let dotMat: THREE.MeshBasicMaterial | null = null, ringMat: THREE.MeshBasicMaterial | null = null;
    let padTex: THREE.Texture | null = null, haloTex: THREE.Texture | null = null;
    const shadowTex = radialTexture("#000000", 0.55, 0);
    disposables.push(shadowTex);
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 3.2), new THREE.MeshBasicMaterial({ map: shadowTex, transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2; shadow.position.y = stage ? 0.012 : 0.01; rig.add(shadow);

    if (stage) {
      const base = new THREE.Mesh(
        new THREE.CylinderGeometry(2.15, 2.4, 0.4, 72),
        new THREE.MeshPhysicalMaterial({ color: "#1b1e27", roughness: 0.35, metalness: 0.6, clearcoat: 1, clearcoatRoughness: 0.2 }),
      );
      base.position.y = -0.2; rig.add(base);
      const topDisc = new THREE.Mesh(new THREE.CylinderGeometry(1.95, 2.0, 0.02, 72), new THREE.MeshStandardMaterial({ color: "#232733", roughness: 0.6, metalness: 0.2 }));
      topDisc.position.y = 0.005; rig.add(topDisc);
      pad = new THREE.Mesh(new THREE.CircleGeometry(2.0, 64), new THREE.MeshBasicMaterial({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
      pad.rotation.x = -Math.PI / 2; pad.position.y = 0.02; rig.add(pad);
      ringMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.9 });
      ring = new THREE.Mesh(new THREE.RingGeometry(1.86, 1.92, 96), ringMat); ring.rotation.x = -Math.PI / 2; ring.position.y = 0.03; rig.add(ring);
      dots = new THREE.Group(); dots.position.y = 0.05; rig.add(dots);
      dotMat = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.9 });
      const dg = new THREE.SphereGeometry(0.035, 8, 8); disposables.push(dg);
      for (let i = 0; i < 40; i++) { const m = new THREE.Mesh(dg, dotMat); const a = (i / 40) * Math.PI * 2; m.position.set(Math.cos(a) * 1.68, 0, Math.sin(a) * 1.68); dots.add(m); }
    }
    halo = new THREE.Mesh(new THREE.PlaneGeometry(10, 10), new THREE.MeshBasicMaterial({ transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity: 0.5 }));
    halo.position.set(0, 2.1, -2.5); rig.add(halo);

    // Particles ———
    const PN = 46;
    const ppos = new Float32Array(PN * 3), pseed = new Float32Array(PN);
    for (let i = 0; i < PN; i++) { pseed[i] = Math.random(); ppos[i * 3] = (Math.random() - 0.5) * 5; ppos[i * 3 + 1] = Math.random() * 4.2; ppos[i * 3 + 2] = (Math.random() - 0.5) * 3 - 0.5; }
    const pgeo = new THREE.BufferGeometry(); pgeo.setAttribute("position", new THREE.BufferAttribute(ppos, 3));
    const pmat = new THREE.PointsMaterial({ size: 0.07, transparent: true, opacity: 0.8, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true });
    const pts = new THREE.Points(pgeo, pmat); rig.add(pts);
    disposables.push(pgeo, pmat);

    // Aura (max-bond golden ring)
    const auraMat = new THREE.MeshBasicMaterial({ color: "#ffc857", transparent: true, opacity: aura ? 0.55 : 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    const auraMesh = new THREE.Mesh(new THREE.TorusGeometry(1.35, 0.02, 8, 80), auraMat); auraMesh.position.y = 2.0; rig.add(auraMesh);
    disposables.push(auraMat, auraMesh.geometry);

    ctxRef.current = {
      scene,
      stageColor: (typeColor, rarityColor) => {
        padTex?.dispose(); haloTex?.dispose();
        padTex = radialTexture(typeColor, 0.7, 0); haloTex = radialTexture(typeColor, 0.55, 0);
        if (pad) { (pad.material as THREE.MeshBasicMaterial).map = padTex; (pad.material as THREE.MeshBasicMaterial).needsUpdate = true; }
        (halo!.material as THREE.MeshBasicMaterial).map = haloTex; (halo!.material as THREE.MeshBasicMaterial).needsUpdate = true;
        ringMat?.color.set(typeColor); dotMat?.color.set(rarityColor); pmat.color.set(rarityColor);
      },
    };

    // Sizing
    let dist = 9.2;
    const resize = () => {
      const w = el.clientWidth || 1, h = el.clientHeight || 1;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      const a = w / h;
      dist = stage ? 9.8 : 9.4;
      if (a < 1) dist *= 1 + (1 - a) * 0.8;
      camera.position.set(0, stage ? 3.2 : 2.9, dist);
      camera.lookAt(0, stage ? 1.65 : 1.7, 0);
      camera.updateProjectionMatrix();
    };
    const ro = new ResizeObserver(resize); ro.observe(el); resize();

    // Interaction
    const ptr = { x: 0, y: 0, dragging: false, moved: 0, lastX: 0, vel: 0, spin: 0, idle: 0 };
    const onMove = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      ptr.x = ((e.clientX - r.left) / r.width - 0.5) * 2;
      ptr.y = ((e.clientY - r.top) / r.height - 0.5) * 2;
      if (ptr.dragging) { const dx = e.clientX - ptr.lastX; ptr.lastX = e.clientX; ptr.moved += Math.abs(dx); ptr.vel = dx * 0.012; ptr.spin += dx * 0.012; ptr.idle = 0; }
    };
    const onDown = (e: PointerEvent) => { ptr.dragging = true; ptr.moved = 0; ptr.lastX = e.clientX; ptr.vel = 0; try { el.setPointerCapture(e.pointerId); } catch { /* noop */ } };
    const onUp = () => {
      if (ptr.dragging && ptr.moved < 6) { subjectRef.current?.hop(); tapRef.current?.(); }
      ptr.dragging = false;
    };
    const onLeave = () => { if (!ptr.dragging) { ptr.x = 0; ptr.y = 0; } };
    if (interactive) {
      el.addEventListener("pointermove", onMove); el.addEventListener("pointerdown", onDown);
      el.addEventListener("pointerup", onUp); el.addEventListener("pointercancel", onUp); el.addEventListener("pointerleave", onLeave);
      el.style.cursor = "grab";
    }

    // Loop
    let raf = 0, visible = true;
    const io = new IntersectionObserver(([en]) => { visible = en.isIntersecting; }, { threshold: 0 }); io.observe(el);
    const clock = new THREE.Clock();
    const loop = () => {
      raf = requestAnimationFrame(loop);
      if (!visible || document.hidden) { clock.getDelta(); return; }
      const dt = Math.min(clock.getDelta(), 0.05), t = clock.elapsedTime;
      const sub = subjectRef.current;
      if (sub) {
        const m = moodRef.current;
        if (sub.kind === "critter") {
          if (!ptr.dragging) {
            ptr.idle += dt;
            ptr.spin += ptr.vel; ptr.vel *= 0.92;
            if (ptr.idle > 1.2 && Math.abs(ptr.vel) < 0.002) { const target = Math.round(ptr.spin / (Math.PI * 2)) * Math.PI * 2; ptr.spin += (target - ptr.spin) * Math.min(1, dt * 2.2); }
          }
          sub.root.rotation.y = ptr.spin + (m === "sleep" ? 0 : Math.sin(t * 0.5) * 0.06);
        }
        sub.tick(t, dt, { lx: ptr.x, ly: ptr.y, mood: m });
        if (sub.kind === "mon") sub.root.rotation.y = Math.max(-1.1, Math.min(1.1, ptr.spin * 0.4)) * 1.0 + (ptr.dragging ? 0 : 0);
        if (sub.kind === "mon" && !ptr.dragging) { ptr.spin *= 0.94; }
      }
      if (dots) dots.rotation.y = t * 0.25;
      if (ring) ringMat!.opacity = 0.65 + Math.sin(t * 2) * 0.2;
      if (halo) (halo.material as THREE.MeshBasicMaterial).opacity = 0.42 + Math.sin(t * 1.3) * 0.07;
      auraMesh.rotation.set(Math.PI / 2.4, t * 0.6, 0); auraMesh.scale.setScalar(1 + Math.sin(t * 2) * 0.03);
      const arr = pgeo.attributes.position.array as Float32Array;
      for (let i = 0; i < PN; i++) {
        arr[i * 3 + 1] += dt * (0.18 + pseed[i] * 0.3);
        arr[i * 3] += Math.sin(t * 0.6 + pseed[i] * 20) * dt * 0.08;
        if (arr[i * 3 + 1] > 4.6) { arr[i * 3 + 1] = 0.1; arr[i * 3] = (Math.random() - 0.5) * 5; }
      }
      pgeo.attributes.position.needsUpdate = true;
      const lift = sub ? Math.max(0, (sub.root.children[0]?.position.y ?? 0) - 0) : 0; void lift;
      renderer.render(scene, camera);
    };
    loop();

    return () => {
      cancelAnimationFrame(raf); ro.disconnect(); io.disconnect();
      el.removeEventListener("pointermove", onMove); el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointerup", onUp); el.removeEventListener("pointercancel", onUp); el.removeEventListener("pointerleave", onLeave);
      cleanups.forEach((c) => c());
      subjectRef.current?.dispose(); subjectRef.current = null;
      disposables.forEach((d) => d.dispose());
      padTex?.dispose(); haloTex?.dispose();
      disposeLights();
      scene.traverse((o) => { const m = o as THREE.Mesh; if (m.geometry && !disposables.includes(m.geometry)) m.geometry.dispose(); const mat = m.material as THREE.Material | undefined; if (mat && "dispose" in mat) mat.dispose(); });
      renderer.dispose(); renderer.forceContextLoss();
      renderer.domElement.remove();
      ctxRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ok, stage, interactive]);

  // Swap subject when the pet changes
  useEffect(() => {
    const ctx = ctxRef.current;
    if (!ctx || !ok) return;
    subjectRef.current?.dispose();
    if (subjectRef.current) ctx.scene.remove(subjectRef.current.root);
    const s = createSubject(pet);
    ctx.scene.add(s.root);
    subjectRef.current = s;
    ctx.stageColor(TYPE_COLOR[pet.type], RARITY[pet.rarity].color);
    s.hop();
    return () => { /* disposed on swap/unmount */ };
  }, [pet.id, ok, stage, interactive]);

  if (!ok) {
    return (
      <div className={`flex items-center justify-center ${className}`}>
        <img src={pet.kind === "mon" ? `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${pet.dex}.png` : ""} alt={pet.name} className="max-h-full max-w-full object-contain" />
      </div>
    );
  }
  return <div ref={host} className={`relative ${className}`} aria-label={`${pet.name} 3D companion`} role="img" />;
}
