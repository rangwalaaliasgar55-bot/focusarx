import * as THREE from "three";
import { RoomEnvironment } from "three/examples/jsm/environments/RoomEnvironment.js";
import { artwork, type PetDef } from "../../lib/pets";
import { createCritter, type CritterCtl } from "./critter";

export interface Subject {
  root: THREE.Object3D;
  tick: (t: number, dt: number, c: CritterCtl) => void;
  hop: () => void;
  dispose: () => void;
  kind: "critter" | "mon";
}

/** Pokéball-style fallback if artwork can't load (offline etc.). */
function fallbackBall() {
  const g = new THREE.Group();
  const red = new THREE.MeshPhysicalMaterial({ color: "#ee4d4d", roughness: 0.25, clearcoat: 1 });
  const white = new THREE.MeshPhysicalMaterial({ color: "#f5f5f5", roughness: 0.25, clearcoat: 1 });
  const dark = new THREE.MeshStandardMaterial({ color: "#222" });
  const top = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 24, 0, Math.PI * 2, 0, Math.PI / 2), red);
  const bot = new THREE.Mesh(new THREE.SphereGeometry(1, 48, 24, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), white);
  const band = new THREE.Mesh(new THREE.TorusGeometry(1, 0.06, 12, 64), dark); band.rotation.x = Math.PI / 2;
  const btn = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.1, 32), white); btn.rotation.x = Math.PI / 2; btn.position.z = 1;
  g.add(top, bot, band, btn);
  return g;
}

export function createMon(def: PetDef): Subject {
  const root = new THREE.Group();
  const holder = new THREE.Group(); holder.position.y = 1.95; root.add(holder);
  const layersGroup = new THREE.Group(); holder.add(layersGroup);
  const SIZE = 3.5, N = 14, STEP = 0.02;
  const geo = new THREE.PlaneGeometry(SIZE, SIZE);
  const mats: THREE.MeshBasicMaterial[] = [];
  let fb: THREE.Group | null = null;
  const tex = new THREE.TextureLoader().setCrossOrigin("anonymous").load(
    artwork(def.dex!),
    (t) => { t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; mats.forEach((m) => { m.needsUpdate = true; }); },
    undefined,
    () => { layersGroup.visible = false; fb = fallbackBall(); fb.scale.setScalar(1.25); holder.add(fb); },
  );
  tex.colorSpace = THREE.SRGBColorSpace;
  for (let i = 0; i < N; i++) {
    const k = i === 0 ? 1 : 0.28 + 0.12 * (1 - i / N);
    const m = new THREE.MeshBasicMaterial({ map: tex, transparent: true, alphaTest: 0.45, color: new THREE.Color(k, k, k * 1.05), side: THREE.DoubleSide });
    mats.push(m);
    const p = new THREE.Mesh(geo, m); p.position.z = -i * STEP + (N * STEP) / 2; layersGroup.add(p);
  }
  let hopT = 0, ry = 0, rx = 0, lx = 0, ly = 0;
  return {
    kind: "mon",
    root,
    tick: (t, dt, ctl) => {
      lx += (ctl.lx - lx) * Math.min(1, dt * 5); ly += (ctl.ly - ly) * Math.min(1, dt * 5);
      let hy = 0, sq = 0;
      if (hopT > 0) { hopT += dt / 0.7; if (hopT >= 1) hopT = 0; else { hy = Math.sin(Math.PI * hopT) * 0.9; sq = hopT < 0.15 ? -hopT * 0.9 : hopT > 0.85 ? -(1 - hopT) * 0.9 : 0.06; } }
      const asleep = ctl.mood === "sleep", cheer = ctl.mood === "cheer";
      if (cheer && hopT === 0 && Math.sin(t * 3.1) > 0.992) hopT = 0.0001;
      const amp = asleep ? 0.03 : 0.09;
      holder.position.y = 1.95 + Math.sin(t * (asleep ? 1 : 1.7)) * amp + hy + (asleep ? -0.12 : 0);
      ry += ((lx * 0.55 + Math.sin(t * 0.6) * 0.1) - ry) * Math.min(1, dt * 6);
      rx += ((-ly * 0.18 + (asleep ? 0.12 : 0)) - rx) * Math.min(1, dt * 6);
      holder.rotation.set(rx, ry, Math.sin(t * 1.1) * 0.015 + (cheer ? Math.sin(t * 9) * 0.05 : 0));
      const b = 1 + Math.sin(t * 2.1) * 0.012 + sq;
      holder.scale.set(1 - (b - 1) * 0.6, b, 1);
    },
    hop: () => { if (hopT === 0) hopT = 0.0001; },
    dispose: () => { geo.dispose(); tex.dispose(); mats.forEach((m) => m.dispose()); },
  };
}

export function createSubject(def: PetDef): Subject {
  if (def.kind === "mon") return createMon(def);
  const c = createCritter(def.species!, def.palette!);
  const s = 1.15; c.root.scale.setScalar(s);
  return { kind: "critter", root: c.root, tick: c.tick, hop: c.hop, dispose: c.dispose };
}

export function setupLights(scene: THREE.Scene, renderer: THREE.WebGLRenderer) {
  const pm = new THREE.PMREMGenerator(renderer);
  const envScene = new RoomEnvironment();
  const env = pm.fromScene(envScene, 0.04).texture;
  scene.environment = env;
  scene.environmentIntensity = 0.55;
  const key = new THREE.DirectionalLight("#fff1dd", 2.4); key.position.set(3.5, 6, 5); scene.add(key);
  const rim = new THREE.DirectionalLight("#8fb9ff", 2.2); rim.position.set(-5, 3.5, -4); scene.add(rim);
  const fill = new THREE.HemisphereLight("#ffffff", "#403a50", 0.55); scene.add(fill);
  return () => { env.dispose(); pm.dispose(); envScene.traverse((o) => { const m = o as THREE.Mesh; if (m.geometry) m.geometry.dispose(); }); };
}

export function radialTexture(color: string, inner = 0.9, outer = 0) {
  const c = document.createElement("canvas"); c.width = c.height = 256;
  const g = c.getContext("2d")!;
  const gr = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  gr.addColorStop(0, hexA(color, inner)); gr.addColorStop(0.55, hexA(color, inner * 0.35)); gr.addColorStop(1, hexA(color, outer));
  g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function hexA(hex: string, a: number) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}
