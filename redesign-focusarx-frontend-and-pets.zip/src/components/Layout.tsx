import { useState, type ReactNode } from "react";
import { LayoutDashboard, Timer, ListChecks, PawPrint, Swords, Target, BarChart3, Settings, Flame, Zap, Coins, Gift, MoreHorizontal, X } from "lucide-react";
import { cn } from "../utils/cn";
import { go, useRoute } from "../lib/router";
import { accountLevel, accountLevelFloor, effectiveStreak, setCheckinOpen, todayKey, useStore } from "../lib/store";
import { PET_MAP } from "../lib/pets";
import { PetPortrait } from "./PetImg";

export function Logo({ size = 28, text = true }: { size?: number; text?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
        <circle cx="16" cy="16" r="14" stroke="#f3eee6" strokeWidth="2" />
        <g transform="translate(16 16)">
          {[0, 60, 120, 180, 240, 300].map((a) => (
            <path key={a} d="M0 -3 L8.5 -9.5 L11 -5 Z" fill={a % 120 === 0 ? "#ff7a45" : "#f3eee6"} transform={`rotate(${a})`} />
          ))}
        </g>
        <circle cx="16" cy="16" r="2.6" fill="#0a0b0e" />
      </svg>
      {text && <span className="font-display text-xl font-extrabold tracking-tight">Focus<span className="text-ember">Arx</span></span>}
    </div>
  );
}

export const NAV = [
  { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { path: "/focus", label: "Focus", icon: Timer },
  { path: "/tasks", label: "Tasks", icon: ListChecks },
  { path: "/pets", label: "Companions", icon: PawPrint },
  { path: "/arena", label: "Arena", icon: Swords },
  { path: "/missions", label: "Missions", icon: Target },
  { path: "/analytics", label: "Analytics", icon: BarChart3 },
  { path: "/settings", label: "Settings", icon: Settings },
];

function Chips() {
  const s = useStore();
  const st = effectiveStreak(s);
  const canCheckin = s.checkin.last !== todayKey();
  return (
    <div className="flex items-center gap-2">
      <div className={cn("flex h-9 items-center gap-1.5 rounded-full border px-3 text-sm font-bold tabular", st.count > 0 ? "border-ember/30 bg-ember/10 text-ember" : "border-white/8 bg-white/4 text-mute")} title="Day streak">
        <Flame size={15} className={st.atRisk ? "animate-pulse-soft" : ""} /> {st.count}
      </div>
      <div className="hidden h-9 items-center gap-1.5 rounded-full border border-mint/20 bg-mint/10 px-3 text-sm font-bold text-mint tabular sm:flex" title="Arena energy">
        <Zap size={15} /> {s.energy}
      </div>
      <div className="flex h-9 items-center gap-1.5 rounded-full border border-gold/20 bg-gold/10 px-3 text-sm font-bold text-gold tabular" title="Coins">
        <Coins size={15} /> {s.coins.toLocaleString()}
      </div>
      <button onClick={() => setCheckinOpen(true)} aria-label="Daily reward" className="relative grid h-9 w-9 place-items-center rounded-full border border-white/8 bg-white/4 text-bone transition hover:bg-white/10 cursor-pointer">
        <Gift size={16} />
        {canCheckin && <span className="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full bg-ember ring-2 ring-ink-950" />}
      </button>
    </div>
  );
}

export default function Layout({ children, immersive }: { children: ReactNode; immersive?: boolean }) {
  const route = useRoute();
  const s = useStore();
  const [more, setMore] = useState(false);
  const lvl = accountLevel(s.xp);
  const floor = accountLevelFloor(lvl), next = accountLevelFloor(lvl + 1);
  const pet = s.pets[s.active] ? PET_MAP[s.active] : null;

  const mobile = [NAV[0], NAV[1], NAV[3], NAV[4]];
  return (
    <div className="min-h-screen lg:pl-64">
      {/* Sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-white/6 bg-ink-950 p-4 lg:flex">
        <button onClick={() => go("/dashboard")} className="mb-8 mt-2 px-2 text-left cursor-pointer"><Logo /></button>
        <nav className="flex flex-1 flex-col gap-1">
          {NAV.map((n) => {
            const on = route === n.path;
            return (
              <button key={n.path} onClick={() => go(n.path)}
                className={cn("group relative flex h-11 items-center gap-3 rounded-xl px-3 text-[14px] font-semibold transition cursor-pointer", on ? "bg-white/8 text-bone" : "text-mute hover:bg-white/5 hover:text-bone")}>
                {on && <span className="absolute -left-4 top-2 h-7 w-1 rounded-r-full bg-ember" />}
                <n.icon size={18} className={on ? "text-ember" : ""} />
                {n.label}
              </button>
            );
          })}
        </nav>
        <div className="surface mt-4 flex items-center gap-3 p-3">
          <div className="relative grid h-14 w-14 shrink-0 place-items-center overflow-hidden rounded-2xl bg-white/5">
            {pet ? <PetPortrait def={pet} size={52} className="scale-110" /> : null}
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-bold">{s.name || "Focuser"}</div>
            <div className="mb-1.5 text-xs text-mute">Level {lvl}</div>
            <div className="h-1.5 overflow-hidden rounded-full bg-white/8"><div className="h-full rounded-full bg-ember transition-all" style={{ width: `${((s.xp - floor) / (next - floor)) * 100}%` }} /></div>
          </div>
        </div>
      </aside>

      {/* Top bar */}
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-white/6 bg-ink-950/80 px-4 backdrop-blur-xl sm:px-8">
        <button onClick={() => go("/dashboard")} className="lg:hidden cursor-pointer"><Logo size={26} /></button>
        <div className="hidden text-sm text-mute lg:block">
          {new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
        </div>
        <Chips />
      </header>

      <main data-immersive={immersive ? "" : undefined}>{children}</main>

      {/* Mobile nav */}
      <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-white/8 bg-ink-950/90 px-2 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden">
        {mobile.map((n) => {
          const on = route === n.path;
          return (
            <button key={n.path} onClick={() => go(n.path)} className={cn("flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px] font-semibold cursor-pointer", on ? "text-ember" : "text-mute")}>
              <n.icon size={21} /> {n.label === "Companions" ? "Pets" : n.label}
            </button>
          );
        })}
        <button onClick={() => setMore(true)} className="flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px] font-semibold text-mute cursor-pointer"><MoreHorizontal size={21} />More</button>
      </nav>
      {more && (
        <div className="fixed inset-0 z-[70] lg:hidden" onClick={() => setMore(false)}>
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
          <div className="surface-solid absolute inset-x-0 bottom-0 rounded-b-none rounded-t-3xl p-5" style={{ animation: "rise .3s ease-out both" }} onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between"><span className="font-display text-lg font-bold">Everything</span><button onClick={() => setMore(false)} aria-label="Close"><X size={20} /></button></div>
            <div className="grid grid-cols-3 gap-2">
              {NAV.map((n) => (
                <button key={n.path} onClick={() => { go(n.path); setMore(false); }} className="flex flex-col items-center gap-2 rounded-2xl bg-white/5 py-4 text-xs font-semibold cursor-pointer"><n.icon size={22} className="text-ember" />{n.label}</button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
