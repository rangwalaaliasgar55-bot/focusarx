import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { fmtClock } from "./ui";
import type { Mode } from "../lib/store";
import { PET_MAP } from "../lib/pets";
import { BattleSprite } from "./PetImg";

export interface FaceProps {
  ms: number; total: number; running: boolean; mode: Mode; petId?: string; label?: string; preview?: boolean;
}
export const ACCENT: Record<Mode, string> = { focus: "#ff7a45", short: "#4fe0b5", long: "#6cb6ff" };
export const MODE_LABEL: Record<Mode, string> = { focus: "Focus", short: "Short break", long: "Long break" };

export const FACES: { id: string; name: string; desc: string }[] = [
  { id: "aurora", name: "Aurora", desc: "Glowing ring with a live tick scale" },
  { id: "flip", name: "Flip", desc: "Mechanical split-flap clock" },
  { id: "orbit", name: "Orbit", desc: "A planet circling its star" },
  { id: "hourglass", name: "Hourglass", desc: "Real falling sand" },
  { id: "trail", name: "Companion Trail", desc: "Your pet walks to the finish flag" },
  { id: "segment", name: "Segment", desc: "Retro LCD with glowing digits" },
  { id: "garden", name: "Garden", desc: "Grow a flower while you focus" },
];

const Wrap = ({ children, className = "" }: { children: ReactNode; className?: string }) => (
  <div className={`relative w-full ${className}`} style={{ containerType: "inline-size" }}>{children}</div>
);

// ═══════════════ 1 · AURORA ═══════════════
function Aurora({ ms, total, running, mode, label }: FaceProps) {
  const acc = ACCENT[mode];
  const p = total ? 1 - ms / total : 0;
  const R = 168, C = 2 * Math.PI * R;
  const ang = p * Math.PI * 2 - Math.PI / 2;
  const hx = 200 + R * Math.cos(ang), hy = 200 + R * Math.sin(ang);
  return (
    <Wrap className="mx-auto aspect-square max-w-[520px]">
      <div className="absolute inset-[8%] rounded-full opacity-60 blur-3xl" style={{ background: `conic-gradient(from ${p * 360}deg, ${acc}55, #a98bff33, #4fe0b533, ${acc}55)`, animation: running ? "spin-slow 24s linear infinite" : undefined }} />
      <svg viewBox="0 0 400 400" className="relative w-full">
        <defs>
          <linearGradient id="ag" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={acc} /><stop offset="1" stopColor="#ffd9a8" /></linearGradient>
          <filter id="agb"><feGaussianBlur stdDeviation="7" /></filter>
        </defs>
        {Array.from({ length: 60 }).map((_, i) => {
          const a = (i / 60) * Math.PI * 2 - Math.PI / 2;
          const major = i % 5 === 0, lit = i / 60 <= p;
          return <line key={i} x1={200 + 186 * Math.cos(a)} y1={200 + 186 * Math.sin(a)} x2={200 + (major ? 196 : 191) * Math.cos(a)} y2={200 + (major ? 196 : 191) * Math.sin(a)}
            stroke={lit ? acc : "rgba(255,255,255,0.16)"} strokeWidth={major ? 2.4 : 1.2} strokeLinecap="round" />;
        })}
        <circle cx="200" cy="200" r={R} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="12" />
        <circle cx="200" cy="200" r={R} fill="none" stroke={acc} strokeWidth="14" strokeLinecap="round" filter="url(#agb)" opacity="0.55"
          strokeDasharray={C} strokeDashoffset={C * (1 - p)} transform="rotate(-90 200 200)" />
        <circle cx="200" cy="200" r={R} fill="none" stroke="url(#ag)" strokeWidth="12" strokeLinecap="round"
          strokeDasharray={C} strokeDashoffset={C * (1 - p)} transform="rotate(-90 200 200)" style={{ transition: "stroke-dashoffset .9s linear" }} />
        {p > 0.005 && <><circle cx={hx} cy={hy} r="12" fill={acc} opacity="0.3" style={{ animation: running ? "pulse-soft 1.6s infinite" : undefined }} /><circle cx={hx} cy={hy} r="6" fill="#fff" /></>}
        <circle cx="200" cy="200" r="138" fill="rgba(255,255,255,0.025)" stroke="rgba(255,255,255,0.05)" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="font-semibold uppercase tracking-[0.3em] text-mute" style={{ fontSize: "2.6cqw" }}>{MODE_LABEL[mode]}</div>
        <div className="font-mono font-medium tabular leading-none tracking-tight" style={{ fontSize: "19cqw", textShadow: `0 0 40px ${acc}55` }}>{fmtClock(ms)}</div>
        <div className="mt-[2cqw] max-w-[60%] truncate text-center text-mute" style={{ fontSize: "3cqw" }}>{label}</div>
      </div>
    </Wrap>
  );
}

// ═══════════════ 2 · FLIP ═══════════════
function FlipCard({ value, accent }: { value: string; accent: string }) {
  const [prev, setPrev] = useState(value);
  const cur = useRef(value);
  const [anim, setAnim] = useState(0);
  useEffect(() => {
    if (value === cur.current) return;
    setPrev(cur.current); cur.current = value; setAnim((a) => a + 1);
    const t = setTimeout(() => setPrev(value), 620);
    return () => clearTimeout(t);
  }, [value]);
  const face = (v: string, half: "top" | "bot") => (
    <div className="absolute inset-x-0 overflow-hidden" style={{ [half === "top" ? "top" : "bottom"]: 0, height: "50%" }}>
      <div className="absolute inset-x-0 flex items-center justify-center font-mono font-bold tabular" style={{ height: "200%", top: half === "top" ? 0 : "-100%", fontSize: "24cqw", color: "#f3eee6" }}>{v}</div>
    </div>
  );
  const flipping = prev !== value;
  const cardBg = "linear-gradient(180deg,#252a35,#1a1d25)";
  const half = (pos: "top" | "bot") => ({ background: pos === "top" ? cardBg : "linear-gradient(180deg,#1c1f27,#15171d)", backfaceVisibility: "hidden" as const });
  return (
    <div className="relative rounded-[2.4cqw] shadow-[0_20px_40px_-12px_rgba(0,0,0,0.8)]" style={{ width: value.length > 2 ? "46cqw" : "35cqw", height: "34cqw", perspective: "120cqw" }}>
      <div className="absolute inset-0 overflow-hidden rounded-[2.4cqw] border border-white/8">
        <div className="absolute inset-x-0 top-0 h-1/2" style={half("top")}>{face(value, "top")}</div>
        <div className="absolute inset-x-0 bottom-0 h-1/2" style={half("bot")}>{face(flipping ? prev : value, "bot")}</div>
        {flipping && (
          <div key={`t${anim}`} className="absolute inset-x-0 top-0 h-1/2 origin-bottom" style={{ ...half("top"), animation: "flip-top .3s ease-in forwards" }}>{face(prev, "top")}</div>
        )}
        {flipping && (
          <div key={`b${anim}`} className="absolute inset-x-0 bottom-0 h-1/2 origin-top" style={{ ...half("bot"), animation: "flip-bottom .3s .3s ease-out both", transform: "rotateX(90deg)" }}>{face(value, "bot")}</div>
        )}
        <div className="absolute inset-x-0 top-1/2 h-[0.6cqw] -translate-y-1/2 bg-black/70" />
        <div className="absolute left-0 top-1/2 h-[3cqw] w-[1.2cqw] -translate-y-1/2 rounded-r bg-black/60" />
        <div className="absolute right-0 top-1/2 h-[3cqw] w-[1.2cqw] -translate-y-1/2 rounded-l bg-black/60" />
        <div className="absolute inset-x-0 bottom-0 h-[0.5cqw]" style={{ background: accent, opacity: 0.55 }} />
      </div>
    </div>
  );
}
function Flip({ ms, total, mode, label }: FaceProps) {
  const acc = ACCENT[mode];
  const s = Math.ceil(ms / 1000), m = Math.floor(s / 60), r = s % 60;
  const p = total ? 1 - ms / total : 0;
  return (
    <Wrap className="mx-auto max-w-[620px]">
      <div className="flex flex-col items-center gap-[3cqw] py-[2cqw]">
        <div className="font-semibold uppercase tracking-[0.3em] text-mute" style={{ fontSize: "2.2cqw" }}>{MODE_LABEL[mode]}</div>
        <div className="flex items-center justify-center gap-[2.4cqw]">
          <FlipCard value={String(m).padStart(2, "0")} accent={acc} />
          <div className="flex flex-col gap-[3cqw]"><span className="h-[2cqw] w-[2cqw] rounded-full" style={{ background: acc }} /><span className="h-[2cqw] w-[2cqw] rounded-full" style={{ background: acc }} /></div>
          <FlipCard value={String(r).padStart(2, "0")} accent={acc} />
        </div>
        <div className="h-[1.2cqw] w-[78cqw] overflow-hidden rounded-full bg-white/8"><div className="h-full rounded-full transition-all duration-1000 ease-linear" style={{ width: `${p * 100}%`, background: acc }} /></div>
        <div className="max-w-[80%] truncate text-mute" style={{ fontSize: "3cqw" }}>{label}</div>
      </div>
    </Wrap>
  );
}

// ═══════════════ 3 · ORBIT ═══════════════
function Orbit({ ms, total, running, mode, label }: FaceProps) {
  const acc = ACCENT[mode];
  const p = total ? 1 - ms / total : 0;
  const R = 160, a = p * Math.PI * 2 - Math.PI / 2;
  const px = 200 + R * Math.cos(a), py = 200 + R * Math.sin(a);
  const stars = useMemo(() => Array.from({ length: 70 }, (_, i) => ({ x: (Math.sin(i * 91.7) * 0.5 + 0.5) * 400, y: (Math.cos(i * 57.3) * 0.5 + 0.5) * 400, r: 0.5 + ((i * 13) % 10) / 10, o: 0.25 + ((i * 7) % 10) / 16 })), []);
  const C = 2 * Math.PI * R;
  return (
    <Wrap className="mx-auto aspect-square max-w-[520px]">
      <svg viewBox="0 0 400 400" className="w-full">
        <defs>
          <radialGradient id="sun" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor={acc} stopOpacity="0.5" /><stop offset="1" stopColor={acc} stopOpacity="0" /></radialGradient>
          <radialGradient id="pl" cx="0.35" cy="0.3" r="0.8"><stop offset="0" stopColor="#ffe8d1" /><stop offset="0.5" stopColor={acc} /><stop offset="1" stopColor="#4a1f12" /></radialGradient>
        </defs>
        {stars.map((s, i) => <circle key={i} cx={s.x} cy={s.y} r={s.r} fill="#fff" opacity={s.o} />)}
        <circle cx="200" cy="200" r="130" fill="url(#sun)" />
        {[70, 105, 135].map((r, i) => <circle key={r} cx="200" cy="200" r={r} fill="none" stroke="rgba(255,255,255,0.07)" strokeDasharray="2 7" style={{ transformOrigin: "200px 200px", animation: `spin-slow ${60 + i * 30}s linear infinite ${i % 2 ? "reverse" : ""}` }} />)}
        <circle cx="200" cy="200" r={R} fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1.5" />
        <circle cx="200" cy="200" r={R} fill="none" stroke={acc} strokeWidth="3" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - p)} transform="rotate(-90 200 200)" opacity="0.9" />
        <g transform={`translate(${px} ${py})`} style={{ transition: "transform 1s linear" }}>
          <circle r="26" fill={acc} opacity="0.18" />
          <ellipse rx="26" ry="7" fill="none" stroke="rgba(255,235,210,0.7)" strokeWidth="2.2" transform="rotate(-24)" />
          <circle r="13" fill="url(#pl)" />
          <ellipse rx="26" ry="7" fill="none" stroke="rgba(255,235,210,0.9)" strokeWidth="2.2" transform="rotate(-24)" strokeDasharray="40 100" strokeDashoffset="-20" />
          <g style={{ animation: running ? "spin-slow 4s linear infinite" : undefined }}><circle cx="0" cy="-30" r="3.2" fill="#e8e4dc" /></g>
        </g>
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="font-semibold uppercase tracking-[0.3em] text-mute" style={{ fontSize: "2.4cqw" }}>{MODE_LABEL[mode]}</div>
        <div className="font-mono font-medium tabular leading-none" style={{ fontSize: "17cqw" }}>{fmtClock(ms)}</div>
        <div className="mt-[1.5cqw] text-mute" style={{ fontSize: "2.8cqw" }}>{Math.round(p * 100)}% around the sun</div>
        <div className="mt-[0.5cqw] max-w-[55%] truncate text-dim" style={{ fontSize: "2.6cqw" }}>{label}</div>
      </div>
    </Wrap>
  );
}

// ═══════════════ 4 · HOURGLASS ═══════════════
function Hourglass({ ms, total, running, mode, label }: FaceProps) {
  const acc = ACCENT[mode];
  const p = total ? 1 - ms / total : 0;
  const glass = "M72 38 H228 C228 112 166 160 156 200 C166 240 228 288 228 362 H72 C72 288 134 240 144 200 C134 160 72 112 72 38 Z";
  const topY = 38 + p * 160;
  const botY = 362 - p * 150;
  return (
    <Wrap className="mx-auto max-w-[420px]">
      <svg viewBox="0 0 300 440" className="w-full">
        <defs>
          <clipPath id="gl"><path d={glass} /></clipPath>
          <linearGradient id="sandg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffd98a" /><stop offset="1" stopColor={acc} /></linearGradient>
          <linearGradient id="glassg" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="rgba(255,255,255,0.18)" /><stop offset="0.5" stopColor="rgba(255,255,255,0.03)" /><stop offset="1" stopColor="rgba(255,255,255,0.14)" /></linearGradient>
        </defs>
        <ellipse cx="150" cy="404" rx="100" ry="10" fill="rgba(0,0,0,0.45)" />
        <rect x="52" y="14" width="196" height="24" rx="12" fill="#2a2e3a" stroke="rgba(255,255,255,0.12)" />
        <rect x="52" y="362" width="196" height="24" rx="12" fill="#2a2e3a" stroke="rgba(255,255,255,0.12)" />
        <path d={glass} fill="rgba(255,255,255,0.03)" />
        <g clipPath="url(#gl)">
          <rect x="60" y={topY} width="180" height={Math.max(0, 200 - topY)} fill="url(#sandg)" />
          {p < 0.995 && <path d={`M60 ${topY} Q150 ${topY + 8} 240 ${topY}`} stroke="#fff3cc" strokeOpacity="0.4" fill="none" />}
          <rect x="60" y={botY} width="180" height={Math.max(0, 362 - botY)} fill="url(#sandg)" />
          <ellipse cx="150" cy={botY} rx="48" ry="9" fill="#ffe3a0" opacity={p > 0.01 ? 0.9 : 0} />
          {running && p < 0.995 && <line x1="150" y1="198" x2="150" y2={botY} stroke="#ffd98a" strokeWidth="2.4" strokeDasharray="3 5" style={{ animation: "sand-fall .35s linear infinite" }} />}
        </g>
        <path d={glass} fill="url(#glassg)" stroke="rgba(255,255,255,0.35)" strokeWidth="2" />
        <path d="M86 60 C86 110 120 140 130 170" stroke="rgba(255,255,255,0.35)" strokeWidth="3" strokeLinecap="round" fill="none" />
      </svg>
      <div className="text-center">
        <div className="font-mono font-medium tabular leading-none" style={{ fontSize: "18cqw" }}>{fmtClock(ms)}</div>
        <div className="mt-[1.5cqw] text-mute" style={{ fontSize: "3.2cqw" }}>{MODE_LABEL[mode]}{label ? ` · ${label}` : ""}</div>
      </div>
    </Wrap>
  );
}

// ═══════════════ 5 · COMPANION TRAIL ═══════════════
function Trail({ ms, total, running, mode, petId, label }: FaceProps) {
  const acc = ACCENT[mode];
  const p = total ? 1 - ms / total : 0;
  const pet = petId ? PET_MAP[petId] : undefined;
  const left = 4 + p * 84;
  return (
    <Wrap className="mx-auto max-w-[760px]">
      <div className="text-center">
        <div className="font-semibold uppercase tracking-[0.3em] text-mute" style={{ fontSize: "1.8cqw" }}>{MODE_LABEL[mode]}</div>
        <div className="font-mono font-medium tabular leading-none" style={{ fontSize: "15cqw" }}>{fmtClock(ms)}</div>
        <div className="mt-[0.8cqw] truncate text-mute" style={{ fontSize: "2.2cqw" }}>{label}</div>
      </div>
      <div className="relative mt-[3cqw] h-[34cqw] overflow-hidden rounded-[3cqw] border border-white/8" style={{ background: "linear-gradient(180deg, #151a27 0%, #1c2233 55%, #1f2b24 55%, #18211b 100%)" }}>
        {/* sky */}
        {[8, 38, 70].map((x, i) => <div key={x} className="absolute rounded-full bg-white/8 blur-[2px]" style={{ left: `${x}%`, top: `${8 + i * 6}%`, width: `${14 + i * 3}cqw`, height: "3.6cqw", animation: `drift ${18 + i * 6}s ease-in-out infinite alternate` }} />)}
        <div className="absolute right-[8%] top-[10%] h-[7cqw] w-[7cqw] rounded-full" style={{ background: `radial-gradient(circle at 35% 35%, #fff4d8, ${acc})`, boxShadow: `0 0 6cqw ${acc}88` }} />
        {/* hills */}
        <svg viewBox="0 0 400 140" preserveAspectRatio="none" className="absolute inset-x-0 bottom-[44%] h-[34%] w-full"><path d="M0 140 L0 80 Q60 30 120 80 T240 70 T400 60 L400 140Z" fill="#202a3a" /></svg>
        {/* path */}
        <div className="absolute inset-x-[4%] top-[63%] h-[1.2cqw] rounded-full bg-white/8" />
        <div className="absolute left-[4%] top-[63%] h-[1.2cqw] rounded-full transition-all duration-1000 ease-linear" style={{ width: `${p * 84}%`, background: acc }} />
        {[0.25, 0.5, 0.75].map((m) => (
          <div key={m} className="absolute top-[58%]" style={{ left: `${4 + m * 84}%` }}>
            <div className="h-[6cqw] w-[0.6cqw] rounded bg-white/15" /><div className="absolute -left-[0.6cqw] top-0 h-[2.4cqw] w-[2.4cqw] rounded-full" style={{ background: p >= m ? acc : "rgba(255,255,255,0.12)" }} />
          </div>
        ))}
        {/* flag */}
        <div className="absolute top-[41%]" style={{ left: "88%" }}>
          <div className="h-[16cqw] w-[0.8cqw] rounded bg-bone/80" />
          <div className="absolute left-[0.8cqw] top-0 h-[6cqw] w-[9cqw] origin-left" style={{ background: acc, clipPath: "polygon(0 0,100% 20%,70% 50%,100% 80%,0 100%)", animation: "pulse-soft 2s infinite" }} />
        </div>
        {/* pet */}
        <div className="absolute transition-all duration-1000 ease-linear" style={{ left: `${left}%`, top: "26%", width: "17cqw", height: "17cqw", transform: "translateX(-50%)" }}>
          <div style={{ animation: running ? "pet-walk .55s ease-in-out infinite" : undefined }} className="h-full w-full">
            {pet ? <div className="h-full w-full -scale-x-100"><BattleSprite def={pet} side="front" className="h-full w-full object-contain object-bottom" /></div> : null}
          </div>
          <div className="absolute -bottom-[1cqw] left-1/2 h-[1.4cqw] w-[10cqw] -translate-x-1/2 rounded-full bg-black/40 blur-[2px]" />
        </div>
        <style>{`@keyframes pet-walk{0%,100%{transform:translateY(0) rotate(-1.5deg)}50%{transform:translateY(-1.6cqw) rotate(1.5deg)}}`}</style>
      </div>
      <div className="mt-[2cqw] flex justify-between px-[2cqw] text-dim" style={{ fontSize: "2cqw" }}><span>Start</span><span>{Math.round(p * 100)}%</span><span>Finish</span></div>
    </Wrap>
  );
}

// ═══════════════ 6 · SEGMENT ═══════════════
const SEG: Record<string, number[]> = {
  "0": [1, 1, 1, 1, 1, 1, 0], "1": [0, 1, 1, 0, 0, 0, 0], "2": [1, 1, 0, 1, 1, 0, 1], "3": [1, 1, 1, 1, 0, 0, 1], "4": [0, 1, 1, 0, 0, 1, 1],
  "5": [1, 0, 1, 1, 0, 1, 1], "6": [1, 0, 1, 1, 1, 1, 1], "7": [1, 1, 1, 0, 0, 0, 0], "8": [1, 1, 1, 1, 1, 1, 1], "9": [1, 1, 1, 1, 0, 1, 1],
};
const SEGP = [
  "M10 4 L46 4 L40 12 L16 12 Z", "M48 6 L48 44 L40 38 L40 14 Z", "M48 52 L48 90 L40 84 L40 58 Z",
  "M10 92 L46 92 L40 84 L16 84 Z", "M8 52 L8 90 L16 84 L16 58 Z", "M8 6 L8 44 L16 38 L16 14 Z", "M10 48 L16 42 L40 42 L46 48 L40 54 L16 54 Z",
];
function Digit({ ch, color }: { ch: string; color: string }) {
  const on = SEG[ch] ?? SEG["8"];
  return (
    <svg viewBox="0 0 56 96" style={{ width: "15cqw" }}>
      {SEGP.map((d, i) => <path key={i} d={d} fill={on[i] ? color : "rgba(255,255,255,0.045)"} style={on[i] ? { filter: `drop-shadow(0 0 5px ${color})` } : undefined} />)}
    </svg>
  );
}
function Segment({ ms, total, running, mode, label }: FaceProps) {
  const acc = mode === "focus" ? "#ffb347" : ACCENT[mode];
  const p = total ? 1 - ms / total : 0;
  const t = fmtClock(ms).replace(":", "");
  const chars = t.padStart(4, "0").split("");
  const blocks = 36;
  return (
    <Wrap className="mx-auto max-w-[640px]">
      <div className="rounded-[4cqw] border border-white/10 p-[4cqw]" style={{ background: "linear-gradient(180deg,#0e0f13,#07080a)", boxShadow: "inset 0 2px 30px rgba(0,0,0,0.9), 0 30px 60px -20px rgba(0,0,0,0.8)" }}>
        <div className="mb-[2cqw] flex justify-between font-mono uppercase tracking-[0.2em] text-dim" style={{ fontSize: "1.9cqw" }}><span>{MODE_LABEL[mode]}</span><span>{running ? "● run" : "○ hold"}</span></div>
        <div className="flex items-center justify-center gap-[1.4cqw]">
          <Digit ch={chars[0]} color={acc} /><Digit ch={chars[1]} color={acc} />
          <div className="flex flex-col gap-[4cqw]" style={{ opacity: running ? undefined : 1, animation: running ? "pulse-soft 1s steps(2) infinite" : undefined }}>
            <span className="h-[2cqw] w-[2cqw] rounded-[0.4cqw]" style={{ background: acc, boxShadow: `0 0 12px ${acc}` }} /><span className="h-[2cqw] w-[2cqw] rounded-[0.4cqw]" style={{ background: acc, boxShadow: `0 0 12px ${acc}` }} />
          </div>
          <Digit ch={chars[2]} color={acc} /><Digit ch={chars[3]} color={acc} />
        </div>
        <div className="mt-[3cqw] flex gap-[0.7cqw]">
          {Array.from({ length: blocks }).map((_, i) => <div key={i} className="h-[2.6cqw] flex-1 rounded-[0.4cqw]" style={{ background: i / blocks < p ? acc : "rgba(255,255,255,0.06)", boxShadow: i / blocks < p ? `0 0 8px ${acc}88` : undefined }} />)}
        </div>
        <div className="mt-[2cqw] truncate font-mono text-dim" style={{ fontSize: "2cqw" }}>&gt; {label || "ready"}</div>
      </div>
    </Wrap>
  );
}

// ═══════════════ 7 · GARDEN ═══════════════
function Garden({ ms, total, mode, label }: FaceProps) {
  const acc = ACCENT[mode];
  const p = total ? 1 - ms / total : 0;
  const leaf = (t: number, x: number, y: number, flip: number, i: number) => {
    const s = Math.max(0, Math.min(1, (p - t) / 0.12));
    return (
      <g key={i} transform={`translate(${x} ${y}) scale(${flip * s} ${s})`} style={{ transition: "transform .9s cubic-bezier(.2,1.4,.4,1)" }}>
        <path d="M0 0 C18 -22 52 -22 62 -2 C46 12 14 12 0 0Z" fill="#59c26a" /><path d="M2 0 C20 -6 40 -6 58 -2" stroke="#2f8a42" strokeWidth="2" fill="none" />
      </g>
    );
  };
  const bloom = Math.max(0, Math.min(1, (p - 0.82) / 0.18));
  const stemTop = 340 - p * 190;
  return (
    <Wrap className="mx-auto max-w-[420px]">
      <svg viewBox="0 0 300 420" className="w-full">
        <defs><radialGradient id="gsun" cx="0.5" cy="0.5" r="0.5"><stop offset="0" stopColor="#ffd98a" stopOpacity="0.5" /><stop offset="1" stopColor="#ffd98a" stopOpacity="0" /></radialGradient></defs>
        <circle cx="236" cy="70" r="70" fill="url(#gsun)" />
        <path d="M95 340 L205 340 L192 410 L108 410 Z" fill="#b4573a" /><rect x="88" y="326" width="124" height="20" rx="8" fill="#c8654a" />
        <ellipse cx="150" cy="328" rx="52" ry="7" fill="#3a2a20" />
        <path d={`M150 330 C150 ${(330 + stemTop) / 2} 146 ${(330 + stemTop) / 2 - 20} 150 ${stemTop}`} stroke="#59c26a" strokeWidth="7" strokeLinecap="round" fill="none" style={{ transition: "all .9s ease-out" }} />
        {leaf(0.12, 150, 300, 1, 0)}{leaf(0.28, 150, 262, -1, 1)}{leaf(0.46, 150, 228, 1, 2)}{leaf(0.62, 150, 196, -1, 3)}
        <g transform={`translate(150 ${stemTop}) scale(${0.3 + bloom * 0.9})`} opacity={p > 0.7 ? 1 : 0} style={{ transition: "all .9s ease-out" }}>
          {Array.from({ length: 8 }).map((_, i) => <ellipse key={i} cx="0" cy="-26" rx="12" ry="22" fill={i % 2 ? acc : "#ffb199"} transform={`rotate(${i * 45}) scale(${0.5 + bloom * 0.5})`} />)}
          <circle r="13" fill="#ffd34d" />
        </g>
        {p > 0.7 && p < 0.82 && <ellipse cx="150" cy={stemTop - 8} rx="9" ry="14" fill={acc} />}
      </svg>
      <div className="text-center">
        <div className="font-mono font-medium tabular leading-none" style={{ fontSize: "18cqw" }}>{fmtClock(ms)}</div>
        <div className="mt-[1.5cqw] text-mute" style={{ fontSize: "3.2cqw" }}>{p < 0.15 ? "Seedling" : p < 0.5 ? "Growing" : p < 0.82 ? "Budding" : p < 1 ? "Almost in bloom" : "In full bloom"}{label ? ` · ${label}` : ""}</div>
      </div>
    </Wrap>
  );
}

export default function TimerFace({ face, ...p }: FaceProps & { face: string }) {
  switch (face) {
    case "flip": return <Flip {...p} />;
    case "orbit": return <Orbit {...p} />;
    case "hourglass": return <Hourglass {...p} />;
    case "trail": return <Trail {...p} />;
    case "segment": return <Segment {...p} />;
    case "garden": return <Garden {...p} />;
    default: return <Aurora {...p} />;
  }
}
