import { useEffect, useMemo, type ButtonHTMLAttributes, type ReactNode } from "react";
import { X, Check } from "lucide-react";
import { cn } from "../utils/cn";
import { TYPE_COLOR, RARITY, type PType, type Rarity } from "../lib/pets";
import { useUI } from "../lib/store";

export function Btn({
  variant = "primary", size = "md", className, ...p
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "soft" | "danger" | "mint"; size?: "sm" | "md" | "lg" }) {
  const v = {
    primary: "bg-ember text-ink-950 hover:bg-ember-300 shadow-[0_8px_24px_-8px_rgba(255,122,69,0.7)]",
    mint: "bg-mint text-ink-950 hover:brightness-110 shadow-[0_8px_24px_-8px_rgba(79,224,181,0.6)]",
    soft: "bg-white/7 text-bone hover:bg-white/12 border border-white/8",
    ghost: "text-mute hover:text-bone hover:bg-white/6",
    danger: "bg-rose/15 text-rose hover:bg-rose/25 border border-rose/20",
  }[variant];
  const s = { sm: "h-8 px-3 text-xs gap-1.5 rounded-lg", md: "h-10 px-4 text-sm gap-2 rounded-xl", lg: "h-13 px-7 text-base gap-2.5 rounded-2xl" }[size];
  return (
    <button
      {...p}
      className={cn(
        "inline-flex items-center justify-center font-semibold transition-all duration-150 active:scale-[0.97] disabled:opacity-40 disabled:pointer-events-none cursor-pointer select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ember",
        v, s, className,
      )}
    />
  );
}

export function Card({ className, children, solid, ...p }: { className?: string; children: ReactNode; solid?: boolean } & React.HTMLAttributes<HTMLDivElement>) {
  return <div {...p} className={cn(solid ? "surface-solid" : "surface", "p-5", className)}>{children}</div>;
}

export function Eyebrow({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("text-[11px] font-semibold uppercase tracking-[0.16em] text-dim", className)}>{children}</div>;
}

export function PageHead({ eyebrow, title, sub, right }: { eyebrow?: string; title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && <Eyebrow className="mb-2 text-ember">{eyebrow}</Eyebrow>}
        <h1 className="font-display text-3xl font-extrabold leading-tight sm:text-4xl">{title}</h1>
        {sub && <p className="mt-2 max-w-xl text-[15px] leading-relaxed text-mute">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function Bar({ value, max = 100, color = "var(--color-ember)", className, h = 8 }: { value: number; max?: number; color?: string; className?: string; h?: number }) {
  const pct = Math.max(0, Math.min(100, (value / Math.max(1, max)) * 100));
  return (
    <div className={cn("relative w-full overflow-hidden rounded-full bg-white/7", className)} style={{ height: h }}>
      <div className="relative h-full rounded-full transition-[width] duration-700 ease-out" style={{ width: `${pct}%`, background: color }}>
        <div className="absolute inset-0 overflow-hidden rounded-full">
          <div className="h-full w-1/3 bg-white/25 blur-sm" style={{ animation: "bar-sheen 3.2s ease-in-out infinite" }} />
        </div>
      </div>
    </div>
  );
}

export function Ring({ value, size = 64, stroke = 6, color = "var(--color-ember)", children }: { value: number; size?: number; stroke?: number; color?: string; children?: ReactNode }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - Math.max(0, Math.min(1, value)))} className="transition-[stroke-dashoffset] duration-700" />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">{children}</div>
    </div>
  );
}

export function TypeBadge({ type, className }: { type: PType; className?: string }) {
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider", className)}
      style={{ background: `${TYPE_COLOR[type]}22`, color: TYPE_COLOR[type] }}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: TYPE_COLOR[type] }} />
      {type}
    </span>
  );
}
export function RarityTag({ rarity, className }: { rarity: Rarity; className?: string }) {
  return <span className={cn("text-[10px] font-bold uppercase tracking-wider", className)} style={{ color: RARITY[rarity].color }}>{RARITY[rarity].label}</span>;
}

export function Modal({ open, onClose, children, className, hideClose }: { open: boolean; onClose: () => void; children: ReactNode; className?: string; hideClose?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    document.body.style.overflow = "hidden";
    return () => { window.removeEventListener("keydown", h); document.body.style.overflow = ""; };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center p-0 sm:items-center sm:p-6" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} style={{ animation: "pop .2s ease-out both" }} />
      <div className={cn("surface-solid relative max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-b-none p-6 shadow-2xl sm:rounded-3xl sm:rounded-b-3xl", className)} style={{ animation: "rise .35s cubic-bezier(.2,.9,.2,1) both" }}>
        {!hideClose && (
          <button onClick={onClose} aria-label="Close" className="absolute right-4 top-4 z-10 rounded-full p-1.5 text-mute transition hover:bg-white/10 hover:text-bone cursor-pointer"><X size={18} /></button>
        )}
        {children}
      </div>
    </div>
  );
}

export function Confetti({ count = 80 }: { count?: number }) {
  const bits = useMemo(() => Array.from({ length: count }, (_, i) => ({
    left: Math.random() * 100, delay: Math.random() * 0.8, dur: 2.4 + Math.random() * 2, dx: (Math.random() - 0.5) * 240,
    rot: 360 + Math.random() * 720, color: ["#ff7a45", "#ffc857", "#4fe0b5", "#6cb6ff", "#a98bff", "#ff6b81"][i % 6], w: 6 + Math.random() * 6, h: 8 + Math.random() * 8,
  })), [count]);
  return (
    <div className="pointer-events-none fixed inset-0 z-[90] overflow-hidden" aria-hidden>
      {bits.map((b, i) => (
        <span key={i} className="absolute top-0 block rounded-[2px]" style={{
          left: `${b.left}%`, width: b.w, height: b.h, background: b.color,
          animation: `confetti-fall ${b.dur}s ${b.delay}s cubic-bezier(.3,.6,.5,1) both`, ["--dx" as string]: `${b.dx}px`, ["--rot" as string]: `${b.rot}deg`,
        }} />
      ))}
    </div>
  );
}

export function Toasts() {
  const { toasts } = useUI();
  return (
    <div className="pointer-events-none fixed bottom-24 left-1/2 z-[100] flex -translate-x-1/2 flex-col items-center gap-2 lg:bottom-8">
      {toasts.map((t) => (
        <div key={t.id} className="surface-solid flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-medium shadow-2xl" style={{ animation: "rise .3s ease-out both", borderColor: t.tone === "warn" ? "rgba(255,107,129,.4)" : "rgba(255,255,255,.1)" }}>
          <span className={cn("grid h-5 w-5 place-items-center rounded-full", t.tone === "warn" ? "bg-rose/20 text-rose" : t.tone === "coin" ? "bg-gold/20 text-gold" : "bg-mint/20 text-mint")}><Check size={12} strokeWidth={3} /></span>
          {t.text}
        </div>
      ))}
    </div>
  );
}

export function Seg<T extends string>({ value, onChange, options, className }: { value: T; onChange: (v: T) => void; options: { id: T; label: ReactNode }[]; className?: string }) {
  return (
    <div className={cn("inline-flex rounded-xl border border-white/8 bg-white/4 p-1", className)}>
      {options.map((o) => (
        <button key={o.id} onClick={() => onChange(o.id)}
          className={cn("rounded-lg px-3.5 py-1.5 text-[13px] font-semibold transition-all cursor-pointer", value === o.id ? "bg-bone text-ink-950 shadow" : "text-mute hover:text-bone")}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Empty({ icon, title, sub, action }: { icon: ReactNode; title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/10 px-6 py-14 text-center">
      <div className="grid h-12 w-12 place-items-center rounded-2xl bg-white/5 text-mute">{icon}</div>
      <div className="font-display text-lg font-bold">{title}</div>
      {sub && <p className="max-w-sm text-sm text-mute">{sub}</p>}
      {action}
    </div>
  );
}

export const fmtMin = (m: number) => {
  if (m < 60) return `${Math.round(m)}m`;
  const h = Math.floor(m / 60), r = Math.round(m % 60);
  return r ? `${h}h ${r}m` : `${h}h`;
};
export const fmtClock = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(s / 60), r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
};
