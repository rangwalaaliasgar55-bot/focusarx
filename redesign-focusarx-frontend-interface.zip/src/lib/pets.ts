export type Species = "fox" | "cat" | "owl" | "slime";

export interface Palette {
  main: number;
  belly: number;
  accent: number;
  dark: number;
}

export interface PetDef {
  key: string;
  species: Species;
  variant: number;
  label: string;
  price: number;
  blurb: string;
  palette: Palette;
  swatch: string;
}

const hex = (n: number) => "#" + n.toString(16).padStart(6, "0");

const raw: Omit<PetDef, "swatch">[] = [
  { key: "fox:0", species: "fox", variant: 0, label: "Ember Fox", price: 0, blurb: "Curious and quick. Sleeps with one ear up.", palette: { main: 0xe8803a, belly: 0xfff1dc, accent: 0xffb3a7, dark: 0x4a2a1d } },
  { key: "fox:1", species: "fox", variant: 1, label: "Snow Fox", price: 220, blurb: "Calm under pressure. Loves long sessions.", palette: { main: 0xe6ecf4, belly: 0xffffff, accent: 0xffc0cb, dark: 0x66758c } },
  { key: "fox:2", species: "fox", variant: 2, label: "Dusk Fox", price: 380, blurb: "A night-owl fox. Best after 9 pm.", palette: { main: 0x7461c9, belly: 0xe8e0ff, accent: 0xffa6d1, dark: 0x2d2457 } },
  { key: "cat:0", species: "cat", variant: 0, label: "Slate Cat", price: 300, blurb: "Unbothered. Judges your tab count.", palette: { main: 0x8d97a8, belly: 0xf1efe9, accent: 0xf4b6c2, dark: 0x3b4252 } },
  { key: "cat:1", species: "cat", variant: 1, label: "Marmalade Cat", price: 420, blurb: "Warm, loud, and very proud of you.", palette: { main: 0xf0b45a, belly: 0xfff4de, accent: 0xf4a3a0, dark: 0x7a4a14 } },
  { key: "cat:2", species: "cat", variant: 2, label: "Cocoa Cat", price: 520, blurb: "Quiet company for deep reading.", palette: { main: 0x8a5a3c, belly: 0xf0dcc4, accent: 0xe8a0a0, dark: 0x3a2314 } },
  { key: "owl:0", species: "owl", variant: 0, label: "Bark Owl", price: 450, blurb: "Wise about breaks. Strict about starts.", palette: { main: 0x9a7050, belly: 0xf1e2c8, accent: 0xf2a33a, dark: 0x3d2817 } },
  { key: "owl:1", species: "owl", variant: 1, label: "Frost Owl", price: 560, blurb: "Cool head, long streaks.", palette: { main: 0xb6c9dc, belly: 0xf6f9fc, accent: 0xf2b34a, dark: 0x4a5d73 } },
  { key: "owl:2", species: "owl", variant: 2, label: "Moss Owl", price: 640, blurb: "Slow, steady, always on time.", palette: { main: 0x6f8f5e, belly: 0xe9efd4, accent: 0xf0a43a, dark: 0x2c3d24 } },
  { key: "slime:0", species: "slime", variant: 0, label: "Mint Slime", price: 600, blurb: "Squishy support. Bounces on breaks.", palette: { main: 0x62d6b0, belly: 0xc8fbe8, accent: 0x3fae6a, dark: 0x0e3a2e } },
  { key: "slime:1", species: "slime", variant: 1, label: "Berry Slime", price: 700, blurb: "Sweet, loud, and easily excited.", palette: { main: 0xe0629e, belly: 0xffc6e0, accent: 0x6fcf7a, dark: 0x4a0f2c } },
  { key: "slime:2", species: "slime", variant: 2, label: "Sky Slime", price: 800, blurb: "Floaty and relaxed. Great for flow.", palette: { main: 0x62a8f0, belly: 0xcfe6ff, accent: 0x5fd39a, dark: 0x0f2f5a } },
];

export const PET_CATALOG: PetDef[] = raw.map((p) => ({ ...p, swatch: hex(p.palette.main) }));

export const SPECIES_LABEL: Record<Species, string> = {
  fox: "Fox",
  cat: "Cat",
  owl: "Owl",
  slime: "Slime",
};

export function getPetDef(species: Species, variant: number): PetDef {
  return PET_CATALOG.find((p) => p.species === species && p.variant === variant) ?? PET_CATALOG[0];
}
