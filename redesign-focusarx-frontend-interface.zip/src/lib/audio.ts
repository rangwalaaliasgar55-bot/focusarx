/* Procedural ambient sound — no audio files, everything is synthesized with WebAudio. */

export type LayerId = "rain" | "brown" | "ocean" | "wind";

export const LAYERS: { id: LayerId; label: string; hint: string }[] = [
  { id: "rain", label: "Rain", hint: "Steady, soft rainfall" },
  { id: "brown", label: "Brown noise", hint: "Deep and warm" },
  { id: "ocean", label: "Ocean", hint: "Slow rolling waves" },
  { id: "wind", label: "Wind", hint: "Drifting air" },
];

let ctx: AudioContext | null = null;
let master: GainNode | null = null;
const nodes: Partial<Record<LayerId, { gain: GainNode; stop: () => void }>> = {};
let volumes: Record<LayerId, number> = { rain: 0, brown: 0, ocean: 0, wind: 0 };
const listeners = new Set<() => void>();

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.9;
    master.connect(ctx.destination);
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

function noiseBuffer(c: AudioContext, type: "white" | "brown" | "pink"): AudioBuffer {
  const len = c.sampleRate * 4;
  const buf = c.createBuffer(2, len, c.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const d = buf.getChannelData(ch);
    let last = 0;
    let b0 = 0,
      b1 = 0,
      b2 = 0;
    for (let i = 0; i < len; i++) {
      const w = Math.random() * 2 - 1;
      if (type === "white") d[i] = w;
      else if (type === "brown") {
        last = (last + 0.02 * w) / 1.02;
        d[i] = last * 3.5;
      } else {
        b0 = 0.99765 * b0 + w * 0.099046;
        b1 = 0.963 * b1 + w * 0.2965164;
        b2 = 0.57 * b2 + w * 1.0526913;
        d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.2;
      }
    }
    // crossfade ends so the loop is seamless
    const fade = 2000;
    for (let i = 0; i < fade; i++) {
      const k = i / fade;
      d[i] = d[i] * k + d[len - fade + i] * (1 - k);
    }
  }
  return buf;
}

function loop(c: AudioContext, type: "white" | "brown" | "pink") {
  const src = c.createBufferSource();
  src.buffer = noiseBuffer(c, type);
  src.loop = true;
  src.loopEnd = src.buffer.duration - 2000 / c.sampleRate;
  src.start();
  return src;
}

function build(id: LayerId, c: AudioContext) {
  const out = c.createGain();
  out.gain.value = 0;
  out.connect(master!);
  const stops: (() => void)[] = [];

  if (id === "rain") {
    const src = loop(c, "white");
    const hp = c.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 900;
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 7500;
    const peak = c.createBiquadFilter();
    peak.type = "peaking";
    peak.frequency.value = 3200;
    peak.gain.value = 4;
    src.connect(hp).connect(peak).connect(lp).connect(out);
    stops.push(() => src.stop());
  } else if (id === "brown") {
    const src = loop(c, "brown");
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 900;
    src.connect(lp).connect(out);
    stops.push(() => src.stop());
  } else if (id === "ocean") {
    const src = loop(c, "pink");
    const lp = c.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 1100;
    const swell = c.createGain();
    swell.gain.value = 0.55;
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.09;
    const depth = c.createGain();
    depth.gain.value = 0.45;
    lfo.connect(depth).connect(swell.gain);
    lfo.start();
    src.connect(lp).connect(swell).connect(out);
    stops.push(() => src.stop(), () => lfo.stop());
  } else {
    const src = loop(c, "pink");
    const bp = c.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 520;
    bp.Q.value = 0.8;
    const lfo = c.createOscillator();
    lfo.frequency.value = 0.07;
    const depth = c.createGain();
    depth.gain.value = 260;
    lfo.connect(depth).connect(bp.frequency);
    lfo.start();
    src.connect(bp).connect(out);
    stops.push(() => src.stop(), () => lfo.stop());
  }
  return {
    gain: out,
    stop: () => {
      stops.forEach((s) => {
        try {
          s();
        } catch {
          /* already stopped */
        }
      });
      out.disconnect();
    },
  };
}

export function setLayer(id: LayerId, vol: number) {
  const c = getCtx();
  if (!c) return;
  volumes = { ...volumes, [id]: vol };
  if (vol > 0 && !nodes[id]) nodes[id] = build(id, c);
  const n = nodes[id];
  if (n) {
    n.gain.gain.cancelScheduledValues(c.currentTime);
    n.gain.gain.setTargetAtTime(vol * vol * 0.55, c.currentTime, 0.12);
    if (vol === 0) {
      const node = n;
      window.setTimeout(() => {
        if (volumes[id] === 0 && nodes[id] === node) {
          node.stop();
          delete nodes[id];
        }
      }, 700);
    }
  }
  listeners.forEach((l) => l());
}

export function stopAll() {
  (Object.keys(volumes) as LayerId[]).forEach((id) => setLayer(id, 0));
}

export function getVolumes() {
  return volumes;
}

export function subscribeAudio(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function playChime() {
  const c = getCtx();
  if (!c || !master) return;
  const t0 = c.currentTime;
  [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => {
    const o = c.createOscillator();
    const g = c.createGain();
    o.type = "sine";
    o.frequency.value = f;
    const t = t0 + i * 0.16;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(0.16, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.4);
    o.connect(g).connect(master!);
    o.start(t);
    o.stop(t + 1.5);
  });
}

export function playTick() {
  const c = getCtx();
  if (!c || !master) return;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = "triangle";
  o.frequency.value = 660;
  g.gain.setValueAtTime(0.0001, c.currentTime);
  g.gain.exponentialRampToValueAtTime(0.08, c.currentTime + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + 0.18);
  o.connect(g).connect(master);
  o.start();
  o.stop(c.currentTime + 0.2);
}
