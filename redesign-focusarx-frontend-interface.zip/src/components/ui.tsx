import { useEffect, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "../utils/cn";
import { A, useStore } from "../store";

/* ───────── Button ───────── */

type Variant = "primary" | "secondary" | "ghost" | "danger";
type Size = "sm" | "md" | "lg";

const variants: Record<Variant, string> = {
  primary: "bg-brand text-brand-ink hover:brightness-110 active:brightness-95",
  secondary: "bg-s2 text-fg border border-line hover:bg-s3 hover:border-line-strong",
  ghost: "text-fg2 hover:text-fg hover:bg-s2",
  danger: "bg-transparent text-bad border border-line hover:bg-bad/10",
};
const sizes: Record<Size, string> = {
  sm: "h-8 px-3 text-[13px] gap-1.5 rounded-lg",
  md: "h-10 px-4 text-sm gap-2 rounded-xl",
  lg: "h-12 px-6 text-[15px] gap-2 rounded-xl",
};

export function Button({
  variant = "secondary",
  size = "md",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: Size }) {
  return (
    <button
      {...props}
      className={cn(
        "inline-flex shrink-0 items-center justify-center font-medium transition-[background,color,border-color,filter,transform] duration-150 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40",
        variants[variant],
        sizes[size],
        className
      )}
    />
  );
}

/* ───────── Surfaces ───────── */

export function Panel({ className, children, ...rest }: { className?: string; children: ReactNode } & React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cn("panel", className)} {...rest}>
      {children}
    </div>
  );
}

export function SectionTitle({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="mb-4 flex items-end justify-between gap-3">
      <div>
        <h2 className="font-display text-[15px] font-semibold tracking-tight text-fg">{title}</h2>
        {hint && <p className="mt-0.5 text-[13px] text-fg3">{hint}</p>}
      </div>
      {action}
    </div>
  );
}

export function PageHeader({ title, sub, action }: { title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="font-display text-[28px] font-bold leading-tight tracking-tight text-fg sm:text-[32px]">{title}</h1>
        {sub && <p className="mt-1.5 max-w-xl text-[15px] text-fg2">{sub}</p>}
      </div>
      {action}
    </div>
  );
}

export function Stat({ label, value, sub, icon }: { label: string; value: ReactNode; sub?: ReactNode; icon?: ReactNode }) {
  return (
    <Panel className="p-5">
      <div className="flex items-center justify-between">
        <span className="eyebrow">{label}</span>
        {icon && <span className="text-fg3">{icon}</span>}
      </div>
      <div className="num mt-3 font-display text-[30px] font-bold leading-none tracking-tight text-fg">{value}</div>
      {sub && <div className="mt-2 text-[13px] text-fg3">{sub}</div>}
    </Panel>
  );
}

export function Bar({ pct, className, tone = "brand" }: { pct: number; className?: string; tone?: "brand" | "ok" }) {
  return (
    <div className={cn("h-1.5 w-full overflow-hidden rounded-full bg-line-strong/60", className)}>
      <div
        className={cn("h-full rounded-full transition-[width] duration-500", tone === "brand" ? "bg-brand" : "bg-ok")}
        style={{ width: `${Math.max(0, Math.min(1, pct)) * 100}%` }}
      />
    </div>
  );
}

export function Chip({ children, active, onClick, className }: { children: ReactNode; active?: boolean; onClick?: () => void; className?: string }) {
  const cls = cn(
    "inline-flex h-7 items-center rounded-full border px-3 text-xs font-medium transition-colors",
    active ? "border-brand/60 bg-brand-soft text-brand" : "border-line text-fg2",
    onClick && !active && "hover:border-line-strong hover:text-fg",
    className
  );
  return onClick ? (
    <button onClick={onClick} className={cls} aria-pressed={active}>
      {children}
    </button>
  ) : (
    <span className={cls}>{children}</span>
  );
}

export function Segmented<T extends string | number>({
  value,
  options,
  onChange,
  className,
  size = "md",
}: {
  value: T;
  options: { value: T; label: ReactNode }[];
  onChange: (v: T) => void;
  className?: string;
  size?: "sm" | "md";
}) {
  const idx = Math.max(0, options.findIndex((o) => o.value === value));
  return (
    <div className={cn("relative inline-grid rounded-xl border border-line bg-s1 p-1", className)} style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0,1fr))` }} role="tablist">
      <span
        className="absolute bottom-1 top-1 rounded-lg bg-s3 shadow-sm transition-[left] duration-200"
        style={{ width: `calc((100% - 8px) / ${options.length})`, left: `calc(4px + ${idx} * (100% - 8px) / ${options.length})` }}
      />
      {options.map((o) => (
        <button
          key={String(o.value)}
          role="tab"
          aria-selected={o.value === value}
          onClick={() => onChange(o.value)}
          className={cn(
            "relative z-10 whitespace-nowrap rounded-lg font-medium transition-colors",
            size === "sm" ? "h-7 px-3 text-xs" : "h-9 px-4 text-sm",
            o.value === value ? "text-fg" : "text-fg3 hover:text-fg2"
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn("relative h-6 w-10 shrink-0 rounded-full transition-colors", checked ? "bg-brand" : "bg-line-strong")}
    >
      <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white transition-[left] duration-150", checked ? "left-[18px]" : "left-0.5")} />
    </button>
  );
}

export function Avatar({ name, size = 36, tone }: { name: string; size?: number; tone?: string }) {
  const hue = tone ?? `hsl(${(name.charCodeAt(0) * 37 + name.length * 19) % 360} 38% 46%)`;
  return (
    <span
      className="inline-flex shrink-0 items-center justify-center rounded-full font-display font-semibold text-white/95"
      style={{ width: size, height: size, background: hue, fontSize: size * 0.4 }}
      aria-hidden
    >
      {name.trim()[0]?.toUpperCase()}
    </span>
  );
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-line-strong px-6 py-12 text-center">
      <p className="font-display text-base font-semibold text-fg">{title}</p>
      <p className="mt-1 max-w-sm text-sm text-fg3">{body}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/* ───────── Toast ───────── */

export function Toaster() {
  const toast = useStore((s) => s.toast);
  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => A.toast(""), 2800);
    return () => window.clearTimeout(t);
  }, [toast]);
  if (!toast || !toast.msg) return null;
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-24 z-[80] flex justify-center px-4 lg:bottom-8" role="status" aria-live="polite">
      <div key={toast.id} className="pop rounded-xl border border-line-strong bg-s3 px-4 py-2.5 text-sm text-fg shadow-xl shadow-black/30">
        {toast.msg}
      </div>
    </div>
  );
}
