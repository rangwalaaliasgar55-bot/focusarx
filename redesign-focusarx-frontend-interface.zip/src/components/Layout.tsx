import { useState, type ReactNode } from "react";
import { BarChart3, CalendarCheck, CheckSquare, Flame, Gauge, LayoutDashboard, Menu, Moon, PawPrint, Sun, Timer, Trophy, Users, X, Coins } from "lucide-react";
import { Link } from "../router";
import { A, computeStreak, fmtClock, levelInfo, useStore } from "../store";
import { cn } from "../utils/cn";
import { Avatar, Bar } from "./ui";

export function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" fill="none" aria-hidden>
      <circle cx="16" cy="16" r="13" stroke="var(--brand)" strokeWidth="2.5" strokeDasharray="62 20" strokeLinecap="round" transform="rotate(-70 16 16)" />
      <circle cx="16" cy="16" r="6.5" fill="var(--brand)" />
      <circle cx="18" cy="14" r="2" fill="var(--bg)" />
    </svg>
  );
}

const NAV: { group: string; items: { to: string; label: string; icon: typeof Timer }[] }[] = [
  {
    group: "Focus",
    items: [
      { to: "/focus", label: "Timer", icon: Timer },
      { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    ],
  },
  {
    group: "Plan",
    items: [
      { to: "/tasks", label: "Tasks", icon: CheckSquare },
      { to: "/habits", label: "Habits", icon: CalendarCheck },
    ],
  },
  { group: "Insights", items: [{ to: "/analytics", label: "Analytics", icon: BarChart3 }] },
  {
    group: "Community",
    items: [
      { to: "/rooms", label: "Study rooms", icon: Users },
      { to: "/leaderboard", label: "Leaderboard", icon: Trophy },
    ],
  },
  { group: "Companion", items: [{ to: "/pets", label: "Pets", icon: PawPrint }] },
];

const TITLES: Record<string, string> = {
  "/focus": "Timer",
  "/dashboard": "Dashboard",
  "/tasks": "Tasks",
  "/habits": "Habits",
  "/analytics": "Analytics",
  "/rooms": "Study rooms",
  "/leaderboard": "Leaderboard",
  "/pets": "Pets",
  "/settings": "Settings",
};

function MiniTimer({ path }: { path: string }) {
  const t = useStore((s) => s.timer);
  if (t.status === "idle" || path === "/focus") return null;
  const c = fmtClock(t.remaining);
  return (
    <Link to="/focus" className="mx-3 mb-3 flex items-center gap-3 rounded-xl border border-brand/40 bg-brand-soft px-3 py-2.5">
      <Gauge size={16} className="text-brand" />
      <div className="min-w-0 flex-1">
        <div className="num font-display text-base font-bold leading-none text-fg">
          {c.m}:{c.s}
        </div>
        <div className="mt-1 text-[11px] text-fg2">{t.status === "paused" ? "Paused" : t.mode === "focus" ? "Focusing" : "On a break"}</div>
      </div>
      <span className="text-xs font-medium text-brand">Open</span>
    </Link>
  );
}

function SidebarBody({ path, onNavigate }: { path: string; onNavigate?: () => void }) {
  const name = useStore((s) => s.settings.name);
  const xp = useStore((s) => s.xp);
  const lv = levelInfo(xp);
  return (
    <div className="flex h-full flex-col">
      <Link to="/" className="flex items-center gap-2.5 px-5 pb-6 pt-5" onClick={onNavigate}>
        <Logo />
        <span className="font-display text-[17px] font-bold tracking-tight">FocusArx</span>
      </Link>
      <nav className="flex-1 space-y-5 overflow-y-auto px-3" aria-label="Main">
        {NAV.map((g) => (
          <div key={g.group}>
            <div className="eyebrow mb-1.5 px-3">{g.group}</div>
            {g.items.map((it) => {
              const active = path === it.to;
              return (
                <Link
                  key={it.to}
                  to={it.to}
                  onClick={onNavigate}
                  aria-current={active ? "page" : undefined}
                  className={cn(
                    "relative flex h-10 items-center gap-3 rounded-xl px-3 text-sm font-medium transition-colors",
                    active ? "bg-s2 text-fg" : "text-fg2 hover:bg-s2/60 hover:text-fg"
                  )}
                >
                  {active && <span className="absolute -left-3 top-2.5 h-5 w-[3px] rounded-r-full bg-brand" />}
                  <it.icon size={17} className={active ? "text-brand" : ""} strokeWidth={active ? 2.2 : 1.9} />
                  {it.label}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>
      <MiniTimer path={path} />
      <div className="border-t border-line p-3">
        <Link to="/settings" onClick={onNavigate} className="flex items-center gap-3 rounded-xl p-2 hover:bg-s2/60">
          <Avatar name={name} size={38} tone="var(--s3)" />
          <div className="min-w-0 flex-1">
            <div className="flex items-center justify-between">
              <span className="truncate text-sm font-medium">{name}</span>
              <span className="num text-xs text-fg3">Lv {lv.level}</span>
            </div>
            <Bar pct={lv.pct} className="mt-1.5" />
          </div>
        </Link>
      </div>
    </div>
  );
}

function TopBar({ path, onMenu }: { path: string; onMenu: () => void }) {
  const sessions = useStore((s) => s.sessions);
  const coins = useStore((s) => s.coins);
  const theme = useStore((s) => s.settings.theme);
  const streak = computeStreak(sessions).current;
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-line bg-bg/85 px-4 backdrop-blur-md sm:px-8">
      <div className="flex items-center gap-3">
        <button onClick={onMenu} className="-ml-1 flex h-9 w-9 items-center justify-center rounded-lg text-fg2 hover:bg-s2 lg:hidden" aria-label="Open menu">
          <Menu size={20} />
        </button>
        <span className="font-display text-[15px] font-semibold tracking-tight lg:hidden">{TITLES[path] ?? "FocusArx"}</span>
        <span className="eyebrow hidden lg:block">{TITLES[path] ?? "FocusArx"}</span>
      </div>
      <div className="flex items-center gap-2">
        <div className="num flex h-9 items-center gap-1.5 rounded-lg border border-line bg-s1 px-3 text-sm font-medium" title="Current streak">
          <Flame size={15} className="text-warn" />
          {streak}
          <span className="hidden text-fg3 sm:inline">day streak</span>
        </div>
        <div className="num flex h-9 items-center gap-1.5 rounded-lg border border-line bg-s1 px-3 text-sm font-medium" title="Focus coins">
          <Coins size={15} className="text-brand" />
          {coins.toLocaleString()}
        </div>
        <button
          onClick={() => A.updateSettings({ theme: theme === "dark" ? "light" : "dark" })}
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-line bg-s1 text-fg2 hover:text-fg"
          aria-label={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}
        >
          {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
        </button>
      </div>
    </header>
  );
}

const TABS = [
  { to: "/focus", label: "Timer", icon: Timer },
  { to: "/dashboard", label: "Home", icon: LayoutDashboard },
  { to: "/tasks", label: "Tasks", icon: CheckSquare },
  { to: "/analytics", label: "Stats", icon: BarChart3 },
  { to: "/pets", label: "Pets", icon: PawPrint },
];

export default function Layout({ path, children }: { path: string; children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="min-h-full">
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[248px] border-r border-line bg-bg lg:block">
        <SidebarBody path={path} />
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <aside className="rise absolute inset-y-0 left-0 w-[280px] border-r border-line bg-bg">
            <button onClick={() => setOpen(false)} className="absolute right-3 top-4 flex h-9 w-9 items-center justify-center rounded-lg text-fg2 hover:bg-s2" aria-label="Close menu">
              <X size={18} />
            </button>
            <SidebarBody path={path} onNavigate={() => setOpen(false)} />
          </aside>
        </div>
      )}

      <div className="lg:pl-[248px]">
        <TopBar path={path} onMenu={() => setOpen(true)} />
        <main className="mx-auto w-full max-w-[1240px] px-4 pb-28 pt-7 sm:px-8 lg:pb-16">{children}</main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-5 border-t border-line bg-bg/92 px-2 pb-[max(6px,env(safe-area-inset-bottom))] pt-1.5 backdrop-blur-md lg:hidden" aria-label="Quick navigation">
        {TABS.map((t) => {
          const active = path === t.to;
          return (
            <Link key={t.to} to={t.to} className={cn("flex flex-col items-center gap-1 rounded-lg py-1.5 text-[11px] font-medium", active ? "text-brand" : "text-fg3")}>
              <t.icon size={20} strokeWidth={active ? 2.3 : 1.8} />
              {t.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

