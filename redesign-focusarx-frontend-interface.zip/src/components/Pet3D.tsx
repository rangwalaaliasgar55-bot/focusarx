import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import { getPetDef, type Palette, type Species } from "../lib/pets";

export type PetMood = "idle" | "focus" | "break" | "celebrate" | "sleep";

interface Rig {
  root: THREE.Group;
  bob: THREE.Group;
  head: THREE.Group;
  tail: THREE.Object3D | null;
  eyes: THREE.Object3D[];
  ears: THREE.Object3D[];
  arms: THREE.Object3D[];
  phones: THREE.Group;
  squishy: boolean;
  armDir?: number;
  dispose: () => void;
}

/* ───────── geometry helpers ───────── */

const sphereGeo = new THREE.SphereGeometry(1, 40, 28);
const coneGeo = new THREE.ConeGeometry(1, 1, 28, 1);

function std(color: number, extra: THREE.MeshStandardMaterialParameters = {}) {
  return new THREE.MeshStandardMaterial({ color, roughness: 0.72, metalness: 0, ...extra });
}

function ell(mat: THREE.Material, r: number, pos: [number, number, number], scale: [number, number, number] = [1, 1, 1]) {
  const m = new THREE.Mesh(sphereGeo, mat);
  m.scale.set(r * scale[0], r * scale[1], r * scale[2]);
  m.position.set(...pos);
  return m;
}

function cone(mat: THREE.Material, r: number, h: number, pos: [number, number, number], scale: [number, number, number] = [1, 1, 1]) {
  const m = new THREE.Mesh(coneGeo, mat);
  m.scale.set(r * scale[0], h * scale[1], r * scale[2]);
  m.position.set(...pos);
  return m;
}

const eyeMat = std(0x16161c, { roughness: 0.25 });
const glintMat = new THREE.MeshBasicMaterial({ color: 0xffffff });

function makeEyes(parent: THREE.Object3D, x: number, y: number, z: number, r: number, iris?: { color: number; r: number }) {
  const eyes: THREE.Object3D[] = [];
  for (const side of [-1, 1]) {
    const g = new THREE.Group();
    g.position.set(side * x, y, z);
    if (iris) g.add(ell(std(iris.color, { roughness: 0.4 }), iris.r, [0, 0, -0.02], [1, 1, 0.45]));
    g.add(ell(eyeMat, r, [0, 0, iris ? 0.06 : 0], [1, 1.12, 0.62]));
    g.add(ell(glintMat, r * 0.3, [r * 0.32, r * 0.42, r * 0.52], [1, 1, 0.5]));
    g.add(ell(glintMat, r * 0.14, [-r * 0.3, -r * 0.3, r * 0.55], [1, 1, 0.5]));
    parent.add(g);
    eyes.push(g);
  }
  return eyes;
}

function makeCheeks(parent: THREE.Object3D, mat: THREE.Material, x: number, y: number, z: number, r: number) {
  for (const side of [-1, 1]) {
    const c = ell(mat, r, [side * x, y, z], [1.2, 0.65, 0.3]);
    c.rotation.y = side * 0.7;
    parent.add(c);
  }
}

function makeEars(parent: THREE.Object3D, main: THREE.Material, inner: THREE.Material, tip: THREE.Material | null, x: number, y: number, r: number, h: number, tilt: number) {
  const ears: THREE.Object3D[] = [];
  for (const side of [-1, 1]) {
    const g = new THREE.Group();
    g.position.set(side * x, y, -0.05);
    g.rotation.z = -side * tilt;
    g.add(cone(main, r, h, [0, h / 2, 0], [1, 1, 0.55]));
    g.add(cone(inner, r * 0.62, h * 0.72, [0, h * 0.4, r * 0.18], [1, 1, 0.4]));
    if (tip) {
      const t = cone(tip, r * 0.42, h * 0.4, [0, h * 0.8, 0], [1, 1, 0.58]);
      g.add(t);
    }
    parent.add(g);
    ears.push(g);
  }
  return ears;
}

function makeHeadphones(R: number, y = 0, squash = 0.8) {
  const g = new THREE.Group();
  g.position.y = y;
  const shell = std(0x24252c, { roughness: 0.45 });
  const brand = std(0x8f82ff, { roughness: 0.35 });
  const band = new THREE.Mesh(new THREE.TorusGeometry(R, 0.06, 14, 56, Math.PI), shell);
  band.scale.y = squash;
  g.add(band);
  for (const side of [-1, 1]) {
    const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.2, 32), shell);
    cup.rotation.z = Math.PI / 2;
    cup.position.set(side * (R + 0.03), 0, 0);
    g.add(cup);
    const ring = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 0.215, 32), brand);
    ring.rotation.z = Math.PI / 2;
    ring.position.set(side * (R + 0.03), 0, 0);
    g.add(ring);
  }
  return g;
}

/* ───────── species builders ───────── */

function buildFox(p: Palette): Rig {
  const root = new THREE.Group();
  const bob = new THREE.Group();
  root.add(bob);
  const main = std(p.main);
  const belly = std(p.belly);
  const dark = std(p.dark);
  const pink = std(p.accent);

  bob.add(ell(main, 0.64, [0, 0.64, 0], [1, 0.95, 0.9]));
  bob.add(ell(belly, 0.5, [0, 0.6, 0.3], [0.85, 0.9, 0.55]));
  const arms: THREE.Object3D[] = [];
  for (const s of [-1, 1]) {
    bob.add(ell(dark, 0.18, [s * 0.3, 0.09, 0.4], [1, 0.62, 1.25]));
    const arm = ell(main, 0.16, [s * 0.58, 0.64, 0.25], [0.8, 1.25, 0.8]);
    arm.rotation.z = s * 0.2;
    bob.add(arm);
    arms.push(arm);
  }

  const tail = new THREE.Group();
  tail.position.set(0, 0.35, -0.52);
  const tailInner = new THREE.Group();
  tailInner.rotation.x = -0.95;
  tailInner.add(ell(main, 0.3, [0, 0.46, 0], [0.85, 1.75, 0.85]));
  tailInner.add(ell(belly, 0.23, [0, 0.98, 0], [0.9, 1, 0.9]));
  tail.add(tailInner);
  bob.add(tail);

  const head = new THREE.Group();
  head.position.set(0, 1.5, 0.05);
  head.add(ell(main, 0.8, [0, 0, 0], [1.15, 0.92, 1]));
  for (const s of [-1, 1]) {
    const tuft = ell(belly, 0.3, [s * 0.66, -0.25, 0.22], [1, 0.72, 0.8]);
    tuft.rotation.z = s * -0.5;
    head.add(tuft);
  }
  head.add(ell(belly, 0.34, [0, -0.26, 0.7], [1.05, 0.75, 0.8]));
  head.add(ell(dark, 0.09, [0, -0.13, 0.99], [1.2, 0.85, 0.9]));
  makeCheeks(head, pink, 0.58, -0.14, 0.57, 0.12);
  const eyes = makeEyes(head, 0.36, 0.1, 0.69, 0.1);
  const ears = makeEars(head, main, pink, dark, 0.52, 0.64, 0.3, 0.7, 0.3);
  const phones = makeHeadphones(0.93, 0.0);
  head.add(phones);
  bob.add(head);

  return { root, bob, head, tail, eyes, ears, arms, phones, squishy: false, dispose: () => {} };
}

function buildCat(p: Palette): Rig {
  const root = new THREE.Group();
  const bob = new THREE.Group();
  root.add(bob);
  const main = std(p.main);
  const belly = std(p.belly);
  const dark = std(p.dark);
  const pink = std(p.accent);

  bob.add(ell(main, 0.6, [0, 0.62, 0], [1, 0.98, 0.88]));
  bob.add(ell(belly, 0.46, [0, 0.58, 0.28], [0.8, 0.9, 0.5]));
  const arms: THREE.Object3D[] = [];
  for (const s of [-1, 1]) {
    bob.add(ell(belly, 0.17, [s * 0.28, 0.09, 0.4], [1, 0.62, 1.25]));
    const arm = ell(main, 0.15, [s * 0.55, 0.62, 0.25], [0.8, 1.25, 0.8]);
    arm.rotation.z = s * 0.2;
    bob.add(arm);
    arms.push(arm);
  }
  // curled tail
  const tail = new THREE.Group();
  tail.position.set(0, 0.32, -0.5);
  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0, 0),
    new THREE.Vector3(0, 0.22, -0.32),
    new THREE.Vector3(0, 0.62, -0.4),
    new THREE.Vector3(0, 0.98, -0.22),
    new THREE.Vector3(0, 1.08, 0.08),
  ]);
  const tube = new THREE.Mesh(new THREE.TubeGeometry(curve, 28, 0.1, 14, false), main);
  tail.add(tube);
  tail.add(ell(dark, 0.115, [0, 1.08, 0.08]));
  bob.add(tail);

  const head = new THREE.Group();
  head.position.set(0, 1.48, 0.05);
  head.add(ell(main, 0.8, [0, 0, 0], [1.2, 0.9, 1]));
  head.add(ell(belly, 0.27, [0, -0.28, 0.66], [1.3, 0.85, 0.75]));
  head.add(ell(pink, 0.07, [0, -0.15, 0.93], [1.3, 0.9, 0.8]));
  makeCheeks(head, pink, 0.6, -0.16, 0.55, 0.11);
  for (const x of [-0.14, 0, 0.14]) {
    const stripe = ell(dark, 0.05, [x, 0.6, 0.42], [0.6, 2.8, 0.4]);
    stripe.rotation.x = -0.85;
    head.add(stripe);
  }
  const whiskerMat = std(p.belly, { roughness: 0.6 });
  for (const s of [-1, 1]) {
    for (const k of [-1, 0, 1]) {
      const w = new THREE.Group();
      w.position.set(s * 0.42, -0.22 + k * 0.07, 0.78);
      w.rotation.y = s * (0.5 + 0.0);
      w.rotation.z = s * k * 0.14;
      const m = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.5, 6), whiskerMat);
      m.rotation.z = Math.PI / 2;
      m.position.x = s * 0.25;
      w.add(m);
      head.add(w);
    }
  }
  const eyes = makeEyes(head, 0.38, 0.1, 0.69, 0.105);
  const ears = makeEars(head, main, pink, null, 0.56, 0.58, 0.31, 0.52, 0.2);
  const phones = makeHeadphones(0.97, 0.0, 0.76);
  head.add(phones);
  bob.add(head);

  return { root, bob, head, tail, eyes, ears, arms, phones, squishy: false, dispose: () => tube.geometry.dispose() };
}

function buildOwl(p: Palette): Rig {
  const root = new THREE.Group();
  const bob = new THREE.Group();
  root.add(bob);
  const main = std(p.main);
  const belly = std(p.belly);
  const dark = std(p.dark);
  const beakMat = std(p.accent, { roughness: 0.45 });

  bob.add(ell(main, 0.78, [0, 0.82, 0], [1, 1.02, 0.9]));
  bob.add(ell(belly, 0.6, [0, 0.76, 0.4], [0.88, 1, 0.45]));
  for (let row = 0; row < 3; row++) {
    for (let i = -1 + (row % 2) * 0.5; i <= 1; i++) {
      const f = ell(dark, 0.07, [i * 0.2, 0.92 - row * 0.2, 0.64 - Math.abs(i) * 0.04 - row * 0.02], [1.4, 0.55, 0.3]);
      f.material = std(p.main, { roughness: 0.8 });
      bob.add(f);
    }
  }
  const arms: THREE.Object3D[] = [];
  for (const s of [-1, 1]) {
    const w = new THREE.Group();
    w.position.set(s * 0.74, 1.05, -0.02);
    const wing = ell(dark, 0.3, [s * 0.06, -0.42, 0], [0.5, 1.5, 0.85]);
    w.add(wing);
    w.rotation.z = s * 0.1;
    bob.add(w);
    arms.push(w);
    bob.add(ell(beakMat, 0.17, [s * 0.26, 0.07, 0.44], [1, 0.45, 1.3]));
  }

  const head = new THREE.Group();
  head.position.set(0, 1.62, 0.05);
  head.add(ell(main, 0.76, [0, 0, 0], [1.2, 0.84, 0.95]));
  for (const s of [-1, 1]) head.add(ell(belly, 0.42, [s * 0.38, -0.02, 0.5], [1, 1.02, 0.35]));
  const beak = new THREE.Mesh(coneGeo, beakMat);
  beak.scale.set(0.11, 0.24, 0.11);
  beak.rotation.x = Math.PI / 2;
  beak.position.set(0, -0.14, 0.86);
  head.add(beak);
  const eyes = makeEyes(head, 0.38, 0.04, 0.66, 0.12, { color: p.accent, r: 0.23 });
  const ears: THREE.Object3D[] = [];
  for (const s of [-1, 1]) {
    const t = new THREE.Group();
    t.position.set(s * 0.6, 0.58, 0);
    t.rotation.z = -s * 0.5;
    t.add(cone(dark, 0.17, 0.44, [0, 0.2, 0], [1, 1, 0.6]));
    head.add(t);
    ears.push(t);
  }
  const phones = makeHeadphones(0.92, 0.0, 0.72);
  head.add(phones);
  bob.add(head);

  return { root, bob, head, tail: null, eyes, ears, arms, phones, squishy: false, armDir: 1, dispose: () => {} };
}

function buildSlime(p: Palette): Rig {
  const root = new THREE.Group();
  const bob = new THREE.Group();
  root.add(bob);
  const jelly = new THREE.MeshPhysicalMaterial({
    color: p.main,
    roughness: 0.22,
    clearcoat: 1,
    clearcoatRoughness: 0.18,
    transparent: true,
    opacity: 0.93,
  });
  const core = std(p.belly, { transparent: true, opacity: 0.55, roughness: 0.4 });
  const leaf = std(p.accent, { roughness: 0.55 });
  const blob = ell(jelly, 0.95, [0, 0.8, 0], [1.16, 0.86, 1.1]);
  bob.add(blob);
  bob.add(ell(core, 0.42, [0, 0.62, -0.05], [1, 0.8, 0.9]));
  bob.add(ell(std(0xffffff, { emissive: 0xffffff, emissiveIntensity: 0.65, transparent: true, opacity: 0.8 }), 0.13, [-0.52, 1.22, 0.62], [1.5, 0.8, 0.5]));
  for (const s of [-1, 1]) bob.add(ell(jelly, 0.2, [s * 1.0, 0.18, 0.22], [1, 0.6, 1]));
  const head = new THREE.Group();
  head.position.set(0, 0.8, 0);
  const eyes = makeEyes(head, 0.34, 0.1, 0.93, 0.115);
  const mouth = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.017, 8, 20, Math.PI), eyeMat);
  mouth.rotation.z = Math.PI;
  mouth.position.set(0, -0.12, 1.0);
  head.add(mouth);
  makeCheeks(head, std(0xff9fb5, { transparent: true, opacity: 0.75 }), 0.58, -0.08, 0.8, 0.12);
  const l1 = ell(leaf, 0.24, [0.09, 0.85, 0], [1, 0.28, 0.55]);
  l1.rotation.z = 0.55;
  const l2 = ell(leaf, 0.2, [-0.12, 0.84, 0.02], [1, 0.28, 0.55]);
  l2.rotation.z = -0.5;
  head.add(l1, l2);
  const phones = makeHeadphones(1.14, 0.0, 0.72);
  head.add(phones);
  bob.add(head);
  return { root, bob, head, tail: null, eyes, ears: [l1, l2], arms: [], phones, squishy: true, dispose: () => mouth.geometry.dispose() };
}

function buildPet(species: Species, palette: Palette): Rig {
  switch (species) {
    case "cat":
      return buildCat(palette);
    case "owl":
      return buildOwl(palette);
    case "slime":
      return buildSlime(palette);
    default:
      return buildFox(palette);
  }
}

function disposeRig(rig: Rig) {
  rig.root.traverse((o) => {
    const m = o as THREE.Mesh;
    if (m.isMesh) {
      const mat = m.material as THREE.Material | THREE.Material[];
      if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      else mat.dispose();
      if (m.geometry !== sphereGeo && m.geometry !== coneGeo) m.geometry.dispose();
    }
  });
  rig.dispose();
}

/* ───────── component ───────── */

interface Props {
  species: Species;
  variant: number;
  mood?: PetMood;
  celebrateAt?: number;
  className?: string;
  zoom?: number;
  yOffset?: number;
  drag?: boolean;
  autoRotate?: boolean;
  onPoke?: () => void;
  label?: string;
}

interface SceneRefs {
  scene: THREE.Scene;
  rig: Rig | null;
  shadow: THREE.Mesh;
  born?: number;
}

export default function Pet3D({ species, variant, mood = "idle", celebrateAt = 0, className = "", zoom = 1, yOffset = 0, drag = false, autoRotate = false, onPoke, label }: Props) {
  const wrap = useRef<HTMLDivElement>(null);
  const refs = useRef<SceneRefs | null>(null);
  const live = useRef({ mood, celebrateAt, zoom, yOffset, drag, autoRotate, onPoke });
  const [failed, setFailed] = useState(false);
  live.current = { mood, celebrateAt, zoom, yOffset, drag, autoRotate, onPoke };

  // swap model when species / colourway changes
  useEffect(() => {
    const r = refs.current;
    if (!r) return;
    if (r.rig) {
      r.scene.remove(r.rig.root);
      disposeRig(r.rig);
    }
    const rig = buildPet(species, getPetDef(species, variant).palette);
    rig.root.scale.setScalar(0.01);
    r.scene.add(rig.root);
    r.rig = rig;
    (r as SceneRefs & { born?: number }).born = performance.now();
  }, [species, variant]);

  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "low-power" });
    } catch {
      setFailed(true);
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.domElement.style.cssText = "width:100%;height:100%;display:block;touch-action:pan-y;outline:none";
    el.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(28, 1, 0.1, 50);

    scene.add(new THREE.HemisphereLight(0xffffff, 0x9a96b8, 1.35));
    const key = new THREE.DirectionalLight(0xfff1e0, 2.6);
    key.position.set(3, 5, 4.5);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0x8f82ff, 2.2);
    rim.position.set(-4, 3, -3);
    scene.add(rim);
    const fill = new THREE.DirectionalLight(0xbcd0ff, 0.6);
    fill.position.set(-3, 1, 4);
    scene.add(fill);

    // soft contact shadow
    const c = document.createElement("canvas");
    c.width = c.height = 128;
    const cx = c.getContext("2d")!;
    const grad = cx.createRadialGradient(64, 64, 0, 64, 64, 64);
    grad.addColorStop(0, "rgba(0,0,0,0.55)");
    grad.addColorStop(0.55, "rgba(0,0,0,0.2)");
    grad.addColorStop(1, "rgba(0,0,0,0)");
    cx.fillStyle = grad;
    cx.fillRect(0, 0, 128, 128);
    const shadow = new THREE.Mesh(new THREE.PlaneGeometry(2.8, 2.8), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false }));
    shadow.rotation.x = -Math.PI / 2;
    shadow.position.y = 0.005;
    scene.add(shadow);

    const sr: SceneRefs & { born?: number } = { scene, rig: null, shadow };
    refs.current = sr;
    const rig = buildPet(species, getPetDef(species, variant).palette);
    rig.root.scale.setScalar(0.01);
    scene.add(rig.root);
    sr.rig = rig;
    sr.born = performance.now();

    const size = { w: 1, h: 1 };
    const resize = () => {
      const w = el.clientWidth || 1;
      const h = el.clientHeight || 1;
      size.w = w;
      size.h = h;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(el);

    let visible = true;
    const io = new IntersectionObserver((e) => {
      visible = e[0]?.isIntersecting ?? true;
    });
    io.observe(el);

    const pointer = { x: 0, y: 0 };
    const onMove = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      const cxp = r.left + r.width / 2;
      const cyp = r.top + r.height * 0.35;
      pointer.x = Math.max(-1, Math.min(1, (e.clientX - cxp) / (window.innerWidth * 0.45)));
      pointer.y = Math.max(-1, Math.min(1, (e.clientY - cyp) / (window.innerHeight * 0.5)));
    };
    window.addEventListener("pointermove", onMove);

    // drag + poke
    let dragging = false;
    let moved = 0;
    let lastX = 0;
    let yaw = 0;
    let pokeAt = -10000;
    const dom = renderer.domElement;
    const down = (e: PointerEvent) => {
      dragging = true;
      moved = 0;
      lastX = e.clientX;
      dom.setPointerCapture?.(e.pointerId);
    };
    const move = (e: PointerEvent) => {
      if (!dragging) return;
      const dx = e.clientX - lastX;
      lastX = e.clientX;
      moved += Math.abs(dx);
      if (live.current.drag) yaw += dx * 0.012;
    };
    const up = () => {
      if (!dragging) return;
      dragging = false;
      if (moved < 5) {
        pokeAt = performance.now();
        live.current.onPoke?.();
      }
    };
    dom.addEventListener("pointerdown", down);
    dom.addEventListener("pointermove", move);
    dom.addEventListener("pointerup", up);
    dom.addEventListener("pointercancel", up);
    dom.style.cursor = "pointer";

    const clock = new THREE.Clock();
    let raf = 0;
    let nextBlink = 2;
    let blinkStart = -1;
    let headX = 0;
    let headY = 0;
    let phonesS = 0;
    let celebrateSeen = live.current.celebrateAt;
    let celebrateStart = -10000;
    let autoYaw = 0;

    const loop = () => {
      raf = requestAnimationFrame(loop);
      const dt = Math.min(clock.getDelta(), 0.05);
      if (!visible || document.hidden) return;
      const t = clock.elapsedTime;
      const nowMs = performance.now();
      const L = live.current;
      const r = sr.rig;

      // frame the camera
      const fovT = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
      const aspect = size.w / size.h;
      const fh = 3.35 / L.zoom;
      const fw = 2.7 / L.zoom;
      const dist = Math.max(fh / 2 / fovT, fw / 2 / (fovT * aspect));
      camera.position.set(0, 1.25 + L.yOffset + 0.55, dist);
      camera.lookAt(0, 1.2 + L.yOffset, 0);

      if (r) {
        if (L.celebrateAt !== celebrateSeen) {
          celebrateSeen = L.celebrateAt;
          if (L.celebrateAt > 0) celebrateStart = nowMs;
        }
        const born = Math.min(1, (nowMs - (sr.born ?? 0)) / 520);
        const eb = 1 - Math.pow(1 - born, 3);
        const overshoot = born < 1 ? 1 + Math.sin(born * Math.PI) * 0.08 : 1;
        r.root.scale.setScalar(Math.max(0.01, eb * overshoot));

        const m = L.mood;
        const cu = (nowMs - celebrateStart) / 1700;
        const celebrating = cu >= 0 && cu < 1;
        const pu = (nowMs - pokeAt) / 650;
        const poking = pu >= 0 && pu < 1;

        // jump
        let jump = 0;
        let spin = 0;
        if (celebrating) {
          jump = Math.abs(Math.sin(cu * Math.PI * 3)) * 0.55 * (1 - cu * 0.6);
          spin = (1 - Math.pow(1 - Math.min(1, cu * 1.4), 3)) * Math.PI * 2;
        } else if (poking) {
          jump = Math.abs(Math.sin(pu * Math.PI * 2)) * 0.28 * (1 - pu);
        } else if (m === "break") {
          jump = Math.abs(Math.sin(t * 3.2)) * 0.2;
        }
        r.bob.position.y = jump;

        // breathing + squash
        const speed = m === "focus" ? 1.3 : m === "sleep" ? 1 : 2.1;
        const br = Math.sin(t * speed);
        const sq = r.squishy ? 0.05 : 0.016;
        let sy = 1 + br * sq;
        let sxz = 1 - br * sq * 0.5;
        if (jump > 0.02) {
          sy += jump * (r.squishy ? 0.35 : 0.12);
          sxz -= jump * (r.squishy ? 0.14 : 0.05);
        } else if (jump > 0 && (celebrating || poking || m === "break")) {
          sy -= r.squishy ? 0.12 : 0.04;
          sxz += r.squishy ? 0.07 : 0.02;
        }
        r.bob.scale.set(sxz, sy, sxz);

        // facing
        let target = 0;
        if (L.drag) {
          if (!dragging && !L.autoRotate) yaw *= 1 - Math.min(1, dt * 1.6);
          if (L.autoRotate && !dragging) {
            autoYaw += dt * 0.5;
          }
        }
        target = yaw + (L.autoRotate ? Math.sin(autoYaw) * 0.5 : 0);
        r.root.rotation.y += (target + spin - r.root.rotation.y) * Math.min(1, dt * (spin ? 20 : 8));

        // head
        let hx = pointer.y * 0.28;
        let hy = pointer.x * 0.6 - yaw * 0.3;
        if (m === "focus") {
          hx = 0.2 + Math.sin(t * 0.7) * 0.03;
          hy = Math.sin(t * 0.45) * 0.08 + pointer.x * 0.18;
        } else if (m === "sleep") {
          hx = 0.42 + Math.sin(t * 1) * 0.03;
          hy = 0;
        }
        headX += (hx - headX) * Math.min(1, dt * 5);
        headY += (hy - headY) * Math.min(1, dt * 5);
        r.head.rotation.x = headX;
        r.head.rotation.y = headY;
        r.head.rotation.z = Math.sin(t * 0.8) * 0.02 + (m === "focus" ? 0 : pointer.x * -0.05);

        // blink
        let open = m === "focus" ? 0.82 : 1;
        if (m === "sleep") open = 0.08;
        else if (celebrating) open = 0.4;
        else {
          if (t > nextBlink && blinkStart < 0) blinkStart = t;
          if (blinkStart >= 0) {
            const k = (t - blinkStart) / 0.16;
            if (k >= 1) {
              blinkStart = -1;
              nextBlink = t + 2 + Math.random() * 3.5;
            } else open *= Math.max(0.06, Math.abs(k * 2 - 1));
          }
        }
        for (const e of r.eyes) e.scale.y += (open - e.scale.y) * Math.min(1, dt * 22);

        // tail
        if (r.tail) {
          const amp = m === "break" || celebrating ? 0.75 : m === "focus" ? 0.12 : 0.28;
          const sp = m === "break" || celebrating ? 9 : m === "focus" ? 1.4 : 2.8;
          r.tail.rotation.y = Math.sin(t * sp) * amp;
        }
        // ears
        r.ears.forEach((e, i) => {
          const base = e.userData.baseZ ?? (e.userData.baseZ = e.rotation.z);
          const tw = Math.sin(t * 0.9 + i * 2.1) > 0.97 ? 0.25 : 0;
          const droop = m === "sleep" ? (i ? -0.3 : 0.3) : 0;
          e.rotation.z += (base + (i ? -tw : tw) + droop - e.rotation.z) * Math.min(1, dt * 12);
        });
        // arms / wings
        r.arms.forEach((a, i) => {
          const s = i === 0 ? -1 : 1;
          const base = a.userData.baseZ ?? (a.userData.baseZ = a.rotation.z);
          const up = celebrating || poking ? 1 : 0;
          const flap = up ? Math.sin(t * 16) * 0.12 : 0;
          const dir = r.armDir ?? -1;
          const tz = base + s * dir * (up ? 0.95 : 0) + flap * s * dir;
          a.rotation.z += (tz - a.rotation.z) * Math.min(1, dt * 14);
        });
        // headphones appear while focusing
        const wantPhones = m === "focus" ? 1 : 0;
        phonesS += (wantPhones - phonesS) * Math.min(1, dt * 7);
        r.phones.visible = phonesS > 0.03;
        r.phones.scale.setScalar(Math.max(0.01, phonesS));

        // shadow
        const ss = 1 - Math.min(0.35, jump * 0.5);
        sr.shadow.scale.set(ss * (r.squishy ? 1.1 : 1), ss * (r.squishy ? 1.1 : 1), 1);
        (sr.shadow.material as THREE.MeshBasicMaterial).opacity = 1 - Math.min(0.4, jump * 0.6);
      }
      renderer.render(scene, camera);
    };
    loop();

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      window.removeEventListener("pointermove", onMove);
      dom.removeEventListener("pointerdown", down);
      dom.removeEventListener("pointermove", move);
      dom.removeEventListener("pointerup", up);
      dom.removeEventListener("pointercancel", up);
      if (sr.rig) disposeRig(sr.rig);
      (shadow.material as THREE.MeshBasicMaterial).map?.dispose();
      (shadow.material as THREE.Material).dispose();
      shadow.geometry.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
      dom.remove();
      refs.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (failed) {
    const def = getPetDef(species, variant);
    return (
      <div className={`flex items-center justify-center ${className}`} role="img" aria-label={label ?? def.label}>
        <div className="flex h-28 w-28 items-center justify-center rounded-full text-3xl font-semibold text-black/70" style={{ background: def.swatch }}>
          {def.label[0]}
        </div>
      </div>
    );
  }

  return <div ref={wrap} className={className} role="img" aria-label={label ?? "Your 3D pet companion. Click to interact."} />;
}
