import { useState } from "react";
import { DAY, dayKey, fmtDuration, type Session } from "../store";
import { cn } from "../utils/cn";

/* ───────── Bar chart (daily minutes) ───────── */

export interface BarDatum {
  label: string;
  value: number;
  tip: string;
  emphasis?: boolean;
}

export function BarChart({ data, height = 190, goal, labelEvery = 1 }: { data: BarDatum[]; height?: number; goal?: number; labelEvery?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(goal ?? 0, ...data.map((d) => d.value), 30) * 1.12;
  const dense = data.length > 20;
  return (
    <div>
      <div className="relative" style={{ height }}>
        {[0, 0.5, 1].map((g) => (
          <div key={g} className="absolute inset-x-0 border-t border-dashed border-line" style={{ bottom: `${g * 100}%` }} />
        ))}
        {goal ? (
          <div className="absolute inset-x-0 z-10 border-t border-dashed border-brand/60" style={{ bottom: `${(goal / max) * 100}%` }}>
            <span className="absolute -top-5 right-0 rounded bg-bg px-1 text-[10px] font-medium text-brand">Goal {fmtDuration(goal)}</span>
          </div>
        ) : null}
        <div className={cn("absolute inset-0 flex items-end", dense ? "gap-[3px]" : "gap-2 sm:gap-3")}>
          {data.map((d, i) => (
            <div key={i} className="relative flex h-full flex-1 items-end" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} onFocus={() => setHover(i)} onBlur={() => setHover(null)} tabIndex={0} aria-label={d.tip}>
              <div
                className={cn("w-full rounded-t-[5px] transition-[height,background] duration-500", d.emphasis ? "bg-brand" : hover === i ? "bg-brand/80" : "bg-brand/35")}
                style={{ height: `${Math.max(d.value > 0 ? 2 : 0.5, (d.value / max) * 100)}%`, minHeight: d.value > 0 ? 3 : 1 }}
              />
              {hover === i && (
                <div className="pop pointer-events-none absolute bottom-full left-1/2 z-20 mb-2 -translate-x-1/2 whitespace-nowrap rounded-lg border border-line-strong bg-s3 px-2.5 py-1.5 text-xs text-fg shadow-lg">
                  {d.tip}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      <div className={cn("mt-2.5 flex", dense ? "gap-[3px]" : "gap-2 sm:gap-3")}>
        {data.map((d, i) => (
          <div key={i} className="num flex-1 text-center text-[11px] text-fg3">
            {i % labelEvery === 0 || i === data.length - 1 ? d.label : ""}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ───────── Heatmap ───────── */

export function Heatmap({ byDay, weeks = 18 }: { byDay: Record<string, number>; weeks?: number }) {
  const [hover, setHover] = useState<string | null>(null);
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  const dow = (today.getDay() + 6) % 7; // Monday = 0
  const start = new Date(today.getTime() - (dow + (weeks - 1) * 7) * DAY);
  const cols: { key: string; date: Date; future: boolean }[][] = [];
  for (let w = 0; w < weeks; w++) {
    const col = [];
    for (let d = 0; d < 7; d++) {
      const date = new Date(start.getTime() + (w * 7 + d) * DAY);
      col.push({ key: dayKey(date), date, future: date.getTime() > today.getTime() + 3600_000 });
    }
    cols.push(col);
  }
  const level = (m: number) => (m <= 0 ? 0 : m < 30 ? 1 : m < 75 ? 2 : m < 130 ? 3 : 4);
  const fill = ["var(--s3)", "color-mix(in oklab, var(--brand) 28%, var(--s3))", "color-mix(in oklab, var(--brand) 52%, var(--s3))", "color-mix(in oklab, var(--brand) 78%, var(--s3))", "var(--brand)"];
  const months: { i: number; label: string }[] = [];
  cols.forEach((c, i) => {
    const d = c[0].date;
    if (i === 0 || d.getMonth() !== cols[i - 1][0].date.getMonth()) months.push({ i, label: d.toLocaleString("en", { month: "short" }) });
  });
  const hv = hover ? cols.flat().find((c) => c.key === hover) : null;
  return (
    <div>
      <div className="overflow-x-auto pb-1">
        <div className="inline-block min-w-full">
          <div className="relative mb-1.5 ml-7 h-4">
            {months.map((m) => (
              <span key={m.i} className="absolute text-[11px] text-fg3" style={{ left: `${(m.i / weeks) * 100}%` }}>
                {m.label}
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <div className="grid w-5 grid-rows-7 gap-[3px] text-[10px] text-fg3" style={{ gridTemplateRows: "repeat(7, 1fr)" }}>
              {["Mon", "", "Wed", "", "Fri", "", "Sun"].map((d, i) => (
                <span key={i} className="flex items-center">
                  {d}
                </span>
              ))}
            </div>
            <div className="grid flex-1 gap-[3px]" style={{ gridTemplateColumns: `repeat(${weeks}, minmax(10px, 1fr))` }}>
              {cols.map((col, i) => (
                <div key={i} className="grid gap-[3px]">
                  {col.map((c) => (
                    <div
                      key={c.key}
                      onMouseEnter={() => setHover(c.key)}
                      onMouseLeave={() => setHover(null)}
                      className={cn("aspect-square w-full rounded-[3px]", c.future && "opacity-0", hover === c.key && "ring-1 ring-fg/60")}
                      style={{ background: fill[level(byDay[c.key] ?? 0)] }}
                      title={`${c.date.toLocaleDateString("en", { month: "short", day: "numeric" })}: ${fmtDuration(byDay[c.key] ?? 0)}`}
                    />
                  ))}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="mt-3 flex items-center justify-between text-[11px] text-fg3">
        <span className="num">{hv ? `${hv.date.toLocaleDateString("en", { weekday: "long", month: "short", day: "numeric" })} · ${fmtDuration(byDay[hv.key] ?? 0)}` : "Hover a day for details"}</span>
        <span className="flex items-center gap-1.5">
          Less
          {fill.map((f, i) => (
            <span key={i} className="h-2.5 w-2.5 rounded-[3px]" style={{ background: f }} />
          ))}
          More
        </span>
      </div>
    </div>
  );
}

/* ───────── Focus DNA (hour of day) ───────── */

export function HourChart({ sessions }: { sessions: Session[] }) {
  const hours = new Array(24).fill(0);
  for (const s of sessions) hours[new Date(s.ts).getHours()] += s.minutes;
  const max = Math.max(...hours, 1);
  const peak = hours.indexOf(Math.max(...hours));
  const fmt = (h: number) => `${h % 12 === 0 ? 12 : h % 12}${h < 12 ? "am" : "pm"}`;
  return (
    <div>
      <div className="flex h-28 items-end gap-[3px]">
        {hours.map((m, h) => (
          <div key={h} className="group relative flex h-full flex-1 items-end" title={`${fmt(h)} · ${fmtDuration(m)}`}>
            <div className={cn("w-full rounded-t-[3px]", h === peak ? "bg-brand" : "bg-brand/30")} style={{ height: `${Math.max(2, (m / max) * 100)}%` }} />
          </div>
        ))}
      </div>
      <div className="mt-2 flex justify-between text-[11px] text-fg3">
        <span>12am</span>
        <span>6am</span>
        <span>12pm</span>
        <span>6pm</span>
        <span>12am</span>
      </div>
      <p className="mt-3 text-[13px] text-fg2">
        Your sharpest hour is <span className="font-semibold text-fg">{fmt(peak)}</span>. Protect it for your hardest task.
      </p>
    </div>
  );
}

/* ───────── Ring gauge ───────── */

export function Gauge({ pct, size = 132, stroke = 10, children }: { pct: number; size?: number; stroke?: number; children?: React.ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const p = Math.max(0, Math.min(1, pct));
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90" aria-hidden>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--ring-track)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={p >= 1 ? "var(--ok)" : "var(--brand)"} strokeWidth={stroke} strokeLinecap="round" strokeDasharray={`${p * c} ${c}`} style={{ transition: "stroke-dasharray .6s ease" }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}
