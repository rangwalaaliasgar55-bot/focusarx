import { useEffect, useState, type AnchorHTMLAttributes, type ReactNode } from "react";

export function currentPath(): string {
  const h = window.location.hash.replace(/^#/, "");
  const p = h.split("?")[0] || "/";
  return p.startsWith("/") ? p : "/" + p;
}

export function useRoute(): string {
  const [path, setPath] = useState(currentPath());
  useEffect(() => {
    const on = () => {
      setPath(currentPath());
      window.scrollTo({ top: 0 });
    };
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return path;
}

export function go(path: string) {
  window.location.hash = path;
}

export function Link({ to, children, ...rest }: { to: string; children: ReactNode } & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href">) {
  return (
    <a href={`#${to}`} {...rest}>
      {children}
    </a>
  );
}
