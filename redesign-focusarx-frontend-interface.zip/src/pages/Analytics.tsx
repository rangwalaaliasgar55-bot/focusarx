import { useMemo, useState } from "react";
import { BarChart, Heatmap, HourChart, type BarDatum } from "../components/charts";
import { PageHeader, Panel, SectionTitle, Segmented, Stat } from "../components/ui";
import { computeStreak, dayKey, daysAgoKey, DAY, fmtDuration, minutesByDay, useStore } from "../store";

type Range = 7 | 30 | 90;

export default function Analytics() {
  const sessions = useStore((s) => s.sessions);
  const goal = useStore((s) => s.settings.goal);
  const [range, setRange] = useState<Range>(30);

  const d = useMemo(() => {
    const by = minutesByDay(sessions);
    const cutoff = Date.now() - range * DAY;
    const inRange = sessions.filter((s) => s.ts >= cutoff - (new Date().getHours() * 3600_000));
    const total = inRange.reduce((a, s) => a + s.minutes, 0);
    const avgScore = inRange.length ? Math.round(inRange.reduce((a, s) => a + s.score, 0) / inRange.length) : 0;

    let bars: BarDatum[] = [];
    if (range === 90) {
      for (let w = 12; w >= 0; w--) {
        let m = 0;
        for (let i = 0; i < 7; i++) m += by[daysAgoKey(w * 7 + i)] ?? 0;
        const end = new Date(daysAgoKey(w * 7) + "T12:00:00");
        bars.push({ label: end.toLocaleDateString("en", { month: "short", day: "numeric" }), value: m, tip: `Week ending ${end.toLocaleDateString("en", { month: "short", day: "numeric" })} · ${fmtDuration(m)}`, emphasis: w === 0 });
      }
    } else {
      bars = Array.from({ length: range }, (_, i) => {
        const k = daysAgoKey(range - 1 - i);
        const date = new Date(k + "T12:00:00");
        return {
          label: range === 7 ? date.toLocaleDateString("en", { weekday: "short" }) : String(date.getDate()),
          value: by[k] ?? 0,
          tip: `${date.toLocaleDateString("en", { weekday: "short", month: "short", day: "numeric" })} · ${fmtDuration(by[k] ?? 0)}`,
          emphasis: i === range - 1,
        };
      });
    }

    const tags: Record<string, number> = {};
    for (const s of inRange) tags[s.tag] = (tags[s.tag] ?? 0) + s.minutes;
    const tagList = Object.entries(tags).sort((a, b) => b[1] - a[1]);

    const dist = [
      { label: "90–100", n: inRange.filter((s) => s.score >= 90).length },
      { label: "80–89", n: inRange.filter((s) => s.score >= 80 && s.score < 90).length },
      { label: "70–79", n: inRange.filter((s) => s.score >= 70 && s.score < 80).length },
      { label: "Below 70", n: inRange.filter((s) => s.score < 70).length },
    ];

    const days = Object.entries(by);
    const bestDay = days.sort((a, b) => b[1] - a[1])[0];
    const perDay: Record<string, number> = {};
    sessions.forEach((s) => (perDay[dayKey(s.ts)] = (perDay[dayKey(s.ts)] ?? 0) + 1));
    const mostSessions = Math.max(0, ...Object.values(perDay));
    const bestScore = Math.max(0, ...sessions.map((s) => s.score));
    const activeDays = bars.filter((b) => b.value > 0).length;
    return { by, total, avgScore, count: inRange.length, bars, tagList, dist, bestDay, mostSessions, bestScore, activeDays, streak: computeStreak(sessions) };
  }, [sessions, range]);

  const maxTag = Math.max(1, ...d.tagList.map((t) => t[1]));
  const maxDist = Math.max(1, ...d.dist.map((x) => x.n));
  const labelEvery = range === 30 ? 3 : range === 90 ? 2 : 1;

  return (
    <div className="rise">
      <PageHeader
        title="Analytics"
        sub="Real numbers from your sessions: no vanity metrics, just what shows when and how well you focus."
        action={
          <Segmented<Range>
            value={range}
            onChange={setRange}
            options={[
              { value: 7, label: "7 days" },
              { value: 30, label: "30 days" },
              { value: 90, label: "90 days" },
            ]}
          />
        }
      />

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Stat label="Total focus" value={fmtDuration(d.total)} sub={`Across ${range} days`} />
        <Stat label="Sessions" value={d.count} sub={d.count ? `${Math.round(d.total / d.count)} min average` : "No sessions yet"} />
        <Stat label="Avg. focus score" value={d.avgScore} sub="Completion and consistency" />
        <Stat label="Daily average" value={fmtDuration(Math.round(d.total / range))} sub={range === 90 ? "Over 90 days" : `${d.activeDays} active ${range === 7 ? "days" : "days"}`} />
      </div>

      <Panel className="mt-6 p-6">
        <SectionTitle title={range === 90 ? "Weekly focus time" : "Daily focus time"} hint="Hover a bar for exact minutes" />
        <BarChart data={d.bars} goal={range === 90 ? undefined : goal} labelEvery={labelEvery} height={220} />
      </Panel>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Panel className="p-6">
          <SectionTitle title="Where your time goes" hint="Focus minutes by tag" />
          <div className="space-y-4">
            {d.tagList.map(([tag, m]) => (
              <div key={tag}>
                <div className="mb-1.5 flex justify-between text-sm">
                  <span className="font-medium">{tag}</span>
                  <span className="num text-fg2">
                    {fmtDuration(m)} <span className="text-fg3">· {Math.round((m / d.total) * 100)}%</span>
                  </span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-line-strong/50">
                  <div className="h-full rounded-full bg-brand" style={{ width: `${(m / maxTag) * 100}%`, transition: "width .5s" }} />
                </div>
              </div>
            ))}
            {d.tagList.length === 0 && <p className="text-sm text-fg3">No sessions in this range.</p>}
          </div>
        </Panel>
        <Panel className="p-6">
          <SectionTitle title="Focus score spread" hint="How your sessions are distributed" />
          <div className="space-y-4">
            {d.dist.map((x) => (
              <div key={x.label} className="flex items-center gap-4">
                <span className="num w-[68px] text-sm text-fg2">{x.label}</span>
                <div className="h-8 flex-1 overflow-hidden rounded-lg bg-s2">
                  <div className="flex h-full items-center rounded-lg bg-brand/80 px-3 text-xs font-semibold text-brand-ink" style={{ width: `${Math.max(8, (x.n / maxDist) * 100)}%`, transition: "width .5s" }}>
                    {x.n}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
        <Panel className="p-6">
          <SectionTitle title="Consistency" hint="The last 26 weeks" />
          <Heatmap byDay={d.by} weeks={26} />
        </Panel>
        <Panel className="p-6">
          <SectionTitle title="Focus DNA" hint="Minutes by hour of day" />
          <HourChart sessions={sessions} />
        </Panel>
      </div>

      <Panel className="mt-6 p-6">
        <SectionTitle title="Personal bests" />
        <div className="grid grid-cols-2 gap-6 lg:grid-cols-4">
          {[
            { l: "Longest day", v: d.bestDay ? fmtDuration(d.bestDay[1]) : "—", s: d.bestDay ? new Date(d.bestDay[0] + "T12:00:00").toLocaleDateString("en", { month: "short", day: "numeric" }) : "" },
            { l: "Best streak", v: `${d.streak.best} days`, s: `Current: ${d.streak.current}` },
            { l: "Highest score", v: String(d.bestScore), s: "Single session" },
            { l: "Most in a day", v: `${d.mostSessions} sessions`, s: "All time" },
          ].map((x) => (
            <div key={x.l}>
              <div className="eyebrow">{x.l}</div>
              <div className="num mt-2 font-display text-2xl font-bold">{x.v}</div>
              <div className="mt-1 text-[13px] text-fg3">{x.s}</div>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}
