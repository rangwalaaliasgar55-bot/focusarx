import { useMemo, useState } from "react";
import { Flame } from "lucide-react";
import { Avatar, PageHeader, Panel, Segmented } from "../components/ui";
import { daysAgoKey, fmtDuration, levelInfo, minutesByDay, useStore, computeStreak } from "../store";
import { cn } from "../utils/cn";

type Range = "week" | "month" | "all";

const PEOPLE: { name: string; week: number; level: number; streak: number }[] = [
  { name: "Maya Lindqvist", week: 1310, level: 14, streak: 41 },
  { name: "Arjun Mehta", week: 1175, level: 12, streak: 28 },
  { name: "Zoe Hartmann", week: 1040, level: 12, streak: 19 },
  { name: "Kofi Mensah", week: 960, level: 10, streak: 33 },
  { name: "Ines Duarte", week: 905, level: 11, streak: 12 },
  { name: "Theo Park", week: 840, level: 9, streak: 17 },
  { name: "Priya Nair", week: 790, level: 9, streak: 22 },
  { name: "Jonas Weber", week: 705, level: 8, streak: 9 },
  { name: "Hana Sato", week: 640, level: 8, streak: 14 },
  { name: "Omar Haddad", week: 570, level: 7, streak: 6 },
  { name: "Beth Collins", week: 495, level: 6, streak: 11 },
  { name: "Leo Rossi", week: 410, level: 5, streak: 4 },
];
const MULT: Record<Range, number> = { week: 1, month: 4.2, all: 15 };

export default function Leaderboard() {
  const [range, setRange] = useState<Range>("week");
  const sessions = useStore((s) => s.sessions);
  const name = useStore((s) => s.settings.name);
  const xp = useStore((s) => s.xp);

  const rows = useMemo(() => {
    const by = minutesByDay(sessions);
    const days = range === "week" ? 7 : range === "month" ? 30 : 400;
    let mine = 0;
    for (let i = 0; i < days; i++) mine += by[daysAgoKey(i)] ?? 0;
    const list = PEOPLE.map((p) => ({ name: p.name, minutes: Math.round(p.week * MULT[range]), level: p.level, streak: p.streak, me: false }));
    list.push({ name, minutes: mine, level: levelInfo(xp).level, streak: computeStreak(sessions).current, me: true });
    return list.sort((a, b) => b.minutes - a.minutes).map((r, i) => ({ ...r, rank: i + 1 }));
  }, [range, sessions, name, xp]);

  const me = rows.find((r) => r.me)!;
  const ahead = rows[me.rank - 2];
  const top = rows.slice(0, 3);
  const podium = [top[1], top[0], top[2]];
  const heights = ["h-24", "h-32", "h-20"];

  return (
    <div className="rise">
      <PageHeader
        title="Leaderboard"
        sub="Ranked by focused minutes, not by who logs in the most."
        action={
          <Segmented<Range>
            value={range}
            onChange={setRange}
            options={[
              { value: "week", label: "This week" },
              { value: "month", label: "30 days" },
              { value: "all", label: "All time" },
            ]}
          />
        }
      />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-6">
          <Panel className="px-4 pb-0 pt-8 sm:px-10">
            <div className="grid grid-cols-3 items-end gap-3 sm:gap-6">
              {podium.map((p, i) => (
                <div key={p.name} className="flex flex-col items-center text-center">
                  <Avatar name={p.name} size={i === 1 ? 64 : 52} />
                  <div className={cn("mt-3 max-w-full truncate text-sm font-semibold", p.me && "text-brand")}>{p.me ? "You" : p.name.split(" ")[0]}</div>
                  <div className="num text-xs text-fg3">{fmtDuration(p.minutes)}</div>
                  <div className={cn("mt-3 flex w-full items-start justify-center rounded-t-xl border border-b-0 pt-3 font-display text-2xl font-bold", heights[i], i === 1 ? "border-brand/50 bg-brand-soft text-brand" : "border-line bg-s2 text-fg2")}>{p.rank}</div>
                </div>
              ))}
            </div>
          </Panel>

          <Panel className="overflow-hidden">
            <div className="grid grid-cols-[44px_1fr_auto] items-center gap-3 border-b border-line px-5 py-3 text-[11px] font-semibold uppercase tracking-[0.12em] text-fg3 sm:grid-cols-[44px_1fr_80px_80px_110px]">
              <span>Rank</span>
              <span>Name</span>
              <span className="hidden text-right sm:block">Level</span>
              <span className="hidden text-right sm:block">Streak</span>
              <span className="text-right">Focused</span>
            </div>
            <ul>
              {rows.map((r) => (
                <li key={r.name} className={cn("grid grid-cols-[44px_1fr_auto] items-center gap-3 border-b border-line px-5 py-3 last:border-0 sm:grid-cols-[44px_1fr_80px_80px_110px]", r.me && "bg-brand-soft")}>
                  <span className={cn("num font-display text-base font-bold", r.rank <= 3 ? "text-fg" : "text-fg3")}>{r.rank}</span>
                  <span className="flex min-w-0 items-center gap-3">
                    <Avatar name={r.name} size={32} />
                    <span className={cn("truncate text-sm font-medium", r.me && "text-brand")}>{r.me ? `${r.name} (you)` : r.name}</span>
                  </span>
                  <span className="num hidden text-right text-sm text-fg2 sm:block">{r.level}</span>
                  <span className="num hidden items-center justify-end gap-1 text-sm text-fg2 sm:flex">
                    <Flame size={13} className="text-warn" />
                    {r.streak}
                  </span>
                  <span className="num text-right text-sm font-semibold">{fmtDuration(r.minutes)}</span>
                </li>
              ))}
            </ul>
          </Panel>
        </div>

        <Panel className="h-fit p-6">
          <div className="eyebrow">Your position</div>
          <div className="num mt-3 font-display text-5xl font-bold tracking-tight">#{me.rank}</div>
          <p className="mt-3 text-sm text-fg2">
            {ahead ? (
              <>
                <span className="num font-semibold text-fg">{fmtDuration(Math.max(1, ahead.minutes - me.minutes + 1))}</span> more focus time to pass {ahead.name.split(" ")[0]}.
              </>
            ) : (
              "You're leading. Keep the streak going."
            )}
          </p>
          <div className="mt-5 rounded-xl bg-s2 p-4 text-[13px] leading-relaxed text-fg3">Your numbers come from the sessions on this device. Complete a timer session and watch your rank move.</div>
        </Panel>
      </div>
    </div>
  );
}
