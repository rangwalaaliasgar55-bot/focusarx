import { useMemo } from "react";
import { ArrowDownRight, ArrowUpRight, Check, Flame, Gift, Play, Target, TrendingUp, Zap } from "lucide-react";
import Pet3D from "../components/Pet3D";
import { BarChart, Gauge, Heatmap, HourChart } from "../components/charts";
import { Bar, Button, EmptyState, PageHeader, Panel, SectionTitle, Stat } from "../components/ui";
import { go, Link } from "../router";
import { A, bondInfo, computeStreak, dayKey, daysAgoKey, fmtDuration, getState, levelInfo, minutesByDay, useStore } from "../store";
import { usePetLine, usePetMood } from "../hooks";
import { getPetDef } from "../lib/pets";
import { cn } from "../utils/cn";

function greeting() {
  const h = new Date().getHours();
  return h < 5 ? "Still up" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

function startNow() {
  const t = getState().timer;
  if (t.status === "idle" && t.mode !== "focus") A.setMode("focus");
  go("/focus");
  if (t.status !== "running") window.setTimeout(() => A.start(), 80);
}

function Companion() {
  const pet = useStore((s) => s.pet);
  const celebrateAt = useStore((s) => s.celebrateAt);
  const coins = useStore((s) => s.coins);
  const mood = usePetMood();
  const line = usePetLine();
  const bond = bondInfo(pet.bond);
  const def = getPetDef(pet.species, pet.variant);
  return (
    <Panel className="relative flex flex-col overflow-hidden">
      <div className="stage-floor absolute inset-x-0 bottom-0 h-3/5" />
      <div className="relative flex items-start justify-between px-5 pt-5">
        <div>
          <div className="eyebrow">Companion</div>
          <div className="mt-1 font-display text-lg font-bold tracking-tight">{pet.name}</div>
          <div className="text-[13px] text-fg3">
            {def.label} · Bond {bond.level}
          </div>
        </div>
        <Link to="/pets" className="rounded-lg px-2.5 py-1.5 text-[13px] font-medium text-fg3 hover:bg-s2 hover:text-fg">
          Manage
        </Link>
      </div>
      <Pet3D className="relative -mt-2 h-[250px] w-full" species={pet.species} variant={pet.variant} mood={mood} celebrateAt={celebrateAt} zoom={1.12} yOffset={-0.05} />
      <div className="relative px-5 pb-5">
        <p key={line} className="bubble mb-4 rounded-xl border border-line bg-s2 px-3.5 py-2.5 text-[13px] leading-snug text-fg2">
          {line}
        </p>
        <div className="mb-3 flex items-center justify-between text-xs text-fg3">
          <span>Bond to level {bond.level + 1}</span>
          <span className="num">
            {bond.into}/{bond.need}
          </span>
        </div>
        <Bar pct={bond.pct} />
        <div className="mt-4 flex gap-2">
          <Button size="sm" className="flex-1" onClick={() => A.feed()} disabled={coins < 5}>
            Feed · 5 coins
          </Button>
          <Button size="sm" className="flex-1" onClick={() => A.celebrate()}>
            Play
          </Button>
        </div>
      </div>
    </Panel>
  );
}

function Missions() {
  const sessions = useStore((s) => s.sessions);
  const claimedAll = useStore((s) => s.claimed);
  const claimed = claimedAll[dayKey(Date.now())] ?? [];
  const today = sessions.filter((s) => dayKey(s.ts) === dayKey(Date.now()));
  const mins = today.reduce((a, s) => a + s.minutes, 0);
  const missions = [
    { id: "m50", title: "Focus for 50 minutes", value: Math.min(mins, 50), target: 50, unit: "min", coins: 30, xp: 40 },
    { id: "m3", title: "Complete 3 sessions", value: Math.min(today.length, 3), target: 3, unit: "", coins: 25, xp: 30 },
    { id: "m90", title: "Reach a focus score of 90", value: Math.min(Math.max(0, ...today.map((s) => s.score)), 90), target: 90, unit: "", coins: 40, xp: 50 },
  ];
  return (
    <Panel className="p-6">
      <SectionTitle title="Daily missions" hint="Resets at midnight" />
      <div className="space-y-4">
        {missions.map((m) => {
          const done = m.value >= m.target;
          const isClaimed = claimed.includes(m.id);
          return (
            <div key={m.id}>
              <div className="mb-2 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <span className={cn("flex h-5 w-5 items-center justify-center rounded-full border", done ? "border-ok bg-ok text-bg" : "border-line-strong text-fg3")}>{done ? <Check size={12} strokeWidth={3.2} /> : <Target size={11} />}</span>
                  <span className="text-sm font-medium">{m.title}</span>
                </div>
                {done ? (
                  <Button size="sm" variant={isClaimed ? "ghost" : "primary"} disabled={isClaimed} onClick={() => A.claim(m.id, m.coins, m.xp)}>
                    {isClaimed ? "Claimed" : `Claim ${m.coins}`}
                  </Button>
                ) : (
                  <span className="num text-xs text-fg3">
                    {m.value}/{m.target} {m.unit}
                  </span>
                )}
              </div>
              <Bar pct={m.value / m.target} tone={done ? "ok" : "brand"} />
            </div>
          );
        })}
      </div>
    </Panel>
  );
}

export default function Dashboard() {
  const sessions = useStore((s) => s.sessions);
  const tasks = useStore((s) => s.tasks);
  const activeId = useStore((s) => s.activeTaskId);
  const xp = useStore((s) => s.xp);
  const goal = useStore((s) => s.settings.goal);
  const name = useStore((s) => s.settings.name);

  const d = useMemo(() => {
    const by = minutesByDay(sessions);
    const todayKey = daysAgoKey(0);
    const week = Array.from({ length: 7 }, (_, i) => {
      const k = daysAgoKey(6 - i);
      const date = new Date(k + "T12:00:00");
      return { k, m: by[k] ?? 0, label: date.toLocaleDateString("en", { weekday: "short" }), full: date.toLocaleDateString("en", { weekday: "long" }) };
    });
    const thisWeek = week.reduce((a, w) => a + w.m, 0);
    let prev = 0;
    for (let i = 7; i < 14; i++) prev += by[daysAgoKey(i)] ?? 0;
    const recent = sessions.filter((s) => s.ts > Date.now() - 7 * 86400000);
    const avgScore = recent.length ? Math.round(recent.reduce((a, s) => a + s.score, 0) / recent.length) : 0;
    const todaySessions = sessions.filter((s) => dayKey(s.ts) === todayKey);
    return { by, week, thisWeek, prev, avgScore, today: by[todayKey] ?? 0, todayCount: todaySessions.length, streak: computeStreak(sessions) };
  }, [sessions]);

  const lv = levelInfo(xp);
  const active = tasks.find((t) => t.id === activeId && !t.completed);
  const openTasks = tasks.filter((t) => !t.completed);
  const left = Math.max(0, goal - d.today);
  const diff = d.prev ? Math.round(((d.thisWeek - d.prev) / d.prev) * 100) : 0;
  const recent = [...sessions].sort((a, b) => b.ts - a.ts).slice(0, 6);

  return (
    <div className="rise">
      <PageHeader
        title={`${greeting()}, ${name}`}
        sub={left > 0 ? `${fmtDuration(left)} left to reach today's ${fmtDuration(goal)} goal.` : "Daily goal reached. Anything more is a bonus."}
        action={
          <Button variant="primary" size="lg" onClick={startNow}>
            <Play size={17} fill="currentColor" /> Start focusing
          </Button>
        }
      />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-6">
          <Panel className="p-6 sm:p-7">
            <div className="flex flex-col gap-7 sm:flex-row sm:items-center">
              <Gauge pct={d.today / goal} size={148} stroke={11}>
                <span className="num font-display text-[28px] font-bold leading-none">{Math.round((d.today / goal) * 100)}%</span>
                <span className="mt-1.5 text-xs text-fg3">of daily goal</span>
              </Gauge>
              <div className="grid flex-1 grid-cols-3 gap-4">
                {[
                  { l: "Focused today", v: fmtDuration(d.today) },
                  { l: "Sessions", v: String(d.todayCount) },
                  { l: "Goal", v: fmtDuration(goal) },
                ].map((x) => (
                  <div key={x.l}>
                    <div className="eyebrow">{x.l}</div>
                    <div className="num mt-2 font-display text-xl font-bold">{x.v}</div>
                  </div>
                ))}
                <div className="col-span-3 mt-1 flex flex-col gap-3 rounded-xl border border-line bg-s2/60 p-3.5 sm:flex-row sm:items-center">
                  <div className="min-w-0 flex-1">
                    <div className="eyebrow">Up next</div>
                    <div className="mt-1 truncate text-sm font-medium">{active ? active.title : "No task selected"}</div>
                    {active && (
                      <div className="num text-xs text-fg3">
                        {active.done}/{active.est} sessions done
                      </div>
                    )}
                  </div>
                  <Button size="sm" onClick={active ? startNow : () => go("/tasks")}>
                    {active ? "Begin" : "Pick a task"}
                  </Button>
                </div>
              </div>
            </div>
          </Panel>

          <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
            <Stat label="Streak" value={<>{d.streak.current}<span className="ml-1 text-base text-fg3">days</span></>} sub={`Best: ${d.streak.best} days`} icon={<Flame size={16} />} />
            <Stat label="Level" value={lv.level} sub={<span className="num">{lv.into}/{lv.need} XP to next</span>} icon={<Zap size={16} />} />
            <Stat label="Focus score" value={d.avgScore} sub="7-day average" icon={<Target size={16} />} />
            <Stat
              label="This week"
              value={fmtDuration(d.thisWeek)}
              sub={
                <span className={cn("inline-flex items-center gap-1", diff >= 0 ? "text-ok" : "text-bad")}>
                  {diff >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                  {Math.abs(diff)}% vs last week
                </span>
              }
              icon={<TrendingUp size={16} />}
            />
          </div>

          <Panel className="p-6">
            <SectionTitle title="Last 7 days" hint="Minutes of focused work per day" action={<Link to="/analytics" className="text-[13px] font-medium text-fg3 hover:text-fg">Full analytics</Link>} />
            <BarChart
              goal={goal}
              data={d.week.map((w, i) => ({ label: w.label, value: w.m, tip: `${w.full} · ${fmtDuration(w.m)}`, emphasis: i === 6 }))}
            />
          </Panel>
        </div>

        <div className="space-y-6">
          <Companion />
          <Missions />
        </div>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
        <Panel className="p-6">
          <SectionTitle title="Consistency" hint="The last 18 weeks" />
          <Heatmap byDay={d.by} />
        </Panel>
        <Panel className="p-6">
          <SectionTitle title="Focus DNA" hint="When you do your best work" />
          <HourChart sessions={sessions} />
        </Panel>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <Panel className="p-6">
          <SectionTitle title="Open tasks" action={<Link to="/tasks" className="text-[13px] font-medium text-fg3 hover:text-fg">Manage</Link>} />
          {openTasks.length === 0 ? (
            <EmptyState title="All clear" body="Nothing left on your list. Add something small for tomorrow." />
          ) : (
            <ul className="divide-y divide-line">
              {openTasks.slice(0, 5).map((t) => (
                <li key={t.id} className="flex items-center gap-3 py-3">
                  <button onClick={() => A.toggleTask(t.id)} className="flex h-5 w-5 shrink-0 items-center justify-center rounded-md border border-line-strong text-transparent transition-colors hover:border-ok hover:text-ok" aria-label={`Complete ${t.title}`}>
                    <Check size={13} strokeWidth={3} />
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{t.title}</div>
                    <div className="num text-xs text-fg3">
                      {t.tag} · {t.done}/{t.est} sessions
                    </div>
                  </div>
                  <span className={cn("h-2 w-2 rounded-full", t.priority === "high" ? "bg-bad" : t.priority === "med" ? "bg-warn" : "bg-fg3")} title={`${t.priority} priority`} />
                </li>
              ))}
            </ul>
          )}
        </Panel>
        <Panel className="p-6">
          <SectionTitle title="Recent sessions" action={<Gift size={16} className="text-fg3" />} />
          <ul className="divide-y divide-line">
            {recent.map((s) => (
              <li key={s.id} className="flex items-center gap-3 py-3">
                <div className="num flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-s2 font-display text-[13px] font-bold">{s.score}</div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{s.task ?? s.tag}</div>
                  <div className="text-xs text-fg3">
                    {s.tag} · {new Date(s.ts).toLocaleDateString("en", { weekday: "short" })},{" "}
                    {new Date(s.ts).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}
                  </div>
                </div>
                <span className="num text-sm text-fg2">{s.minutes}m</span>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </div>
  );
}
