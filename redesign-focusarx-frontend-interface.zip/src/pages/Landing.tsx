import { ArrowRight, AudioLines, BarChart3, Gauge as GaugeIcon, Headphones, ListChecks, PawPrint, ShieldCheck, Target } from "lucide-react";
import Pet3D from "../components/Pet3D";
import { Logo } from "../components/Layout";
import { Link } from "../router";
import { A, getState, useStore } from "../store";

const FEATURES = [
  { icon: GaugeIcon, title: "A timer you can trust", body: "Deadline-based, so background tabs, screen lock and sleep never skew it. Close the tab and your session is still there." },
  { icon: Target, title: "Focus score, 0 to 100", body: "Every session is scored on completion and consistency, not on hours logged. Hours are a vanity metric." },
  { icon: PawPrint, title: "A companion that reacts", body: "A 3D pet that puts on headphones while you work, hops on breaks and celebrates when you finish." },
  { icon: AudioLines, title: "Ambient sound, synthesized", body: "Rain, brown noise, ocean and wind generated in your browser. Mix the layers; nothing to download." },
  { icon: ListChecks, title: "Tasks sized in sessions", body: "Estimate work in focus blocks, pick the one you're on, and watch the sessions fill in." },
  { icon: BarChart3, title: "Analytics from real sessions", body: "Heatmap, weekly trends, personal bests and Focus DNA: the hours your brain is sharpest." },
];

const STEPS = [
  { n: "01", t: "Pick one thing", d: "Choose a task or just set a length. 25 minutes is the default; 50 works well for deep work." },
  { n: "02", t: "Press start once", d: "Your companion settles in, the ring starts to empty and everything else can wait." },
  { n: "03", t: "Collect the result", d: "Finish to earn XP, coins and a focus score. Then take the break; it's part of the method." },
];

const FAQ = [
  { q: "Do I need an account?", a: "No. The timer is guest-first: open it, set a length and start. Everything is stored on your device." },
  { q: "Is it free?", a: "Yes. The timer, tasks, habits, analytics, study rooms and companions are all included." },
  { q: "What is the Focus Score?", a: "A 0–100 rating for a session based on completion, consistency and pauses, not on elapsed time alone." },
  { q: "Does the timer survive a locked phone?", a: "Yes. Remaining time is derived from a wall-clock deadline rather than counting ticks." },
];

export default function Landing() {
  const pet = useStore((s) => s.pet);
  return (
    <div className="min-h-full">
      <header className="sticky top-0 z-40 border-b border-line bg-bg/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-[1180px] items-center justify-between px-5 sm:px-8">
          <Link to="/" className="flex items-center gap-2.5">
            <Logo />
            <span className="font-display text-[17px] font-bold tracking-tight">FocusArx</span>
          </Link>
          <nav className="hidden items-center gap-8 text-sm text-fg2 md:flex">
            <a href="#/" onClick={(e) => { e.preventDefault(); document.getElementById("features")?.scrollIntoView({ behavior: "smooth" }); }} className="hover:text-fg">Features</a>
            <a href="#/" onClick={(e) => { e.preventDefault(); document.getElementById("how")?.scrollIntoView({ behavior: "smooth" }); }} className="hover:text-fg">How it works</a>
            <a href="#/" onClick={(e) => { e.preventDefault(); document.getElementById("faq")?.scrollIntoView({ behavior: "smooth" }); }} className="hover:text-fg">FAQ</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/dashboard" className="hidden h-9 items-center rounded-lg px-3 text-sm font-medium text-fg2 hover:text-fg sm:inline-flex">
              Dashboard
            </Link>
            <Link to="/focus" className="inline-flex h-9 items-center rounded-lg bg-brand px-4 text-sm font-semibold text-brand-ink hover:brightness-110">
              Open timer
            </Link>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(50% 60% at 78% 45%, var(--brand-soft), transparent 70%)" }} />
        <div className="relative mx-auto grid max-w-[1180px] items-center gap-6 px-5 pb-16 pt-14 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:pb-24 lg:pt-20">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-line px-3 py-1 text-xs font-medium text-fg2">
              <ShieldCheck size={13} className="text-ok" /> Free · No account · Data stays on your device
            </span>
            <h1 className="mt-6 font-display text-[44px] font-extrabold leading-[1.02] tracking-[-0.035em] sm:text-[64px]">
              A focus timer
              <br />
              that sits with you.
            </h1>
            <p className="mt-6 max-w-[520px] text-[17px] leading-relaxed text-fg2">
              Adaptive Pomodoro sessions, a calm dashboard and a small 3D companion who keeps you company while you work. Start in one click.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-3">
              <Link
                to="/focus"
                onClick={() => {
                  const t = getState().timer;
                  if (t.status === "idle" && t.mode !== "focus") A.setMode("focus");
                }}
                className="inline-flex h-13 items-center gap-2 rounded-full bg-brand px-7 py-3.5 font-display text-[15px] font-bold text-brand-ink transition hover:brightness-110"
              >
                Start a session <ArrowRight size={17} />
              </Link>
              <Link to="/dashboard" className="inline-flex h-13 items-center rounded-full border border-line-strong px-6 py-3.5 text-[15px] font-medium text-fg hover:bg-s2">
                See the dashboard
              </Link>
            </div>
            <dl className="mt-12 grid max-w-md grid-cols-3 gap-6 border-t border-line pt-6">
              {[
                ["25 min", "default session"],
                ["0–100", "focus score"],
                ["4", "pet species"],
              ].map(([v, l]) => (
                <div key={l}>
                  <dt className="num font-display text-xl font-bold">{v}</dt>
                  <dd className="mt-0.5 text-xs text-fg3">{l}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative mx-auto w-full max-w-[520px]">
            <div className="panel relative overflow-hidden rounded-[32px]">
              <div className="stage-floor absolute inset-x-0 bottom-0 h-2/3" />
              <Pet3D className="relative h-[430px] w-full sm:h-[500px]" species={pet.species} variant={pet.variant} mood="focus" drag autoRotate zoom={1.05} />
              <div className="absolute inset-x-4 bottom-4 flex items-center gap-4 rounded-2xl border border-line-strong bg-s2/90 p-4 backdrop-blur-md">
                <svg width="52" height="52" viewBox="0 0 52 52" aria-hidden>
                  <circle cx="26" cy="26" r="21" fill="none" stroke="var(--ring-track)" strokeWidth="5" />
                  <circle cx="26" cy="26" r="21" fill="none" stroke="var(--brand)" strokeWidth="5" strokeLinecap="round" strokeDasharray="88 132" transform="rotate(-90 26 26)" />
                </svg>
                <div className="min-w-0 flex-1">
                  <div className="num font-display text-[22px] font-bold leading-none">16:42</div>
                  <div className="mt-1.5 truncate text-xs text-fg3">Revise thermodynamics</div>
                </div>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-brand-soft px-2.5 py-1 text-xs font-semibold text-brand">
                  <Headphones size={12} /> In the zone
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="mx-auto max-w-[1180px] scroll-mt-20 px-5 py-20 sm:px-8">
        <div className="max-w-xl">
          <div className="eyebrow">What's inside</div>
          <h2 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">Quiet tools for deep work</h2>
          <p className="mt-3 text-fg2">One accent colour, flat surfaces and nothing that moves unless it has to. The timer is the calmest thing on the screen.</p>
        </div>
        <div className="mt-12 grid gap-px overflow-hidden rounded-3xl border border-line bg-line sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <div key={f.title} className="bg-s1 p-7">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-soft text-brand">
                <f.icon size={19} />
              </span>
              <h3 className="mt-5 font-display text-[17px] font-bold tracking-tight">{f.title}</h3>
              <p className="mt-2 text-[14.5px] leading-relaxed text-fg2">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="how" className="scroll-mt-20 border-y border-line bg-s1/50">
        <div className="mx-auto max-w-[1180px] px-5 py-20 sm:px-8">
          <div className="eyebrow">How a session works</div>
          <h2 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">Three steps, no setup</h2>
          <div className="mt-12 grid gap-10 md:grid-cols-3">
            {STEPS.map((s) => (
              <div key={s.n} className="border-t border-line-strong pt-5">
                <div className="num font-display text-sm font-bold text-brand">{s.n}</div>
                <h3 className="mt-3 font-display text-xl font-bold tracking-tight">{s.t}</h3>
                <p className="mt-2 text-[15px] leading-relaxed text-fg2">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="mx-auto max-w-3xl scroll-mt-20 px-5 py-20 sm:px-8">
        <div className="eyebrow">Questions</div>
        <h2 className="mt-3 font-display text-3xl font-bold tracking-tight sm:text-4xl">Frequently asked</h2>
        <div className="mt-8 divide-y divide-line border-y border-line">
          {FAQ.map((f) => (
            <details key={f.q} className="group py-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-display text-[17px] font-semibold">
                {f.q}
                <span className="text-xl font-light text-fg3 transition-transform group-open:rotate-45">+</span>
              </summary>
              <p className="mt-3 max-w-[560px] text-[15px] leading-relaxed text-fg2">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-[1180px] px-5 pb-20 sm:px-8">
        <div className="panel flex flex-col items-start justify-between gap-6 rounded-[28px] p-8 sm:flex-row sm:items-center sm:p-12">
          <div>
            <h2 className="font-display text-3xl font-bold tracking-tight">Your next 25 minutes are free.</h2>
            <p className="mt-2 text-fg2">Open the timer, pick a task, press start.</p>
          </div>
          <Link to="/focus" className="inline-flex shrink-0 items-center gap-2 rounded-full bg-brand px-7 py-3.5 font-display text-[15px] font-bold text-brand-ink hover:brightness-110">
            Start focusing <ArrowRight size={17} />
          </Link>
        </div>
      </section>

      <footer className="border-t border-line">
        <div className="mx-auto flex max-w-[1180px] flex-col items-center justify-between gap-3 px-5 py-8 text-[13px] text-fg3 sm:flex-row sm:px-8">
          <div className="flex items-center gap-2">
            <Logo size={20} />
            <span>FocusArx · Focus deliberately.</span>
          </div>
          <div className="flex gap-6">
            <Link to="/dashboard" className="hover:text-fg">Dashboard</Link>
            <Link to="/analytics" className="hover:text-fg">Analytics</Link>
            <Link to="/rooms" className="hover:text-fg">Study rooms</Link>
            <Link to="/pets" className="hover:text-fg">Pets</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
