import { useState } from "react";
import { Check, Minus, Play, Plus, Trash2 } from "lucide-react";
import { Button, Chip, EmptyState, PageHeader, Panel, Segmented } from "../components/ui";
import { go } from "../router";
import { A, fmtDuration, TAGS, useStore, type Task } from "../store";
import { cn } from "../utils/cn";

type Filter = "active" | "done" | "all";
const PRI: Record<Task["priority"], { label: string; dot: string }> = {
  high: { label: "High", dot: "bg-bad" },
  med: { label: "Medium", dot: "bg-warn" },
  low: { label: "Low", dot: "bg-fg3" },
};

function Row({ t, active }: { t: Task; active: boolean }) {
  return (
    <li className={cn("group flex items-center gap-4 px-5 py-4 transition-colors", active && "bg-brand-soft/60")}>
      <button
        onClick={() => A.toggleTask(t.id)}
        className={cn("flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-md border transition-colors", t.completed ? "border-ok bg-ok text-bg" : "border-line-strong text-transparent hover:border-ok hover:text-ok")}
        aria-label={t.completed ? `Mark ${t.title} as not done` : `Mark ${t.title} as done`}
      >
        <Check size={14} strokeWidth={3.2} />
      </button>
      <div className="min-w-0 flex-1">
        <div className={cn("truncate text-[15px] font-medium", t.completed && "text-fg3 line-through")}>{t.title}</div>
        <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-fg3">
          <span className="inline-flex items-center gap-1.5">
            <span className={cn("h-1.5 w-1.5 rounded-full", PRI[t.priority].dot)} />
            {PRI[t.priority].label}
          </span>
          <span>{t.tag}</span>
          <span className="inline-flex items-center gap-1" aria-label={`${t.done} of ${t.est} sessions`}>
            {Array.from({ length: Math.min(t.est, 8) }).map((_, i) => (
              <span key={i} className={cn("h-1.5 w-3.5 rounded-full", i < t.done ? "bg-brand" : "bg-line-strong")} />
            ))}
            <span className="num ml-1">
              {t.done}/{t.est}
            </span>
          </span>
          {active && <span className="font-medium text-brand">Current focus</span>}
        </div>
      </div>
      {!t.completed && (
        <Button
          size="sm"
          variant={active ? "primary" : "secondary"}
          onClick={() => {
            A.setActiveTask(t.id);
            go("/focus");
          }}
        >
          <Play size={13} fill="currentColor" /> Focus
        </Button>
      )}
      <button onClick={() => A.removeTask(t.id)} className="flex h-8 w-8 items-center justify-center rounded-lg text-fg3 opacity-100 transition hover:bg-s2 hover:text-bad sm:opacity-0 sm:group-hover:opacity-100 sm:focus:opacity-100" aria-label={`Delete ${t.title}`}>
        <Trash2 size={15} />
      </button>
    </li>
  );
}

export default function Tasks() {
  const tasks = useStore((s) => s.tasks);
  const activeId = useStore((s) => s.activeTaskId);
  const focusMin = useStore((s) => s.settings.focus);
  const [filter, setFilter] = useState<Filter>("active");
  const [title, setTitle] = useState("");
  const [tag, setTag] = useState(TAGS[0]);
  const [priority, setPriority] = useState<Task["priority"]>("med");
  const [est, setEst] = useState(2);

  const open = tasks.filter((t) => !t.completed);
  const done = tasks.filter((t) => t.completed);
  const shown = filter === "active" ? open : filter === "done" ? done : tasks;
  const order = { high: 0, med: 1, low: 2 };
  const sorted = [...shown].sort((a, b) => Number(a.completed) - Number(b.completed) || order[a.priority] - order[b.priority] || b.createdAt - a.createdAt);
  const remaining = open.reduce((a, t) => a + Math.max(0, t.est - t.done), 0);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const v = title.trim();
    if (!v) return;
    A.addTask(v, tag, priority, est);
    setTitle("");
    setEst(2);
    A.toast("Task added");
  };

  return (
    <div className="rise">
      <PageHeader title="Tasks" sub="Decide what matters, estimate it in focus sessions, then work through it one block at a time." />

      <Panel className="mb-6 p-5">
        <form onSubmit={submit} className="space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="What do you need to get done?"
              className="h-11 min-w-0 flex-1 rounded-xl border border-line bg-s2 px-4 text-[15px] text-fg placeholder:text-fg3 focus:border-brand focus:outline-none"
              aria-label="Task title"
            />
            <Button type="submit" variant="primary" size="lg" className="h-11" disabled={!title.trim()}>
              <Plus size={16} /> Add task
            </Button>
          </div>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
            <div className="flex items-center gap-2">
              <span className="eyebrow">Tag</span>
              <div className="flex flex-wrap gap-1.5">
                {TAGS.map((t) => (
                  <Chip key={t} active={tag === t} onClick={() => setTag(t)}>
                    {t}
                  </Chip>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className="eyebrow">Priority</span>
              <Segmented<Task["priority"]>
                size="sm"
                value={priority}
                onChange={setPriority}
                options={[
                  { value: "low", label: "Low" },
                  { value: "med", label: "Medium" },
                  { value: "high", label: "High" },
                ]}
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="eyebrow">Sessions</span>
              <div className="flex items-center rounded-full border border-line">
                <button type="button" onClick={() => setEst(Math.max(1, est - 1))} className="flex h-7 w-7 items-center justify-center text-fg2 hover:text-fg" aria-label="Fewer sessions">
                  <Minus size={13} />
                </button>
                <span className="num w-6 text-center text-[13px] font-medium">{est}</span>
                <button type="button" onClick={() => setEst(Math.min(12, est + 1))} className="flex h-7 w-7 items-center justify-center text-fg2 hover:text-fg" aria-label="More sessions">
                  <Plus size={13} />
                </button>
              </div>
            </div>
          </div>
        </form>
      </Panel>

      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <Segmented<Filter>
          value={filter}
          onChange={setFilter}
          options={[
            { value: "active", label: `Active · ${open.length}` },
            { value: "done", label: `Done · ${done.length}` },
            { value: "all", label: "All" },
          ]}
        />
        <p className="text-[13px] text-fg3">
          <span className="num font-medium text-fg2">{remaining}</span> sessions left · about <span className="num font-medium text-fg2">{fmtDuration(remaining * focusMin)}</span> of focus
        </p>
      </div>

      {sorted.length === 0 ? (
        <EmptyState title={filter === "done" ? "Nothing finished yet" : "Your list is empty"} body={filter === "done" ? "Completed tasks will collect here." : "Add the one task you'd feel good about finishing today."} />
      ) : (
        <Panel className="overflow-hidden">
          <ul className="divide-y divide-line">
            {sorted.map((t) => (
              <Row key={t.id} t={t} active={t.id === activeId && !t.completed} />
            ))}
          </ul>
        </Panel>
      )}
    </div>
  );
}
