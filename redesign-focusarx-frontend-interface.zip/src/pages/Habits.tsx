import { useState } from "react";
import { Check, Flame, Plus, Trash2 } from "lucide-react";
import { Gauge } from "../components/charts";
import { Button, EmptyState, PageHeader, Panel, SectionTitle } from "../components/ui";
import { A, daysAgoKey, useStore, type Habit } from "../store";
import { cn } from "../utils/cn";

function streakOf(h: Habit) {
  const set = new Set(h.log);
  let i = set.has(daysAgoKey(0)) ? 0 : 1;
  let n = 0;
  while (set.has(daysAgoKey(i))) {
    n++;
    i++;
  }
  return n;
}

export default function Habits() {
  const habits = useStore((s) => s.habits);
  const [name, setName] = useState("");
  const [note, setNote] = useState("");

  const days = Array.from({ length: 7 }, (_, i) => {
    const key = daysAgoKey(6 - i);
    const date = new Date(key + "T12:00:00");
    return { key, label: date.toLocaleDateString("en", { weekday: "narrow" }), n: date.getDate(), today: i === 6 };
  });

  const todayKey = daysAgoKey(0);
  const doneToday = habits.filter((h) => h.log.includes(todayKey)).length;
  const weekPossible = habits.length * 7;
  const weekDone = habits.reduce((a, h) => a + days.filter((d) => h.log.includes(d.key)).length, 0);

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    const v = name.trim();
    if (!v) return;
    A.addHabit(v, note.trim());
    setName("");
    setNote("");
  };

  return (
    <div className="rise">
      <PageHeader title="Habits" sub="The small routines that make deep work easier. Tap a day to log it." />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="space-y-6">
          <Panel className="overflow-hidden">
            <div className="hidden items-center border-b border-line px-5 py-3 sm:flex">
              <span className="eyebrow flex-1">Habit</span>
              <div className="flex gap-1.5">
                {days.map((d) => (
                  <span key={d.key} className={cn("num flex w-9 flex-col items-center text-[11px]", d.today ? "text-brand" : "text-fg3")}>
                    <span className="font-semibold">{d.label}</span>
                    <span>{d.n}</span>
                  </span>
                ))}
              </div>
              <span className="eyebrow w-28 text-right">Streak</span>
            </div>
            {habits.length === 0 ? (
              <div className="p-5">
                <EmptyState title="No habits yet" body="Start with one: the tiny thing that makes focus easier." />
              </div>
            ) : (
              <ul className="divide-y divide-line">
                {habits.map((h) => {
                  const s = streakOf(h);
                  const rate = Math.round((days.filter((d) => h.log.includes(d.key)).length / 7) * 100);
                  return (
                    <li key={h.id} className="group flex flex-col gap-4 px-5 py-4 sm:flex-row sm:items-center">
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[15px] font-medium">{h.name}</div>
                        {h.note && <div className="mt-0.5 truncate text-[13px] text-fg3">{h.note}</div>}
                        <div className="num mt-1 text-xs text-fg3 sm:hidden">{rate}% this week</div>
                      </div>
                      <div className="flex gap-1.5">
                        {days.map((d) => {
                          const on = h.log.includes(d.key);
                          return (
                            <button
                              key={d.key}
                              onClick={() => A.toggleHabit(h.id, d.key)}
                              className={cn(
                                "flex h-9 w-9 items-center justify-center rounded-lg border transition-colors",
                                on ? "border-brand bg-brand text-brand-ink" : "border-line text-transparent hover:border-line-strong hover:text-fg3",
                                d.today && !on && "border-line-strong"
                              )}
                              aria-pressed={on}
                              aria-label={`${h.name}, ${new Date(d.key + "T12:00:00").toLocaleDateString("en", { weekday: "long" })}`}
                            >
                              <Check size={16} strokeWidth={3} />
                            </button>
                          );
                        })}
                      </div>
                      <div className="flex w-28 items-center justify-between gap-2 sm:justify-end">
                        <span className="num inline-flex items-center gap-1.5 text-sm font-medium">
                          <Flame size={14} className={s > 0 ? "text-warn" : "text-fg3"} />
                          {s} {s === 1 ? "day" : "days"}
                        </span>
                        <button onClick={() => A.removeHabit(h.id)} className="flex h-7 w-7 items-center justify-center rounded-md text-fg3 hover:bg-s2 hover:text-bad sm:opacity-0 sm:group-hover:opacity-100 sm:focus:opacity-100" aria-label={`Delete ${h.name}`}>
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </Panel>

          <Panel className="p-5">
            <SectionTitle title="Add a habit" />
            <form onSubmit={add} className="flex flex-col gap-3 sm:flex-row">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Habit name" aria-label="Habit name" className="h-11 flex-1 rounded-xl border border-line bg-s2 px-4 text-sm placeholder:text-fg3 focus:border-brand focus:outline-none" />
              <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Short note (optional)" aria-label="Habit note" className="h-11 flex-1 rounded-xl border border-line bg-s2 px-4 text-sm placeholder:text-fg3 focus:border-brand focus:outline-none" />
              <Button type="submit" variant="primary" className="h-11" disabled={!name.trim()}>
                <Plus size={16} /> Add
              </Button>
            </form>
          </Panel>
        </div>

        <Panel className="h-fit p-6">
          <SectionTitle title="This week" />
          <div className="flex flex-col items-center py-2">
            <Gauge pct={weekPossible ? weekDone / weekPossible : 0} size={150} stroke={11}>
              <span className="num font-display text-3xl font-bold">{weekPossible ? Math.round((weekDone / weekPossible) * 100) : 0}%</span>
              <span className="mt-1 text-xs text-fg3">completed</span>
            </Gauge>
            <div className="mt-6 grid w-full grid-cols-2 gap-4 text-center">
              <div className="rounded-xl bg-s2 p-3">
                <div className="num font-display text-xl font-bold">
                  {doneToday}/{habits.length}
                </div>
                <div className="mt-0.5 text-xs text-fg3">done today</div>
              </div>
              <div className="rounded-xl bg-s2 p-3">
                <div className="num font-display text-xl font-bold">{Math.max(0, ...habits.map(streakOf))}</div>
                <div className="mt-0.5 text-xs text-fg3">longest streak</div>
              </div>
            </div>
            <p className="mt-5 text-[13px] leading-relaxed text-fg3">Keep the list short. Three or four habits you actually do beat ten you quietly abandon.</p>
          </div>
        </Panel>
      </div>
    </div>
  );
}
