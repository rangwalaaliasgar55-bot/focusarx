import { useState, type ReactNode } from "react";
import { Download, Minus, Plus, RotateCcw } from "lucide-react";
import { Button, PageHeader, Panel, Segmented, Switch } from "../components/ui";
import { A, getState, useStore } from "../store";

function Row({ title, hint, children }: { title: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-3 py-4 sm:flex-row sm:items-center sm:justify-between">
      <div>
        <div className="text-sm font-medium">{title}</div>
        {hint && <div className="mt-0.5 text-[13px] text-fg3">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

function Stepper({ value, min, max, step = 1, unit, onChange, label }: { value: number; min: number; max: number; step?: number; unit: string; onChange: (v: number) => void; label: string }) {
  return (
    <div className="flex items-center rounded-full border border-line">
      <button onClick={() => onChange(Math.max(min, value - step))} className="flex h-9 w-9 items-center justify-center text-fg2 hover:text-fg" aria-label={`Decrease ${label}`}>
        <Minus size={15} />
      </button>
      <span className="num min-w-[64px] text-center text-sm font-medium">
        {value} {unit}
      </span>
      <button onClick={() => onChange(Math.min(max, value + step))} className="flex h-9 w-9 items-center justify-center text-fg2 hover:text-fg" aria-label={`Increase ${label}`}>
        <Plus size={15} />
      </button>
    </div>
  );
}

export default function Settings() {
  const s = useStore((x) => x.settings);
  const [confirm, setConfirm] = useState(false);
  const [name, setName] = useState(s.name);

  const exportData = () => {
    const blob = new Blob([JSON.stringify(getState(), null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "focusarx-data.json";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="rise mx-auto max-w-3xl">
      <PageHeader title="Settings" sub="Tune the timer to how you actually work. Everything is saved on this device." />

      <Panel className="divide-y divide-line px-6">
        <Row title="Display name" hint="Shown on your dashboard and the leaderboard">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            onBlur={() => A.updateSettings({ name: name.trim() || "Alex" })}
            maxLength={18}
            aria-label="Display name"
            className="h-10 w-full rounded-xl border border-line bg-s2 px-3 text-sm focus:border-brand focus:outline-none sm:w-56"
          />
        </Row>
        <Row title="Theme">
          <Segmented<"dark" | "light"> value={s.theme} onChange={(v) => A.updateSettings({ theme: v })} options={[{ value: "dark", label: "Dark" }, { value: "light", label: "Light" }]} />
        </Row>
      </Panel>

      <h2 className="eyebrow mb-3 mt-8">Timer</h2>
      <Panel className="divide-y divide-line px-6">
        <Row title="Focus length">
          <Stepper label="focus length" value={s.focus} min={5} max={120} step={5} unit="min" onChange={(v) => A.updateSettings({ focus: v })} />
        </Row>
        <Row title="Short break">
          <Stepper label="short break" value={s.short} min={1} max={30} unit="min" onChange={(v) => A.updateSettings({ short: v })} />
        </Row>
        <Row title="Long break" hint="After every fourth focus session">
          <Stepper label="long break" value={s.long} min={5} max={60} step={5} unit="min" onChange={(v) => A.updateSettings({ long: v })} />
        </Row>
        <Row title="Daily goal" hint="Used for your progress ring and charts">
          <Stepper label="daily goal" value={s.goal} min={30} max={480} step={15} unit="min" onChange={(v) => A.updateSettings({ goal: v })} />
        </Row>
        <Row title="Start breaks automatically" hint="The break begins as soon as a focus session ends">
          <Switch checked={s.autoBreak} onChange={(v) => A.updateSettings({ autoBreak: v })} label="Start breaks automatically" />
        </Row>
        <Row title="Completion chime">
          <Switch checked={s.chime} onChange={(v) => A.updateSettings({ chime: v })} label="Completion chime" />
        </Row>
      </Panel>

      <h2 className="eyebrow mb-3 mt-8">Your data</h2>
      <Panel className="divide-y divide-line px-6">
        <Row title="Export" hint="Download sessions, tasks and habits as JSON">
          <Button onClick={exportData}>
            <Download size={15} /> Export data
          </Button>
        </Row>
        <Row title="Reset everything" hint="Restores the demo data and default settings">
          {confirm ? (
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => setConfirm(false)}>
                Cancel
              </Button>
              <Button
                variant="danger"
                onClick={() => {
                  A.resetAll();
                  setConfirm(false);
                  setName("Alex");
                }}
              >
                Yes, reset
              </Button>
            </div>
          ) : (
            <Button variant="danger" onClick={() => setConfirm(true)}>
              <RotateCcw size={15} /> Reset data
            </Button>
          )}
        </Row>
      </Panel>
    </div>
  );
}
