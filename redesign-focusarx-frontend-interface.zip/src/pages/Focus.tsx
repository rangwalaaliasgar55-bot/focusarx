import { useEffect, useState, useSyncExternalStore, type ReactNode } from "react";
import { Check, Maximize2, Minimize2, Minus, Pause, Play, Plus, RotateCcw, SkipForward, Sparkles, Volume2 } from "lucide-react";
import Pet3D from "../components/Pet3D";
import { Bar, Button, Panel, Segmented } from "../components/ui";
import { Link } from "../router";
import { A, bondInfo, fmtClock, useStore, type Mode } from "../store";
import { usePetLine, usePetMood } from "../hooks";
import { getPetDef } from "../lib/pets";
import { LAYERS, getVolumes, setLayer, subscribeAudio } from "../lib/audio";
import { cn } from "../utils/cn";

const PRESETS: Record<Mode, number[]> = {
  focus: [15, 25, 45, 50, 90],
  short: [3, 5, 10],
  long: [10, 15, 20, 30],
};
const MODE_LABEL: Record<Mode, string> = { focus: "Focus", short: "Short break", long: "Long break" };

/* ───────────────────────── Ring ───────────────────────── */

function TimerRing({ elapsed, running, mode, zen, children }: { elapsed: number; running: boolean; mode: Mode; zen: boolean; children: ReactNode }) {
  const R = 172;
  const C = 2 * Math.PI * R;
  const lit = Math.floor(elapsed * 120);
  const theta = elapsed * Math.PI * 2;
  const color = mode === "focus" ? "var(--brand)" : "var(--ok)";
  const ticks = [];
  for (let i = 0; i < 120; i++) {
    const a = (i * 3 * Math.PI) / 180;
    const major = i % 10 === 0;
    const r1 = major ? 189 : 196;
    const r2 = 208;
    ticks.push(
      <line
        key={i}
        x1={220 + r1 * Math.sin(a)}
        y1={220 - r1 * Math.cos(a)}
        x2={220 + r2 * Math.sin(a)}
        y2={220 - r2 * Math.cos(a)}
        stroke={i >= lit ? color : "var(--tick)"}
        strokeWidth={major ? 2.6 : 1.5}
        strokeLinecap="round"
        opacity={i >= lit ? (major ? 1 : 0.7) : 1}
      />
    );
  }
  return (
    <div className="relative mx-auto aspect-square" style={{ width: zen ? "min(86vw, 62vh, 620px)" : "min(88vw, 440px)" }}>
      <svg viewBox="0 0 440 440" className="absolute inset-0 h-full w-full" aria-hidden>
        {ticks}
        <circle cx="220" cy="220" r={R} fill="none" stroke="var(--ring-track)" strokeWidth="7" />
        <circle
          cx="220"
          cy="220"
          r={R}
          fill="none"
          stroke={color}
          strokeWidth="7"
          strokeLinecap="round"
          strokeDasharray={`${Math.max(0.001, (1 - elapsed) * C)} ${C}`}
          strokeDashoffset={-elapsed * C}
          transform="rotate(-90 220 220)"
          style={{ transition: running ? "stroke-dasharray 1s linear, stroke-dashoffset 1s linear" : "stroke-dasharray .4s ease, stroke-dashoffset .4s ease" }}
        />
        {elapsed < 0.995 && (
          <g style={{ transition: running ? "transform 1s linear" : "transform .4s ease", transformOrigin: "220px 220px", transform: `rotate(${theta}rad)` }}>
            <circle cx="220" cy={220 - R} r="12" fill="var(--bg)" />
            <circle cx="220" cy={220 - R} r="8.5" fill={color} />
          </g>
        )}
        <circle cx="220" cy="220" r="146" fill="none" stroke="var(--line)" strokeWidth="1" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center">{children}</div>
    </div>
  );
}

/* ───────────────────────── Sounds ───────────────────────── */

function SoundMixer() {
  const vols = useSyncExternalStore(subscribeAudio, getVolumes, getVolumes);
  const active = LAYERS.filter((l) => vols[l.id] > 0).length;
  return (
    <Panel className="p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Volume2 size={16} className="text-fg3" />
          <h3 className="font-display text-sm font-semibold">Ambient sound</h3>
        </div>
        <span className="text-xs text-fg3">{active ? `${active} playing` : "Off"}</span>
      </div>
      <div className="space-y-3.5">
        {LAYERS.map((l) => (
          <div key={l.id} className="flex items-center gap-3">
            <button
              onClick={() => setLayer(l.id, vols[l.id] > 0 ? 0 : 0.5)}
              className={cn("h-8 w-[92px] shrink-0 rounded-lg border text-left px-2.5 text-[13px] font-medium transition-colors", vols[l.id] > 0 ? "border-brand/50 bg-brand-soft text-brand" : "border-line text-fg2 hover:text-fg")}
              aria-pressed={vols[l.id] > 0}
              title={l.hint}
            >
              {l.label}
            </button>
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={vols[l.id]}
              onChange={(e) => setLayer(l.id, Number(e.target.value))}
              className="min-w-0 flex-1"
              aria-label={`${l.label} volume`}
            />
          </div>
        ))}
      </div>
    </Panel>
  );
}

/* ───────────────────────── Tasks ───────────────────────── */

function TaskPicker() {
  const tasks = useStore((s) => s.tasks);
  const activeId = useStore((s) => s.activeTaskId);
  const [draft, setDraft] = useState("");
  const open = tasks.filter((t) => !t.completed).slice(0, 5);
  return (
    <Panel className="p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-sm font-semibold">Working on</h3>
        <Link to="/tasks" className="text-xs font-medium text-fg3 hover:text-fg">
          All tasks
        </Link>
      </div>
      <div className="space-y-1.5">
        {open.map((t) => {
          const on = t.id === activeId;
          return (
            <button
              key={t.id}
              onClick={() => A.setActiveTask(on ? null : t.id)}
              className={cn("flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors", on ? "border-brand/50 bg-brand-soft" : "border-transparent hover:bg-s2")}
              aria-pressed={on}
            >
              <span className={cn("flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full border", on ? "border-brand bg-brand text-brand-ink" : "border-line-strong")}>{on && <Check size={11} strokeWidth={3.2} />}</span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[13.5px] font-medium text-fg">{t.title}</span>
                <span className="num text-[11.5px] text-fg3">
                  {t.done}/{t.est} sessions · {t.tag}
                </span>
              </span>
            </button>
          );
        })}
        {open.length === 0 && <p className="px-1 py-3 text-sm text-fg3">Nothing queued. Add the one thing you want to finish.</p>}
      </div>
      <form
        className="mt-3"
        onSubmit={(e) => {
          e.preventDefault();
          const v = draft.trim();
          if (!v) return;
          const id = A.addTask(v, "Study", "med", 1);
          A.setActiveTask(id);
          setDraft("");
        }}
      >
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Add a task and press Enter"
          className="h-10 w-full rounded-xl border border-line bg-s2 px-3 text-sm text-fg placeholder:text-fg3 focus:border-brand focus:outline-none"
        />
      </form>
    </Panel>
  );
}

/* ───────────────────────── Companion ───────────────────────── */

function Companion({ zen }: { zen?: boolean }) {
  const pet = useStore((s) => s.pet);
  const celebrateAt = useStore((s) => s.celebrateAt);
  const mood = usePetMood();
  const line = usePetLine();
  const [poke, setPoke] = useState<string | null>(null);
  const bond = bondInfo(pet.bond);
  const def = getPetDef(pet.species, pet.variant);

  useEffect(() => {
    if (!poke) return;
    const t = window.setTimeout(() => setPoke(null), 2200);
    return () => window.clearTimeout(t);
  }, [poke]);

  const pokes = ["Hehe, that tickles.", `${pet.name} blinks at you.`, "I'm here. Back to it?", "You're doing great."];
  const shown = poke ?? line;

  const bubble = (
    <div key={shown} className="bubble relative max-w-[250px] rounded-2xl rounded-bl-md border border-line-strong bg-s2 px-3.5 py-2.5 text-[13px] leading-snug text-fg">
      {shown}
    </div>
  );

  if (zen) {
    return (
      <div className="pointer-events-none absolute bottom-0 right-0 flex flex-col items-end sm:right-6">
        <div className="pointer-events-auto mb-[-14px] mr-6 hidden sm:block">{bubble}</div>
        <Pet3D className="pointer-events-auto h-[280px] w-[260px] sm:h-[340px] sm:w-[320px]" species={pet.species} variant={pet.variant} mood={mood} celebrateAt={celebrateAt} onPoke={() => setPoke(pokes[Math.floor(Math.random() * pokes.length)])} />
      </div>
    );
  }

  return (
    <Panel className="relative overflow-hidden">
      <div className="stage-floor absolute inset-x-0 bottom-0 h-1/2" />
      <div className="absolute left-4 top-4 z-10">{bubble}</div>
      <Pet3D className="relative h-[360px] w-full" species={pet.species} variant={pet.variant} mood={mood} celebrateAt={celebrateAt} onPoke={() => setPoke(pokes[Math.floor(Math.random() * pokes.length)])} zoom={1.06} yOffset={-0.05} />
      <div className="relative flex items-center gap-3 border-t border-line px-5 py-4">
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between">
            <span className="font-display text-sm font-semibold">{pet.name}</span>
            <span className="text-xs text-fg3">
              {def.label} · Bond {bond.level}
            </span>
          </div>
          <Bar pct={bond.pct} className="mt-2" />
        </div>
      </div>
    </Panel>
  );
}

/* ───────────────────────── Completion ───────────────────────── */

function CompletionBanner() {
  const c = useStore((s) => s.completion);
  const mode = useStore((s) => s.timer.mode);
  if (!c) return null;
  const isFocus = c.mode === "focus";
  return (
    <div className="rise mb-6 flex flex-wrap items-center gap-x-6 gap-y-3 rounded-2xl border border-brand/40 bg-brand-soft px-5 py-4">
      <div className="flex min-w-0 items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand text-brand-ink">
          <Check size={18} strokeWidth={3} />
        </span>
        <div>
          <div className="font-display text-[15px] font-bold">{isFocus ? `${c.minutes} minutes saved` : "Break finished"}</div>
          <div className="truncate text-[13px] text-fg2">{isFocus ? (c.task ? c.task : "Session logged to your history") : "Ready for the next focus block?"}</div>
        </div>
      </div>
      {isFocus && (
        <div className="num flex items-center gap-5 text-sm">
          <div>
            <div className="eyebrow">Score</div>
            <div className="font-display text-lg font-bold">{c.score}</div>
          </div>
          <div>
            <div className="eyebrow">XP</div>
            <div className="font-display text-lg font-bold">+{c.xp}</div>
          </div>
          <div>
            <div className="eyebrow">Coins</div>
            <div className="font-display text-lg font-bold">+{c.coins}</div>
          </div>
          {c.levelUp && (
            <div className="flex items-center gap-1.5 rounded-full bg-brand px-3 py-1 text-xs font-semibold text-brand-ink">
              <Sparkles size={13} /> Level up
            </div>
          )}
        </div>
      )}
      <div className="ml-auto flex gap-2">
        <Button variant="ghost" size="sm" onClick={() => A.dismissCompletion()}>
          Dismiss
        </Button>
        <Button variant="primary" size="sm" onClick={() => A.start()}>
          {mode === "focus" ? "Start focus" : "Start break"}
        </Button>
      </div>
    </div>
  );
}

/* ───────────────────────── Page ───────────────────────── */

export default function Focus() {
  const timer = useStore((s) => s.timer);
  const tasks = useStore((s) => s.tasks);
  const activeId = useStore((s) => s.activeTaskId);
  const [zen, setZen] = useState(false);

  const running = timer.status === "running";
  const elapsed = 1 - timer.remaining / timer.total;
  const clock = fmtClock(timer.remaining);
  const task = tasks.find((t) => t.id === activeId);
  const endsAt = new Date(Date.now() + timer.remaining * 1000);
  const endLabel = endsAt.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const canSave = timer.mode === "focus" && timer.status !== "idle" && timer.total - timer.remaining >= 60;

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el.matches("input, textarea, select, [contenteditable]")) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.code === "Space") {
        if (el.tagName === "BUTTON") return;
        e.preventDefault();
        A.toggle();
      } else if (e.key === "r" || e.key === "R") A.reset();
      else if (e.key === "s" || e.key === "S") A.skip();
      else if (e.key === "f" || e.key === "F") setZen((z) => !z);
      else if (e.key === "Escape") setZen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const presets = PRESETS[timer.mode];
  const currentMin = Math.round(timer.total / 60);

  const stage = (
    <div className={cn("relative", zen ? "flex min-h-full flex-col items-center justify-center px-4 py-10" : "")}>
      <div className="flex justify-center">
        <Segmented<Mode>
          value={timer.mode}
          onChange={(m) => A.setMode(m)}
          options={(Object.keys(MODE_LABEL) as Mode[]).map((m) => ({ value: m, label: MODE_LABEL[m] }))}
        />
      </div>

      <div className="mt-8 sm:mt-10">
        <TimerRing elapsed={elapsed} running={running} mode={timer.mode} zen={zen}>
          <span className="eyebrow mb-1 sm:mb-2">{timer.status === "paused" ? "Paused" : MODE_LABEL[timer.mode]}</span>
          <div
            className={cn("num font-display font-bold leading-none tracking-[-0.045em] text-fg", zen ? "text-[clamp(72px,17vw,150px)]" : "text-[clamp(64px,18vw,104px)]")}
            aria-label={`${clock.m} minutes ${clock.s} seconds remaining`}
            role="timer"
          >
            {clock.m}
            <span className={cn("mx-[0.02em] text-fg3", running && "colon-blink")}>:</span>
            {clock.s}
          </div>
          <div className="mt-3 max-w-[62%] truncate text-sm text-fg2 sm:mt-4">
            {running ? `Ends at ${endLabel}` : timer.mode === "focus" ? (task ? task.title : "Pick a task, or just begin") : "Step away from the screen"}
          </div>
        </TimerRing>
      </div>

      <div className="mt-8 flex items-center justify-center gap-4 sm:mt-10">
        <button onClick={() => A.reset()} className="flex h-12 w-12 items-center justify-center rounded-full border border-line bg-s1 text-fg2 transition-colors hover:border-line-strong hover:text-fg" aria-label="Reset timer" title="Reset (R)">
          <RotateCcw size={18} />
        </button>
        <button
          onClick={() => A.toggle()}
          className="flex h-16 min-w-[176px] items-center justify-center gap-3 rounded-full bg-brand px-8 font-display text-[17px] font-bold text-brand-ink transition-[filter,transform] hover:brightness-110 active:scale-[0.97]"
          style={timer.mode !== "focus" ? { background: "var(--ok)" } : undefined}
          title="Start / pause (Space)"
        >
          {running ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />}
          {running ? "Pause" : timer.status === "paused" ? "Resume" : "Start"}
        </button>
        <button onClick={() => A.skip()} className="flex h-12 w-12 items-center justify-center rounded-full border border-line bg-s1 text-fg2 transition-colors hover:border-line-strong hover:text-fg" aria-label="Skip to next" title="Skip (S)">
          <SkipForward size={18} />
        </button>
      </div>

      <div className="mt-7 flex min-h-[44px] flex-col items-center gap-3">
        {timer.status === "idle" ? (
          <div className="flex flex-wrap items-center justify-center gap-2">
            {presets.map((m) => (
              <button
                key={m}
                onClick={() => A.setLength(m)}
                className={cn("num h-8 rounded-full border px-3.5 text-[13px] font-medium transition-colors", m === currentMin ? "border-brand/60 bg-brand-soft text-brand" : "border-line text-fg2 hover:border-line-strong hover:text-fg")}
              >
                {m}m
              </button>
            ))}
            <span className="mx-1 hidden h-4 w-px bg-line-strong sm:block" />
            <div className="flex items-center rounded-full border border-line">
              <button onClick={() => A.setLength(Math.max(1, currentMin - 5))} className="flex h-8 w-8 items-center justify-center rounded-full text-fg2 hover:text-fg" aria-label="Decrease by 5 minutes">
                <Minus size={14} />
              </button>
              <span className="num min-w-[44px] text-center text-[13px] font-medium">{currentMin}m</span>
              <button onClick={() => A.setLength(Math.min(180, currentMin + 5))} className="flex h-8 w-8 items-center justify-center rounded-full text-fg2 hover:text-fg" aria-label="Increase by 5 minutes">
                <Plus size={14} />
              </button>
            </div>
          </div>
        ) : (
          canSave && (
            <button onClick={() => A.finishEarly()} className="text-[13px] font-medium text-fg3 underline-offset-4 hover:text-fg hover:underline">
              End now and save {Math.floor((timer.total - timer.remaining) / 60)} minutes
            </button>
          )
        )}
      </div>

      <div className="mt-5 flex items-center justify-center gap-3">
        <div className="flex gap-1.5" aria-label={`Session ${(timer.cycle % 4) + 1} of 4`}>
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className={cn("h-1.5 rounded-full transition-all", i < timer.cycle % 4 ? "w-6 bg-brand" : i === timer.cycle % 4 ? "w-6 bg-brand/40" : "w-1.5 bg-line-strong")} />
          ))}
        </div>
        <span className="text-xs text-fg3">Session {(timer.cycle % 4) + 1} of 4</span>
      </div>
    </div>
  );

  if (zen) {
    return (
      <div className="fixed inset-0 z-[60] overflow-auto bg-bg">
        <div className="stage-floor pointer-events-none absolute inset-0" />
        <button onClick={() => setZen(false)} className="absolute right-4 top-4 z-10 flex h-10 items-center gap-2 rounded-xl border border-line bg-s1 px-3.5 text-sm font-medium text-fg2 hover:text-fg" aria-label="Exit zen mode">
          <Minimize2 size={15} /> Exit
        </button>
        {stage}
        <Companion zen />
      </div>
    );
  }

  return (
    <div>
      <CompletionBanner />
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_370px]">
        <Panel className="relative overflow-hidden rounded-[28px] px-4 pb-8 pt-6 sm:px-10 sm:pb-10 sm:pt-8">
          <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(55% 45% at 50% 46%, var(--brand-soft), transparent 75%)", opacity: running ? 1 : 0.55, transition: "opacity .6s" }} />
          <button onClick={() => setZen(true)} className="absolute right-4 top-4 z-10 hidden h-9 items-center gap-2 rounded-lg px-3 text-[13px] font-medium text-fg3 transition-colors hover:bg-s2 hover:text-fg sm:flex" title="Zen mode (F)">
            <Maximize2 size={14} /> Zen
          </button>
          <div className="relative">{stage}</div>
          <p className="relative mt-8 hidden text-center text-xs text-fg3 sm:block">
            <kbd className="rounded border border-line-strong px-1.5 py-0.5 font-sans">Space</kbd> start / pause · <kbd className="rounded border border-line-strong px-1.5 py-0.5 font-sans">R</kbd> reset ·{" "}
            <kbd className="rounded border border-line-strong px-1.5 py-0.5 font-sans">S</kbd> skip · <kbd className="rounded border border-line-strong px-1.5 py-0.5 font-sans">F</kbd> zen
          </p>
        </Panel>
        <div className="space-y-6">
          <Companion />
          <TaskPicker />
          <SoundMixer />
        </div>
      </div>
    </div>
  );
}
