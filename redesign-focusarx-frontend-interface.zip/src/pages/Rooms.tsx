import { useState } from "react";
import { Hand, Play, Users } from "lucide-react";
import { Avatar, Button, Chip, PageHeader, Panel, SectionTitle } from "../components/ui";
import { go } from "../router";
import { A, useStore } from "../store";
import { useNow } from "../hooks";
import { cn } from "../utils/cn";

interface Room {
  id: string;
  name: string;
  topic: string;
  focus: number;
  brk: number;
  offset: number;
  members: string[];
  extra: number;
}

const ROOMS: Room[] = [
  { id: "lib", name: "Quiet Library", topic: "Silent study, no chat", focus: 50, brk: 10, offset: 0, members: ["Maya", "Jonas", "Priya", "Theo", "Lena"], extra: 9 },
  { id: "am", name: "Morning Deep Work", topic: "Early starters, hardest task first", focus: 25, brk: 5, offset: 0, members: ["Sam", "Ines", "Kofi", "Ravi"], extra: 5 },
  { id: "code", name: "Code & Coffee", topic: "Building things, side projects welcome", focus: 50, brk: 10, offset: 17, members: ["Dana", "Mo", "Yuki", "Ana", "Leo"], extra: 6 },
  { id: "write", name: "Thesis Writers", topic: "Drafting, editing, citations", focus: 25, brk: 5, offset: 7, members: ["Hana", "Omar", "Beth"], extra: 3 },
  { id: "exam", name: "Exam Season", topic: "Past papers and revision sprints", focus: 45, brk: 15, offset: 11, members: ["Zoe", "Arjun", "Nina", "Ben", "Cleo"], extra: 18 },
  { id: "owl", name: "Night Owls", topic: "Late sessions, low light, soft focus", focus: 25, brk: 5, offset: 3, members: ["Ivo", "Sasha", "Rui", "Mina"], extra: 4 },
];

function phase(r: Room, now: number) {
  const cycle = (r.focus + r.brk) * 60000;
  const t = (now + r.offset * 60000) % cycle;
  const inFocus = t < r.focus * 60000;
  const left = inFocus ? r.focus * 60000 - t : cycle - t;
  const total = (inFocus ? r.focus : r.brk) * 60000;
  return { inFocus, left, pct: 1 - left / total };
}

const mmss = (ms: number) => {
  const s = Math.ceil(ms / 1000);
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
};

export default function Rooms() {
  const now = useNow();
  const name = useStore((s) => s.settings.name);
  const [selected, setSelected] = useState<string>("lib");
  const [joined, setJoined] = useState<string | null>(null);
  const room = ROOMS.find((r) => r.id === selected)!;
  const ph = phase(room, now);
  const isIn = joined === room.id;

  const syncAndStart = () => {
    A.setMode(ph.inFocus ? "focus" : "short");
    A.setLength(Math.max(1, Math.ceil(ph.left / 60000)));
    go("/focus");
    window.setTimeout(() => A.start(), 80);
    A.toast(`Timer synced with ${room.name}`);
  };

  const people = [...(isIn ? [name + " (you)"] : []), ...room.members];

  return (
    <div className="rise">
      <PageHeader title="Study rooms" sub="Body-doubling: work silently alongside others on a shared clock. Every room runs on its own repeating focus and break cycle." />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        <div className="grid gap-4 sm:grid-cols-2">
          {ROOMS.map((r) => {
            const p = phase(r, now);
            const on = r.id === selected;
            const count = r.members.length + r.extra + (joined === r.id ? 1 : 0);
            return (
              <button
                key={r.id}
                onClick={() => setSelected(r.id)}
                className={cn("panel flex flex-col p-5 text-left transition-colors hover:border-line-strong", on && "!border-brand/60")}
                aria-pressed={on}
              >
                <div className="flex items-center justify-between">
                  <span className={cn("inline-flex items-center gap-1.5 text-xs font-semibold", p.inFocus ? "text-brand" : "text-ok")}>
                    <span className={cn("h-1.5 w-1.5 rounded-full", p.inFocus ? "bg-brand" : "bg-ok")} />
                    {p.inFocus ? "Focusing" : "On break"}
                  </span>
                  <span className="num font-display text-lg font-bold">{mmss(p.left)}</span>
                </div>
                <h3 className="mt-4 font-display text-[17px] font-bold tracking-tight">{r.name}</h3>
                <p className="mt-1 text-[13px] text-fg3">{r.topic}</p>
                <div className="mt-4 h-1 overflow-hidden rounded-full bg-line-strong/60">
                  <div className={cn("h-full rounded-full", p.inFocus ? "bg-brand" : "bg-ok")} style={{ width: `${p.pct * 100}%`, transition: "width 1s linear" }} />
                </div>
                <div className="mt-4 flex items-center justify-between">
                  <div className="flex -space-x-2">
                    {r.members.slice(0, 4).map((m) => (
                      <span key={m} className="rounded-full ring-2 ring-[var(--s1)]">
                        <Avatar name={m} size={26} />
                      </span>
                    ))}
                  </div>
                  <span className="num inline-flex items-center gap-1.5 text-xs text-fg2">
                    <Users size={13} /> {count} · {r.focus}/{r.brk}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        <Panel className="h-fit p-6 lg:sticky lg:top-24">
          <div className="flex items-start justify-between">
            <div>
              <div className="eyebrow">{ph.inFocus ? "Focus block" : "Break"}</div>
              <h2 className="mt-1 font-display text-xl font-bold tracking-tight">{room.name}</h2>
            </div>
            <Chip>{room.focus}/{room.brk} cycle</Chip>
          </div>
          <div className="mt-6 text-center">
            <div className={cn("num font-display text-[56px] font-bold leading-none tracking-[-0.04em]", ph.inFocus ? "text-fg" : "text-ok")}>{mmss(ph.left)}</div>
            <div className="mt-2 text-[13px] text-fg3">{ph.inFocus ? "until the next break" : "until focus resumes"}</div>
          </div>
          <div className="mt-6 flex gap-2">
            <Button variant={isIn ? "secondary" : "primary"} className="flex-1" onClick={() => setJoined(isIn ? null : room.id)}>
              {isIn ? "Leave room" : "Join room"}
            </Button>
            <Button className="flex-1" onClick={syncAndStart}>
              <Play size={14} fill="currentColor" /> Sync my timer
            </Button>
          </div>

          <div className="mt-7">
            <SectionTitle title={`In the room · ${people.length + room.extra}`} />
            <ul className="space-y-1">
              {people.map((m) => (
                <li key={m} className="flex items-center gap-3 rounded-xl px-2 py-2 hover:bg-s2">
                  <Avatar name={m} size={32} />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{m}</div>
                    <div className="text-xs text-fg3">{ph.inFocus ? "Focusing" : "Stretching"}</div>
                  </div>
                  {!m.includes("(you)") && (
                    <button onClick={() => A.toast(`Sent a cheer to ${m}`)} className="flex h-8 w-8 items-center justify-center rounded-lg text-fg3 hover:bg-s3 hover:text-fg" aria-label={`Cheer ${m}`}>
                      <Hand size={15} />
                    </button>
                  )}
                </li>
              ))}
              <li className="px-2 py-2 text-[13px] text-fg3">and {room.extra} more working quietly</li>
            </ul>
          </div>
        </Panel>
      </div>
    </div>
  );
}
