import { useState } from "react";
import { Check, Coins, Heart, Lock } from "lucide-react";
import Pet3D, { type PetMood } from "../components/Pet3D";
import { Bar, Button, PageHeader, Panel, Segmented } from "../components/ui";
import { A, bondInfo, useStore } from "../store";
import { PET_CATALOG, SPECIES_LABEL, type Species } from "../lib/pets";
import { cn } from "../utils/cn";

const SPECIES: Species[] = ["fox", "cat", "owl", "slime"];

export default function Pets() {
  const pet = useStore((s) => s.pet);
  const coins = useStore((s) => s.coins);
  const celebrateAt = useStore((s) => s.celebrateAt);
  const [previewKey, setPreviewKey] = useState(`${pet.species}:${pet.variant}`);
  const [mood, setMood] = useState<PetMood>("idle");
  const [name, setName] = useState(pet.name);

  const preview = PET_CATALOG.find((p) => p.key === previewKey) ?? PET_CATALOG[0];
  const owned = pet.owned.includes(preview.key);
  const current = `${pet.species}:${pet.variant}` === preview.key;
  const bond = bondInfo(pet.bond);

  return (
    <div className="rise">
      <PageHeader title="Pets" sub="Your companion works beside you. Focus to deepen your bond, and earn coins to adopt more." />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_400px]">
        <div className="space-y-6">
          <Panel className="relative overflow-hidden">
            <div className="stage-floor absolute inset-x-0 bottom-0 h-2/3" />
            <div className="absolute left-5 top-5 z-10">
              <div className="eyebrow">{SPECIES_LABEL[preview.species]}</div>
              <h2 className="mt-1 font-display text-2xl font-bold tracking-tight">{preview.label}</h2>
              <p className="mt-1 max-w-[260px] text-[13px] text-fg2">{preview.blurb}</p>
            </div>
            <div className="absolute right-5 top-5 z-10 hidden sm:block">
              <Segmented<PetMood>
                size="sm"
                value={mood}
                onChange={setMood}
                options={[
                  { value: "idle", label: "Idle" },
                  { value: "focus", label: "Focus" },
                  { value: "break", label: "Break" },
                  { value: "sleep", label: "Sleep" },
                ]}
              />
            </div>
            <Pet3D className="relative h-[480px] w-full sm:h-[540px]" species={preview.species} variant={preview.variant} mood={mood} celebrateAt={celebrateAt} drag autoRotate zoom={1.02} />
            <p className="pointer-events-none absolute inset-x-0 bottom-3 text-center text-xs text-fg3">Drag to rotate · tap to say hello</p>
          </Panel>

          <Panel className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
            <div className="flex-1">
              {owned ? (
                <p className="text-sm text-fg2">{current ? "This is your current companion." : "You own this pet."}</p>
              ) : (
                <p className="text-sm text-fg2">
                  Adopt {preview.label} for <span className="num font-semibold text-fg">{preview.price}</span> coins. You have <span className="num font-semibold text-fg">{coins}</span>.
                </p>
              )}
            </div>
            {owned ? (
              <Button variant="primary" disabled={current} onClick={() => A.selectPet(preview.key)}>
                {current ? (
                  <>
                    <Check size={16} /> Current companion
                  </>
                ) : (
                  "Set as companion"
                )}
              </Button>
            ) : (
              <Button variant="primary" disabled={coins < preview.price} onClick={() => A.adopt(preview.key)}>
                <Coins size={16} /> Adopt · {preview.price}
              </Button>
            )}
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel className="p-5">
            <div className="flex items-center gap-3">
              <div className="min-w-0 flex-1">
                <label htmlFor="petname" className="eyebrow">
                  Companion name
                </label>
                <input
                  id="petname"
                  value={name}
                  maxLength={14}
                  onChange={(e) => setName(e.target.value)}
                  onBlur={() => A.renamePet(name)}
                  onKeyDown={(e) => e.key === "Enter" && (e.currentTarget.blur(), undefined)}
                  className="mt-2 h-10 w-full rounded-xl border border-line bg-s2 px-3 font-display text-base font-semibold focus:border-brand focus:outline-none"
                />
              </div>
              <div className="pt-6 text-right">
                <div className="num font-display text-2xl font-bold leading-none">{bond.level}</div>
                <div className="mt-1 text-xs text-fg3">Bond level</div>
              </div>
            </div>
            <div className="mt-4">
              <Bar pct={bond.pct} />
              <div className="num mt-2 flex justify-between text-xs text-fg3">
                <span>{bond.into} bond</span>
                <span>{bond.need} for next level</span>
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <Button className="flex-1" onClick={() => A.feed()}>
                <Heart size={15} /> Feed · 5
              </Button>
              <Button className="flex-1" onClick={() => A.celebrate()}>
                Play
              </Button>
            </div>
          </Panel>

          {SPECIES.map((sp) => (
            <Panel key={sp} className="p-5">
              <div className="mb-3 eyebrow">{SPECIES_LABEL[sp]}s</div>
              <div className="grid grid-cols-1 gap-2">
                {PET_CATALOG.filter((p) => p.species === sp).map((p) => {
                  const has = pet.owned.includes(p.key);
                  const sel = previewKey === p.key;
                  const cur = `${pet.species}:${pet.variant}` === p.key;
                  return (
                    <button
                      key={p.key}
                      onClick={() => setPreviewKey(p.key)}
                      className={cn("flex items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors", sel ? "border-brand/60 bg-brand-soft" : "border-transparent hover:bg-s2")}
                      aria-pressed={sel}
                    >
                      <span className="h-9 w-9 shrink-0 rounded-full border border-white/10" style={{ background: `radial-gradient(circle at 35% 30%, #fff6, transparent 45%), ${p.swatch}` }} />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-medium">{p.label}</span>
                        <span className="block truncate text-xs text-fg3">{p.blurb}</span>
                      </span>
                      <span className="num flex shrink-0 items-center gap-1 text-xs font-medium text-fg2">
                        {cur ? (
                          <span className="text-brand">Active</span>
                        ) : has ? (
                          <span className="text-ok">Owned</span>
                        ) : (
                          <>
                            <Lock size={12} className="text-fg3" /> {p.price}
                          </>
                        )}
                      </span>
                    </button>
                  );
                })}
              </div>
            </Panel>
          ))}
        </div>
      </div>
    </div>
  );
}
