import { useEffect, type ComponentType } from "react";
import Layout from "./components/Layout";
import { Toaster } from "./components/ui";
import { useRoute, go } from "./router";
import { fmtClock, useStore } from "./store";
import Landing from "./pages/Landing";
import Focus from "./pages/Focus";
import Dashboard from "./pages/Dashboard";
import Tasks from "./pages/Tasks";
import Habits from "./pages/Habits";
import Analytics from "./pages/Analytics";
import Rooms from "./pages/Rooms";
import Leaderboard from "./pages/Leaderboard";
import Pets from "./pages/Pets";
import Settings from "./pages/Settings";

const ROUTES: Record<string, ComponentType> = {
  "/focus": Focus,
  "/dashboard": Dashboard,
  "/tasks": Tasks,
  "/habits": Habits,
  "/analytics": Analytics,
  "/rooms": Rooms,
  "/leaderboard": Leaderboard,
  "/pets": Pets,
  "/settings": Settings,
};

function useTabTitle() {
  const timer = useStore((s) => s.timer);
  useEffect(() => {
    if (timer.status === "idle") {
      document.title = "FocusArx — Focus timer with a 3D companion";
      return;
    }
    const c = fmtClock(timer.remaining);
    document.title = `${c.m}:${c.s} · ${timer.mode === "focus" ? "Focus" : "Break"} — FocusArx`;
  }, [timer.status, timer.remaining, timer.mode]);
}

export default function App() {
  const path = useRoute();
  useTabTitle();

  const Page = ROUTES[path];

  useEffect(() => {
    if (path !== "/" && !Page) go("/dashboard");
  }, [path, Page]);

  return (
    <>
      {path === "/" ? (
        <Landing />
      ) : Page ? (
        <Layout path={path}>
          <Page />
        </Layout>
      ) : null}
      <Toaster />
    </>
  );
}
