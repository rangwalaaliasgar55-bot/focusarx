import { useSyncExternalStore } from "react";
import type { Species } from "./lib/pets";
import { PET_CATALOG } from "./lib/pets";
import { playChime } from "./lib/audio";

/* ───────────────────────── Types ───────────────────────── */

export type Mode = "focus" | "short" | "long";

export interface Task {
  id: string;
  title: string;
  tag: string;
  priority: "high" | "med" | "low";
  est: number;
  done: number;
  completed: boolean;
  createdAt: number;
}

export interface Session {
  id: string;
  ts: number;
  minutes: number;
  tag: string;
  task?: string;
  score: number;
}

export interface Habit {
  id: string;
  name: string;
  note: string;
  log: string[];
}

export interface PetState {
  species: Species;
  variant: number;
  name: string;
  owned: string[];
  bond: number;
  fedAt: number;
}

export interface Settings {
  name: string;
  focus: number;
  short: number;
  long: number;
  goal: number;
  theme: "dark" | "light";
  autoBreak: boolean;
  chime: boolean;
}

export interface TimerState {
  mode: Mode;
  status: "idle" | "running" | "paused";
  total: number;
  remaining: number;
  endsAt: number;
  now: number;
  pauses: number;
  cycle: number;
}

export interface Completion {
  id: string;
  mode: Mode;
  minutes: number;
  xp: number;
  coins: number;
  score: number;
  task?: string;
  levelUp: boolean;
  at: number;
}

export interface AppState {
  xp: number;
  coins: number;
  tasks: Task[];
  sessions: Session[];
  habits: Habit[];
  pet: PetState;
  settings: Settings;
  activeTaskId: string | null;
  claimed: Record<string, string[]>;
  timer: TimerState;
  completion: Completion | null;
  toast: { id: number; msg: string } | null;
  celebrateAt: number;
}

/* ───────────────────────── Date helpers ───────────────────────── */

export const DAY = 86400000;

export function dayKey(ts: number | Date): string {
  const d = typeof ts === "number" ? new Date(ts) : ts;
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${dd}`;
}

export function startOfDay(ts: number): number {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

export function daysAgoKey(n: number): string {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() - n);
  return dayKey(d);
}

/* ───────────────────────── Derived helpers ───────────────────────── */

export function minutesByDay(sessions: Session[]): Record<string, number> {
  const out: Record<string, number> = {};
  for (const s of sessions) {
    const k = dayKey(s.ts);
    out[k] = (out[k] ?? 0) + s.minutes;
  }
  return out;
}

export function computeStreak(sessions: Session[]): { current: number; best: number } {
  const by = minutesByDay(sessions);
  let current = 0;
  let i = by[daysAgoKey(0)] ? 0 : 1;
  while (by[daysAgoKey(i)]) {
    current++;
    i++;
  }
  const keys = Object.keys(by).sort();
  let best = 0;
  let run = 0;
  let prev = 0;
  for (const k of keys) {
    const t = new Date(k + "T12:00:00").getTime();
    run = prev && Math.round((t - prev) / DAY) === 1 ? run + 1 : 1;
    best = Math.max(best, run);
    prev = t;
  }
  return { current, best };
}

export function levelInfo(xp: number) {
  const level = Math.floor(Math.sqrt(xp / 120)) + 1;
  const floor = 120 * (level - 1) ** 2;
  const next = 120 * level ** 2;
  return { level, floor, next, pct: (xp - floor) / (next - floor), into: xp - floor, need: next - floor };
}

export function bondInfo(bond: number) {
  const level = Math.floor(Math.sqrt(bond / 40)) + 1;
  const floor = 40 * (level - 1) ** 2;
  const next = 40 * level ** 2;
  return { level, pct: (bond - floor) / (next - floor), into: bond - floor, need: next - floor };
}

export function fmtDuration(min: number): string {
  const h = Math.floor(min / 60);
  const m = Math.round(min % 60);
  if (h === 0) return `${m}m`;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}

export function fmtClock(sec: number): { m: string; s: string } {
  const t = Math.max(0, Math.ceil(sec));
  return { m: String(Math.floor(t / 60)).padStart(2, "0"), s: String(t % 60).padStart(2, "0") };
}

/* ───────────────────────── Seed data ───────────────────────── */

function rng(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const TAGS = ["Study", "Deep work", "Reading", "Writing", "Code"];
const TASK_NAMES: Record<string, string[]> = {
  Study: ["Revise thermodynamics", "Organic chemistry problem set", "Past paper 2022"],
  "Deep work": ["Draft quarterly proposal", "Design review prep"],
  Reading: ["Chapter 6 — Thinking, Fast and Slow", "Read two research papers"],
  Writing: ["Essay outline", "Weekly journal"],
  Code: ["Refactor auth module", "Ship settings page"],
};

function seedSessions(): Session[] {
  const r = rng(42);
  const out: Session[] = [];
  const hours = [8, 9, 10, 11, 14, 15, 16, 17, 20, 21];
  const weights = [2, 5, 6, 4, 2, 4, 5, 3, 3, 2];
  const pickHour = () => {
    const total = weights.reduce((a, b) => a + b, 0);
    let x = r() * total;
    for (let i = 0; i < hours.length; i++) {
      x -= weights[i];
      if (x <= 0) return hours[i];
    }
    return 9;
  };
  for (let d = 1; d <= 120; d++) {
    const date = new Date();
    date.setDate(date.getDate() - d);
    const dow = date.getDay();
    const skip = d > 10 && r() < (dow === 0 ? 0.45 : dow === 6 ? 0.3 : 0.14);
    if (skip) continue;
    const count = 1 + Math.floor(r() * (dow === 0 || dow === 6 ? 3 : 5));
    for (let i = 0; i < count; i++) {
      const tag = TAGS[Math.floor(r() * TAGS.length)];
      const minutes = [25, 25, 25, 45, 50, 15][Math.floor(r() * 6)];
      const dt = new Date(date);
      dt.setHours(pickHour(), Math.floor(r() * 50), 0, 0);
      out.push({
        id: `s${d}-${i}`,
        ts: dt.getTime(),
        minutes,
        tag,
        task: TASK_NAMES[tag][Math.floor(r() * TASK_NAMES[tag].length)],
        score: Math.round(72 + r() * 27),
      });
    }
  }
  const now = new Date();
  if (now.getHours() >= 11) {
    const a = new Date();
    a.setHours(9, 5, 0, 0);
    out.push({ id: "today-1", ts: a.getTime(), minutes: 25, tag: "Study", task: "Revise thermodynamics", score: 94 });
    const b = new Date();
    b.setHours(9, 40, 0, 0);
    out.push({ id: "today-2", ts: b.getTime(), minutes: 25, tag: "Study", task: "Revise thermodynamics", score: 88 });
  }
  return out.sort((a, b) => a.ts - b.ts);
}

function seedHabits(): Habit[] {
  const mk = (name: string, note: string, p: number, seed: number): Habit => {
    const r = rng(seed);
    const log: string[] = [];
    for (let i = 0; i < 60; i++) if (i < 4 || r() < p) log.push(daysAgoKey(i));
    return { id: name, name, note, log };
  };
  return [
    mk("Phone away while studying", "Out of the room, not just face-down", 0.82, 7),
    mk("Plan tomorrow tonight", "Three tasks, no more", 0.66, 11),
    mk("Walk for 20 minutes", "Outside, no headphones", 0.55, 13),
    mk("Read 10 pages", "Paper, not a screen", 0.7, 17),
  ];
}

function seedTasks(): Task[] {
  const t = Date.now();
  const mk = (i: number, title: string, tag: string, priority: Task["priority"], est: number, done: number): Task => ({
    id: `t${i}`,
    title,
    tag,
    priority,
    est,
    done,
    completed: false,
    createdAt: t - i * 3600_000,
  });
  return [
    mk(1, "Revise thermodynamics — chapters 4 to 6", "Study", "high", 4, 2),
    mk(2, "Organic chemistry problem set", "Study", "high", 3, 0),
    mk(3, "Draft the quarterly proposal", "Deep work", "med", 3, 1),
    mk(4, "Read two research papers", "Reading", "med", 2, 0),
    mk(5, "Refactor the auth module", "Code", "low", 2, 0),
    { ...mk(6, "Email supervisor about thesis dates", "Writing", "low", 1, 1), completed: true },
  ];
}

/* ───────────────────────── Store core ───────────────────────── */

const KEY = "focusarx.v2";

function defaultSettings(): Settings {
  return { name: "Alex", focus: 25, short: 5, long: 15, goal: 120, theme: "dark", autoBreak: false, chime: true };
}

function initialTimer(s: Settings): TimerState {
  return { mode: "focus", status: "idle", total: s.focus * 60, remaining: s.focus * 60, endsAt: 0, now: Date.now(), pauses: 0, cycle: 0 };
}

function createInitial(): AppState {
  const settings = defaultSettings();
  return {
    xp: 2380,
    coins: 640,
    tasks: seedTasks(),
    sessions: seedSessions(),
    habits: seedHabits(),
    pet: { species: "fox", variant: 0, name: "Mochi", owned: ["fox:0"], bond: 310, fedAt: 0 },
    settings,
    activeTaskId: "t1",
    claimed: {},
    timer: initialTimer(settings),
    completion: null,
    toast: null,
    celebrateAt: 0,
  };
}

function load(): AppState {
  const base = createInitial();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return base;
    const saved = JSON.parse(raw) as Partial<AppState>;
    const merged: AppState = { ...base, ...saved, settings: { ...base.settings, ...(saved.settings ?? {}) }, completion: null, toast: null, celebrateAt: 0 };
    merged.timer = { ...base.timer, ...(saved.timer ?? {}), now: Date.now() };
    return merged;
  } catch {
    return base;
  }
}

let state: AppState = load();
const listeners = new Set<() => void>();

function persist() {
  try {
    const { completion: _c, toast: _t, celebrateAt: _x, ...rest } = state;
    void _c;
    void _t;
    void _x;
    localStorage.setItem(KEY, JSON.stringify(rest));
  } catch {
    /* storage unavailable */
  }
}

let persistTimer: number | undefined;
function emit(save = true) {
  listeners.forEach((l) => l());
  if (save) {
    window.clearTimeout(persistTimer);
    persistTimer = window.setTimeout(persist, 200);
  }
}

function set(patch: Partial<AppState> | ((s: AppState) => Partial<AppState>), save = true) {
  const p = typeof patch === "function" ? patch(state) : patch;
  state = { ...state, ...p };
  emit(save);
}

export function useStore<T>(selector: (s: AppState) => T): T {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => selector(state),
    () => selector(state)
  );
}

export function getState() {
  return state;
}

export function applyTheme(theme: Settings["theme"]) {
  const el = document.documentElement;
  el.classList.remove("dark", "light");
  el.classList.add(theme);
  const meta = document.querySelector('meta[name="theme-color"]');
  meta?.setAttribute("content", theme === "dark" ? "#0B0B0C" : "#F6F5F2");
}

/* ───────────────────────── Timer engine ───────────────────────── */

const dur = (mode: Mode, s: Settings) => (mode === "focus" ? s.focus : mode === "short" ? s.short : s.long) * 60;

function idleTimer(mode: Mode, patch: Partial<TimerState> = {}): TimerState {
  const total = dur(mode, state.settings);
  return { ...state.timer, mode, status: "idle", total, remaining: total, endsAt: 0, pauses: 0, now: Date.now(), ...patch };
}

function toast(msg: string) {
  set({ toast: { id: Date.now(), msg } }, false);
}

function recordSession(minutes: number, score: number): Completion {
  const prevLevel = levelInfo(state.xp).level;
  const xp = minutes * 2 + (score >= 90 ? 10 : 0);
  const coins = minutes + (score >= 95 ? 5 : 0);
  const task = state.tasks.find((t) => t.id === state.activeTaskId);
  const session: Session = {
    id: `s${Date.now()}`,
    ts: Date.now(),
    minutes,
    tag: task?.tag ?? "Study",
    task: task?.title,
    score,
  };
  const tasks = task ? state.tasks.map((t) => (t.id === task.id ? { ...t, done: t.done + 1 } : t)) : state.tasks;
  const newXp = state.xp + xp;
  set({
    sessions: [...state.sessions, session],
    tasks,
    xp: newXp,
    coins: state.coins + coins,
    pet: { ...state.pet, bond: state.pet.bond + minutes },
    celebrateAt: Date.now(),
  });
  return { id: session.id, mode: "focus", minutes, xp, coins, score, task: task?.title, levelUp: levelInfo(newXp).level > prevLevel, at: Date.now() };
}

function complete() {
  const t = state.timer;
  if (t.mode === "focus") {
    const minutes = Math.round(t.total / 60);
    const score = Math.max(58, Math.min(100, 100 - t.pauses * 7 - (minutes < 20 ? 4 : 0) + (minutes >= 45 ? 3 : 0)));
    const completion = recordSession(minutes, score);
    const cycle = t.cycle + 1;
    const next: Mode = cycle % 4 === 0 ? "long" : "short";
    const total = dur(next, state.settings);
    set({ completion, timer: { ...t, mode: next, status: "idle", total, remaining: total, endsAt: 0, pauses: 0, cycle, now: Date.now() } });
    if (state.settings.autoBreak) A.start();
  } else {
    const total = dur("focus", state.settings);
    set({
      completion: { id: `b${Date.now()}`, mode: t.mode, minutes: Math.round(t.total / 60), xp: 0, coins: 0, score: 0, levelUp: false, at: Date.now() },
      timer: { ...t, mode: "focus", status: "idle", total, remaining: total, endsAt: 0, pauses: 0, now: Date.now() },
    });
  }
  if (state.settings.chime) playChime();
}

export const A = {
  start() {
    const t = state.timer;
    if (t.status === "running") return;
    const now = Date.now();
    set({ completion: null, timer: { ...t, status: "running", endsAt: now + t.remaining * 1000, now } });
  },
  pause() {
    const t = state.timer;
    if (t.status !== "running") return;
    const remaining = Math.max(1, Math.ceil((t.endsAt - Date.now()) / 1000));
    set({ timer: { ...t, status: "paused", remaining, endsAt: 0, pauses: t.pauses + 1, now: Date.now() } });
  },
  toggle() {
    if (state.timer.status === "running") A.pause();
    else A.start();
  },
  reset() {
    set({ timer: idleTimer(state.timer.mode), completion: null });
  },
  setMode(mode: Mode) {
    set({ timer: idleTimer(mode), completion: null });
  },
  setLength(minutes: number) {
    if (state.timer.status === "running") return;
    const total = minutes * 60;
    set({ timer: { ...state.timer, total, remaining: total, status: "idle", pauses: 0, now: Date.now() } });
  },
  skip() {
    const t = state.timer;
    const next: Mode = t.mode === "focus" ? ((t.cycle + 1) % 4 === 0 ? "long" : "short") : "focus";
    set({ timer: idleTimer(next, { cycle: t.mode === "focus" ? t.cycle + 1 : t.cycle }), completion: null });
  },
  finishEarly() {
    const t = state.timer;
    if (t.mode !== "focus") return A.skip();
    const left = t.status === "running" ? Math.ceil((t.endsAt - Date.now()) / 1000) : t.remaining;
    const minutes = Math.floor((t.total - left) / 60);
    if (minutes < 1) {
      toast("Under a minute — nothing to save yet.");
      return A.reset();
    }
    const completion = recordSession(minutes, Math.max(55, 84 - t.pauses * 6));
    set({ completion, timer: idleTimer("short", { cycle: t.cycle + 1 }) });
  },
  dismissCompletion() {
    set({ completion: null }, false);
  },
  toast,

  /* tasks */
  addTask(title: string, tag: string, priority: Task["priority"], est: number) {
    const task: Task = { id: `t${Date.now()}`, title, tag, priority, est, done: 0, completed: false, createdAt: Date.now() };
    set({ tasks: [task, ...state.tasks], activeTaskId: state.activeTaskId ?? task.id });
    return task.id;
  },
  toggleTask(id: string) {
    set({ tasks: state.tasks.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t)) });
    const t = state.tasks.find((x) => x.id === id);
    if (t?.completed && state.activeTaskId === id) set({ activeTaskId: null });
  },
  removeTask(id: string) {
    set({ tasks: state.tasks.filter((t) => t.id !== id), activeTaskId: state.activeTaskId === id ? null : state.activeTaskId });
  },
  setActiveTask(id: string | null) {
    set({ activeTaskId: id });
  },

  /* habits */
  addHabit(name: string, note: string) {
    set({ habits: [...state.habits, { id: `h${Date.now()}`, name, note, log: [] }] });
  },
  toggleHabit(id: string, key: string) {
    set({
      habits: state.habits.map((h) => (h.id === id ? { ...h, log: h.log.includes(key) ? h.log.filter((k) => k !== key) : [...h.log, key] } : h)),
    });
  },
  removeHabit(id: string) {
    set({ habits: state.habits.filter((h) => h.id !== id) });
  },

  /* missions */
  claim(id: string, coins: number, xp: number) {
    const k = dayKey(Date.now());
    const list = state.claimed[k] ?? [];
    if (list.includes(id)) return;
    set({ claimed: { ...state.claimed, [k]: [...list, id] }, coins: state.coins + coins, xp: state.xp + xp });
    toast(`Claimed ${coins} coins and ${xp} XP`);
  },

  /* pets */
  selectPet(key: string) {
    const def = PET_CATALOG.find((p) => p.key === key);
    if (!def || !state.pet.owned.includes(key)) return;
    set({ pet: { ...state.pet, species: def.species, variant: def.variant } });
  },
  adopt(key: string) {
    const def = PET_CATALOG.find((p) => p.key === key);
    if (!def || state.pet.owned.includes(key)) return false;
    if (state.coins < def.price) {
      toast(`You need ${def.price - state.coins} more coins`);
      return false;
    }
    set({ coins: state.coins - def.price, pet: { ...state.pet, owned: [...state.pet.owned, key], species: def.species, variant: def.variant } });
    toast(`${def.label} joined you`);
    return true;
  },
  renamePet(name: string) {
    set({ pet: { ...state.pet, name: name.trim().slice(0, 14) || state.pet.name } });
  },
  feed() {
    if (Date.now() - state.pet.fedAt < 60_000) {
      toast(`${state.pet.name} isn't hungry yet`);
      return;
    }
    if (state.coins < 5) {
      toast("Feeding costs 5 coins");
      return;
    }
    set({ coins: state.coins - 5, pet: { ...state.pet, fedAt: Date.now(), bond: state.pet.bond + 3 }, celebrateAt: Date.now() });
    toast(`${state.pet.name} loved that. +3 bond`);
  },
  celebrate() {
    set({ celebrateAt: Date.now() }, false);
  },

  /* settings */
  updateSettings(patch: Partial<Settings>) {
    const settings = { ...state.settings, ...patch };
    const timerPatch: Partial<AppState> = {};
    if (state.timer.status === "idle") {
      const total = dur(state.timer.mode, settings);
      timerPatch.timer = { ...state.timer, total, remaining: total };
    }
    set({ settings, ...timerPatch });
    if (patch.theme) applyTheme(patch.theme);
  },
  resetAll() {
    localStorage.removeItem(KEY);
    state = createInitial();
    applyTheme(state.settings.theme);
    emit(false);
  },
};

/* ───────────────────────── Ticker ───────────────────────── */

function tick() {
  const t = state.timer;
  if (t.status !== "running") return;
  const now = Date.now();
  const remaining = Math.ceil((t.endsAt - now) / 1000);
  if (remaining <= 0) {
    complete();
    return;
  }
  if (remaining !== t.remaining) set({ timer: { ...t, remaining, now } }, false);
}

if (typeof window !== "undefined") {
  window.setInterval(tick, 250);
  document.addEventListener("visibilitychange", tick);
  applyTheme(state.settings.theme);
  window.addEventListener("beforeunload", persist);
  // A session that ended while the tab was closed
  if (state.timer.status === "running") {
    window.setTimeout(tick, 0);
  }
}

/* ───────────────────────── Selectors ───────────────────────── */

export function todayMinutes(sessions: Session[]): number {
  const k = dayKey(Date.now());
  return sessions.filter((s) => dayKey(s.ts) === k).reduce((a, s) => a + s.minutes, 0);
}

export { TAGS };
