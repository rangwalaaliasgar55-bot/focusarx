import { useEffect, useMemo, useState } from "react";
import type { PetMood } from "./components/Pet3D";
import { useStore } from "./store";

export function useNow(ms = 1000): number {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(id);
  }, [ms]);
  return now;
}

export function usePetMood(): PetMood {
  const status = useStore((s) => s.timer.status);
  const mode = useStore((s) => s.timer.mode);
  if (status === "running" || status === "paused") {
    if (mode === "focus") return status === "running" ? "focus" : "idle";
    return "break";
  }
  const h = new Date().getHours();
  return h >= 23 || h < 5 ? "sleep" : "idle";
}

const IDLE_LINES = [
  "Ready when you are. One session is plenty to start.",
  "Pick one task. I'll keep the seat warm.",
  "No pressure. Press start whenever.",
  "Small sessions count. So do you.",
];
const FOCUS_LINES: [number, string][] = [
  [0, "Headphones on. Just the first few minutes now."],
  [0.2, "The hard part is the start. You're past it."],
  [0.4, "Steady. I'm not going anywhere."],
  [0.6, "More than halfway. Keep your eyes on one thing."],
  [0.8, "Nearly there. Finish the sentence, then rest."],
];
const BREAK_LINES = ["Stand up. Look at something far away.", "Water, then stretch. I'll hop for both of us.", "Let your mind wander for a bit."];

export function usePetLine(): string {
  const timer = useStore((s) => s.timer);
  const name = useStore((s) => s.pet.name);
  const completion = useStore((s) => s.completion);
  return useMemo(() => {
    if (completion && completion.mode === "focus") return completion.levelUp ? `Level up! That was a great session, ${name} is proud.` : `Session saved. ${completion.minutes} minutes of real work.`;
    if (timer.status === "idle" && timer.mode !== "focus") return BREAK_LINES[timer.cycle % BREAK_LINES.length];
    if (timer.mode !== "focus") return BREAK_LINES[timer.cycle % BREAK_LINES.length];
    if (timer.status === "idle") return IDLE_LINES[(timer.cycle + new Date().getDate()) % IDLE_LINES.length];
    const p = 1 - timer.remaining / timer.total;
    let line = FOCUS_LINES[0][1];
    for (const [t, l] of FOCUS_LINES) if (p >= t) line = l;
    if (timer.status === "paused") return "Paused. Take a breath, then pick it back up.";
    return line;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timer.status, timer.mode, timer.cycle, Math.floor(((1 - timer.remaining / timer.total) * 100) / 20), completion?.id, name]);
}
