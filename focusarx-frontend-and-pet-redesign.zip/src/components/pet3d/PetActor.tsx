import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { Species } from "../../lib/pets";
import { ProceduralBody, SpriteBody, type PetState } from "./bodies";
import { shadowTexture } from "./fx";

export type { PetState } from "./bodies";

interface Props {
  species: Species;
  state: PetState;
  /** 1 = faces right, -1 = faces left, 0 = faces camera */
  facing?: 0 | 1 | -1;
  position?: [number, number, number];
  scale?: number;
  look?: boolean;
  /** change to retrigger the same state (e.g. two attacks in a row) */
  stateKey?: number;
  lunge?: number;
  onPoke?: () => void;
}

const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const easeOut = (x: number) => 1 - (1 - x) ** 3;
const easeInOut = (x: number) => (x < 0.5 ? 2 * x * x : 1 - (-2 * x + 2) ** 2 / 2);

export function PetActor({ species, state, facing = 0, position = [0, 0, 0], scale = 1, look = true, stateKey = 0, lunge = 1.7, onPoke }: Props) {
  const motion = useRef<THREE.Group>(null);
  const root = useRef<THREE.Group>(null);
  const shadow = useRef<THREE.Mesh>(null);
  const startT = useRef(0);
  const prevKey = useRef("");
  const rig = useRef({ y: 0, sx: 1, sy: 1, rz: 0, rx: 0, x: 0, lookY: 0, lookX: 0 });
  const flashActive = useRef(false);
  const phase = useMemo(() => Math.random() * 10, []);
  const shTex = useMemo(() => shadowTexture(), []);
  const f = facing || 1;
  const isSprite = species.kind === "pokemon";
  const mirror = isSprite && facing === 1;
  const baseYaw = isSprite ? facing * 0.28 : facing * 0.72;

  useFrame((s, dt) => {
    const m = motion.current;
    const r = rig.current;
    if (!m || !root.current) return;
    const t = s.clock.elapsedTime;
    const key = `${state}:${stateKey}`;
    if (prevKey.current !== key) {
      prevKey.current = key;
      startT.current = t;
    }
    const st = t - startT.current;
    let mode: PetState = state;
    if ((state === "happy" || state === "eat") && st > 2.4) mode = "idle";

    let ty = 0;
    let sx = 1;
    let sy = 1;
    let rz = 0;
    let rx = 0;
    let tx = 0;
    let ry = 0;
    let flash = 0;
    let k = 12;
    const br = Math.sin(t * 2.1 + phase);

    switch (mode) {
      case "idle": {
        sy = 1 + br * 0.018;
        sx = 1 - br * 0.01;
        rz = Math.sin(t * 0.8 + phase) * 0.03;
        const c = (t + phase) % 6.5;
        if (c < 0.6) {
          const u = c / 0.6;
          ty = Math.sin(u * Math.PI) * 0.2;
          sy *= 1 + 0.05 * Math.sin(u * Math.PI);
        }
        break;
      }
      case "focus": {
        ty = Math.abs(Math.sin(t * 5)) * 0.03;
        rz = Math.sin(t * 2.5) * 0.025;
        rx = 0.07;
        sy = 1 + Math.sin(t * 5) * 0.012;
        break;
      }
      case "break": {
        const j = Math.abs(Math.sin(t * 3.2));
        ty = j * 0.14;
        rz = Math.sin(t * 1.6) * 0.14;
        ry = Math.sin(t * 1.6) * 0.4;
        sy = 0.97 + j * 0.06;
        break;
      }
      case "sleep": {
        const b = Math.sin(t * 1.1 + phase);
        sy = 1 + b * 0.035;
        sx = 1 - b * 0.018;
        rz = 0.15;
        ty = -0.03;
        break;
      }
      case "celebrate": {
        k = 26;
        const j = Math.abs(Math.sin(st * 5.2));
        ty = j * 0.75;
        sy = 0.9 + j * 0.2;
        sx = 1.08 - j * 0.12;
        ry = st < 1 ? easeOut(st) * Math.PI * 2 : Math.sin(st * 3) * 0.3;
        rz = Math.sin(st * 5.2) * 0.06;
        break;
      }
      case "attack": {
        k = 40;
        if (st < 0.18) tx = -f * 0.3 * (st / 0.18);
        else if (st < 0.36) {
          tx = THREE.MathUtils.lerp(-f * 0.3, f * lunge, easeOut((st - 0.18) / 0.18));
          sx = 1.12;
          sy = 0.94;
        } else tx = f * lunge * (1 - easeInOut(clamp((st - 0.36) / 0.44)));
        ty = Math.sin(clamp(st / 0.6) * Math.PI) * 0.22;
        break;
      }
      case "hurt": {
        k = 38;
        tx = -f * 0.5 * Math.exp(-st * 5);
        rz = Math.sin(st * 40) * 0.1 * Math.exp(-st * 4);
        sy = 1 - 0.1 * Math.exp(-st * 6);
        sx = 1 + 0.08 * Math.exp(-st * 6);
        flash = Math.max(0, 1 - st * 2.2) * (0.55 + 0.45 * Math.sin(st * 42));
        break;
      }
      case "faint": {
        k = 10;
        const e = easeOut(clamp(st / 0.7));
        rz = f * 1.45 * e;
        ty = -0.12 * e;
        tx = -f * 0.3 * e;
        break;
      }
      case "happy": {
        k = 24;
        const j = Math.abs(Math.sin(st * 7.5)) * Math.exp(-st * 0.9);
        ty = j * 0.6;
        sy = 0.93 + j * 0.18;
        sx = 1.05 - j * 0.1;
        rz = Math.sin(st * 15) * 0.08 * Math.exp(-st * 1.2);
        break;
      }
      case "eat": {
        k = 22;
        sy = 1 + Math.sin(st * 14) * 0.06;
        sx = 1 - Math.sin(st * 14) * 0.035;
        ty = Math.abs(Math.sin(st * 7)) * 0.05;
        rz = Math.sin(st * 7) * 0.05;
        break;
      }
    }

    r.y = THREE.MathUtils.damp(r.y, ty, k, dt);
    r.sx = THREE.MathUtils.damp(r.sx, sx, k, dt);
    r.sy = THREE.MathUtils.damp(r.sy, sy, k, dt);
    r.rz = THREE.MathUtils.damp(r.rz, rz, k, dt);
    r.rx = THREE.MathUtils.damp(r.rx, rx, k, dt);
    r.x = THREE.MathUtils.damp(r.x, tx, k, dt);

    const canLook = look && mode !== "sleep" && mode !== "faint" && mode !== "attack" && mode !== "hurt";
    r.lookY = THREE.MathUtils.damp(r.lookY, canLook ? s.pointer.x * (isSprite ? 0.55 : 0.2) : 0, 5, dt);
    r.lookX = THREE.MathUtils.damp(r.lookX, canLook ? -s.pointer.y * 0.1 : 0, 5, dt);

    m.position.set(r.x, r.y, 0);
    m.scale.set(r.sx * (mirror ? -1 : 1), r.sy, r.sx);
    m.rotation.set(r.rx + r.lookX, baseYaw + r.lookY + ry, r.rz);

    /* hit flash */
    if (flash > 0 || flashActive.current) {
      flashActive.current = flash > 0;
      m.traverse((o) => {
        const mesh = o as THREE.Mesh;
        if (!mesh.isMesh) return;
        const mat = mesh.material as THREE.Material & { emissive?: THREE.Color; color?: THREE.Color };
        if (mat.emissive) mat.emissive.setRGB(flash * 0.95, flash * 0.12, flash * 0.12);
        else if (mesh.renderOrder === 5 && mat.color) mat.color.setRGB(1, 1 - flash * 0.65, 1 - flash * 0.65);
      });
    }

    const sh = shadow.current;
    if (sh) {
      const w = (isSprite ? (species.scale ?? 2) * 0.46 : 0.95) * (1 - Math.min(0.5, r.y * 0.35));
      sh.scale.set(w * 2, w * 2, 1);
      sh.position.x = r.x;
      (sh.material as THREE.MeshBasicMaterial).opacity = Math.max(0.2, 0.85 - r.y * 0.6);
    }
  });

  return (
    <group ref={root} position={position} scale={scale} onClick={onPoke}>
      <mesh ref={shadow} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.012, 0]}>
        <planeGeometry args={[1, 1]} />
        <meshBasicMaterial map={shTex} transparent depthWrite={false} opacity={0.8} />
      </mesh>
      <group ref={motion}>
        {isSprite ? (
          <SpriteBody species={species} state={state} />
        ) : (
          <ProceduralBody params={species.body!} id={species.id} state={state} look={look} />
        )}
      </group>
    </group>
  );
}
