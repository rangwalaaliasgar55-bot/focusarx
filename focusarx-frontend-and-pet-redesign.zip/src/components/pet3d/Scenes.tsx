import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import type { Species } from "../../lib/pets";
import { useApp } from "../../lib/store";
import { PetActor, type PetState } from "./PetActor";
import { Burst, Projectile, Ring, type Shot } from "./fx";

function Lights({ accent, light }: { accent: string; light: boolean }) {
  return (
    <>
      <hemisphereLight args={["#ffffff", light ? "#cfc9bd" : "#6a6a7c", light ? 1.2 : 1.0]} />
      <directionalLight position={[3.5, 6, 5]} intensity={light ? 2.4 : 2.7} />
      <directionalLight position={[-5, 3, -4]} intensity={1.3} color={accent} />
      <pointLight position={[0, 1.5, 3.5]} intensity={8} distance={9} color="#fff4e6" />
    </>
  );
}

function Pad({ position, radius = 1.6, color, ring }: { position: [number, number, number]; radius?: number; color: string; ring: string }) {
  return (
    <group position={position}>
      <mesh position={[0, -0.06, 0]}>
        <cylinderGeometry args={[radius, radius + 0.06, 0.12, 64]} />
        <meshStandardMaterial color={color} roughness={0.85} />
      </mesh>
      <mesh position={[0, 0.004, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[radius - 0.16, radius - 0.12, 64]} />
        <meshBasicMaterial color={ring} transparent opacity={0.9} />
      </mesh>
    </group>
  );
}

function usePalette() {
  const theme = useApp((s) => s.settings.theme);
  const accent = useApp((s) => s.settings.accent);
  const light = theme === "light";
  return { light, accent, floor: light ? "#dcd8cf" : "#202026" };
}

/* ------------------------------ companion stage ------------------------------ */

interface StageProps {
  species: Species;
  state: PetState;
  stateKey?: number;
  burst?: number;
  onPoke?: () => void;
  className?: string;
  scale?: number;
  platform?: boolean;
}

export function PetStage({ species, state, stateKey, burst = 0, onPoke, className, scale = 1, platform = true }: StageProps) {
  const { light, accent, floor } = usePalette();
  return (
    <div className={className}>
      <Canvas
        dpr={[1, 2]}
        camera={{ position: [0, 1.55, 6.8], fov: 30 }}
        gl={{ alpha: true, antialias: true }}
        onCreated={({ camera }) => camera.lookAt(0, 1.05, 0)}
      >
        <Lights accent={accent} light={light} />
        {platform && <Pad position={[0, 0, 0]} radius={1.55} color={floor} ring={accent} />}
        <Suspense fallback={null}>
          <PetActor species={species} state={state} stateKey={stateKey} scale={scale} onPoke={onPoke} />
        </Suspense>
        <Burst trigger={burst} position={[0, 0.6, 0]} colors={["#ffd166", "#ef476f", "#06d6a0", "#4cc9f0", "#f8f9fa", accent]} count={90} power={1.5} gravity={4.5} life={1.9} size={0.22} />
      </Canvas>
    </div>
  );
}

/* ------------------------------ battle arena ------------------------------ */

export interface Impact {
  key: number;
  side: "player" | "foe";
  color: string;
  kind: "hit" | "heal" | "guard";
}

interface ArenaProps {
  player: Species;
  foe: Species;
  playerState: PetState;
  foeState: PetState;
  playerKey: number;
  foeKey: number;
  shot: Shot | null;
  impact: Impact | null;
  className?: string;
  compact?: boolean;
}

export const ARENA_POS = {
  player: [-2.3, 0, 0.9] as [number, number, number],
  foe: [2.3, 0, -0.7] as [number, number, number],
};

export function ArenaScene({ player, foe, playerState, foeState, playerKey, foeKey, shot, impact, className, compact }: ArenaProps) {
  const { light, accent, floor } = usePalette();
  const pp = ARENA_POS.player;
  const fp = ARENA_POS.foe;
  const mid = (side: "player" | "foe"): [number, number, number] => (side === "player" ? [pp[0], 0.9, pp[2]] : [fp[0], 0.9, fp[2]]);
  const hitColor = impact?.color ?? "#fff";
  return (
    <div className={className}>
      <Canvas
        dpr={[1, 2]}
        camera={{ position: [0, compact ? 2.5 : 3.1, compact ? 9.2 : 8.6], fov: 34 }}
        gl={{ alpha: true, antialias: true }}
        onCreated={({ camera }) => camera.lookAt(0, 1.05, 0)}
      >
        <Lights accent={accent} light={light} />
        {/* ground */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.13, 0]}>
          <circleGeometry args={[7.5, 80]} />
          <meshStandardMaterial color={light ? "#e6e2d9" : "#16161a"} roughness={1} />
        </mesh>
        {[3.6, 5.2, 6.8].map((r) => (
          <mesh key={r} rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.12, 0]}>
            <ringGeometry args={[r, r + 0.015, 96]} />
            <meshBasicMaterial color={accent} transparent opacity={0.16} />
          </mesh>
        ))}
        <Pad position={[pp[0], 0, pp[2]]} radius={1.45} color={floor} ring={accent} />
        <Pad position={[fp[0], 0, fp[2]]} radius={1.35} color={floor} ring="#f2646a" />

        <Suspense fallback={null}>
          <PetActor species={player} state={playerState} stateKey={playerKey} facing={1} position={pp} scale={1.1} look={false} lunge={3.2} />
          <PetActor species={foe} state={foeState} stateKey={foeKey} facing={-1} position={fp} scale={1} look={false} lunge={3.2} />
        </Suspense>

        <Projectile shot={shot} />
        <Burst
          trigger={impact?.side === "foe" ? impact.key : 0}
          position={mid("foe")}
          color={hitColor}
          count={impact?.kind === "heal" ? 30 : 56}
          power={impact?.kind === "heal" ? 0.7 : 1.3}
          gravity={impact?.kind === "heal" ? -1 : 6}
        />
        <Burst
          trigger={impact?.side === "player" ? impact.key : 0}
          position={mid("player")}
          color={hitColor}
          count={impact?.kind === "heal" ? 30 : 56}
          power={impact?.kind === "heal" ? 0.7 : 1.3}
          gravity={impact?.kind === "heal" ? -1 : 6}
        />
        <Ring trigger={impact && impact.kind !== "hit" && impact.side === "player" ? impact.key : 0} position={[pp[0], 0.05, pp[2]]} color={hitColor} />
        <Ring trigger={impact && impact.kind !== "hit" && impact.side === "foe" ? impact.key : 0} position={[fp[0], 0.05, fp[2]]} color={hitColor} />
      </Canvas>
    </div>
  );
}
