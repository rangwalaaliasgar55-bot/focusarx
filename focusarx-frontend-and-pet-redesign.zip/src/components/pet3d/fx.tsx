import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { Move } from "../../lib/pets";

/* ------------------------------ textures ------------------------------ */

let dot: THREE.Texture | null = null;
export function dotTexture() {
  if (dot) return dot;
  const c = document.createElement("canvas");
  c.width = c.height = 64;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, "rgba(255,255,255,1)");
  grd.addColorStop(0.45, "rgba(255,255,255,0.85)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  dot = new THREE.CanvasTexture(c);
  return dot;
}

const texCache = new Map<string, Promise<THREE.Texture>>();
export function loadTex(url: string): Promise<THREE.Texture> {
  let p = texCache.get(url);
  if (!p) {
    p = new Promise((res, rej) => {
      const l = new THREE.TextureLoader();
      l.setCrossOrigin("anonymous");
      l.load(
        url,
        (t) => {
          t.colorSpace = THREE.SRGBColorSpace;
          t.anisotropy = 8;
          res(t);
        },
        undefined,
        (e) => rej(e),
      );
    });
    texCache.set(url, p);
  }
  return p;
}

/* ------------------------------ shadow ------------------------------ */

let shadowTex: THREE.Texture | null = null;
export function shadowTexture() {
  if (shadowTex) return shadowTex;
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  grd.addColorStop(0, "rgba(0,0,0,0.65)");
  grd.addColorStop(0.55, "rgba(0,0,0,0.28)");
  grd.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, 128, 128);
  shadowTex = new THREE.CanvasTexture(c);
  return shadowTex;
}

/* ------------------------------ particle burst ------------------------------ */

interface BurstProps {
  trigger: number;
  position?: [number, number, number];
  color?: string;
  colors?: string[];
  count?: number;
  power?: number;
  gravity?: number;
  life?: number;
  size?: number;
}

export function Burst({ trigger, position = [0, 1, 0], color = "#ffffff", colors, count = 40, power = 1, gravity = 5, life = 1.1, size = 0.2 }: BurstProps) {
  const ref = useRef<THREE.Points>(null);
  const data = useMemo(
    () => ({ pos: new Float32Array(count * 3), vel: new Float32Array(count * 3), col: new Float32Array(count * 3), age: 99 }),
    [count],
  );
  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(data.pos, 3));
    g.setAttribute("color", new THREE.BufferAttribute(data.col, 3));
    return g;
  }, [data]);
  const tex = useMemo(() => dotTexture(), []);
  const palette = (colors && colors.length ? colors : [color]).join(",");

  useEffect(() => {
    if (!trigger) return;
    const list = palette.split(",").map((c) => new THREE.Color(c));
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const u = Math.random() * 0.9 + 0.1;
      const sp = (1.2 + Math.random() * 2.4) * power;
      data.pos[i * 3] = 0;
      data.pos[i * 3 + 1] = 0;
      data.pos[i * 3 + 2] = 0;
      data.vel[i * 3] = Math.cos(a) * sp * u;
      data.vel[i * 3 + 1] = (0.8 + Math.random() * 2.2) * power;
      data.vel[i * 3 + 2] = Math.sin(a) * sp * u * 0.6;
      const c = list[i % list.length];
      data.col[i * 3] = c.r;
      data.col[i * 3 + 1] = c.g;
      data.col[i * 3 + 2] = c.b;
    }
    (geo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
    data.age = 0;
  }, [trigger, count, power, palette, data, geo]);

  useFrame((_, dt) => {
    const pts = ref.current;
    if (!pts) return;
    const mat = pts.material as THREE.PointsMaterial;
    if (data.age > life) {
      mat.opacity = 0;
      return;
    }
    data.age += Math.min(dt, 0.05);
    for (let i = 0; i < count; i++) {
      data.vel[i * 3 + 1] -= gravity * dt;
      data.pos[i * 3] += data.vel[i * 3] * dt;
      data.pos[i * 3 + 1] += data.vel[i * 3 + 1] * dt;
      data.pos[i * 3 + 2] += data.vel[i * 3 + 2] * dt;
    }
    (geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    mat.opacity = Math.max(0, 1 - data.age / life);
  });

  return (
    <points ref={ref} geometry={geo} position={position} frustumCulled={false}>
      <pointsMaterial size={size} map={tex} vertexColors transparent depthWrite={false} opacity={0} sizeAttenuation blending={THREE.AdditiveBlending} />
    </points>
  );
}

/* ------------------------------ projectile ------------------------------ */

export interface Shot {
  id: number;
  from: [number, number, number];
  to: [number, number, number];
  color: string;
  fx: Move["fx"];
}

const TRAIL = 7;

export function Projectile({ shot, duration = 0.42 }: { shot: Shot | null; duration?: number }) {
  const group = useRef<THREE.Group>(null);
  const start = useRef(0);
  const last = useRef(0);
  const meshes = useRef<(THREE.Mesh | null)[]>([]);

  useFrame((s) => {
    const g = group.current;
    if (!g) return;
    if (!shot) {
      g.visible = false;
      return;
    }
    if (last.current !== shot.id) {
      last.current = shot.id;
      start.current = s.clock.elapsedTime;
    }
    const prog = (s.clock.elapsedTime - start.current) / duration;
    if (prog > 1.15) {
      g.visible = false;
      return;
    }
    g.visible = true;
    const big = shot.fx === "burst" || shot.fx === "rock" || shot.fx === "flame";
    for (let i = 0; i < TRAIL; i++) {
      const m = meshes.current[i];
      if (!m) continue;
      const k = Math.min(1, Math.max(0, prog - i * 0.035));
      const ease = k * k * (3 - 2 * k);
      m.position.set(
        THREE.MathUtils.lerp(shot.from[0], shot.to[0], ease),
        THREE.MathUtils.lerp(shot.from[1], shot.to[1], ease) + Math.sin(k * Math.PI) * 0.7,
        THREE.MathUtils.lerp(shot.from[2], shot.to[2], ease),
      );
      const sc = (big ? 0.42 : 0.3) * (1 - i / (TRAIL + 1)) * (prog > 1 ? Math.max(0, 1 - (prog - 1) * 6) : 1);
      m.scale.setScalar(Math.max(0.001, sc));
      m.rotation.set(prog * 9 + i, prog * 7, 0);
      if (shot.fx === "bolt") m.scale.set(sc * 0.5, sc * 1.8, sc * 0.5);
      (m.material as THREE.MeshBasicMaterial).color.set(shot.color);
    }
  });

  const shape = shot?.fx === "bolt" || shot?.fx === "rock" || shot?.fx === "leaf" || shot?.fx === "ice" ? "oct" : "sphere";
  return (
    <group ref={group} visible={false}>
      {Array.from({ length: TRAIL }).map((_, i) => (
        <mesh
          key={i}
          ref={(el) => {
            meshes.current[i] = el;
          }}
        >
          {shape === "oct" ? <octahedronGeometry args={[1, 0]} /> : <sphereGeometry args={[1, 16, 12]} />}
          <meshBasicMaterial color="#ffffff" transparent opacity={1 - i * 0.12} blending={THREE.AdditiveBlending} depthWrite={false} />
        </mesh>
      ))}
    </group>
  );
}

/* expanding ring pulse (heal / guard / level up) */
export function Ring({ trigger, position, color = "#6ee7a8" }: { trigger: number; position: [number, number, number]; color?: string }) {
  const ref = useRef<THREE.Mesh>(null);
  const t0 = useRef(-10);
  const seen = useRef(0);
  useFrame((s) => {
    const m = ref.current;
    if (!m) return;
    if (trigger && seen.current !== trigger) {
      seen.current = trigger;
      t0.current = s.clock.elapsedTime;
    }
    const k = (s.clock.elapsedTime - t0.current) / 0.8;
    if (k < 0 || k > 1) {
      m.visible = false;
      return;
    }
    m.visible = true;
    const sc = 0.4 + k * 1.8;
    m.scale.set(sc, sc, sc);
    (m.material as THREE.MeshBasicMaterial).opacity = (1 - k) * 0.9;
  });
  return (
    <mesh ref={ref} position={position} rotation={[-Math.PI / 2, 0, 0]} visible={false}>
      <torusGeometry args={[1, 0.035, 8, 48]} />
      <meshBasicMaterial color={color} transparent depthWrite={false} blending={THREE.AdditiveBlending} />
    </mesh>
  );
}
