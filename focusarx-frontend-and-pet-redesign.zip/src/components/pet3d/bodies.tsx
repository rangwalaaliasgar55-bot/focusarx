import { useEffect, useMemo, useRef, useState } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { artworkUrl, type BodyParams, type Species } from "../../lib/pets";
import { loadTex } from "./fx";

export type PetState = "idle" | "focus" | "break" | "celebrate" | "sleep" | "attack" | "hurt" | "faint" | "happy" | "eat";

/* ------------------------------ helpers ------------------------------ */

function Fur({ color, rough = 0.9 }: { color: string; rough?: number }) {
  const sheen = useMemo(() => new THREE.Color(color).lerp(new THREE.Color("#ffffff"), 0.5), [color]);
  return <meshPhysicalMaterial color={color} roughness={rough} sheen={1} sheenRoughness={0.55} sheenColor={sheen} />;
}

type V3 = [number, number, number];

function Ball({ p = [0, 0, 0], r, s = [1, 1, 1], color, rot = [0, 0, 0] }: { p?: V3; r: number; s?: V3; color: string; rot?: V3 }) {
  return (
    <mesh position={p} scale={s} rotation={rot}>
      <sphereGeometry args={[r, 32, 24]} />
      <Fur color={color} />
    </mesh>
  );
}

function darken(c: string, a: number) {
  return `#${new THREE.Color(c).lerp(new THREE.Color("#000000"), a).getHexString()}`;
}

/* ------------------------------ procedural creature ------------------------------ */

interface ProcProps {
  params: BodyParams;
  id: string;
  state: PetState;
  look: boolean;
}

export function ProceduralBody({ params, id, state, look }: ProcProps) {
  const head = useRef<THREE.Group>(null);
  const eyes = useRef<THREE.Group>(null);
  const tail = useRef<THREE.Group>(null);
  const wingL = useRef<THREE.Group>(null);
  const wingR = useRef<THREE.Group>(null);
  const earL = useRef<THREE.Group>(null);
  const earR = useRef<THREE.Group>(null);
  const blinkOffset = useMemo(() => Math.random() * 4, []);

  const { body, belly, patch, ears, tail: tailKind, beak, wings, snout, horns, squish = 1 } = params;
  const isPanda = id === "bamboo";
  const isOwl = id === "hoot";
  const limbColor = isPanda && patch ? patch : body;
  const earColor = isPanda && patch ? patch : body;
  const wingColor = isOwl ? darken(body, 0.18) : id === "drake" ? darken(body, 0.12) : body;

  useFrame((s, dt) => {
    const t = s.clock.elapsedTime;
    const sleeping = state === "sleep" || state === "faint";
    const h = head.current;
    if (h) {
      const px = look && !sleeping ? s.pointer.x * 0.6 : 0;
      const py = look && !sleeping ? -s.pointer.y * 0.28 : 0;
      const tx = sleeping ? 0.42 : state === "focus" ? 0.16 + py * 0.3 : py;
      h.rotation.y = THREE.MathUtils.damp(h.rotation.y, px, 6, dt);
      h.rotation.x = THREE.MathUtils.damp(h.rotation.x, tx, 6, dt);
      h.rotation.z = THREE.MathUtils.damp(h.rotation.z, sleeping ? 0.14 : state === "break" ? Math.sin(t * 3) * 0.1 : 0, 6, dt);
    }
    const e = eyes.current;
    if (e) {
      const c = (t * 0.9 + blinkOffset) % 4;
      const blink = c < 0.13 ? 0.08 : 1;
      const target = sleeping ? 0.07 : state === "hurt" ? 0.3 : blink;
      e.scale.y = THREE.MathUtils.damp(e.scale.y, target, 30, dt);
    }
    const tl = tail.current;
    if (tl) {
      const speed = state === "celebrate" || state === "break" || state === "happy" ? 11 : state === "focus" ? 4 : 2.4;
      tl.rotation.y = Math.sin(t * speed) * (state === "sleep" ? 0.05 : 0.45);
    }
    const flap = state === "celebrate" ? 0.55 : state === "focus" ? 0.12 : state === "break" ? 0.3 : 0.05;
    const f = Math.sin(t * (state === "celebrate" ? 16 : 5)) * flap;
    if (wingL.current) wingL.current.rotation.z = -0.25 - f;
    if (wingR.current) wingR.current.rotation.z = 0.25 + f;
    const tw = Math.sin(t * 7) > 0.97 ? 0.3 : 0;
    if (earL.current) earL.current.rotation.z = THREE.MathUtils.damp(earL.current.rotation.z, 0.12 + tw, 14, dt);
    if (earR.current) earR.current.rotation.z = THREE.MathUtils.damp(earR.current.rotation.z, -0.12, 14, dt);
  });

  const eyeSz = isOwl ? 0.12 : 0.1;
  const eyeX = isOwl ? 0.25 : 0.23;

  return (
    <group scale={[1, squish, 1]}>
      {/* body */}
      <Ball p={[0, 0.6, 0]} r={0.6} s={[1, 0.95, 0.96]} color={body} />
      <Ball p={[0, 0.54, 0.3]} r={0.46} s={[0.9, 0.98, 0.55]} color={belly} />

      {/* feet */}
      {[-1, 1].map((sx) => (
        <Ball key={`f${sx}`} p={[sx * 0.28, 0.1, 0.34]} r={0.19} s={[1, 0.6, 1.35]} color={limbColor} />
      ))}
      {/* arms */}
      {!wings &&
        [-1, 1].map((sx) => (
          <Ball key={`a${sx}`} p={[sx * 0.58, 0.66, 0.22]} r={0.16} s={[0.8, 1.25, 0.85]} color={limbColor} rot={[0, 0, sx * 0.35]} />
        ))}

      {/* wings */}
      {wings && (
        <>
          <group ref={wingL} position={[-0.6, 0.78, -0.05]}>
            <Ball p={[-0.04, -0.18, 0]} r={0.34} s={[0.28, 1, 0.7]} color={wingColor} />
          </group>
          <group ref={wingR} position={[0.6, 0.78, -0.05]}>
            <Ball p={[0.04, -0.18, 0]} r={0.34} s={[0.28, 1, 0.7]} color={wingColor} />
          </group>
        </>
      )}

      {/* tail */}
      <group ref={tail} position={[0, 0.42, -0.5]}>
        {tailKind === "fluffy" && (
          <>
            <Ball p={[0, 0.12, -0.28]} r={0.3} s={[0.85, 0.85, 1.6]} rot={[-0.5, 0, 0]} color={body} />
            <Ball p={[0, 0.32, -0.62]} r={0.17} s={[1, 1, 1.1]} color={belly} />
          </>
        )}
        {tailKind === "long" && (
          <>
            <Ball p={[0, 0.0, -0.18]} r={0.14} color={body} />
            <Ball p={[0, 0.1, -0.38]} r={0.13} color={body} />
            <Ball p={[0, 0.26, -0.52]} r={0.12} color={body} />
            <Ball p={[0, 0.46, -0.58]} r={id === "drake" ? 0.14 : 0.12} color={id === "drake" ? "#f2e6c9" : patch ?? body} />
          </>
        )}
        {tailKind === "stub" && <Ball p={[0, 0.02, -0.12]} r={0.16} color={isPanda ? "#ffffff" : belly} />}
      </group>

      {/* head */}
      <group ref={head} position={[0, 1.38, 0.02]}>
        <Ball r={0.62} s={[1.1, 0.95, 1]} color={body} />

        {/* ears */}
        {ears !== "none" &&
          [-1, 1].map((sx) => (
            <group key={`e${sx}`} ref={sx < 0 ? earL : earR} position={[sx * 0.4, 0.5, 0]} rotation={[0, 0, -sx * 0.12]}>
              {ears === "round" && <Ball p={[sx * 0.04, 0.08, 0]} r={0.2} s={[1, 1, 0.55]} color={earColor} />}
              {ears === "pointy" && (
                <mesh position={[sx * 0.04, 0.16, 0]} rotation={[0, 0, -sx * 0.2]}>
                  <coneGeometry args={[0.2, 0.46, 24]} />
                  <Fur color={body} />
                </mesh>
              )}
              {ears === "long" && <Ball p={[sx * 0.04, 0.3, 0]} r={0.15} s={[0.75, 2.3, 0.5]} color={body} rot={[0, 0, -sx * 0.18]} />}
              {ears === "tuft" && (
                <mesh position={[sx * 0.02, 0.14, 0]} rotation={[0, 0, -sx * 0.55]}>
                  <coneGeometry args={[0.15, 0.4, 16]} />
                  <Fur color={darken(body, 0.2)} />
                </mesh>
              )}
            </group>
          ))}

        {horns &&
          [-1, 1].map((sx) => (
            <mesh key={`h${sx}`} position={[sx * 0.28, 0.58, 0.05]} rotation={[-0.2, 0, -sx * 0.35]}>
              <coneGeometry args={[0.09, 0.4, 16]} />
              <meshStandardMaterial color="#f2e6c9" roughness={0.45} />
            </mesh>
          ))}

        {/* owl facial disc / panda eye patch / cheek fluff */}
        {isOwl &&
          [-1, 1].map((sx) => <Ball key={`d${sx}`} p={[sx * eyeX, 0.04, 0.46]} r={0.23} s={[1, 1, 0.4]} color={belly} />)}
        {isPanda &&
          patch &&
          [-1, 1].map((sx) => <Ball key={`p${sx}`} p={[sx * 0.25, 0.02, 0.5]} r={0.17} s={[0.8, 1.2, 0.4]} color={patch} rot={[0, 0, sx * 0.5]} />)}
        {!isPanda &&
          !isOwl &&
          patch &&
          [-1, 1].map((sx) => <Ball key={`c${sx}`} p={[sx * 0.4, -0.17, 0.36]} r={0.2} s={[1, 0.8, 0.8]} color={patch} />)}

        {/* eyes */}
        <group ref={eyes} position={[0, 0.04, 0]}>
          {[-1, 1].map((sx) => (
            <group key={`ey${sx}`} position={[sx * eyeX, 0, isOwl ? 0.54 : 0.55]}>
              {isOwl && (
                <mesh scale={[1, 1, 0.5]}>
                  <sphereGeometry args={[0.15, 24, 16]} />
                  <meshStandardMaterial color="#f7c64a" roughness={0.3} />
                </mesh>
              )}
              <mesh position={[0, 0, isOwl ? 0.05 : 0]} scale={[1, 1.15, 0.8]}>
                <sphereGeometry args={[eyeSz, 24, 16]} />
                <meshStandardMaterial color="#17171d" roughness={0.15} metalness={0.1} />
              </mesh>
              <mesh position={[0.035, 0.045, isOwl ? 0.11 : 0.07]}>
                <sphereGeometry args={[0.032, 12, 8]} />
                <meshBasicMaterial color="#ffffff" />
              </mesh>
            </group>
          ))}
        </group>

        {/* cheeks */}
        {!isPanda &&
          [-1, 1].map((sx) => (
            <mesh key={`ch${sx}`} position={[sx * 0.42, -0.13, 0.46]} scale={[1, 0.65, 0.35]}>
              <sphereGeometry args={[0.1, 16, 12]} />
              <meshStandardMaterial color="#ff9db0" roughness={0.9} transparent opacity={0.75} />
            </mesh>
          ))}

        {/* snout / beak / nose / mouth */}
        {snout && (
          <>
            <Ball p={[0, -0.14, 0.52]} r={0.22} s={[1.15, 0.8, 0.9]} color={isPanda ? "#ffffff" : patch ?? belly} />
            <mesh position={[0, -0.05, 0.72]} scale={[1.2, 0.8, 0.8]}>
              <sphereGeometry args={[0.065, 16, 12]} />
              <meshStandardMaterial color="#1a1a20" roughness={0.3} />
            </mesh>
          </>
        )}
        {beak && (
          <mesh position={[0, -0.1, 0.64]} rotation={[Math.PI / 2, 0, 0]}>
            <coneGeometry args={[0.1, 0.24, 20]} />
            <meshStandardMaterial color="#f2a33a" roughness={0.45} />
          </mesh>
        )}
        {!snout && !beak && (
          <mesh position={[0, -0.08, 0.6]} scale={[1.2, 0.8, 0.8]}>
            <sphereGeometry args={[0.048, 12, 8]} />
            <meshStandardMaterial color="#2a2028" roughness={0.3} />
          </mesh>
        )}
        {!beak && (
          <mesh position={[0, snout ? -0.2 : -0.17, snout ? 0.7 : 0.57]} rotation={[0, 0, Math.PI]}>
            <torusGeometry args={[0.055, 0.012, 8, 20, Math.PI]} />
            <meshBasicMaterial color="#2a2028" />
          </mesh>
        )}
      </group>
    </group>
  );
}

/* ------------------------------ layered artwork "standee" ------------------------------ */

const LAYERS = 12;

export function SpriteBody({ species, state }: { species: Species; state: PetState }) {
  const [tex, setTex] = useState<THREE.Texture | null>(null);
  const [failed, setFailed] = useState(false);
  const dex = species.dex ?? 0;
  const orb = useRef<THREE.Mesh>(null);

  useEffect(() => {
    let live = true;
    setTex(null);
    setFailed(false);
    loadTex(artworkUrl(dex))
      .then((t) => live && setTex(t))
      .catch(() => live && setFailed(true));
    return () => {
      live = false;
    };
  }, [dex]);

  useFrame((s) => {
    if (orb.current) {
      const k = 0.8 + Math.sin(s.clock.elapsedTime * 4) * 0.15;
      orb.current.scale.setScalar(k);
    }
  });

  const h = species.scale ?? 2.1;
  const img = tex?.image as { width: number; height: number } | undefined;
  const w = img ? h * (img.width / img.height) : h;
  const depth = h * 0.16;

  const layers = useMemo(() => {
    const edge = new THREE.Color("#ffffff").lerp(new THREE.Color(species.color), 0.7);
    return Array.from({ length: LAYERS }, (_, i) => {
      const k = i / (LAYERS - 1);
      const c = edge.clone().multiplyScalar(0.38 + k * 0.5);
      return { z: (k - 0.5) * depth, s: 0.93 + k * 0.07, c };
    });
  }, [species.color, depth]);

  if (failed) {
    return (
      <ProceduralBody
        params={{ body: species.color, belly: "#ffffff", ears: "round", tail: "stub" }}
        id={species.id}
        state={state}
        look={false}
      />
    );
  }

  if (!tex) {
    return (
      <mesh ref={orb} position={[0, 0.9, 0]}>
        <sphereGeometry args={[0.35, 24, 16]} />
        <meshBasicMaterial color={species.color} transparent opacity={0.6} />
      </mesh>
    );
  }

  return (
    <group>
      {layers.map((l, i) => (
        <mesh key={i} position={[0, h / 2 + 0.02, l.z]} scale={[l.s, l.s, 1]}>
          <planeGeometry args={[w, h]} />
          <meshBasicMaterial map={tex} color={l.c} alphaTest={0.55} side={THREE.DoubleSide} />
        </mesh>
      ))}
      <mesh position={[0, h / 2 + 0.02, depth / 2 + 0.004]} renderOrder={5}>
        <planeGeometry args={[w, h]} />
        <meshBasicMaterial map={tex} transparent alphaTest={0.02} depthWrite={false} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}
