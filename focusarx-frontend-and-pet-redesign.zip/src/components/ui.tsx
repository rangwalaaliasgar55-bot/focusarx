import type { ButtonHTMLAttributes, HTMLAttributes, ReactNode } from "react";
import { cn } from "../utils/cn";

export function BrandMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden>
      <defs>
        <linearGradient id="bm" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#8A5CFF" />
          <stop offset="1" stopColor="#4E7CFF" />
        </linearGradient>
        <linearGradient id="bs" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" stopOpacity="0.32" />
          <stop offset="0.42" stopColor="#fff" stopOpacity="0" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="14.3" fill="url(#bm)" />
      <rect width="64" height="64" rx="14.3" fill="url(#bs)" />
      <circle cx="32" cy="32" r="19.8" fill="none" stroke="#fff" strokeWidth="6.1" />
      <circle cx="32" cy="32" r="4.5" fill="#fff" />
    </svg>
  );
}

export function BrandLockup() {
  return (
    <div className="flex items-center gap-2.5">
      <BrandMark />
      <div className="leading-tight">
        <div className="text-[15px] font-semibold tracking-tight">FocusArx</div>
        <div className="text-[11px] text-subtle">Deep work, made clear</div>
      </div>
    </div>
  );
}

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "outline" | "danger" | "soft";
  size?: "sm" | "md" | "lg";
};

export function Btn({ variant = "outline", size = "md", className, ...p }: BtnProps) {
  const v = {
    primary: "bg-brand-600 text-white hover:bg-brand-600/90 border-transparent",
    soft: "bg-brand-soft text-brand-strong hover:bg-brand-soft/70 border-transparent",
    outline: "border-line-strong bg-transparent hover:bg-s2 text-fg",
    ghost: "border-transparent bg-transparent text-muted hover:bg-s2 hover:text-fg",
    danger: "border-transparent bg-bad-soft text-bad hover:bg-bad-soft/70",
  }[variant];
  const s = { sm: "h-8 px-3 text-[13px] gap-1.5", md: "h-10 px-4 text-sm gap-2", lg: "h-12 px-6 text-[15px] gap-2" }[size];
  return (
    <button
      {...p}
      className={cn(
        "inline-flex select-none items-center justify-center rounded-[10px] border font-medium transition-[background,transform,opacity] duration-150 active:scale-[0.98] disabled:pointer-events-none disabled:opacity-40",
        v,
        s,
        className,
      )}
    />
  );
}

export function Panel({ className, children, ...p }: { className?: string; children: ReactNode } & HTMLAttributes<HTMLDivElement>) {
  return (
    <div {...p} className={cn("panel", className)}>
      {children}
    </div>
  );
}

export function Progress({ value, color = "var(--brand-500)", className, height = 6 }: { value: number; color?: string; className?: string; height?: number }) {
  return (
    <div className={cn("w-full overflow-hidden rounded-full bg-s3", className)} style={{ height }} role="progressbar" aria-valuenow={Math.round(value * 100)} aria-valuemin={0} aria-valuemax={100}>
      <div className="h-full rounded-full transition-[width] duration-500" style={{ width: `${Math.min(100, Math.max(0, value * 100))}%`, background: color }} />
    </div>
  );
}

export function PageHead({ title, sub, right }: { title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-[34px] leading-none tracking-tight">{title}</h1>
        {sub && <p className="mt-2 max-w-xl text-sm text-muted">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function Segmented<T extends string>({ value, onChange, options, className }: { value: T; onChange: (v: T) => void; options: { id: T; label: string }[]; className?: string }) {
  return (
    <div className={cn("inline-flex rounded-[10px] border border-line bg-s2 p-0.5", className)} role="tablist">
      {options.map((o) => (
        <button
          key={o.id}
          role="tab"
          aria-selected={value === o.id}
          onClick={() => onChange(o.id)}
          className={cn(
            "h-8 rounded-[8px] px-3 text-[13px] font-medium transition-colors duration-150",
            value === o.id ? "bg-s1 text-fg shadow-[0_1px_2px_rgba(0,0,0,0.25)]" : "text-muted hover:text-fg",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

export function Tag({ children, color, className }: { children: ReactNode; color?: string; className?: string }) {
  return (
    <span
      className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold", className)}
      style={color ? { color, background: `color-mix(in srgb, ${color} 16%, transparent)` } : { background: "var(--surface-3)", color: "var(--foreground-muted)" }}
    >
      {children}
    </span>
  );
}

export function Empty({ title, hint, action }: { title: string; hint?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-[14px] border border-dashed border-line-strong px-6 py-10 text-center">
      <div className="text-sm font-medium">{title}</div>
      {hint && <div className="mt-1 max-w-sm text-[13px] text-muted">{hint}</div>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Stat({ label, value, sub, icon }: { label: string; value: ReactNode; sub?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="px-4 py-3.5">
      <div className="flex items-center gap-1.5 text-[12px] text-subtle">
        {icon}
        {label}
      </div>
      <div className="tnum mt-1 text-[24px] font-semibold leading-tight tracking-tight">{value}</div>
      {sub && <div className="mt-0.5 text-[12px] text-muted">{sub}</div>}
    </div>
  );
}
