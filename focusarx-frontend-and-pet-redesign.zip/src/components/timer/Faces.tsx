import { useEffect, useId, useState, type CSSProperties } from "react";
import type { FaceId } from "../../lib/store";
import type { Mode } from "../../lib/timer";

export interface FaceProps {
  secondsLeft: number;
  totalSec: number;
  mode: Mode;
  running: boolean;
  color: string;
}

export const FACES: { id: FaceId; name: string; note: string }[] = [
  { id: "classic", name: "Classic", note: "Clean progress ring" },
  { id: "neon", name: "Neon", note: "Gradient ring, lit digits" },
  { id: "zen", name: "Zen", note: "Hairline ring, breathing circle" },
  { id: "flip", name: "Flip", note: "Mechanical split-flap cards" },
  { id: "analog", name: "Analog", note: "Wedge dial that empties" },
  { id: "hourglass", name: "Hourglass", note: "Falling sand" },
  { id: "orbit", name: "Orbit", note: "Planet and moon on rails" },
  { id: "segment", name: "Segment", note: "Seven-segment readout" },
];

export function parts(sec: number): [string, string, string] {
  if (sec >= 6000) {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return [String(h).padStart(2, "0"), String(m).padStart(2, "0"), "h m"];
  }
  return [String(Math.floor(sec / 60)).padStart(2, "0"), String(sec % 60).padStart(2, "0"), "m s"];
}

export const clockText = (sec: number) => {
  const [a, b] = parts(sec);
  return `${a}:${b}`;
};

const modeWord: Record<Mode, string> = { focus: "Focus", short: "Short break", long: "Long break" };

const cq = (n: number): CSSProperties => ({ fontSize: `${n}cqw` });
const box: CSSProperties = { containerType: "inline-size" };

function elapsedFrac(p: FaceProps) {
  return p.totalSec > 0 ? Math.min(1, Math.max(0, 1 - p.secondsLeft / p.totalSec)) : 0;
}

/* ------------------------------ classic ------------------------------ */

function Classic(p: FaceProps) {
  const R = 45;
  const C = 2 * Math.PI * R;
  const e = elapsedFrac(p);
  const [m, s] = parts(p.secondsLeft);
  return (
    <div className="relative mx-auto aspect-square w-full" style={box}>
      <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
        <circle cx="50" cy="50" r="48.6" fill="var(--surface-1)" />
        <circle cx="50" cy="50" r={R} fill="none" stroke="var(--surface-3)" strokeWidth="3.2" />
        <circle
          cx="50"
          cy="50"
          r={R}
          fill="none"
          stroke={p.color}
          strokeWidth="3.2"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - Math.max(e, 0.0001))}
          style={{ transition: p.running ? "stroke-dashoffset 1s linear" : "stroke-dashoffset 0.4s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="tnum font-semibold tracking-tight" style={{ ...cq(21), lineHeight: 1 }}>
          {m}
          <span className={p.running ? "anim-tick" : ""} style={{ opacity: 0.55, margin: "0 0.02em" }}>
            :
          </span>
          {s}
        </div>
        <div className="mt-[3cqw] font-medium uppercase text-muted" style={{ ...cq(3.1), letterSpacing: "0.16em" }}>
          {modeWord[p.mode]}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ neon ------------------------------ */

function Neon(p: FaceProps) {
  const id = useId().replace(/:/g, "");
  const R = 44;
  const C = 2 * Math.PI * R;
  const e = elapsedFrac(p);
  const [m, s] = parts(p.secondsLeft);
  const breakMode = p.mode !== "focus";
  const a = breakMode ? p.color : "var(--brand-500)";
  const b = breakMode ? p.color : "#ff5fa8";
  return (
    <div className="relative mx-auto aspect-square w-full" style={box}>
      <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90 overflow-visible">
        <defs>
          <linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor={a} />
            <stop offset="1" stopColor={b} />
          </linearGradient>
          <filter id={`f${id}`} x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="1.6" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <circle cx="50" cy="50" r="48.4" fill="#07070a" />
        <circle cx="50" cy="50" r={R} fill="none" stroke="rgba(255,255,255,0.07)" strokeWidth="2.4" />
        {Array.from({ length: 60 }).map((_, i) => {
          const ang = (i / 60) * Math.PI * 2;
          const big = i % 5 === 0;
          const r1 = 38.2;
          const r2 = big ? 35.2 : 36.6;
          return (
            <line
              key={i}
              x1={50 + Math.cos(ang) * r1}
              y1={50 + Math.sin(ang) * r1}
              x2={50 + Math.cos(ang) * r2}
              y2={50 + Math.sin(ang) * r2}
              stroke="rgba(255,255,255,0.22)"
              strokeWidth={big ? 0.5 : 0.25}
            />
          );
        })}
        <circle
          cx="50"
          cy="50"
          r={R}
          fill="none"
          stroke={`url(#g${id})`}
          strokeWidth="2.6"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - Math.max(e, 0.0001))}
          filter={`url(#f${id})`}
          style={{ transition: p.running ? "stroke-dashoffset 1s linear" : "stroke-dashoffset 0.4s ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center font-mono" style={{ color: "#fff" }}>
        <div
          className="tnum font-bold"
          style={{ ...cq(19), lineHeight: 1, textShadow: `0 0 0.35em ${breakMode ? p.color : "rgba(130,140,255,0.7)"}` }}
        >
          {m}
          <span className={p.running ? "anim-tick" : ""}>:</span>
          {s}
        </div>
        <div className="mt-[3cqw] uppercase" style={{ ...cq(2.9), letterSpacing: "0.3em", color: "rgba(255,255,255,0.55)" }}>
          {modeWord[p.mode]}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ zen ------------------------------ */

function Zen(p: FaceProps) {
  const R = 47;
  const C = 2 * Math.PI * R;
  const e = elapsedFrac(p);
  const [m, s] = parts(p.secondsLeft);
  return (
    <div className="relative mx-auto aspect-square w-full" style={box}>
      <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90">
        <circle cx="50" cy="50" r={R} fill="none" stroke="var(--border-strong)" strokeWidth="0.3" />
        <circle
          cx="50"
          cy="50"
          r={R}
          fill="none"
          stroke={p.color}
          strokeWidth="0.9"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - Math.max(e, 0.0001))}
          style={{ transition: p.running ? "stroke-dashoffset 1s linear" : "stroke-dashoffset 0.4s ease" }}
        />
        <g className="origin-center" style={{ transformOrigin: "50px 50px", animation: p.running ? "zenBreath 8s ease-in-out infinite" : undefined }}>
          <circle cx="50" cy="50" r="38" fill={p.color} opacity="0.07" />
          <circle cx="50" cy="50" r="30" fill={p.color} opacity="0.06" />
        </g>
        <circle
          cx={50 + Math.cos(e * Math.PI * 2) * R}
          cy={50 + Math.sin(e * Math.PI * 2) * R}
          r="1.2"
          fill={p.color}
          style={{ transition: "none" }}
        />
      </svg>
      <style>{`@keyframes zenBreath{0%,100%{transform:scale(0.86)}50%{transform:scale(1.04)}}`}</style>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="tnum font-display" style={{ ...cq(25), lineHeight: 0.95, letterSpacing: "-0.02em" }}>
          {m}
          <span style={{ opacity: 0.35 }}>:</span>
          {s}
        </div>
        <div className="mt-[3cqw] font-display italic text-muted" style={cq(5)}>
          {p.mode === "focus" ? (p.running ? "breathe in, stay with it" : "when you're ready") : "rest your eyes"}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ flip ------------------------------ */

function Half({ v, pos }: { v: string; pos: "top" | "bottom" }) {
  return (
    <div
      className={`absolute left-0 right-0 overflow-hidden ${pos === "top" ? "top-0 rounded-t-[1.6cqw]" : "bottom-0 rounded-b-[1.6cqw]"}`}
      style={{ height: "50%", background: pos === "top" ? "var(--surface-2)" : "var(--surface-3)", backfaceVisibility: "hidden" }}
    >
      <div className="absolute left-0 right-0 flex items-center justify-center" style={{ height: "200%", top: pos === "top" ? 0 : "-100%" }}>
        {v}
      </div>
    </div>
  );
}

function FlipDigit({ value }: { value: string }) {
  const [cur, setCur] = useState(value);
  const [prev, setPrev] = useState(value);
  const [n, setN] = useState(0);
  useEffect(() => {
    if (value !== cur) {
      setPrev(cur);
      setCur(value);
      setN((x) => x + 1);
    }
  }, [value, cur]);
  return (
    <div
      className="tnum relative font-bold"
      style={{ width: "21cqw", height: "30cqw", perspective: "90cqw", fontSize: "23cqw", lineHeight: 1, boxShadow: "0 1.2cqw 3cqw -1cqw rgba(0,0,0,0.45)", borderRadius: "1.6cqw" }}
    >
      <Half v={cur} pos="top" />
      <Half v={n === 0 ? cur : prev} pos="bottom" />
      {n > 0 && (
        <>
          <div
            key={`t${n}`}
            className="absolute left-0 right-0 top-0"
            style={{ height: "50%", transformOrigin: "bottom", animation: "flipTop 0.28s ease-in forwards", zIndex: 2 }}
          >
            <Half v={prev} pos="top" />
          </div>
          <div
            key={`b${n}`}
            className="absolute bottom-0 left-0 right-0"
            style={{ height: "50%", transformOrigin: "top", transform: "rotateX(90deg)", animation: "flipBottom 0.28s 0.27s ease-out forwards", zIndex: 2 }}
          >
            <Half v={cur} pos="bottom" />
          </div>
        </>
      )}
      <div className="absolute left-0 right-0" style={{ top: "calc(50% - 0.25cqw)", height: "0.5cqw", background: "var(--background)", zIndex: 3 }} />
    </div>
  );
}

function Flip(p: FaceProps) {
  const [a, b, unit] = parts(p.secondsLeft);
  const e = elapsedFrac(p);
  return (
    <div className="mx-auto w-full" style={box}>
      <div className="flex items-center justify-center" style={{ gap: "2cqw" }}>
        <FlipDigit value={a[0]} />
        <FlipDigit value={a[1]} />
        <div className="flex flex-col" style={{ gap: "4cqw", margin: "0 1cqw" }}>
          <span className={p.running ? "anim-tick" : ""} style={{ width: "2.6cqw", height: "2.6cqw", borderRadius: "50%", background: p.color }} />
          <span className={p.running ? "anim-tick" : ""} style={{ width: "2.6cqw", height: "2.6cqw", borderRadius: "50%", background: p.color }} />
        </div>
        <FlipDigit value={b[0]} />
        <FlipDigit value={b[1]} />
      </div>
      <div className="mx-auto mt-[6cqw] overflow-hidden rounded-full" style={{ height: "1.2cqw", width: "88cqw", background: "var(--surface-3)" }}>
        <div className="h-full rounded-full" style={{ width: `${e * 100}%`, background: p.color, transition: "width 1s linear" }} />
      </div>
      <div className="mt-[3cqw] text-center font-medium uppercase text-muted" style={{ ...cq(3), letterSpacing: "0.16em" }}>
        {modeWord[p.mode]} · {unit}
      </div>
    </div>
  );
}

/* ------------------------------ analog (wedge dial) ------------------------------ */

function Analog(p: FaceProps) {
  const span = Math.max(p.totalSec, 3600 * (p.totalSec > 3600 ? 2 : 1));
  const frac = Math.min(1, p.secondsLeft / span);
  const L = 2 * Math.PI * 22;
  const ang = frac * Math.PI * 2 - Math.PI / 2;
  const [m, s] = parts(p.secondsLeft);
  const hours = span / 3600;
  return (
    <div className="relative mx-auto aspect-square w-full" style={box}>
      <svg viewBox="0 0 100 100" className="absolute inset-0">
        <circle cx="50" cy="50" r="49" fill="var(--surface-1)" stroke="var(--border-strong)" strokeWidth="0.4" />
        <circle cx="50" cy="50" r="44" fill="var(--surface-2)" />
        <circle
          cx="50"
          cy="50"
          r="22"
          fill="none"
          stroke={p.color}
          strokeWidth="44"
          strokeDasharray={`${L * frac} ${L}`}
          transform="rotate(-90 50 50)"
          opacity="0.9"
          style={{ transition: p.running ? "stroke-dasharray 1s linear" : "stroke-dasharray 0.4s ease" }}
        />
        {Array.from({ length: 60 }).map((_, i) => {
          const a = (i / 60) * Math.PI * 2 - Math.PI / 2;
          const big = i % 5 === 0;
          const r1 = 44;
          const r2 = big ? 39.5 : 41.8;
          return (
            <line
              key={i}
              x1={50 + Math.cos(a) * r1}
              y1={50 + Math.sin(a) * r1}
              x2={50 + Math.cos(a) * r2}
              y2={50 + Math.sin(a) * r2}
              stroke="var(--foreground)"
              strokeOpacity={big ? 0.9 : 0.35}
              strokeWidth={big ? 0.7 : 0.3}
            />
          );
        })}
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * Math.PI * 2 - Math.PI / 2;
          const label = hours > 1 ? String(i * 10) : String(i * 5);
          return (
            <text
              key={i}
              x={50 + Math.cos(a) * 33.5}
              y={50 + Math.sin(a) * 33.5 + 1.6}
              textAnchor="middle"
              fontSize="4.6"
              fontWeight="600"
              fill="var(--foreground)"
              fillOpacity="0.8"
            >
              {i === 0 ? (hours > 1 ? "0" : "60") : label}
            </text>
          );
        })}
        <line x1="50" y1="50" x2={50 + Math.cos(ang) * 43} y2={50 + Math.sin(ang) * 43} stroke="var(--foreground)" strokeWidth="1.1" strokeLinecap="round" />
        <circle cx="50" cy="50" r="3" fill="var(--foreground)" />
        <circle cx="50" cy="50" r="1.2" fill={p.color} />
      </svg>
      <div className="absolute left-1/2 top-[67%] -translate-x-1/2 rounded-full border border-line bg-s1 px-[3cqw] py-[1cqw] tnum font-semibold" style={cq(5.4)}>
        {m}:{s}
      </div>
    </div>
  );
}

/* ------------------------------ hourglass ------------------------------ */

function Hourglass(p: FaceProps) {
  const id = useId().replace(/:/g, "");
  const e = elapsedFrac(p);
  const glass = "M22 8 H78 C78 40 56 56 54 70 C56 84 78 100 78 132 H22 C22 100 44 84 46 70 C44 56 22 40 22 8 Z";
  const topY = 10 + e * 58;
  const botY = 132 - e * 60;
  const [m, s] = parts(p.secondsLeft);
  const flowing = p.running && p.secondsLeft > 0;
  return (
    <div className="mx-auto w-full" style={box}>
      <div className="mx-auto" style={{ width: "58cqw" }}>
        <svg viewBox="0 0 100 140" className="w-full overflow-visible">
          <defs>
            <clipPath id={`c${id}`}>
              <path d={glass} />
            </clipPath>
            <linearGradient id={`s${id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={p.color} stopOpacity="1" />
              <stop offset="1" stopColor={p.color} stopOpacity="0.7" />
            </linearGradient>
          </defs>
          <path d={glass} fill="var(--surface-2)" />
          <g clipPath={`url(#c${id})`}>
            <rect x="0" y={topY} width="100" height={Math.max(0, 70 - topY)} fill={`url(#s${id})`} style={{ transition: "y 1s linear, height 1s linear" }} />
            <rect x="0" y={botY} width="100" height={Math.max(0, 132 - botY)} fill={`url(#s${id})`} style={{ transition: "y 1s linear, height 1s linear" }} />
            {e < 0.995 && (
              <ellipse cx="50" cy={botY} rx={Math.min(26, 6 + e * 40)} ry="2.4" fill={p.color} opacity="0.85" style={{ transition: "cy 1s linear" }} />
            )}
            {flowing && (
              <line
                x1="50"
                y1="68"
                x2="50"
                y2={botY}
                stroke={p.color}
                strokeWidth="1.1"
                strokeDasharray="2 3"
                style={{ animation: "sandFall 0.35s linear infinite" }}
              />
            )}
          </g>
          <path d={glass} fill="none" stroke="var(--foreground)" strokeOpacity="0.55" strokeWidth="1.2" strokeLinejoin="round" />
          <path d="M30 14 C30 34 40 46 47 58" fill="none" stroke="#fff" strokeOpacity="0.22" strokeWidth="1.6" strokeLinecap="round" />
          <rect x="14" y="2" width="72" height="7" rx="3.5" fill="var(--foreground)" fillOpacity="0.85" />
          <rect x="14" y="131" width="72" height="7" rx="3.5" fill="var(--foreground)" fillOpacity="0.85" />
        </svg>
      </div>
      <div className="mt-[4cqw] text-center">
        <div className="tnum font-semibold tracking-tight" style={{ ...cq(14), lineHeight: 1 }}>
          {m}:{s}
        </div>
        <div className="mt-[1.5cqw] font-medium uppercase text-muted" style={{ ...cq(3), letterSpacing: "0.16em" }}>
          {modeWord[p.mode]}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ orbit ------------------------------ */

function Orbit(p: FaceProps) {
  const e = elapsedFrac(p);
  const R = 43;
  const r2 = 31;
  const ang = e * Math.PI * 2 - Math.PI / 2;
  const sec = ((p.totalSec - p.secondsLeft) % 60) / 60;
  const ang2 = sec * Math.PI * 2 - Math.PI / 2;
  const C = 2 * Math.PI * R;
  const [m, s] = parts(p.secondsLeft);
  const stars = Array.from({ length: 26 }).map((_, i) => ({
    x: 50 + Math.cos(i * 2.399) * (8 + ((i * 7) % 40)),
    y: 50 + Math.sin(i * 2.399) * (8 + ((i * 7) % 40)),
    r: 0.25 + (i % 3) * 0.15,
  }));
  return (
    <div className="relative mx-auto aspect-square w-full" style={box}>
      <svg viewBox="0 0 100 100" className="absolute inset-0 overflow-visible">
        <circle cx="50" cy="50" r="49" fill="var(--surface-1)" />
        {stars.map((st, i) => (
          <circle key={i} cx={st.x} cy={st.y} r={st.r} fill="var(--foreground)" opacity="0.28" />
        ))}
        <circle cx="50" cy="50" r={R} fill="none" stroke="var(--border-strong)" strokeWidth="0.35" strokeDasharray="0.6 1.6" />
        <circle cx="50" cy="50" r={r2} fill="none" stroke="var(--border)" strokeWidth="0.3" />
        <circle
          cx="50"
          cy="50"
          r={R}
          fill="none"
          stroke={p.color}
          strokeWidth="1.1"
          strokeLinecap="round"
          strokeDasharray={C}
          strokeDashoffset={C * (1 - Math.max(e, 0.0001))}
          transform="rotate(-90 50 50)"
          style={{ transition: p.running ? "stroke-dashoffset 1s linear" : "stroke-dashoffset 0.4s ease" }}
        />
        {/* planet */}
        <g style={{ transform: `translate(${50 + Math.cos(ang) * R}px, ${50 + Math.sin(ang) * R}px)`, transition: p.running ? "transform 1s linear" : "transform 0.4s ease" }}>
          <circle r="4.2" fill={p.color} />
          <ellipse rx="7" ry="1.6" fill="none" stroke="var(--foreground)" strokeOpacity="0.55" strokeWidth="0.45" transform="rotate(-24)" />
          <circle cx="-1.2" cy="-1.3" r="1.2" fill="#fff" opacity="0.35" />
        </g>
        {/* moon marks seconds */}
        <circle
          cx={50 + Math.cos(ang2) * r2}
          cy={50 + Math.sin(ang2) * r2}
          r="1.6"
          fill="var(--foreground)"
          opacity="0.85"
          style={{ transition: sec < 0.02 ? "none" : p.running ? "cx 1s linear, cy 1s linear" : undefined }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="tnum font-semibold tracking-tight" style={{ ...cq(17), lineHeight: 1 }}>
          {m}:{s}
        </div>
        <div className="mt-[2.5cqw] font-medium uppercase text-muted" style={{ ...cq(2.9), letterSpacing: "0.18em" }}>
          {modeWord[p.mode]}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ segment ------------------------------ */

const SEG: Record<string, string> = {
  a: "M5 3.5 L8.5 0 H27.5 L31 3.5 L27.5 7 H8.5 Z",
  g: "M5 32 L8.5 28.5 H27.5 L31 32 L27.5 35.5 H8.5 Z",
  d: "M5 60.5 L8.5 57 H27.5 L31 60.5 L27.5 64 H8.5 Z",
  f: "M3.5 5 L7 8.5 V27.5 L3.5 31 L0 27.5 V8.5 Z",
  b: "M32.5 5 L36 8.5 V27.5 L32.5 31 L29 27.5 V8.5 Z",
  e: "M3.5 33 L7 36.5 V55.5 L3.5 59 L0 55.5 V36.5 Z",
  c: "M32.5 33 L36 36.5 V55.5 L32.5 59 L29 55.5 V36.5 Z",
};
const DIGITS: Record<string, string> = {
  "0": "abcdef",
  "1": "bc",
  "2": "abdeg",
  "3": "abcdg",
  "4": "bcfg",
  "5": "acdfg",
  "6": "acdefg",
  "7": "abc",
  "8": "abcdefg",
  "9": "abcdfg",
};

function Segment(p: FaceProps) {
  const [a, b] = parts(p.secondsLeft);
  const digits = [a[0], a[1], b[0], b[1]];
  const xs = [0, 46, 112, 158];
  const e = elapsedFrac(p);
  const blocks = 24;
  const lit = Math.round(e * blocks);
  return (
    <div className="mx-auto w-full" style={box}>
      <div className="rounded-[3cqw] p-[3.5cqw]" style={{ background: "linear-gradient(180deg,#0b0c10,#050507)", border: "1px solid rgba(255,255,255,0.09)", boxShadow: "inset 0 0 0 0.6cqw #14151b, 0 2cqw 5cqw -2cqw rgba(0,0,0,0.6)" }}>
        <svg viewBox="-4 -4 202 72" className="w-full overflow-visible">
          {digits.map((d, i) => (
            <g key={i} transform={`translate(${xs[i]} 0)`}>
              {Object.keys(SEG).map((k) => (
                <path key={k} d={SEG[k]} fill={p.color} opacity={DIGITS[d].includes(k) ? 1 : 0.07} style={DIGITS[d].includes(k) ? { filter: `drop-shadow(0 0 2.5px ${p.color})` } : undefined} />
              ))}
            </g>
          ))}
          <g className={p.running ? "anim-tick" : ""} style={{ filter: `drop-shadow(0 0 2.5px ${p.color})` }}>
            <rect x="89" y="18" width="7" height="7" rx="1" fill={p.color} />
            <rect x="89" y="40" width="7" height="7" rx="1" fill={p.color} />
          </g>
        </svg>
        <div className="mt-[3cqw] flex gap-[0.7cqw]">
          {Array.from({ length: blocks }).map((_, i) => (
            <span key={i} className="h-[2cqw] flex-1 rounded-[0.4cqw]" style={{ background: p.color, opacity: i < lit ? 0.95 : 0.1, transition: "opacity 0.4s" }} />
          ))}
        </div>
        <div className="mt-[2.5cqw] flex justify-between font-mono uppercase" style={{ ...cq(2.5), letterSpacing: "0.22em", color: "rgba(255,255,255,0.45)" }}>
          <span>{modeWord[p.mode]}</span>
          <span>{Math.round(e * 100)}%</span>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ switch ------------------------------ */

export function TimerFace({ face, ...p }: FaceProps & { face: FaceId }) {
  switch (face) {
    case "neon":
      return <Neon {...p} />;
    case "zen":
      return <Zen {...p} />;
    case "flip":
      return <Flip {...p} />;
    case "analog":
      return <Analog {...p} />;
    case "hourglass":
      return <Hourglass {...p} />;
    case "orbit":
      return <Orbit {...p} />;
    case "segment":
      return <Segment {...p} />;
    default:
      return <Classic {...p} />;
  }
}

/* tiny static previews for the picker */
export function FacePreview({ face, color }: { face: FaceId; color: string }) {
  const common = { secondsLeft: 15 * 60, totalSec: 25 * 60, mode: "focus" as Mode, running: false, color };
  return (
    <div className="pointer-events-none w-full">
      <TimerFace face={face} {...common} />
    </div>
  );
}
