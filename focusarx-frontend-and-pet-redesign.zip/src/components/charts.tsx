import { useState, type ReactNode } from "react";
import { dayKey } from "../lib/store";

export function RingProgress({ value, size = 120, stroke = 9, color = "var(--brand-500)", children }: { value: number; size?: number; stroke?: number; color?: string; children?: ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.min(1, Math.max(0, value));
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-3)" strokeWidth={stroke} />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={c * (1 - v)}
          style={{ transition: "stroke-dashoffset 0.8s cubic-bezier(.2,.7,.2,1)" }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
}

export interface Bar {
  label: string;
  value: number;
  sub?: string;
  highlight?: boolean;
}

export function BarChart({ bars, height = 168, unit = "m", goal }: { bars: Bar[]; height?: number; unit?: string; goal?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const max = Math.max(goal ?? 0, ...bars.map((b) => b.value), 1) * 1.1;
  return (
    <div className="relative" style={{ height: height + 28 }}>
      {goal != null && (
        <div className="absolute left-0 right-0 border-t border-dashed border-line-strong" style={{ bottom: 28 + (goal / max) * height }}>
          <span className="absolute -top-2.5 right-0 bg-s1 pl-1.5 text-[10px] text-subtle">goal</span>
        </div>
      )}
      <div className="flex h-full items-end gap-1.5 sm:gap-2.5">
        {bars.map((b, i) => (
          <div key={i} className="relative flex flex-1 flex-col items-center justify-end" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}>
            {hover === i && (
              <div className="anim-pop absolute -top-1 z-10 -translate-y-full whitespace-nowrap rounded-md border border-line-strong bg-s3 px-2 py-1 text-[11px] shadow-[var(--shadow-float)]">
                <span className="tnum font-semibold">
                  {b.value}
                  {unit}
                </span>
                {b.sub && <span className="ml-1 text-subtle">{b.sub}</span>}
              </div>
            )}
            <div
              className="w-full rounded-t-[6px] transition-[height,background] duration-500"
              style={{
                height: Math.max(3, (b.value / max) * height),
                background: b.highlight ? "var(--brand-500)" : hover === i ? "var(--brand-strong)" : "color-mix(in srgb, var(--brand-500) 38%, var(--surface-3))",
              }}
            />
            <div className={`mt-2 h-4 text-[11px] ${b.highlight ? "font-semibold text-fg" : "text-subtle"}`}>{b.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Heatmap({ days, weeks = 15 }: { days: Map<string, number>; weeks?: number }) {
  const today = new Date();
  const dow = (today.getDay() + 6) % 7;
  const start = new Date(today.getFullYear(), today.getMonth(), today.getDate() - dow - (weeks - 1) * 7);
  const cols: { key: string; v: number; future: boolean; date: Date }[][] = [];
  for (let w = 0; w < weeks; w++) {
    const col = [];
    for (let d = 0; d < 7; d++) {
      const date = new Date(start.getFullYear(), start.getMonth(), start.getDate() + w * 7 + d);
      const key = dayKey(date.getTime());
      col.push({ key, v: days.get(key) ?? 0, future: date.getTime() > today.getTime(), date });
    }
    cols.push(col);
  }
  const level = (v: number) => (v === 0 ? 0 : v < 30 ? 1 : v < 75 ? 2 : v < 130 ? 3 : 4);
  const shades = ["var(--surface-3)", "color-mix(in srgb, var(--brand-500) 28%, var(--surface-3))", "color-mix(in srgb, var(--brand-500) 52%, var(--surface-3))", "color-mix(in srgb, var(--brand-500) 76%, var(--surface-3))", "var(--brand-500)"];
  return (
    <div>
      <div className="flex gap-[3px] overflow-x-auto pb-1">
        <div className="mr-1 flex flex-col justify-between py-[1px] text-[10px] text-subtle">
          <span>Mon</span>
          <span>Wed</span>
          <span>Fri</span>
          <span>Sun</span>
        </div>
        {cols.map((col, i) => (
          <div key={i} className="flex flex-1 flex-col gap-[3px]">
            {col.map((c) => (
              <div
                key={c.key}
                title={`${c.date.toLocaleDateString(undefined, { month: "short", day: "numeric" })} — ${c.v} min`}
                className="aspect-square w-full min-w-[12px] rounded-[3px]"
                style={{ background: c.future ? "transparent" : shades[level(c.v)] }}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-center justify-end gap-1.5 text-[11px] text-subtle">
        Less
        {shades.map((s, i) => (
          <span key={i} className="h-3 w-3 rounded-[3px]" style={{ background: s }} />
        ))}
        More
      </div>
    </div>
  );
}
