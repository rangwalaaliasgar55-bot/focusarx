import { useState } from "react";
import { animatedUrl, artworkUrl, type Species } from "../lib/pets";

function Original({ sp }: { sp: Species }) {
  const b = sp.body!;
  const dark = "#1c1b22";
  const isPanda = sp.id === "bamboo";
  const isOwl = sp.id === "hoot";
  const earColor = isPanda ? b.patch! : b.body;
  return (
    <svg viewBox="0 0 100 100" className="h-full w-full">
      {/* ears */}
      {b.ears === "round" && (
        <>
          <circle cx="27" cy="27" r="12" fill={earColor} />
          <circle cx="73" cy="27" r="12" fill={earColor} />
        </>
      )}
      {b.ears === "pointy" && (
        <>
          <polygon points="18,40 24,10 44,28" fill={b.body} />
          <polygon points="82,40 76,10 56,28" fill={b.body} />
        </>
      )}
      {b.ears === "long" && (
        <>
          <ellipse cx="36" cy="18" rx="8" ry="20" fill={b.body} transform="rotate(-8 36 18)" />
          <ellipse cx="64" cy="18" rx="8" ry="20" fill={b.body} transform="rotate(8 64 18)" />
        </>
      )}
      {b.ears === "tuft" && (
        <>
          <polygon points="24,38 22,12 44,28" fill="#7d5934" />
          <polygon points="76,38 78,12 56,28" fill="#7d5934" />
        </>
      )}
      {b.horns && (
        <>
          <polygon points="34,30 30,8 44,26" fill="#f2e6c9" />
          <polygon points="66,30 70,8 56,26" fill="#f2e6c9" />
        </>
      )}
      <ellipse cx="50" cy="86" rx="26" ry="10" fill={b.body} />
      <circle cx="50" cy="56" r="35" fill={b.body} />
      {isOwl && (
        <>
          <circle cx="36" cy="52" r="14" fill={b.belly} />
          <circle cx="64" cy="52" r="14" fill={b.belly} />
        </>
      )}
      {isPanda && (
        <>
          <ellipse cx="36" cy="52" rx="8" ry="11" fill={b.patch} transform="rotate(25 36 52)" />
          <ellipse cx="64" cy="52" rx="8" ry="11" fill={b.patch} transform="rotate(-25 64 52)" />
        </>
      )}
      {(b.snout || (!b.beak && !isPanda)) && <ellipse cx="50" cy="68" rx="17" ry="12" fill={b.patch && !isPanda ? b.patch : b.belly} />}
      {isOwl && <circle cx="36" cy="52" r="6" fill="#f7c64a" />}
      {isOwl && <circle cx="64" cy="52" r="6" fill="#f7c64a" />}
      <circle cx="37" cy="52" r={isOwl ? 3.6 : 4.6} fill={dark} />
      <circle cx="63" cy="52" r={isOwl ? 3.6 : 4.6} fill={dark} />
      <circle cx="38.4" cy="50.6" r="1.4" fill="#fff" />
      <circle cx="64.4" cy="50.6" r="1.4" fill="#fff" />
      {b.beak ? <polygon points="44,62 56,62 50,73" fill="#f2a33a" /> : <ellipse cx="50" cy="64" rx="3.4" ry="2.4" fill={dark} />}
      {!b.beak && <path d="M44 71 Q50 76 56 71" stroke={dark} strokeWidth="1.8" fill="none" strokeLinecap="round" />}
      {!isPanda && (
        <>
          <ellipse cx="25" cy="66" rx="5" ry="3" fill="#ff9db0" opacity="0.7" />
          <ellipse cx="75" cy="66" rx="5" ry="3" fill="#ff9db0" opacity="0.7" />
        </>
      )}
    </svg>
  );
}

export function PetThumb({ sp, animated = false, className = "" }: { sp: Species; animated?: boolean; className?: string }) {
  const [stage, setStage] = useState<0 | 1 | 2>(0);
  if (sp.kind === "original" || stage === 2) {
    return (
      <div className={className}>
        <Original sp={sp.kind === "original" ? sp : { ...sp, body: { body: sp.color, belly: "#fff", ears: "round", tail: "stub" } }} />
      </div>
    );
  }
  const dex = sp.dex!;
  const src = animated && stage === 0 ? animatedUrl(dex) : artworkUrl(dex);
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <img
        src={src}
        alt={sp.name}
        loading="lazy"
        draggable={false}
        onError={() => setStage((s) => (s === 0 ? 1 : 2))}
        className="max-h-full max-w-full object-contain"
        style={stage === 0 && animated ? { imageRendering: "pixelated" } : undefined}
      />
    </div>
  );
}
