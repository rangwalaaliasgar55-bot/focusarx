import { useState, type ReactNode } from "react";
import { BarChart3, Coins, LayoutDashboard, ListChecks, Menu, Moon, PawPrint, SlidersHorizontal, Sun, Swords, Target, Timer as TimerIcon, X } from "lucide-react";
import { navigate, useRoute } from "../lib/router";
import { setSetting, useApp, userLevel } from "../lib/store";
import { SPECIES_BY_ID } from "../lib/pets";
import { MODE_LABEL, useTimer } from "../lib/timer";
import { clockText } from "./timer/Faces";
import { useToasts, dismiss } from "../lib/toast";
import { BrandLockup, Progress } from "./ui";
import { PetThumb } from "./PetThumb";
import { cn } from "../utils/cn";

export const NAV = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard },
  { to: "/timer", label: "Timer", icon: TimerIcon },
  { to: "/tasks", label: "Tasks", icon: ListChecks },
  { to: "/pets", label: "Companions", icon: PawPrint },
  { to: "/battle", label: "Battle", icon: Swords },
  { to: "/missions", label: "Missions", icon: Target },
  { to: "/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/settings", label: "Settings", icon: SlidersHorizontal },
];

const MOBILE = ["/", "/timer", "/pets", "/battle", "/tasks"];

function NavLink({ to, label, icon: Icon, active, onClick }: { to: string; label: string; icon: typeof LayoutDashboard; active: boolean; onClick?: () => void }) {
  return (
    <a
      href={`#${to}`}
      onClick={onClick}
      aria-current={active ? "page" : undefined}
      className={cn(
        "group relative flex h-10 items-center gap-3 rounded-[10px] px-3 text-sm font-medium transition-colors duration-150",
        active ? "bg-s2 text-fg" : "text-muted hover:bg-s2/70 hover:text-fg",
      )}
    >
      {active && <span className="absolute left-0 top-2.5 h-5 w-[3px] rounded-full bg-brand" />}
      <Icon size={17} strokeWidth={active ? 2.2 : 1.9} className={active ? "text-brand-strong" : ""} />
      {label}
    </a>
  );
}

function Sidebar({ path, onNav }: { path: string; onNav?: () => void }) {
  const active = useApp((s) => s.activePet);
  const pet = useApp((s) => s.pets.find((p) => p.id === s.activePet));
  const sp = SPECIES_BY_ID[active];
  return (
    <div className="flex h-full flex-col gap-6 px-3 py-5">
      <div className="px-2">
        <BrandLockup />
      </div>
      <nav className="flex flex-col gap-0.5" aria-label="Primary">
        {NAV.map((n) => (
          <NavLink key={n.to} {...n} active={path === n.to} onClick={onNav} />
        ))}
      </nav>
      {sp && pet && (
        <a
          href="#/pets"
          onClick={onNav}
          className="mt-auto flex items-center gap-3 rounded-[14px] border border-line bg-s1 p-2.5 transition-colors hover:bg-s2"
        >
          <PetThumb sp={sp} className="h-12 w-12 shrink-0 rounded-[10px] bg-s2 p-1" />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[13px] font-semibold">{sp.name}</div>
            <div className="text-[11px] text-subtle">Level {pet.level} · active</div>
            <Progress value={pet.xp / (50 + pet.level * 35)} height={3} className="mt-1.5" />
          </div>
        </a>
      )}
    </div>
  );
}

function LivePill() {
  const t = useTimer();
  if (t.status === "idle") return null;
  const paused = t.status === "paused";
  return (
    <a
      href="#/timer"
      className={cn(
        "hidden h-9 items-center gap-2 rounded-full border px-3 text-[13px] font-medium sm:flex",
        paused ? "border-warn/40 bg-warn-soft text-warn" : "border-brand/40 bg-brand-soft text-brand-strong",
      )}
    >
      <span className={cn("h-1.5 w-1.5 rounded-full", paused ? "bg-warn" : "bg-brand anim-tick")} />
      {MODE_LABEL[t.mode]}
      <span className="tnum font-semibold">{clockText(t.secondsLeft)}</span>
    </a>
  );
}

function Toasts() {
  const items = useToasts();
  return (
    <div className="pointer-events-none fixed bottom-20 right-4 z-[80] flex w-[min(360px,calc(100vw-2rem))] flex-col gap-2 lg:bottom-6">
      {items.map((t) => (
        <div
          key={t.id}
          className="anim-rise pointer-events-auto flex items-start gap-3 rounded-[12px] border border-line-strong bg-s3 p-3 shadow-[var(--shadow-float)]"
        >
          <span
            className="mt-1.5 h-2 w-2 shrink-0 rounded-full"
            style={{ background: t.tone === "ok" ? "var(--success)" : t.tone === "bad" ? "var(--danger)" : t.tone === "warn" ? "var(--warning)" : "var(--brand-500)" }}
          />
          <div className="min-w-0 flex-1">
            <div className="text-[13px] font-medium">{t.text}</div>
            {t.detail && <div className="mt-0.5 text-[12px] text-muted">{t.detail}</div>}
          </div>
          <button aria-label="Dismiss" onClick={() => dismiss(t.id)} className="text-subtle hover:text-fg">
            <X size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const path = useRoute();
  const [open, setOpen] = useState(false);
  const coins = useApp((s) => s.coins);
  const xp = useApp((s) => s.xp);
  const theme = useApp((s) => s.settings.theme);
  const lv = userLevel(xp);
  const t = useTimer();
  const focusing = t.status === "running" && t.mode === "focus";

  return (
    <div className="min-h-full">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[240px] border-r border-line bg-bg lg:block">
        <Sidebar path={path} />
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/55" onClick={() => setOpen(false)} />
          <aside className="anim-rise absolute inset-y-0 left-0 w-[264px] border-r border-line bg-bg">
            <button aria-label="Close menu" className="absolute right-3 top-4 text-muted" onClick={() => setOpen(false)}>
              <X size={18} />
            </button>
            <Sidebar path={path} onNav={() => setOpen(false)} />
          </aside>
        </div>
      )}

      <div className="lg:pl-[240px]">
        <header className="sticky top-0 z-20 flex h-14 items-center gap-3 border-b border-line bg-bg/85 px-4 backdrop-blur-md sm:px-6">
          <button aria-label="Open menu" className="grid h-9 w-9 place-items-center rounded-[10px] text-muted hover:bg-s2 lg:hidden" onClick={() => setOpen(true)}>
            <Menu size={19} />
          </button>
          <div className="lg:hidden">
            <BrandLockup />
          </div>
          <div className="ml-auto flex items-center gap-2">
            <LivePill />
            <div className="flex h-9 items-center gap-1.5 rounded-full border border-line bg-s1 px-3 text-[13px] font-semibold" title="Focus coins">
              <Coins size={14} className="text-gold" />
              <span className="tnum">{coins.toLocaleString()}</span>
            </div>
            <div className="hidden h-9 items-center gap-2.5 rounded-full border border-line bg-s1 pl-3 pr-3.5 text-[13px] sm:flex" title={`${lv.into} / ${lv.need} XP to next level`}>
              <span className="font-semibold">Lv {lv.level}</span>
              <Progress value={lv.pct} className="w-16" height={4} />
            </div>
            <button
              aria-label="Toggle theme"
              onClick={() => setSetting("theme", theme === "dark" ? "light" : "dark")}
              className="grid h-9 w-9 place-items-center rounded-full border border-line bg-s1 text-muted transition-colors hover:text-fg"
            >
              {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            </button>
          </div>
        </header>

        <main key={path} className="anim-rise mx-auto w-full max-w-[1180px] px-4 pb-28 pt-6 sm:px-6 lg:pb-14">
          {children}
        </main>
      </div>

      {/* mobile bottom nav — hidden while a focus block runs, so nothing competes with the timer */}
      {!focusing && (
        <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md lg:hidden" aria-label="Mobile">
          <div className="mx-auto grid max-w-md grid-cols-5">
            {NAV.filter((n) => MOBILE.includes(n.to)).map((n) => {
              const Icon = n.icon;
              const active = path === n.to;
              return (
                <button
                  key={n.to}
                  onClick={() => navigate(n.to)}
                  className={cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[10.5px] font-medium", active ? "text-brand-strong" : "text-subtle")}
                >
                  <Icon size={19} strokeWidth={active ? 2.3 : 1.8} />
                  {n.to === "/pets" ? "Pets" : n.label}
                </button>
              );
            })}
          </div>
        </nav>
      )}
      <Toasts />
    </div>
  );
}
