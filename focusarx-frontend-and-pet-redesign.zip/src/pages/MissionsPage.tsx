import { Award, Check, Coins } from "lucide-react";
import { claimReward, useApp } from "../lib/store";
import { computeAchievements, computeMissions, type Mission } from "../lib/missions";
import { Btn, PageHead, Panel, Progress } from "../components/ui";
import { toast } from "../lib/toast";
import { cn } from "../utils/cn";

function Row({ m }: { m: Mission }) {
  const done = m.progress >= m.goal;
  return (
    <div className="flex items-center gap-4 px-5 py-4">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className={cn("text-sm font-semibold", m.claimed && "text-subtle")}>{m.title}</span>
          {m.claimed && <Check size={14} className="text-ok" />}
        </div>
        <div className="text-[12.5px] text-muted">{m.desc}</div>
        <div className="mt-2.5 flex items-center gap-3">
          <Progress value={m.progress / m.goal} className="max-w-[320px]" color={done ? "var(--success)" : undefined} />
          <span className="tnum text-[12px] text-subtle">
            {m.progress}/{m.goal} {m.unit}
          </span>
        </div>
      </div>
      <div className="hidden text-right text-[12px] text-muted sm:block">
        <div className="flex items-center justify-end gap-1 font-semibold text-fg tnum">
          <Coins size={12} className="text-gold" />
          {m.coins}
        </div>
        <div className="tnum">{m.xp} XP</div>
      </div>
      <Btn
        size="sm"
        variant={done && !m.claimed ? "primary" : "outline"}
        disabled={!done || m.claimed}
        onClick={() => {
          claimReward(m.key, m.coins, m.xp);
          toast(`Claimed ${m.title}`, "ok", `+${m.coins} coins, +${m.xp} XP`);
        }}
      >
        {m.claimed ? "Claimed" : "Claim"}
      </Btn>
    </div>
  );
}

export function MissionsPage() {
  const state = useApp((s) => s);
  const missions = computeMissions(state);
  const ach = computeAchievements(state);
  const done = ach.filter((a) => a.progress >= a.goal).length;

  return (
    <div>
      <PageHead title="Missions" sub="Daily missions reset at midnight, weekly ones on Monday. Rewards go straight to your wallet." />
      <div className="grid gap-5 lg:grid-cols-2">
        {(["daily", "weekly"] as const).map((p) => (
          <Panel key={p} className="overflow-hidden">
            <div className="border-b border-line px-5 py-3.5">
              <div className="eyebrow">{p === "daily" ? "Today" : "This week"}</div>
            </div>
            <div className="divide-y divide-line">
              {missions
                .filter((m) => m.period === p)
                .map((m) => (
                  <Row key={m.key} m={m} />
                ))}
            </div>
          </Panel>
        ))}
      </div>

      <div className="mb-4 mt-9 flex items-end justify-between">
        <div>
          <div className="eyebrow">Achievements</div>
          <div className="mt-1 text-sm text-muted">
            {done} of {ach.length} unlocked
          </div>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {ach.map((a) => {
          const ok = a.progress >= a.goal;
          return (
            <div key={a.id} className={cn("flex gap-3.5 rounded-[14px] border p-4", ok ? "border-gold/40 bg-s1" : "border-line bg-s1")}>
              <div className={cn("grid h-10 w-10 shrink-0 place-items-center rounded-[10px]", ok ? "bg-warn-soft text-gold" : "bg-s2 text-subtle")}>
                <Award size={19} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold">{a.title}</div>
                <div className="text-[12px] text-muted">{a.desc}</div>
                <Progress value={a.progress / a.goal} className="mt-2.5" height={4} color={ok ? "var(--gold)" : undefined} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
