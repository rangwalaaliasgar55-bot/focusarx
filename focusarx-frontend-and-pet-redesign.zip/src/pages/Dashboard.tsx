import { useMemo } from "react";
import { ArrowRight, Flame, Play, Timer as TimerIcon, Trophy, Gauge, Layers } from "lucide-react";
import { claimReward, clearDemo, dayKey, minutesByDay, streakOf, toggleTask, useApp, userLevel } from "../lib/store";
import { SPECIES_BY_ID } from "../lib/pets";
import { computeMissions } from "../lib/missions";
import { MODE_LABEL, start, useTimer } from "../lib/timer";
import { navigate } from "../lib/router";
import { BarChart, RingProgress } from "../components/charts";
import { PetStage } from "../components/pet3d/Scenes";
import { clockText } from "../components/timer/Faces";
import { Btn, Panel, Progress, Stat, Tag, Empty } from "../components/ui";
import { toast } from "../lib/toast";
import { cn } from "../utils/cn";

function greeting() {
  const h = new Date().getHours();
  return h < 5 ? "Still up" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
}

export function Dashboard() {
  const state = useApp((s) => s);
  const t = useTimer();
  const { sessions, tasks, settings, activePet, pets, seeded } = state;
  const species = SPECIES_BY_ID[activePet];
  const owned = pets.find((p) => p.id === activePet);

  const m = useMemo(() => {
    const byDay = minutesByDay(sessions);
    const now = new Date();
    const week = Array.from({ length: 7 }).map((_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - (6 - i));
      return { label: d.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 3), value: byDay.get(dayKey(d.getTime())) ?? 0, sub: d.toLocaleDateString(undefined, { month: "short", day: "numeric" }), highlight: i === 6 };
    });
    const today = byDay.get(dayKey(now.getTime())) ?? 0;
    const weekTotal = week.reduce((a, b) => a + b.value, 0);
    const weekSessions = sessions.filter((s) => now.getTime() - s.end < 7 * 86400000);
    const avg = weekSessions.length ? Math.round(weekSessions.reduce((a, s) => a + s.score, 0) / weekSessions.length) : 0;
    return { week, today, weekTotal, avg, streak: streakOf(sessions), count: weekSessions.length };
  }, [sessions]);

  const missions = computeMissions(state).filter((x) => x.period === "daily");
  const open = tasks.filter((x) => !x.done).slice(0, 4);
  const recent = [...sessions].sort((a, b) => b.end - a.end).slice(0, 5);
  const lv = userLevel(state.xp);
  const left = Math.max(0, settings.dailyGoal - m.today);
  const live = t.status !== "idle";

  return (
    <div className="flex flex-col gap-5">
      {seeded && sessions.some((s) => s.demo) && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-[12px] border border-line bg-s1 px-4 py-2.5 text-[13px]">
          <span className="text-muted">You're looking at three weeks of sample history so every chart has something to show.</span>
          <button className="font-medium text-brand-strong hover:underline" onClick={clearDemo}>
            Clear sample data
          </button>
        </div>
      )}

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_380px]">
        <Panel className="flex flex-col justify-between p-6 sm:p-8">
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div className="max-w-md">
              <div className="eyebrow">{new Date().toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}</div>
              <h1 className="mt-3 font-display text-[44px] leading-[1.02] tracking-tight sm:text-[52px]">
                {greeting()},
                <br />
                <span className="italic text-brand-strong">{settings.name}.</span>
              </h1>
              <p className="mt-4 text-[15px] text-muted">
                {left > 0 ? (
                  <>
                    <span className="tnum font-semibold text-fg">{left} minutes</span> to reach today's goal of {settings.dailyGoal}.
                  </>
                ) : (
                  <>Daily goal reached — everything from here is a bonus.</>
                )}{" "}
                {m.streak > 0 && <>You're on a {m.streak}-day streak.</>}
              </p>
            </div>
            <RingProgress value={m.today / settings.dailyGoal} size={132} stroke={10} color={m.today >= settings.dailyGoal ? "var(--success)" : "var(--brand-500)"}>
              <div className="tnum text-[26px] font-semibold leading-none">{Math.round((m.today / settings.dailyGoal) * 100)}%</div>
              <div className="mt-1 text-[11px] text-subtle tnum">
                {m.today}/{settings.dailyGoal}m
              </div>
            </RingProgress>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            {live ? (
              <Btn variant="primary" size="lg" onClick={() => navigate("/timer")}>
                <TimerIcon size={18} /> Back to timer · <span className="tnum">{clockText(t.secondsLeft)}</span>
              </Btn>
            ) : (
              <Btn
                variant="primary"
                size="lg"
                onClick={() => {
                  navigate("/timer");
                  start();
                }}
              >
                <Play size={17} fill="currentColor" /> Start a {settings.focusMin}-minute block
              </Btn>
            )}
            {live && <Tag color="var(--brand-500)">{MODE_LABEL[t.mode]} {t.status === "paused" ? "paused" : "running"}</Tag>}
            <Btn variant="ghost" size="lg" onClick={() => navigate("/tasks")}>
              Plan tasks <ArrowRight size={16} />
            </Btn>
          </div>
        </Panel>

        <Panel className="relative overflow-hidden">
          <div className="stage-bg">
            <PetStage species={species} state={t.status === "running" && t.mode === "focus" ? "focus" : "idle"} className="h-[290px] w-full" />
          </div>
          <div className="flex items-center justify-between gap-3 border-t border-line p-4">
            <div>
              <div className="text-[15px] font-semibold">{species.name}</div>
              <div className="text-[12px] text-subtle">Level {owned?.level} · {owned ? owned.wins : 0} battle wins</div>
            </div>
            <Btn size="sm" onClick={() => navigate("/pets")}>
              Companions <ArrowRight size={14} />
            </Btn>
          </div>
        </Panel>
      </div>

      <Panel className="grid grid-cols-2 divide-line sm:grid-cols-3 lg:grid-cols-6 lg:divide-x [&>*]:border-b [&>*]:border-line lg:[&>*]:border-b-0">
        <Stat label="Today" value={`${m.today}m`} sub={`goal ${settings.dailyGoal}m`} icon={<TimerIcon size={13} />} />
        <Stat label="Streak" value={`${m.streak}d`} sub={m.streak ? "keep it alive" : "start today"} icon={<Flame size={13} />} />
        <Stat label="This week" value={`${(m.weekTotal / 60).toFixed(1)}h`} sub={`${m.count} blocks`} icon={<Layers size={13} />} />
        <Stat label="Focus score" value={m.avg || "–"} sub="7-day average" icon={<Gauge size={13} />} />
        <Stat label="Level" value={lv.level} sub={`${lv.into}/${lv.need} XP`} icon={<Trophy size={13} />} />
        <Stat label="Battles" value={`${state.battle.wins}–${state.battle.losses}`} sub={`streak ${state.battle.streak}`} icon={<Trophy size={13} />} />
      </Panel>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
        <Panel className="p-5">
          <div className="mb-5 flex items-end justify-between">
            <div>
              <div className="eyebrow">Last 7 days</div>
              <div className="tnum mt-1 text-[22px] font-semibold tracking-tight">{(m.weekTotal / 60).toFixed(1)} hours focused</div>
            </div>
            <Btn size="sm" variant="ghost" onClick={() => navigate("/analytics")}>
              Analytics <ArrowRight size={14} />
            </Btn>
          </div>
          <BarChart bars={m.week} goal={settings.dailyGoal} />
        </Panel>

        <Panel className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <div className="eyebrow">Daily missions</div>
            <button className="text-[12px] font-medium text-brand-strong hover:underline" onClick={() => navigate("/missions")}>
              All
            </button>
          </div>
          <div className="flex flex-col gap-4">
            {missions.map((x) => {
              const done = x.progress >= x.goal;
              return (
                <div key={x.key}>
                  <div className="flex items-center justify-between gap-2 text-[13px]">
                    <span className={cn("font-medium", x.claimed && "text-subtle line-through")}>{x.desc}</span>
                    {done && !x.claimed ? (
                      <button
                        className="rounded-full bg-brand-soft px-2.5 py-0.5 text-[11px] font-semibold text-brand-strong hover:opacity-80"
                        onClick={() => {
                          claimReward(x.key, x.coins, x.xp);
                          toast(`Claimed +${x.coins} coins`, "ok");
                        }}
                      >
                        Claim +{x.coins}
                      </button>
                    ) : (
                      <span className="tnum text-[12px] text-subtle">
                        {x.progress}/{x.goal}
                      </span>
                    )}
                  </div>
                  <Progress value={x.progress / x.goal} className="mt-1.5" height={4} color={done ? "var(--success)" : undefined} />
                </div>
              );
            })}
          </div>
        </Panel>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <Panel className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <div className="eyebrow">Up next</div>
            <button className="text-[12px] font-medium text-brand-strong hover:underline" onClick={() => navigate("/tasks")}>
              Manage
            </button>
          </div>
          {open.length === 0 ? (
            <Empty title="Nothing queued" hint="Add a task so each block has a purpose." action={<Btn size="sm" onClick={() => navigate("/tasks")}>Add task</Btn>} />
          ) : (
            <ul className="divide-y divide-line">
              {open.map((x) => (
                <li key={x.id} className="flex items-center gap-3 py-2.5">
                  <button
                    aria-label={`Complete ${x.title}`}
                    onClick={() => toggleTask(x.id)}
                    className="grid h-[18px] w-[18px] shrink-0 place-items-center rounded-full border border-line-strong transition-colors hover:border-brand"
                  />
                  <span className="min-w-0 flex-1 truncate text-sm">{x.title}</span>
                  <span className="tnum text-[12px] text-subtle">
                    {x.spent}/{x.est}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </Panel>

        <Panel className="p-5">
          <div className="eyebrow mb-3">Recent blocks</div>
          {recent.length === 0 ? (
            <Empty title="No sessions yet" hint="Finish a focus block and it will show up here." />
          ) : (
            <ul className="divide-y divide-line">
              {recent.map((s) => (
                <li key={s.id} className="flex items-center gap-3 py-2.5 text-sm">
                  <span className="tnum w-12 font-semibold">{s.minutes}m</span>
                  <span className="min-w-0 flex-1 truncate text-muted">{s.label ?? "Free focus"}</span>
                  <span className="text-[12px] text-subtle">{new Date(s.end).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</span>
                  <Tag color={s.score >= 90 ? "var(--success)" : s.score >= 75 ? "var(--brand-500)" : "var(--warning)"}>{s.score}</Tag>
                </li>
              ))}
            </ul>
          )}
        </Panel>
      </div>
    </div>
  );
}
