import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Coins, Hand, Lock, Utensils } from "lucide-react";
import { adoptPet, feedPet, playWithPet, setActivePet, useApp } from "../lib/store";
import { levelProgress, moodOf, movesFor, RARITY_META, SHOP_SPECIES, SPECIES_BY_ID, statsFor, TYPE_COLOR, xpForLevel, type Species } from "../lib/pets";
import { PetStage } from "../components/pet3d/Scenes";
import type { PetState } from "../components/pet3d/PetActor";
import { PetThumb } from "../components/PetThumb";
import { Btn, PageHead, Panel, Progress, Segmented, Tag } from "../components/ui";
import { toast } from "../lib/toast";
import { cn } from "../utils/cn";

type Filter = "all" | "owned" | "pokemon" | "original";

const MOTIONS: { id: PetState; label: string }[] = [
  { id: "idle", label: "Idle" },
  { id: "focus", label: "Focus" },
  { id: "break", label: "Break" },
  { id: "celebrate", label: "Celebrate" },
  { id: "sleep", label: "Sleep" },
  { id: "attack", label: "Attack" },
  { id: "hurt", label: "Hurt" },
];

export function TypeChip({ t }: { t: string }) {
  return (
    <span className="rounded-full px-2 py-0.5 text-[11px] font-semibold capitalize text-white" style={{ background: TYPE_COLOR[t as keyof typeof TYPE_COLOR] }}>
      {t}
    </span>
  );
}

export function PetsPage() {
  const pets = useApp((s) => s.pets);
  const active = useApp((s) => s.activePet);
  const coins = useApp((s) => s.coins);
  const [sel, setSel] = useState(active);
  const [filter, setFilter] = useState<Filter>("all");
  const [motion, setMotion] = useState<{ state: PetState; key: number }>({ state: "idle", key: 0 });
  const [burst, setBurst] = useState(0);
  const timer = useRef<number | null>(null);

  const sp: Species = SPECIES_BY_ID[sel];
  const owned = pets.find((p) => p.id === sel);
  const level = owned?.level ?? 1;
  const stats = statsFor(sp, level);
  const moves = movesFor(sp);
  const rar = RARITY_META[sp.rarity];

  const play = (state: PetState) => {
    setMotion({ state, key: Date.now() });
    if (timer.current) window.clearTimeout(timer.current);
    if (["celebrate", "attack", "hurt", "happy", "eat"].includes(state)) {
      timer.current = window.setTimeout(() => setMotion({ state: "idle", key: Date.now() }), state === "celebrate" ? 3600 : 1400);
    }
  };
  useEffect(() => () => void (timer.current && window.clearTimeout(timer.current)), []);

  const list = useMemo(() => {
    return SHOP_SPECIES.filter((s) => {
      if (filter === "owned") return pets.some((p) => p.id === s.id);
      if (filter === "pokemon") return s.kind === "pokemon";
      if (filter === "original") return s.kind === "original";
      return true;
    });
  }, [filter, pets]);

  const mood = owned ? moodOf(owned) : null;

  return (
    <div>
      <PageHead
        title="Companions"
        sub="Every focus minute feeds your active companion. Adopt new ones with coins, level them up, then send them into battle."
        right={
          <div className="flex h-9 items-center gap-1.5 rounded-full border border-line bg-s1 px-3.5 text-[13px] font-semibold">
            <Coins size={14} className="text-gold" />
            <span className="tnum">{coins.toLocaleString()}</span>
          </div>
        }
      />

      <Panel className="grid overflow-hidden lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <div className="stage-bg relative border-b border-line lg:border-b-0 lg:border-r">
          <PetStage species={sp} state={motion.state} stateKey={motion.key} burst={burst} onPoke={() => play("happy")} className="h-[420px] w-full cursor-pointer lg:h-[520px]" />
          <div className="absolute left-4 top-4 flex flex-col gap-2">
            <Tag color={rar.color}>{rar.label}</Tag>
            {sp.kind === "pokemon" && <Tag>Pokémon #{sp.dex}</Tag>}
          </div>
          <div className="absolute inset-x-3 bottom-3 flex flex-wrap justify-center gap-1.5">
            {MOTIONS.map((m) => (
              <button
                key={m.id}
                onClick={() => play(m.id)}
                className={cn(
                  "h-7 rounded-full border px-3 text-[12px] font-medium backdrop-blur transition-colors",
                  motion.state === m.id ? "border-brand bg-brand-soft text-brand-strong" : "border-line-strong bg-s1/80 text-muted hover:text-fg",
                )}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col p-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-[40px] leading-none tracking-tight">{sp.name}</h2>
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {sp.types.map((t) => (
                  <TypeChip key={t} t={t} />
                ))}
              </div>
            </div>
            {owned && mood && <Tag color={mood.tone === "ok" ? "var(--success)" : mood.tone === "warn" ? "var(--warning)" : "var(--danger)"}>{mood.label}</Tag>}
          </div>
          <p className="mt-4 text-[14px] text-muted">{sp.blurb}</p>

          <div className="mt-5 grid grid-cols-4 gap-2">
            {(
              [
                ["HP", stats.hp],
                ["ATK", stats.atk],
                ["DEF", stats.def],
                ["SPD", stats.spd],
              ] as const
            ).map(([k, v]) => (
              <div key={k} className="rounded-[10px] border border-line bg-s2 px-3 py-2.5">
                <div className="text-[10.5px] font-semibold tracking-wider text-subtle">{k}</div>
                <div className="tnum text-[20px] font-semibold leading-tight">{v}</div>
              </div>
            ))}
          </div>

          {owned ? (
            <div className="mt-5 grid gap-3">
              <div>
                <div className="mb-1 flex justify-between text-[12px] text-muted">
                  <span>Level {owned.level}</span>
                  <span className="tnum">
                    {owned.xp}/{xpForLevel(owned.level)} XP
                  </span>
                </div>
                <Progress value={levelProgress(owned)} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="mb-1 flex justify-between text-[12px] text-muted">
                    <span>Fed</span>
                    <span className="tnum">{owned.hunger}%</span>
                  </div>
                  <Progress value={owned.hunger / 100} color="var(--warning)" height={5} />
                </div>
                <div>
                  <div className="mb-1 flex justify-between text-[12px] text-muted">
                    <span>Joy</span>
                    <span className="tnum">{owned.joy}%</span>
                  </div>
                  <Progress value={owned.joy / 100} color="var(--success)" height={5} />
                </div>
              </div>
            </div>
          ) : (
            <div className="mt-5 flex items-center gap-2 rounded-[10px] border border-dashed border-line-strong px-3 py-2.5 text-[13px] text-muted">
              <Lock size={14} /> Not adopted yet — preview its motion on the left.
            </div>
          )}

          <div className="mt-5">
            <div className="eyebrow mb-2">Moves</div>
            <div className="grid grid-cols-2 gap-2">
              {moves.map((m) => (
                <div key={m.id} className="rounded-[10px] border border-line px-3 py-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[13px] font-semibold">{m.name}</span>
                    <span className="h-2 w-2 rounded-full" style={{ background: TYPE_COLOR[m.type] }} />
                  </div>
                  <div className="mt-0.5 text-[11px] text-subtle">
                    {m.kind === "heal" ? "Heal" : `${m.power} power`} · {m.cost === 0 ? "free" : `${m.cost} energy`}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-auto flex flex-wrap gap-2 pt-6">
            {owned ? (
              <>
                {active === sel ? (
                  <Btn variant="soft" disabled>
                    <Check size={15} /> Active companion
                  </Btn>
                ) : (
                  <Btn
                    variant="primary"
                    onClick={() => {
                      setActivePet(sel);
                      toast(`${sp.name} is now your companion`, "ok");
                      play("celebrate");
                      setBurst((b) => b + 1);
                    }}
                  >
                    Make active
                  </Btn>
                )}
                <Btn
                  disabled={coins < 15}
                  onClick={() => {
                    if (feedPet(sel)) play("eat");
                    else toast("Not enough coins", "warn");
                  }}
                >
                  <Utensils size={14} /> Feed · 15
                </Btn>
                <Btn
                  onClick={() => {
                    if (playWithPet(sel)) play("happy");
                  }}
                >
                  <Hand size={14} /> Play
                </Btn>
              </>
            ) : (
              <Btn
                variant="primary"
                size="lg"
                disabled={coins < sp.price}
                onClick={() => {
                  if (adoptPet(sel)) {
                    toast(`${sp.name} joined your team`, "ok", `-${sp.price} coins`);
                    play("celebrate");
                    setBurst((b) => b + 1);
                  }
                }}
              >
                <Coins size={16} /> Adopt for {sp.price.toLocaleString()}
              </Btn>
            )}
            {!owned && coins < sp.price && <span className="self-center text-[12px] text-subtle">Need {(sp.price - coins).toLocaleString()} more coins</span>}
          </div>
        </div>
      </Panel>

      <div className="mb-4 mt-8 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="eyebrow">Collection</div>
          <div className="mt-1 text-sm text-muted">
            {pets.length} of {SHOP_SPECIES.length} adopted
          </div>
        </div>
        <Segmented<Filter>
          value={filter}
          onChange={setFilter}
          options={[
            { id: "all", label: "All" },
            { id: "owned", label: "Owned" },
            { id: "pokemon", label: "Pokémon" },
            { id: "original", label: "Original" },
          ]}
        />
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {list.map((s) => {
          const o = pets.find((p) => p.id === s.id);
          const on = sel === s.id;
          return (
            <button
              key={s.id}
              onClick={() => {
                setSel(s.id);
                setMotion({ state: "happy", key: Date.now() });
              }}
              className={cn(
                "group relative flex flex-col overflow-hidden rounded-[14px] border bg-s1 text-left transition-[border-color,transform] duration-150 hover:-translate-y-0.5",
                on ? "border-brand" : "border-line hover:border-line-strong",
              )}
            >
              <div className="relative flex h-[132px] items-center justify-center" style={{ background: `radial-gradient(70% 70% at 50% 60%, color-mix(in srgb, ${s.color} 22%, transparent), transparent)` }}>
                <PetThumb sp={s} className="h-[104px] w-[104px] transition-transform duration-200 group-hover:scale-105" />
                <span className="absolute left-2.5 top-2.5 h-2 w-2 rounded-full" style={{ background: RARITY_META[s.rarity].color }} title={RARITY_META[s.rarity].label} />
                {active === s.id && <span className="absolute right-2.5 top-2.5 rounded-full bg-brand px-2 py-0.5 text-[10px] font-semibold text-white">Active</span>}
              </div>
              <div className="border-t border-line px-3 py-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[13.5px] font-semibold">{s.name}</span>
                  {o ? <span className="text-[11px] text-subtle tnum">Lv {o.level}</span> : <span className="flex items-center gap-1 text-[12px] font-semibold tnum"><Coins size={11} className="text-gold" />{s.price}</span>}
                </div>
                <div className="mt-1.5 flex gap-1">
                  {s.types.map((t) => (
                    <span key={t} className="h-1.5 w-5 rounded-full" style={{ background: TYPE_COLOR[t] }} title={t} />
                  ))}
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
