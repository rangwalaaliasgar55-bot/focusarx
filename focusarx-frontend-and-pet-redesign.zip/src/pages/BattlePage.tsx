import { useEffect, useMemo, useRef, useState } from "react";
import { Coins, Flag, RefreshCw, Swords, Trophy, Zap } from "lucide-react";
import { recordBattle, useApp } from "../lib/store";
import { effectiveness, movesFor, RARITY_META, SHOP_SPECIES, SPECIES_BY_ID, statsFor, TYPE_COLOR, WILD_SPECIES, type Move, type Species } from "../lib/pets";
import { ARENA_POS, ArenaScene, type Impact } from "../components/pet3d/Scenes";
import type { PetState } from "../components/pet3d/PetActor";
import type { Shot } from "../components/pet3d/fx";
import { PetThumb } from "../components/PetThumb";
import { TypeChip } from "./PetsPage";
import { Btn, PageHead, Panel, Tag } from "../components/ui";
import { cn } from "../utils/cn";

interface Foe {
  species: Species;
  level: number;
  tier: "Easy" | "Normal" | "Hard";
  mult: number;
}

const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];

function makeFoes(lv: number): Foe[] {
  const easy = pick(WILD_SPECIES);
  const normalPool = [...WILD_SPECIES, ...SHOP_SPECIES.filter((s) => s.rarity === "rare")].filter((s) => s.id !== easy.id);
  const normal = pick(normalPool);
  const hardPool = SHOP_SPECIES.filter((s) => s.rarity === "epic" || s.rarity === "legendary");
  return [
    { species: easy, level: Math.max(1, lv - 1), tier: "Easy", mult: 0.8 },
    { species: normal, level: lv + 1, tier: "Normal", mult: 1.2 },
    { species: pick(hardPool), level: lv + 3, tier: "Hard", mult: 2 },
  ];
}

function bestAdvantage(a: Species, b: Species) {
  const m = movesFor(a).slice(1, 3);
  return Math.max(...m.map((x) => effectiveness(x.type, b.types)));
}

/* ------------------------------ select screen ------------------------------ */

export function BattlePage() {
  const pets = useApp((s) => s.pets);
  const active = useApp((s) => s.activePet);
  const battle = useApp((s) => s.battle);
  const [sel, setSel] = useState(active);
  const [fight, setFight] = useState<{ pet: string; foe: Foe; n: number } | null>(null);

  const pet = pets.find((p) => p.id === sel) ?? pets[0];
  const sp = SPECIES_BY_ID[pet.id];
  const [foes, setFoes] = useState<Foe[]>(() => makeFoes(pet.level));
  useEffect(() => setFoes(makeFoes(pet.level)), [pet.level, pet.id]);

  if (fight) {
    return (
      <div>
        <PageHead title="Battle" sub="Pick moves, manage energy, and read the type matchup." />
        <Fight key={`${fight.pet}-${fight.foe.species.id}-${fight.n}`} petId={fight.pet} foe={fight.foe} onExit={() => setFight(null)} onAgain={() => setFight({ ...fight, n: fight.n + 1 })} />
      </div>
    );
  }

  const stats = statsFor(sp, pet.level);
  const total = battle.wins + battle.losses;

  return (
    <div>
      <PageHead
        title="Battle"
        sub="Turn-based fights between companions. Energy builds every turn — spend it on heavy moves, or heal when you're low."
        right={
          <div className="flex items-center gap-2 text-[13px]">
            <Tag color="var(--success)">{battle.wins} wins</Tag>
            <Tag color="var(--danger)">{battle.losses} losses</Tag>
            <Tag color="var(--gold)">best streak {battle.best}</Tag>
          </div>
        }
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)]">
        <Panel className="p-5">
          <div className="eyebrow mb-3">Your fighter</div>
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 lg:grid-cols-3 xl:grid-cols-4">
            {pets.map((p) => {
              const s = SPECIES_BY_ID[p.id];
              return (
                <button
                  key={p.id}
                  onClick={() => setSel(p.id)}
                  className={cn("rounded-[12px] border p-2 text-center transition-colors", sel === p.id ? "border-brand bg-brand-soft" : "border-line hover:border-line-strong")}
                >
                  <PetThumb sp={s} className="mx-auto h-14 w-14" />
                  <div className="mt-1 truncate text-[12px] font-semibold">{s.name}</div>
                  <div className="text-[10.5px] text-subtle tnum">Lv {p.level}</div>
                </button>
              );
            })}
          </div>
          <div className="mt-5 rounded-[12px] border border-line bg-s2 p-4">
            <div className="flex items-center justify-between">
              <div className="text-[15px] font-semibold">{sp.name}</div>
              <div className="flex gap-1">
                {sp.types.map((t) => (
                  <TypeChip key={t} t={t} />
                ))}
              </div>
            </div>
            <div className="mt-3 grid grid-cols-4 gap-2 text-center">
              {(
                [
                  ["HP", stats.hp],
                  ["ATK", stats.atk],
                  ["DEF", stats.def],
                  ["SPD", stats.spd],
                ] as const
              ).map(([k, v]) => (
                <div key={k}>
                  <div className="text-[10px] font-semibold tracking-wider text-subtle">{k}</div>
                  <div className="tnum text-[17px] font-semibold">{v}</div>
                </div>
              ))}
            </div>
            <div className="mt-3 space-y-1.5">
              {movesFor(sp).map((m) => (
                <div key={m.id} className="flex items-center justify-between text-[12.5px]">
                  <span className="flex items-center gap-2">
                    <span className="h-2 w-2 rounded-full" style={{ background: TYPE_COLOR[m.type] }} />
                    {m.name}
                  </span>
                  <span className="text-subtle tnum">{m.kind === "heal" ? "heal 30%" : m.power} · {m.cost}⚡</span>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-4 text-[12px] text-subtle">
            Record {battle.wins}–{battle.losses}
            {total > 0 && <> · {Math.round((battle.wins / total) * 100)}% win rate</>}
          </div>
        </Panel>

        <Panel className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <div className="eyebrow">Choose an opponent</div>
            <Btn size="sm" variant="ghost" onClick={() => setFoes(makeFoes(pet.level))}>
              <RefreshCw size={13} /> Reroll
            </Btn>
          </div>
          <div className="flex flex-col gap-3">
            {foes.map((f) => {
              const fs = statsFor(f.species, f.level);
              const adv = bestAdvantage(sp, f.species);
              const threat = bestAdvantage(f.species, sp);
              const coins = Math.round((25 + f.level * 5) * f.mult);
              return (
                <div key={f.tier} className="flex items-center gap-4 rounded-[14px] border border-line p-3 transition-colors hover:border-line-strong">
                  <div className="grid h-[84px] w-[84px] shrink-0 place-items-center rounded-[12px]" style={{ background: `color-mix(in srgb, ${f.species.color} 18%, var(--surface-2))` }}>
                    <PetThumb sp={f.species} className="h-[70px] w-[70px]" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[15px] font-semibold">{f.species.name}</span>
                      <span className="text-[12px] text-subtle tnum">Lv {f.level}</span>
                      <Tag color={f.tier === "Easy" ? "var(--success)" : f.tier === "Normal" ? "var(--warning)" : "var(--danger)"}>{f.tier}</Tag>
                      <Tag color={RARITY_META[f.species.rarity].color}>{RARITY_META[f.species.rarity].label}</Tag>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                      {f.species.types.map((t) => (
                        <TypeChip key={t} t={t} />
                      ))}
                      <span className="text-[12px] text-subtle tnum">· {fs.hp} HP · {fs.atk} ATK</span>
                    </div>
                    <div className="mt-1.5 flex flex-wrap items-center gap-3 text-[12px]">
                      <span className="flex items-center gap-1 text-muted">
                        <Coins size={12} className="text-gold" /> up to {coins}
                      </span>
                      {adv > 1 && <span className="text-ok">You have type advantage</span>}
                      {adv < 1 && <span className="text-warn">Resisted by this type</span>}
                      {threat > 1 && <span className="text-bad">Dangerous matchup</span>}
                    </div>
                  </div>
                  <Btn variant="primary" onClick={() => setFight({ pet: pet.id, foe: f, n: 0 })}>
                    <Swords size={15} /> Fight
                  </Btn>
                </div>
              );
            })}
          </div>

          {battle.log.length > 0 && (
            <div className="mt-6">
              <div className="eyebrow mb-2">Recent fights</div>
              <ul className="divide-y divide-line text-[13px]">
                {battle.log.slice(0, 4).map((l, i) => (
                  <li key={i} className="flex items-center justify-between py-2">
                    <span>
                      {SPECIES_BY_ID[l.pet]?.name} vs {SPECIES_BY_ID[l.foe]?.name ?? l.foe}
                    </span>
                    <span className={l.win ? "font-semibold text-ok" : "font-semibold text-bad"}>{l.win ? "Won" : "Lost"}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Panel>
      </div>
    </div>
  );
}

/* ------------------------------ the fight ------------------------------ */

const wait = (ms: number) => new Promise<void>((r) => window.setTimeout(r, ms));

interface Float {
  id: number;
  side: "p" | "f";
  text: string;
  color: string;
}

function Fight({ petId, foe, onExit, onAgain }: { petId: string; foe: Foe; onExit: () => void; onAgain: () => void }) {
  const pets = useApp((s) => s.pets);
  const owned = pets.find((p) => p.id === petId)!;
  const player = SPECIES_BY_ID[petId];
  const fsp = foe.species;
  const [startLevel] = useState(owned.level);
  const pStats = useMemo(() => statsFor(player, startLevel), [player, startLevel]);
  const fStats = useMemo(() => statsFor(fsp, foe.level), [fsp, foe.level]);
  const moves = useMemo(() => movesFor(player), [player]);

  const H = useRef({ p: pStats.hp, f: fStats.hp });
  const E = useRef({ p: 2, f: 2 });
  const alive = useRef(true);
  const idc = useRef(1);
  const acted = useRef(false);
  const recorded = useRef(false);

  const [hp, setHp] = useState({ p: pStats.hp, f: fStats.hp });
  const [en, setEn] = useState({ p: 2, f: 2 });
  const [turn, setTurn] = useState<"player" | "busy" | "over">("player");
  const [ps, setPs] = useState<PetState>("idle");
  const [fs, setFs] = useState<PetState>("idle");
  const [pk, setPk] = useState(0);
  const [fk, setFk] = useState(0);
  const [shot, setShot] = useState<Shot | null>(null);
  const [impact, setImpact] = useState<Impact | null>(null);
  const [floats, setFloats] = useState<Float[]>([]);
  const [msg, setMsg] = useState(`A wild ${fsp.name} appeared!`);
  const [log, setLog] = useState<string[]>([`A wild ${fsp.name} appeared!`]);
  const [shake, setShake] = useState(false);
  const [result, setResult] = useState<null | { win: boolean; coins: number; xp: number; petXp: number }>(null);
  const [round, setRound] = useState(1);

  useEffect(() => {
    alive.current = true;
    return () => {
      alive.current = false;
    };
  }, []);

  const say = (t: string) => {
    setMsg(t);
    setLog((l) => [t, ...l].slice(0, 40));
  };
  const addFloat = (side: "p" | "f", text: string, color: string) => {
    const id = idc.current++;
    setFloats((f) => [...f, { id, side, text, color }]);
    window.setTimeout(() => setFloats((f) => f.filter((x) => x.id !== id)), 950);
  };

  async function perform(side: "p" | "f", mv: Move): Promise<boolean> {
    const other = side === "p" ? "f" : "p";
    const att = side === "p" ? player : fsp;
    const def = side === "p" ? fsp : player;
    const aS = side === "p" ? pStats : fStats;
    const dS = side === "p" ? fStats : pStats;
    const setA = side === "p" ? setPs : setFs;
    const setD = side === "p" ? setFs : setPs;
    const bumpA = side === "p" ? setPk : setFk;
    const bumpD = side === "p" ? setFk : setPk;
    const from = ARENA_POS[side === "p" ? "player" : "foe"];
    const to = ARENA_POS[side === "p" ? "foe" : "player"];
    const dir = side === "p" ? 1 : -1;
    const color = TYPE_COLOR[mv.type];

    say(`${att.name} used ${mv.name}!`);
    E.current[side] -= mv.cost;
    setEn({ ...E.current });
    setA("attack");
    bumpA((k) => k + 1);
    await wait(mv.kind === "heal" ? 260 : 230);
    if (!alive.current) return false;

    if (mv.kind === "heal") {
      const max = side === "p" ? pStats.hp : fStats.hp;
      const amt = Math.round(max * 0.3);
      H.current[side] = Math.min(max, H.current[side] + amt);
      setHp({ ...H.current });
      setImpact({ key: idc.current++, side: side === "p" ? "player" : "foe", color: "#4ade80", kind: "heal" });
      addFloat(side, `+${amt}`, "var(--success)");
      setA("happy");
      bumpA((k) => k + 1);
      await wait(900);
      if (!alive.current) return false;
      setA("idle");
      return false;
    }

    setShot({ id: idc.current++, from: [from[0] + dir * 0.6, 1.15, from[2]], to: [to[0], 1.0, to[2]], color, fx: mv.fx });
    await wait(400);
    if (!alive.current) return false;
    setA("idle");

    if (Math.random() < 0.06) {
      say("…but it missed!");
      addFloat(other, "miss", "var(--foreground-muted)");
      await wait(600);
      return false;
    }

    const eff = effectiveness(mv.type, def.types);
    const crit = Math.random() < 0.09 ? 1.5 : 1;
    const stab = att.types.includes(mv.type) ? 1.25 : 1;
    const rnd = 0.9 + Math.random() * 0.2;
    const dmg = Math.max(1, Math.round(mv.power * (aS.atk / dS.def) * 0.85 * eff * stab * crit * rnd));
    H.current[other] = Math.max(0, H.current[other] - dmg);
    setHp({ ...H.current });
    setD("hurt");
    bumpD((k) => k + 1);
    setImpact({ key: idc.current++, side: side === "p" ? "foe" : "player", color, kind: "hit" });
    addFloat(other, `-${dmg}`, crit > 1 ? "var(--warning)" : "var(--danger)");
    setShake(true);
    window.setTimeout(() => setShake(false), 320);
    if (crit > 1) say("A critical hit!");
    else if (eff > 1) say("It's super effective!");
    else if (eff < 1) say("It's not very effective…");
    await wait(800);
    if (!alive.current) return false;
    if (H.current[other] <= 0) {
      setD("faint");
      bumpD((k) => k + 1);
      say(`${def.name} fainted!`);
      return true;
    }
    setD("idle");
    return false;
  }

  function foeChoose(): Move {
    const fm = movesFor(fsp);
    const e = E.current.f;
    const low = H.current.f < fStats.hp * 0.35;
    if (low && e >= 3 && Math.random() < 0.45) return fm[3];
    if (e >= 4 && Math.random() < 0.7) return fm[2];
    if (e >= 2 && Math.random() < 0.65) return fm[1];
    return fm[0];
  }

  async function finish(win: boolean) {
    setTurn("over");
    const coins = win ? Math.round((25 + foe.level * 5) * foe.mult) : 5;
    const xp = win ? Math.round((30 + foe.level * 4) * foe.mult) : 8;
    const petXp = win ? Math.round((35 + foe.level * 6) * foe.mult) : 10;
    if (!recorded.current) {
      recorded.current = true;
      recordBattle(win, petId, fsp.id, coins, xp, petXp);
    }
    await wait(500);
    if (!alive.current) return;
    if (win) {
      setPs("celebrate");
      setPk((k) => k + 1);
      setImpact({ key: idc.current++, side: "foe", color: "#ffd166", kind: "hit" });
    } else {
      setFs("happy");
      setFk((k) => k + 1);
    }
    await wait(900);
    if (alive.current) setResult({ win, coins, xp, petXp });
  }

  async function choose(mv: Move) {
    if (turn !== "player" || E.current.p < mv.cost) return;
    acted.current = true;
    setTurn("busy");
    const down = await perform("p", mv);
    if (!alive.current) return;
    if (down) return finish(true);
    await wait(250);
    if (!alive.current) return;
    const fm = foeChoose();
    const down2 = await perform("f", fm);
    if (!alive.current) return;
    if (down2) return finish(false);
    E.current.p = Math.min(6, E.current.p + 1 + (mv.id === "tackle" ? 1 : 0));
    E.current.f = Math.min(6, E.current.f + 1 + (fm.id === "tackle" ? 1 : 0));
    setEn({ ...E.current });
    setRound((r) => r + 1);
    setTurn("player");
    say("Your move.");
  }

  function forfeit() {
    if (turn === "busy" || turn === "over") return;
    if (acted.current && !recorded.current) {
      recorded.current = true;
      recordBattle(false, petId, fsp.id, 0, 0, 5);
    }
    onExit();
  }

  const pPct = hp.p / pStats.hp;
  const fPct = hp.f / fStats.hp;
  const hpColor = (v: number) => (v > 0.5 ? "var(--success)" : v > 0.25 ? "var(--warning)" : "var(--danger)");

  return (
    <Panel className="overflow-hidden">
      <div className={cn("stage-bg relative", shake && "anim-shake")}>
        <ArenaScene
          player={player}
          foe={fsp}
          playerState={ps}
          foeState={fs}
          playerKey={pk}
          foeKey={fk}
          shot={shot}
          impact={impact}
          className="h-[380px] w-full sm:h-[470px]"
        />

        {/* HUD */}
        <div className="pointer-events-none absolute inset-x-3 top-3 flex items-start justify-between gap-3 sm:inset-x-5 sm:top-5">
          <HudCard name={player.name} level={startLevel} hp={hp.p} max={pStats.hp} pct={pPct} color={hpColor(pPct)} types={player.types} />
          <HudCard name={fsp.name} level={foe.level} hp={hp.f} max={fStats.hp} pct={fPct} color={hpColor(fPct)} types={fsp.types} align="right" />
        </div>

        {floats.map((f) => (
          <span key={f.id} className="dmg-float text-[24px]" style={{ left: f.side === "p" ? "30%" : "70%", top: f.side === "p" ? "48%" : "34%", color: f.color }}>
            {f.text}
          </span>
        ))}

        <div className="pointer-events-none absolute inset-x-0 bottom-3 flex justify-center px-4">
          <div key={msg} className="anim-pop rounded-full border border-line-strong bg-s1/90 px-4 py-1.5 text-[13px] font-medium shadow-[var(--shadow-float)] backdrop-blur">
            {msg}
          </div>
        </div>

        {result && (
          <div className="anim-pop absolute inset-0 grid place-items-center bg-black/55 p-4 backdrop-blur-[2px]">
            <div className="w-full max-w-sm rounded-[18px] border border-line-strong bg-s1 p-6 text-center shadow-[var(--shadow-float)]">
              <div className={cn("mx-auto mb-3 grid h-12 w-12 place-items-center rounded-full", result.win ? "bg-ok-soft text-ok" : "bg-bad-soft text-bad")}>
                {result.win ? <Trophy size={22} /> : <Flag size={22} />}
              </div>
              <div className="font-display text-[34px] leading-none">{result.win ? "Victory" : "Defeated"}</div>
              <p className="mt-2 text-[13px] text-muted">
                {result.win ? `${player.name} beat ${fsp.name} in ${round} round${round > 1 ? "s" : ""}.` : `${fsp.name} was too strong this time.`}
              </p>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                {[
                  ["Coins", result.coins],
                  ["XP", result.xp],
                  ["Pet XP", result.petXp],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-[10px] bg-s2 py-2">
                    <div className="tnum text-[18px] font-semibold">+{v}</div>
                    <div className="text-[11px] text-subtle">{k}</div>
                  </div>
                ))}
              </div>
              <div className="mt-5 flex gap-2">
                <Btn className="flex-1" onClick={onExit}>
                  Back
                </Btn>
                <Btn variant="primary" className="flex-1" onClick={onAgain}>
                  Rematch
                </Btn>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* controls */}
      <div className="border-t border-line p-4 sm:p-5">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="eyebrow">Energy</span>
            <div className="flex gap-1" aria-label={`${en.p} of 6 energy`}>
              {Array.from({ length: 6 }).map((_, i) => (
                <span key={i} className="grid h-5 w-5 place-items-center rounded-[6px] transition-colors" style={{ background: i < en.p ? "var(--brand-500)" : "var(--surface-3)" }}>
                  <Zap size={11} className={i < en.p ? "text-white" : "text-subtle"} fill={i < en.p ? "currentColor" : "none"} />
                </span>
              ))}
            </div>
            <span className="text-[12px] text-subtle">Round {round}</span>
          </div>
          <Btn size="sm" variant="ghost" onClick={forfeit} disabled={turn === "busy" || turn === "over"}>
            <Flag size={13} /> {acted.current ? "Forfeit" : "Leave"}
          </Btn>
        </div>

        <div className="grid grid-cols-2 gap-2.5 lg:grid-cols-4">
          {moves.map((m) => {
            const can = turn === "player" && en.p >= m.cost;
            const eff = m.kind === "attack" ? effectiveness(m.type, fsp.types) : 1;
            return (
              <button
                key={m.id}
                disabled={!can}
                onClick={() => choose(m)}
                className={cn(
                  "group relative overflow-hidden rounded-[12px] border border-line bg-s2 p-3 text-left transition-[border-color,transform,opacity] duration-150",
                  can ? "hover:-translate-y-0.5 hover:border-line-strong" : "opacity-45",
                )}
              >
                <span className="absolute inset-y-0 left-0 w-[3px]" style={{ background: TYPE_COLOR[m.type] }} />
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[14px] font-semibold">{m.name}</span>
                  <span className="flex items-center gap-0.5 text-[12px] font-semibold tnum text-brand-strong">
                    {m.cost}
                    <Zap size={11} fill="currentColor" />
                  </span>
                </div>
                <div className="mt-1 flex items-center justify-between text-[11.5px] text-subtle">
                  <span>{m.kind === "heal" ? "Restore 30% HP" : `${m.power} power · ${m.type}`}</span>
                  {eff > 1 && <span className="font-semibold text-ok">×{eff}</span>}
                  {eff < 1 && <span className="font-semibold text-warn">×{eff}</span>}
                </div>
              </button>
            );
          })}
        </div>

        <div className="mt-4 max-h-[84px] overflow-y-auto rounded-[10px] bg-s2 px-3 py-2 text-[12px] text-muted">
          {log.slice(0, 6).map((l, i) => (
            <div key={i} className={i === 0 ? "text-fg" : ""}>
              {l}
            </div>
          ))}
        </div>
      </div>
    </Panel>
  );
}

function HudCard({ name, level, hp, max, pct, color, types, align }: { name: string; level: number; hp: number; max: number; pct: number; color: string; types: string[]; align?: "right" }) {
  return (
    <div className="w-[47%] max-w-[260px] rounded-[12px] border border-line-strong bg-s1/90 px-3 py-2.5 backdrop-blur">
      <div className={cn("flex items-center gap-2", align === "right" && "justify-between")}>
        <span className="truncate text-[13.5px] font-semibold">{name}</span>
        <span className="text-[11px] text-subtle tnum">Lv {level}</span>
      </div>
      <div className="mt-1.5 h-[7px] overflow-hidden rounded-full bg-s3">
        <div className="h-full rounded-full" style={{ width: `${Math.max(0, pct) * 100}%`, background: color, transition: "width 0.7s cubic-bezier(.2,.7,.2,1), background 0.3s" }} />
      </div>
      <div className="mt-1.5 flex items-center justify-between">
        <div className="flex gap-1">
          {types.map((t) => (
            <span key={t} className="h-1.5 w-4 rounded-full" style={{ background: TYPE_COLOR[t as keyof typeof TYPE_COLOR] }} title={t} />
          ))}
        </div>
        <span className="text-[11px] text-muted tnum">
          {hp}/{max}
        </span>
      </div>
    </div>
  );
}
