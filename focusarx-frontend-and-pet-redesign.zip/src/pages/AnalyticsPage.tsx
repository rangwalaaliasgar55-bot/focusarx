import { useMemo, useState } from "react";
import { dayKey, minutesByDay, streakOf, useApp } from "../lib/store";
import { BarChart, Heatmap } from "../components/charts";
import { PageHead, Panel, Segmented, Stat } from "../components/ui";
import { Empty } from "../components/ui";

type Range = "7" | "30";

export function AnalyticsPage() {
  const sessions = useApp((s) => s.sessions);
  const goal = useApp((s) => s.settings.dailyGoal);
  const [range, setRange] = useState<Range>("7");

  const a = useMemo(() => {
    const byDay = minutesByDay(sessions);
    const n = +range;
    const now = new Date();
    const bars = Array.from({ length: n }).map((_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - (n - 1 - i));
      return {
        label: n === 7 ? d.toLocaleDateString(undefined, { weekday: "short" }).slice(0, 3) : i % 5 === 0 ? String(d.getDate()) : "",
        value: byDay.get(dayKey(d.getTime())) ?? 0,
        sub: d.toLocaleDateString(undefined, { month: "short", day: "numeric" }),
        highlight: i === n - 1,
      };
    });
    const cutoff = now.getTime() - n * 86400000;
    const inRange = sessions.filter((s) => s.end >= cutoff);
    const total = inRange.reduce((x, s) => x + s.minutes, 0);
    const activeDays = bars.filter((b) => b.value > 0).length;
    const hours = Array.from({ length: 24 }, () => 0);
    sessions.forEach((s) => (hours[new Date(s.end - s.minutes * 60000).getHours()] += s.minutes));
    const bestHour = hours.indexOf(Math.max(...hours));
    const avgScore = inRange.length ? Math.round(inRange.reduce((x, s) => x + s.score, 0) / inRange.length) : 0;
    const bestDay = Math.max(0, ...bars.map((b) => b.value));
    const lengths = new Map<number, number>();
    inRange.forEach((s) => lengths.set(s.minutes, (lengths.get(s.minutes) ?? 0) + 1));
    return { byDay, bars, total, count: inRange.length, activeDays, hours, bestHour, avgScore, bestDay, lengths, streak: streakOf(sessions), n };
  }, [sessions, range]);

  const maxHour = Math.max(...a.hours, 1);
  const fmtHour = (h: number) => `${((h + 11) % 12) + 1}${h < 12 ? "am" : "pm"}`;

  if (sessions.length === 0) {
    return (
      <div>
        <PageHead title="Analytics" />
        <Empty title="No data yet" hint="Complete a focus block and your trends, heatmap and best hours will appear here." />
      </div>
    );
  }

  return (
    <div>
      <PageHead title="Analytics" sub="Real numbers from your focus blocks — nothing estimated." right={<Segmented<Range> value={range} onChange={setRange} options={[{ id: "7", label: "7 days" }, { id: "30", label: "30 days" }]} />} />

      <Panel className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 [&>*]:border-b [&>*]:border-line lg:[&>*]:border-b-0 lg:divide-x lg:divide-line">
        <Stat label="Focus time" value={`${(a.total / 60).toFixed(1)}h`} sub={`last ${a.n} days`} />
        <Stat label="Blocks" value={a.count} sub={`${a.activeDays} active days`} />
        <Stat label="Avg score" value={a.avgScore || "–"} sub="completion + consistency" />
        <Stat label="Best day" value={`${a.bestDay}m`} sub="in this range" />
        <Stat label="Streak" value={`${a.streak}d`} sub="current" />
      </Panel>

      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
        <Panel className="p-5">
          <div className="eyebrow mb-5">Minutes per day</div>
          <BarChart bars={a.bars} goal={goal} height={200} />
        </Panel>
        <Panel className="p-5">
          <div className="eyebrow mb-1">Sharpest hour</div>
          <div className="font-display text-[46px] leading-none tracking-tight">{fmtHour(a.bestHour)}</div>
          <p className="mt-2 text-[13px] text-muted">Most of your focused minutes start around this time. Protect it.</p>
          <div className="mt-5 flex h-[84px] items-end gap-[3px]">
            {a.hours.map((v, h) => (
              <div key={h} className="flex-1 rounded-t-[3px]" title={`${fmtHour(h)} — ${v} min`} style={{ height: Math.max(2, (v / maxHour) * 84), background: h === a.bestHour ? "var(--brand-500)" : "color-mix(in srgb, var(--brand-500) 30%, var(--surface-3))" }} />
            ))}
          </div>
          <div className="mt-1.5 flex justify-between text-[10px] text-subtle">
            <span>12am</span>
            <span>6am</span>
            <span>12pm</span>
            <span>6pm</span>
          </div>
        </Panel>
      </div>

      <div className="mt-5 grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
        <Panel className="p-5">
          <div className="eyebrow mb-4">Consistency · last 15 weeks</div>
          <Heatmap days={a.byDay} />
        </Panel>
        <Panel className="p-5">
          <div className="eyebrow mb-4">Block lengths</div>
          <div className="flex flex-col gap-3">
            {[...a.lengths.entries()].sort((x, y) => y[1] - x[1]).map(([len, count]) => (
              <div key={len}>
                <div className="mb-1 flex justify-between text-[13px]">
                  <span className="tnum font-medium">{len} min</span>
                  <span className="text-subtle tnum">{count} blocks</span>
                </div>
                <div className="h-1.5 overflow-hidden rounded-full bg-s3">
                  <div className="h-full rounded-full bg-brand" style={{ width: `${(count / a.count) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    </div>
  );
}
