import { useEffect, useMemo, useRef, useState } from "react";
import { Check, Pause, Play, RotateCcw, SkipForward, Utensils, Hand, Swords, PawPrint, Sparkles } from "lucide-react";
import { feedPet, playWithPet, setSetting, useApp, dayKey, type FaceId } from "../lib/store";
import { MODE_LABEL, pause, reset, selectTask, setCustomMinutes, setMode, skip, start, syncIdle, useTimer, type Mode, type TimerSnap } from "../lib/timer";
import { movesFor, SPECIES_BY_ID, TYPE_COLOR, WILD_SPECIES, moodOf, type Species } from "../lib/pets";
import { FACES, FacePreview, TimerFace } from "../components/timer/Faces";
import { ARENA_POS, ArenaScene, PetStage, type Impact } from "../components/pet3d/Scenes";
import type { PetState } from "../components/pet3d/PetActor";
import type { Shot } from "../components/pet3d/fx";
import { Btn, Panel, Progress, Segmented, Tag } from "../components/ui";
import { toast } from "../lib/toast";
import { cn } from "../utils/cn";

const PRESETS: Record<Mode, number[]> = {
  focus: [15, 25, 45, 60, 90],
  short: [3, 5, 10, 15],
  long: [10, 15, 20, 30],
};

const LINES: Record<string, string[]> = {
  idle: ["Ready when you are.", "Pick a task and press space.", "I'll keep your seat warm."],
  focus: ["Eyes on the prize.", "I'm right here with you.", "One thing. Just this one.", "Quiet is working."],
  break: ["Look far away for a bit.", "Water. Stretch. Breathe.", "You earned this one."],
  sleep: ["Paused. I'll nap.", "Zzz… wake me when you're back."],
  celebrate: ["That was a clean block!", "Look at you go!"],
  happy: ["Hehe, that tickles.", "Again!"],
  eat: ["Nom nom nom.", "Delicious. Back to work?"],
};

function pickLine(k: string, seed: number) {
  const a = LINES[k] ?? LINES.idle;
  return a[seed % a.length];
}

export function TimerPage() {
  const t = useTimer();
  const settings = useApp((s) => s.settings);
  const tasks = useApp((s) => s.tasks);
  const sessions = useApp((s) => s.sessions);
  const coins = useApp((s) => s.coins);
  const ownedPet = useApp((s) => s.pets.find((p) => p.id === s.activePet));
  const activeId = useApp((s) => s.activePet);
  const species = SPECIES_BY_ID[activeId];

  const [custom, setCustom] = useState("");
  const [override, setOverride] = useState<{ state: PetState; key: number } | null>(null);
  const [celebrating, setCelebrating] = useState(false);
  const [burst, setBurst] = useState(0);
  const [lineSeed, setLineSeed] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const overrideTimer = useRef<number | null>(null);

  const running = t.status === "running";
  const modeColor = t.mode === "focus" ? settings.accent : t.mode === "short" ? "#3ecf8e" : "#4aa3e8";

  /* settings changed while idle → re-read durations */
  useEffect(() => {
    syncIdle();
  }, [settings.focusMin, settings.shortMin, settings.longMin]);

  /* keyboard: space toggles, r resets */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.tagName === "SELECT" || el.isContentEditable)) return;
      if (e.code === "Space") {
        e.preventDefault();
        if (running) pause();
        else start();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [running]);

  /* completion → celebration */
  useEffect(() => {
    if (!t.completedAt || Date.now() - t.completedAt > 4000) return;
    setShowResult(t.completedMode === "focus");
    if (t.completedMode === "focus") {
      setCelebrating(true);
      setBurst((k) => k + 1);
      const id = window.setTimeout(() => setCelebrating(false), 5200);
      return () => window.clearTimeout(id);
    }
  }, [t.completedAt, t.completedMode]);

  const poke = (st: PetState) => {
    setOverride({ state: st, key: Date.now() });
    setLineSeed((n) => n + 1);
    if (overrideTimer.current) window.clearTimeout(overrideTimer.current);
    overrideTimer.current = window.setTimeout(() => setOverride(null), 2500);
  };

  const base: PetState = celebrating
    ? "celebrate"
    : t.status === "paused"
      ? "sleep"
      : running
        ? t.mode === "focus"
          ? "focus"
          : "break"
        : "idle";
  const petState = override && base !== "celebrate" ? override.state : base;
  const line = pickLine(petState, lineSeed + t.cycle);

  const today = dayKey(Date.now());
  const todayMin = useMemo(() => sessions.filter((s) => dayKey(s.end) === today).reduce((a, s) => a + s.minutes, 0), [sessions, today]);
  const openTasks = tasks.filter((x) => !x.done);
  const mins = Math.round(t.totalSec / 60);

  const submitCustom = () => {
    const n = parseInt(custom, 10);
    if (!n || n < 1 || n > 240) return toast("Enter 1–240 minutes", "warn");
    setCustomMinutes(n);
    setCustom("");
  };

  return (
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_400px]">
      {/* ------------- timer ------------- */}
      <div className="flex flex-col gap-5">
        <Panel className="relative overflow-hidden p-5 sm:p-7">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <Segmented<Mode>
              value={t.mode}
              onChange={(m) => setMode(m)}
              options={[
                { id: "focus", label: "Focus" },
                { id: "short", label: "Short break" },
                { id: "long", label: "Long break" },
              ]}
            />
            <div className="flex items-center gap-1.5" aria-label="Session progress">
              {Array.from({ length: settings.longEvery }).map((_, i) => (
                <span
                  key={i}
                  className="h-2 w-2 rounded-full transition-colors"
                  style={{ background: i < t.cycle % settings.longEvery || (t.cycle > 0 && t.cycle % settings.longEvery === 0 && t.mode === "long") ? settings.accent : "var(--surface-3)" }}
                />
              ))}
              <span className="ml-1 text-[12px] text-subtle tnum">
                {Math.min(t.cycle % settings.longEvery, settings.longEvery)}/{settings.longEvery}
              </span>
            </div>
          </div>

          <div className="mx-auto mt-6 w-full max-w-[420px]">
            <TimerFace face={settings.face} secondsLeft={t.secondsLeft} totalSec={t.totalSec} mode={t.mode} running={running} color={modeColor} />
          </div>

          {/* controls */}
          <div className="mt-7 flex items-center justify-center gap-3">
            <Btn variant="ghost" size="lg" className="w-12 px-0" onClick={reset} aria-label="Reset" title="Reset">
              <RotateCcw size={18} />
            </Btn>
            <button
              onClick={() => (running ? pause() : start())}
              className="grid h-16 min-w-[168px] place-items-center rounded-full text-[15px] font-semibold text-white transition-transform duration-150 active:scale-[0.97]"
              style={{ background: modeColor, boxShadow: `0 10px 28px -10px ${modeColor}` }}
            >
              <span className="flex items-center gap-2">
                {running ? <Pause size={19} fill="currentColor" /> : <Play size={19} fill="currentColor" />}
                {running ? "Pause" : t.status === "paused" ? "Resume" : t.mode === "focus" ? "Start focus" : "Start break"}
              </span>
            </button>
            <Btn variant="ghost" size="lg" className="w-12 px-0" onClick={skip} aria-label="Skip" title="Skip to next">
              <SkipForward size={18} />
            </Btn>
          </div>
          <div className="mt-3 text-center text-[12px] text-subtle">
            Press <kbd className="rounded border border-line-strong bg-s2 px-1.5 py-0.5 text-[11px]">Space</kbd> to start or pause
          </div>

          {showResult && t.lastResult && (
            <div className="anim-pop mt-5 flex flex-wrap items-center justify-between gap-3 rounded-[12px] border border-ok/30 bg-ok-soft px-4 py-3">
              <div className="flex items-center gap-2.5 text-sm font-medium text-ok">
                <Check size={16} /> Block complete · focus score {t.lastResult.score}
              </div>
              <div className="flex items-center gap-3 text-[13px] text-fg">
                <span className="tnum">+{t.lastResult.coins} coins</span>
                <span className="tnum">+{t.lastResult.xp} XP</span>
                <span className="tnum">+{t.lastResult.petXp} pet XP</span>
                <button className="text-subtle hover:text-fg" onClick={() => setShowResult(false)} aria-label="Dismiss">
                  ×
                </button>
              </div>
            </div>
          )}

          {/* duration */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2 border-t border-line pt-5">
            {PRESETS[t.mode].map((m) => (
              <button
                key={m}
                disabled={running}
                onClick={() => setCustomMinutes(m)}
                className={cn(
                  "h-8 rounded-full border px-3.5 text-[13px] font-medium tnum transition-colors disabled:opacity-40",
                  mins === m ? "border-brand bg-brand-soft text-brand-strong" : "border-line text-muted hover:border-line-strong hover:text-fg",
                )}
              >
                {m}m
              </button>
            ))}
            <form
              className="flex items-center gap-1.5"
              onSubmit={(e) => {
                e.preventDefault();
                submitCustom();
              }}
            >
              <input
                value={custom}
                onChange={(e) => setCustom(e.target.value.replace(/\D/g, "").slice(0, 3))}
                disabled={running}
                inputMode="numeric"
                placeholder="Custom"
                aria-label="Custom minutes"
                className="h-8 w-[84px] rounded-full border border-line bg-transparent px-3 text-center text-[13px] outline-none placeholder:text-subtle focus:border-brand disabled:opacity-40"
              />
              <Btn size="sm" variant="ghost" type="submit" disabled={running || !custom}>
                Set
              </Btn>
            </form>
          </div>
        </Panel>

        {/* task + today */}
        <div className="grid gap-5 sm:grid-cols-2">
          <Panel className="p-4">
            <div className="eyebrow mb-2">Working on</div>
            <select
              value={t.taskId ?? ""}
              onChange={(e) => selectTask(e.target.value || null)}
              className="h-10 w-full rounded-[10px] border border-line bg-s2 px-3 text-sm outline-none focus:border-brand"
              aria-label="Current task"
            >
              <option value="">No task — free focus</option>
              {openTasks.map((x) => (
                <option key={x.id} value={x.id}>
                  {x.title}
                </option>
              ))}
            </select>
            <p className="mt-2 text-[12px] text-subtle">Completed blocks are logged against the selected task.</p>
          </Panel>
          <Panel className="p-4">
            <div className="flex items-baseline justify-between">
              <div className="eyebrow">Today</div>
              <div className="text-[12px] text-muted tnum">
                {todayMin} / {settings.dailyGoal} min
              </div>
            </div>
            <div className="tnum mt-2 text-[26px] font-semibold leading-none tracking-tight">
              {Math.floor(todayMin / 60)}h {todayMin % 60}m
            </div>
            <Progress value={todayMin / settings.dailyGoal} className="mt-3" color={todayMin >= settings.dailyGoal ? "var(--success)" : undefined} />
          </Panel>
        </div>

        {/* faces */}
        <Panel className="p-5">
          <div className="mb-4 flex items-end justify-between">
            <div>
              <div className="eyebrow">Timer face</div>
              <div className="mt-1 text-sm text-muted">Eight designs. Switch any time, even mid-session.</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {FACES.map((f) => {
              const on = settings.face === f.id;
              return (
                <button
                  key={f.id}
                  onClick={() => setSetting("face", f.id as FaceId)}
                  aria-pressed={on}
                  className={cn(
                    "group flex flex-col overflow-hidden rounded-[14px] border text-left transition-colors duration-150",
                    on ? "border-brand bg-brand-soft" : "border-line bg-s2 hover:border-line-strong",
                  )}
                >
                  <div className="flex h-[104px] items-center justify-center overflow-hidden p-3">
                    <div className="w-full max-w-[104px]">
                      <FacePreview face={f.id} color={settings.accent} />
                    </div>
                  </div>
                  <div className="border-t border-line px-3 py-2">
                    <div className="flex items-center justify-between text-[13px] font-semibold">
                      {f.name}
                      {on && <Check size={14} className="text-brand-strong" />}
                    </div>
                    <div className="truncate text-[11px] text-subtle">{f.note}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </Panel>
      </div>

      {/* ------------- companion ------------- */}
      <div className="flex flex-col gap-5">
        <Panel className="overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-4 py-3">
            <Segmented<"companion" | "boss">
              value={settings.companionMode}
              onChange={(v) => setSetting("companionMode", v)}
              options={[
                { id: "companion", label: "Companion" },
                { id: "boss", label: "Boss fight" },
              ]}
            />
            <Tag color={modeColor}>{MODE_LABEL[t.mode]}</Tag>
          </div>

          {settings.companionMode === "companion" ? (
            <div className="stage-bg relative">
              <PetStage
                species={species}
                state={petState}
                stateKey={override?.key}
                burst={burst}
                onPoke={() => poke("happy")}
                className="h-[360px] w-full cursor-pointer"
              />
              <div className="pointer-events-none absolute inset-x-0 top-3 flex justify-center px-4">
                <div key={petState + lineSeed} className="anim-pop rounded-full border border-line-strong bg-s1/90 px-3.5 py-1.5 text-[13px] shadow-[var(--shadow-float)] backdrop-blur">
                  {line}
                </div>
              </div>
              <div className="pointer-events-none absolute bottom-2 left-0 right-0 text-center text-[11px] text-subtle">Click your companion · move the cursor and it will look</div>
            </div>
          ) : (
            <BossPanel pet={species} t={t} />
          )}

          {ownedPet && (
            <div className="border-t border-line p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-[15px] font-semibold">{species.name}</div>
                  <div className="text-[12px] text-subtle">
                    Level {ownedPet.level} · {species.types.join(" / ")}
                  </div>
                </div>
                <Tag color={moodOf(ownedPet).tone === "ok" ? "var(--success)" : moodOf(ownedPet).tone === "warn" ? "var(--warning)" : "var(--danger)"}>{moodOf(ownedPet).label}</Tag>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-3 text-[11px] text-subtle">
                <Meter label="XP" v={ownedPet.xp / (50 + ownedPet.level * 35)} color="var(--brand-500)" />
                <Meter label="Fed" v={ownedPet.hunger / 100} color="var(--warning)" />
                <Meter label="Joy" v={ownedPet.joy / 100} color="var(--success)" />
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2">
                <Btn
                  size="sm"
                  disabled={coins < 15}
                  onClick={() => {
                    if (feedPet(activeId)) poke("eat");
                  }}
                >
                  <Utensils size={14} /> Feed · 15
                </Btn>
                <Btn
                  size="sm"
                  onClick={() => {
                    if (playWithPet(activeId)) poke("happy");
                  }}
                >
                  <Hand size={14} /> Play
                </Btn>
              </div>
            </div>
          )}
        </Panel>

        <Panel className="p-4">
          <div className="flex items-center gap-2 text-[13px] font-medium">
            <Sparkles size={14} className="text-brand-strong" /> How the companion behaves
          </div>
          <ul className="mt-3 space-y-2 text-[13px] text-muted">
            <li className="flex gap-2">
              <PawPrint size={14} className="mt-0.5 shrink-0 text-subtle" /> Works beside you while a focus block runs.
            </li>
            <li className="flex gap-2">
              <PawPrint size={14} className="mt-0.5 shrink-0 text-subtle" /> Dances on breaks and falls asleep when you pause.
            </li>
            <li className="flex gap-2">
              <Swords size={14} className="mt-0.5 shrink-0 text-subtle" /> In Boss fight, every tenth of the block lands a hit. Finish to win.
            </li>
          </ul>
        </Panel>
      </div>
    </div>
  );
}

function Meter({ label, v, color }: { label: string; v: number; color: string }) {
  return (
    <div>
      <div className="mb-1 flex justify-between">
        <span>{label}</span>
        <span className="tnum">{Math.round(Math.min(1, v) * 100)}%</span>
      </div>
      <Progress value={v} color={color} height={4} />
    </div>
  );
}

/* ------------------------------ boss fight (follows the timer) ------------------------------ */

function BossPanel({ pet, t }: { pet: Species; t: TimerSnap }) {
  const [shownCycle, setShownCycle] = useState(t.cycle);
  const foe = WILD_SPECIES[(shownCycle * 2 + 1) % WILD_SPECIES.length];
  const [over, setOver] = useState<{ p?: PetState; f?: PetState }>({});
  const [pk, setPk] = useState(0);
  const [fk, setFk] = useState(0);
  const [shot, setShot] = useState<Shot | null>(null);
  const [impact, setImpact] = useState<Impact | null>(null);
  const [dmg, setDmg] = useState<{ id: number; v: number }[]>([]);
  const lastHit = useRef(-1);
  const timers = useRef<number[]>([]);
  const idc = useRef(1);

  const running = t.status === "running";
  const focus = t.mode === "focus";
  const elapsed = t.totalSec > 0 ? 1 - t.secondsLeft / t.totalSec : 0;
  const hp = focus && t.status !== "idle" ? 1 - elapsed : 1;
  const hitStep = focus && running ? Math.floor(elapsed * 10) : -1;

  const later = (fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms));
  };
  useEffect(() => () => timers.current.forEach(window.clearTimeout), []);

  /* hits */
  useEffect(() => {
    if (hitStep < 0) {
      lastHit.current = -1;
      return;
    }
    if (lastHit.current < 0) {
      lastHit.current = hitStep;
      return;
    }
    if (hitStep === lastHit.current) return;
    lastHit.current = hitStep;
    const mv = movesFor(pet)[1];
    const color = TYPE_COLOR[mv.type];
    setOver({ p: "attack" });
    setPk((k) => k + 1);
    later(() => {
      setShot({ id: idc.current++, from: [ARENA_POS.player[0] + 0.5, 1.1, ARENA_POS.player[2]], to: [ARENA_POS.foe[0], 1.0, ARENA_POS.foe[2]], color, fx: mv.fx });
    }, 220);
    later(() => {
      setOver({ p: "attack", f: "hurt" });
      setFk((k) => k + 1);
      setImpact({ key: idc.current++, side: "foe", color, kind: "hit" });
      const v = 8 + Math.floor(Math.random() * 9);
      const id = idc.current++;
      setDmg((d) => [...d, { id, v }]);
      later(() => setDmg((d) => d.filter((x) => x.id !== id)), 900);
    }, 620);
    later(() => setOver({}), 1000);
  }, [hitStep, pet]);

  /* completion */
  useEffect(() => {
    if (!t.completedAt || Date.now() - t.completedAt > 4000 || t.completedMode !== "focus") return;
    setOver({ p: "celebrate", f: "faint" });
    setFk((k) => k + 1);
    setPk((k) => k + 1);
    setImpact({ key: idc.current++, side: "foe", color: "#ffd166", kind: "hit" });
    later(() => {
      setOver({});
      setShownCycle(t.cycle);
    }, 4200);
  }, [t.completedAt]);

  useEffect(() => {
    if (!t.completedAt || Date.now() - t.completedAt > 4500) setShownCycle(t.cycle);
  }, [t.cycle, t.completedAt]);

  const baseP: PetState = t.status === "paused" ? "sleep" : running ? (focus ? "focus" : "break") : "idle";
  const baseF: PetState = !focus ? "sleep" : t.status === "paused" ? "idle" : "idle";
  const hpColor = hp > 0.5 ? "var(--success)" : hp > 0.25 ? "var(--warning)" : "var(--danger)";

  return (
    <div className="stage-bg relative">
      <ArenaScene
        player={pet}
        foe={foe}
        playerState={over.p ?? baseP}
        foeState={over.f ?? baseF}
        playerKey={pk}
        foeKey={fk}
        shot={shot}
        impact={impact}
        compact
        className="h-[360px] w-full"
      />
      <div className="absolute inset-x-3 top-3 flex items-start justify-between gap-3">
        <div className="w-[46%] rounded-[10px] border border-line-strong bg-s1/90 px-3 py-2 backdrop-blur">
          <div className="flex items-center justify-between text-[12px] font-semibold">
            <span>{pet.name}</span>
            <span className="text-subtle tnum">{Math.round(elapsed * 100)}%</span>
          </div>
          <Progress value={elapsed} className="mt-1.5" height={5} />
        </div>
        <div className="relative w-[46%] rounded-[10px] border border-line-strong bg-s1/90 px-3 py-2 backdrop-blur">
          <div className="flex items-center justify-between text-[12px] font-semibold">
            <span>{foe.name}</span>
            <span className="text-subtle tnum">{Math.round(hp * 100)}% HP</span>
          </div>
          <Progress value={hp} color={hpColor} className="mt-1.5" height={5} />
          {dmg.map((d) => (
            <span key={d.id} className="dmg-float left-1/2 top-full text-[15px] text-bad" style={{ color: "var(--danger)" }}>
              −{d.v}
            </span>
          ))}
        </div>
      </div>
      <div className="pointer-events-none absolute bottom-2 left-0 right-0 text-center text-[11px] text-subtle">
        {focus ? (running ? `${foe.name} is losing focus… keep going` : `A wild ${foe.name} blocks your session`) : "Break — the arena rests"}
      </div>
    </div>
  );
}
