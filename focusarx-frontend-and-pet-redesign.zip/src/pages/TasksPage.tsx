import { useState } from "react";
import { Check, Play, Plus, Trash2 } from "lucide-react";
import { addTask, deleteTask, toggleTask, useApp, type Task } from "../lib/store";
import { selectTask } from "../lib/timer";
import { navigate } from "../lib/router";
import { Btn, Empty, PageHead, Panel, Segmented, Tag } from "../components/ui";
import { cn } from "../utils/cn";

type Filter = "open" | "done" | "all";
const PRIORITY: Record<Task["priority"], { label: string; color: string }> = {
  high: { label: "High", color: "var(--danger)" },
  med: { label: "Medium", color: "var(--warning)" },
  low: { label: "Low", color: "var(--foreground-subtle)" },
};

export function TasksPage() {
  const tasks = useApp((s) => s.tasks);
  const [title, setTitle] = useState("");
  const [est, setEst] = useState(2);
  const [prio, setPrio] = useState<Task["priority"]>("med");
  const [filter, setFilter] = useState<Filter>("open");

  const open = tasks.filter((t) => !t.done);
  const done = tasks.filter((t) => t.done);
  const shown = (filter === "open" ? open : filter === "done" ? done : tasks).slice().sort((a, b) => {
    if (a.done !== b.done) return a.done ? 1 : -1;
    const w = { high: 0, med: 1, low: 2 };
    return w[a.priority] - w[b.priority] || b.createdAt - a.createdAt;
  });
  const plannedBlocks = open.reduce((a, t) => a + Math.max(0, t.est - t.spent), 0);

  return (
    <div>
      <PageHead title="Tasks" sub="Give every focus block a purpose. Pick a task, press play, and each finished block is logged against it." />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_300px]">
        <div className="flex flex-col gap-4">
          <Panel className="p-4">
            <form
              className="flex flex-wrap items-center gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                addTask(title, est, prio);
                setTitle("");
              }}
            >
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="What are you working on?"
                aria-label="New task"
                className="h-10 min-w-[200px] flex-1 rounded-[10px] border border-line bg-s2 px-3 text-sm outline-none placeholder:text-subtle focus:border-brand"
              />
              <select value={est} onChange={(e) => setEst(+e.target.value)} aria-label="Estimated blocks" className="h-10 rounded-[10px] border border-line bg-s2 px-2.5 text-sm outline-none focus:border-brand">
                {[1, 2, 3, 4, 5, 6, 8].map((n) => (
                  <option key={n} value={n}>
                    {n} block{n > 1 ? "s" : ""}
                  </option>
                ))}
              </select>
              <select value={prio} onChange={(e) => setPrio(e.target.value as Task["priority"])} aria-label="Priority" className="h-10 rounded-[10px] border border-line bg-s2 px-2.5 text-sm outline-none focus:border-brand">
                <option value="high">High</option>
                <option value="med">Medium</option>
                <option value="low">Low</option>
              </select>
              <Btn variant="primary" type="submit" disabled={!title.trim()}>
                <Plus size={16} /> Add
              </Btn>
            </form>
          </Panel>

          <div className="flex items-center justify-between">
            <Segmented<Filter>
              value={filter}
              onChange={setFilter}
              options={[
                { id: "open", label: `Open · ${open.length}` },
                { id: "done", label: `Done · ${done.length}` },
                { id: "all", label: "All" },
              ]}
            />
          </div>

          {shown.length === 0 ? (
            <Empty title={filter === "done" ? "Nothing finished yet" : "All clear"} hint={filter === "done" ? "Completed tasks will collect here." : "Add a task above to plan your next block."} />
          ) : (
            <Panel className="divide-y divide-line">
              {shown.map((t) => (
                <div key={t.id} className="group flex items-center gap-3 px-4 py-3.5">
                  <button
                    aria-label={t.done ? "Mark as open" : "Mark as done"}
                    onClick={() => toggleTask(t.id)}
                    className={cn("grid h-5 w-5 shrink-0 place-items-center rounded-full border transition-colors", t.done ? "border-ok bg-ok text-white" : "border-line-strong hover:border-brand")}
                  >
                    {t.done && <Check size={12} strokeWidth={3} />}
                  </button>
                  <div className="min-w-0 flex-1">
                    <div className={cn("truncate text-sm font-medium", t.done && "text-subtle line-through")}>{t.title}</div>
                    <div className="mt-1 flex items-center gap-2.5">
                      <div className="flex gap-1" aria-label={`${t.spent} of ${t.est} blocks`}>
                        {Array.from({ length: Math.max(t.est, t.spent) }).map((_, i) => (
                          <span key={i} className="h-1.5 w-4 rounded-full" style={{ background: i < t.spent ? "var(--brand-500)" : "var(--surface-3)" }} />
                        ))}
                      </div>
                      <span className="text-[11.5px] text-subtle tnum">
                        {t.spent}/{t.est} blocks
                      </span>
                    </div>
                  </div>
                  <Tag color={PRIORITY[t.priority].color}>{PRIORITY[t.priority].label}</Tag>
                  {!t.done && (
                    <Btn
                      size="sm"
                      variant="soft"
                      onClick={() => {
                        selectTask(t.id);
                        navigate("/timer");
                      }}
                    >
                      <Play size={12} fill="currentColor" /> Focus
                    </Btn>
                  )}
                  <button aria-label="Delete task" onClick={() => deleteTask(t.id)} className="text-subtle opacity-0 transition-opacity hover:text-bad focus:opacity-100 group-hover:opacity-100 max-sm:opacity-100">
                    <Trash2 size={15} />
                  </button>
                </div>
              ))}
            </Panel>
          )}
        </div>

        <div className="flex flex-col gap-4">
          <Panel className="p-5">
            <div className="eyebrow">Plan</div>
            <div className="tnum mt-2 text-[34px] font-semibold leading-none tracking-tight">{plannedBlocks}</div>
            <div className="mt-1 text-[13px] text-muted">blocks left to do</div>
            <div className="mt-4 border-t border-line pt-3 text-[13px] text-muted">
              About <span className="tnum font-semibold text-fg">{Math.round((plannedBlocks * 25) / 60 * 10) / 10}</span> hours of focus at 25 minutes a block.
            </div>
          </Panel>
          <Panel className="p-5 text-[13px] text-muted">
            <div className="mb-2 font-medium text-fg">A tip</div>
            Break a task bigger than four blocks into two. Smaller targets are easier to start, and starting is the hard part.
          </Panel>
        </div>
      </div>
    </div>
  );
}
