import type { ReactNode } from "react";
import { Moon, Sun } from "lucide-react";
import { clearDemo, resetAll, setSetting, useApp } from "../lib/store";
import { chime } from "../lib/timer";
import { Btn, PageHead, Panel, Segmented } from "../components/ui";
import { toast } from "../lib/toast";
import { cn } from "../utils/cn";

const ACCENTS = [
  { name: "Indigo", v: "#6e7bff" },
  { name: "Violet", v: "#9d7bff" },
  { name: "Sky", v: "#3ba7ff" },
  { name: "Teal", v: "#22b8a4" },
  { name: "Emerald", v: "#34c279" },
  { name: "Amber", v: "#e8a23a" },
  { name: "Orange", v: "#f0763c" },
  { name: "Rose", v: "#f0527a" },
];

function Row({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-4 py-4">
      <div className="min-w-0">
        <div className="text-sm font-medium">{label}</div>
        {hint && <div className="text-[12.5px] text-muted">{hint}</div>}
      </div>
      {children}
    </div>
  );
}

function Num({ value, onChange, min, max, step = 1, suffix }: { value: number; onChange: (n: number) => void; min: number; max: number; step?: number; suffix?: string }) {
  return (
    <div className="flex items-center gap-2">
      <div className="inline-flex h-9 items-center rounded-[10px] border border-line bg-s2">
        <button className="h-full w-9 text-muted hover:text-fg" aria-label="Decrease" onClick={() => onChange(Math.max(min, value - step))}>
          −
        </button>
        <span className="tnum w-12 text-center text-sm font-semibold">{value}</span>
        <button className="h-full w-9 text-muted hover:text-fg" aria-label="Increase" onClick={() => onChange(Math.min(max, value + step))}>
          +
        </button>
      </div>
      {suffix && <span className="text-[12px] text-subtle">{suffix}</span>}
    </div>
  );
}

function Toggle({ on, onChange, label }: { on: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)} className={cn("relative h-6 w-11 rounded-full transition-colors", on ? "bg-brand" : "bg-s3")}>
      <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-[left]", on ? "left-[22px]" : "left-0.5")} />
    </button>
  );
}

export function SettingsPage() {
  const s = useApp((x) => x.settings);
  const demo = useApp((x) => x.sessions.some((y) => y.demo));

  return (
    <div className="max-w-3xl">
      <PageHead title="Settings" sub="Everything is stored on this device. Nothing leaves your browser." />

      <Panel className="divide-y divide-line px-5">
        <div className="eyebrow pb-1 pt-4">Appearance</div>
        <Row label="Theme">
          <Segmented<"dark" | "light"> value={s.theme} onChange={(v) => setSetting("theme", v)} options={[{ id: "dark", label: "Dark" }, { id: "light", label: "Light" }]} />
        </Row>
        <Row label="Accent colour" hint="The one colour used for primary actions, rings and the active page.">
          <div className="flex flex-wrap items-center gap-2">
            {ACCENTS.map((a) => (
              <button
                key={a.v}
                aria-label={a.name}
                title={a.name}
                onClick={() => setSetting("accent", a.v)}
                className={cn("grid h-7 w-7 place-items-center rounded-full ring-offset-2 ring-offset-[var(--surface-1)] transition-shadow", s.accent === a.v && "ring-2")}
                style={{ background: a.v, ["--tw-ring-color" as string]: a.v }}
              />
            ))}
            <label className="relative ml-1 grid h-7 w-7 cursor-pointer place-items-center overflow-hidden rounded-full border border-dashed border-line-strong text-[10px] text-subtle" title="Custom">
              +
              <input type="color" value={s.accent} onChange={(e) => setSetting("accent", e.target.value)} className="absolute inset-0 cursor-pointer opacity-0" aria-label="Custom accent" />
            </label>
          </div>
        </Row>
        <Row label="Display name">
          <input value={s.name} onChange={(e) => setSetting("name", e.target.value.slice(0, 20))} className="h-9 w-44 rounded-[10px] border border-line bg-s2 px-3 text-sm outline-none focus:border-brand" aria-label="Display name" />
        </Row>
      </Panel>

      <Panel className="mt-5 divide-y divide-line px-5">
        <div className="eyebrow pb-1 pt-4">Timer</div>
        <Row label="Focus length">
          <Num value={s.focusMin} min={5} max={120} step={5} suffix="min" onChange={(n) => setSetting("focusMin", n)} />
        </Row>
        <Row label="Short break">
          <Num value={s.shortMin} min={1} max={30} suffix="min" onChange={(n) => setSetting("shortMin", n)} />
        </Row>
        <Row label="Long break">
          <Num value={s.longMin} min={5} max={60} step={5} suffix="min" onChange={(n) => setSetting("longMin", n)} />
        </Row>
        <Row label="Long break every" hint="Number of focus blocks before a long break.">
          <Num value={s.longEvery} min={2} max={8} suffix="blocks" onChange={(n) => setSetting("longEvery", n)} />
        </Row>
        <Row label="Daily goal">
          <Num value={s.dailyGoal} min={30} max={600} step={15} suffix="min" onChange={(n) => setSetting("dailyGoal", n)} />
        </Row>
        <Row label="Auto-start next block" hint="Begin the next focus or break as soon as one ends.">
          <Toggle on={s.autoStart} onChange={(v) => setSetting("autoStart", v)} label="Auto-start" />
        </Row>
      </Panel>

      <Panel className="mt-5 divide-y divide-line px-5">
        <div className="eyebrow pb-1 pt-4">Sound</div>
        <Row label="Completion chime">
          <Toggle on={s.sound} onChange={(v) => setSetting("sound", v)} label="Sound" />
        </Row>
        <Row label="Volume">
          <div className="flex items-center gap-3">
            <input type="range" min={0} max={1} step={0.05} value={s.volume} onChange={(e) => setSetting("volume", +e.target.value)} className="w-40" aria-label="Volume" />
            <Btn size="sm" onClick={() => chime("done")}>
              Test
            </Btn>
          </div>
        </Row>
      </Panel>

      <Panel className="mt-5 divide-y divide-line px-5">
        <div className="eyebrow pb-1 pt-4">Data</div>
        {demo && (
          <Row label="Sample history" hint="Three weeks of example sessions so charts have something to show.">
            <Btn
              onClick={() => {
                clearDemo();
                toast("Sample data cleared", "ok");
              }}
            >
              Clear sample data
            </Btn>
          </Row>
        )}
        <Row label="Reset everything" hint="Removes sessions, tasks, companions and settings from this browser.">
          <Btn
            variant="danger"
            onClick={() => {
              if (window.confirm("Reset all FocusArx data on this device?")) {
                resetAll();
                toast("Everything reset", "info");
              }
            }}
          >
            Reset data
          </Btn>
        </Row>
      </Panel>
      <div className="mt-6 flex items-center gap-2 text-[12px] text-subtle">
        {s.theme === "dark" ? <Moon size={13} /> : <Sun size={13} />} FocusArx front-end build · data lives in localStorage
      </div>
    </div>
  );
}
