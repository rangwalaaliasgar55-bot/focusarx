import { useEffect } from "react";
import { Shell } from "./components/Shell";
import { useRoute } from "./lib/router";
import { applyTheme, useApp } from "./lib/store";
import { bootTimer } from "./lib/timer";
import { Dashboard } from "./pages/Dashboard";
import { TimerPage } from "./pages/TimerPage";
import { TasksPage } from "./pages/TasksPage";
import { PetsPage } from "./pages/PetsPage";
import { BattlePage } from "./pages/BattlePage";
import { MissionsPage } from "./pages/MissionsPage";
import { AnalyticsPage } from "./pages/AnalyticsPage";
import { SettingsPage } from "./pages/SettingsPage";

export default function App() {
  const path = useRoute();
  const settings = useApp((s) => s.settings);

  useEffect(() => {
    applyTheme(settings);
  }, [settings]);

  useEffect(() => {
    bootTimer();
  }, []);

  let page;
  switch (path) {
    case "/timer":
      page = <TimerPage />;
      break;
    case "/tasks":
      page = <TasksPage />;
      break;
    case "/pets":
      page = <PetsPage />;
      break;
    case "/battle":
      page = <BattlePage />;
      break;
    case "/missions":
      page = <MissionsPage />;
      break;
    case "/analytics":
      page = <AnalyticsPage />;
      break;
    case "/settings":
      page = <SettingsPage />;
      break;
    default:
      page = <Dashboard />;
  }

  return <Shell>{page}</Shell>;
}
