export type Rarity = "common" | "rare" | "epic" | "legendary";

export type ElementType =
  | "normal"
  | "fire"
  | "water"
  | "grass"
  | "electric"
  | "psychic"
  | "ghost"
  | "dragon"
  | "fairy"
  | "fighting"
  | "dark"
  | "rock"
  | "steel"
  | "ice"
  | "flying";

export type EarKind = "round" | "pointy" | "long" | "tuft" | "none";
export type TailKind = "fluffy" | "long" | "stub" | "none";

export interface BodyParams {
  body: string;
  belly: string;
  patch?: string;
  ears: EarKind;
  tail: TailKind;
  beak?: boolean;
  wings?: boolean;
  snout?: boolean;
  horns?: boolean;
  squish?: number; // 1 = normal; <1 flatter (slime)
}

export interface Species {
  id: string;
  name: string;
  kind: "original" | "pokemon";
  dex?: number;
  rarity: Rarity;
  price: number;
  types: ElementType[];
  color: string;
  blurb: string;
  base: { hp: number; atk: number; def: number; spd: number };
  body?: BodyParams;
  wild?: boolean;
  /** world-space height of the 3D billboard */
  scale?: number;
}

const P = (
  id: string,
  name: string,
  dex: number,
  rarity: Rarity,
  price: number,
  types: ElementType[],
  color: string,
  blurb: string,
  base: Species["base"],
  extra: Partial<Species> = {},
): Species => ({ id, name, kind: "pokemon", dex, rarity, price, types, color, blurb, base, ...extra });

export const SPECIES: Species[] = [
  // ----- originals, built in 3D -----
  {
    id: "hoot",
    name: "Hoot",
    kind: "original",
    rarity: "common",
    price: 0,
    types: ["flying", "psychic"],
    color: "#b98a5c",
    blurb: "A night-shift owl who treats every deadline as a personal insult.",
    base: { hp: 70, atk: 18, def: 12, spd: 14 },
    body: { body: "#a97b50", belly: "#f1e1c4", ears: "tuft", tail: "stub", beak: true, wings: true },
  },
  {
    id: "ember",
    name: "Ember",
    kind: "original",
    rarity: "rare",
    price: 220,
    types: ["fire"],
    color: "#e8793a",
    blurb: "Warms up slowly, then refuses to cool down.",
    base: { hp: 66, atk: 22, def: 10, spd: 16 },
    body: { body: "#e8793a", belly: "#fbe7cf", patch: "#fff3e3", ears: "pointy", tail: "fluffy", snout: true },
  },
  {
    id: "mochi",
    name: "Mochi",
    kind: "original",
    rarity: "common",
    price: 120,
    types: ["normal", "fairy"],
    color: "#f1ebe2",
    blurb: "Soft, round and a little smug about both.",
    base: { hp: 74, atk: 16, def: 14, spd: 15 },
    body: { body: "#efe6da", belly: "#ffffff", patch: "#d9b48f", ears: "pointy", tail: "long" },
  },
  {
    id: "bamboo",
    name: "Bamboo",
    kind: "original",
    rarity: "rare",
    price: 260,
    types: ["fighting", "grass"],
    color: "#2f2f33",
    blurb: "Moves like it has all day. Wins like it did.",
    base: { hp: 92, atk: 17, def: 20, spd: 8 },
    body: { body: "#f4f4f2", belly: "#f4f4f2", patch: "#27272b", ears: "round", tail: "stub", snout: true },
  },
  {
    id: "clover",
    name: "Clover",
    kind: "original",
    rarity: "common",
    price: 140,
    types: ["grass", "normal"],
    color: "#9fd18c",
    blurb: "Hops first, plans never.",
    base: { hp: 62, atk: 15, def: 11, spd: 24 },
    body: { body: "#a9d89a", belly: "#effbe8", ears: "long", tail: "stub" },
  },
  {
    id: "pip",
    name: "Pip",
    kind: "original",
    rarity: "rare",
    price: 240,
    types: ["ice", "water"],
    color: "#4a6a8f",
    blurb: "Waddles into exams like it owns the building.",
    base: { hp: 78, atk: 18, def: 16, spd: 12 },
    body: { body: "#33465f", belly: "#f6f8fb", ears: "none", tail: "stub", beak: true, wings: true },
  },
  {
    id: "blob",
    name: "Blob",
    kind: "original",
    rarity: "common",
    price: 80,
    types: ["water", "normal"],
    color: "#69c6b8",
    blurb: "Mostly vibes. Surprisingly durable.",
    base: { hp: 84, atk: 13, def: 15, spd: 9 },
    body: { body: "#69c6b8", belly: "#c9f0e9", ears: "none", tail: "none", squish: 0.82 },
  },
  {
    id: "drake",
    name: "Drake",
    kind: "original",
    rarity: "epic",
    price: 520,
    types: ["dragon", "fire"],
    color: "#7a62d9",
    blurb: "Hoards completed sessions instead of gold.",
    base: { hp: 88, atk: 26, def: 18, spd: 14 },
    body: { body: "#7a62d9", belly: "#e8dfff", ears: "none", tail: "long", wings: true, horns: true, snout: true },
  },

  // ----- Pokémon -----
  P("pikachu", "Pikachu", 25, "rare", 320, ["electric"], "#f5cb3f", "Charges on caffeine and short breaks.", { hp: 62, atk: 24, def: 11, spd: 26 }, { scale: 2.1 }),
  P("charmander", "Charmander", 4, "common", 180, ["fire"], "#ee8130", "The tail flame burns brighter the longer you stay on task.", { hp: 66, atk: 21, def: 11, spd: 17 }, { scale: 2.1 }),
  P("bulbasaur", "Bulbasaur", 1, "common", 180, ["grass"], "#6cbf72", "Soaks up the sun while you study.", { hp: 74, atk: 18, def: 15, spd: 12 }, { scale: 2.0 }),
  P("squirtle", "Squirtle", 7, "common", 180, ["water"], "#5aa9e0", "Retreats into its shell when notifications arrive.", { hp: 72, atk: 17, def: 19, spd: 11 }, { scale: 2.0 }),
  P("eevee", "Eevee", 133, "rare", 300, ["normal"], "#b98a5a", "Undecided about everything except finishing the block.", { hp: 70, atk: 18, def: 13, spd: 18 }, { scale: 2.0 }),
  P("jigglypuff", "Jigglypuff", 39, "rare", 280, ["normal", "fairy"], "#f6a5c4", "Sings you to sleep. Do not start the break early.", { hp: 100, atk: 14, def: 9, spd: 10 }, { scale: 2.1 }),
  P("psyduck", "Psyduck", 54, "rare", 280, ["water"], "#f1d24a", "Permanent headache, permanent focus.", { hp: 78, atk: 18, def: 14, spd: 14 }, { scale: 2.1 }),
  P("togepi", "Togepi", 175, "rare", 300, ["fairy"], "#f4ecd7", "Radiates good luck onto every pending task.", { hp: 64, atk: 12, def: 16, spd: 12 }, { scale: 1.9 }),
  P("umbreon", "Umbreon", 197, "epic", 540, ["dark"], "#35373f", "Comes alive during the late-night grind.", { hp: 96, atk: 17, def: 26, spd: 14 }, { scale: 2.2 }),
  P("gengar", "Gengar", 94, "epic", 560, ["ghost"], "#6b4fa1", "Haunts your procrastination until it leaves.", { hp: 72, atk: 28, def: 12, spd: 22 }, { scale: 2.3 }),
  P("snorlax", "Snorlax", 143, "epic", 580, ["normal"], "#4f7f84", "Takes naps seriously. Takes tasks even more seriously.", { hp: 130, atk: 24, def: 18, spd: 5 }, { scale: 2.6 }),
  P("lucario", "Lucario", 448, "epic", 620, ["fighting", "steel"], "#4a74c9", "Senses the exact moment your attention drifts.", { hp: 82, atk: 28, def: 17, spd: 19 }, { scale: 2.4 }),
  P("gardevoir", "Gardevoir", 282, "epic", 640, ["psychic", "fairy"], "#9ad0b4", "Bends the room's mood toward calm.", { hp: 80, atk: 27, def: 15, spd: 17 }, { scale: 2.4 }),
  P("charizard", "Charizard", 6, "legendary", 1100, ["fire", "flying"], "#ee7a2c", "Soars past every distraction on the horizon.", { hp: 96, atk: 32, def: 20, spd: 22 }, { scale: 2.7 }),
  P("mew", "Mew", 151, "legendary", 1400, ["psychic"], "#f4b6d2", "Said to hold the DNA of every great study habit.", { hp: 100, atk: 30, def: 22, spd: 26 }, { scale: 2.0 }),
  P("rayquaza", "Rayquaza", 384, "legendary", 1800, ["dragon", "flying"], "#3f9c6b", "Lives above the clouds where no tab can reach.", { hp: 110, atk: 36, def: 22, spd: 22 }, { scale: 3.0 }),
  P("mewtwo", "Mewtwo", 150, "legendary", 2000, ["psychic"], "#b9a7cf", "Pure, uninterrupted deep work, made flesh.", { hp: 114, atk: 38, def: 20, spd: 26 }, { scale: 2.7 }),

  // ----- wild opponents (battle only) -----
  P("gastly", "Gastly", 92, "common", 0, ["ghost"], "#5a4a8f", "Drifts in whenever you open a second tab.", { hp: 52, atk: 18, def: 8, spd: 20 }, { wild: true, scale: 2.0 }),
  P("zubat", "Zubat", 41, "common", 0, ["flying"], "#5d6fb0", "Screeches during the quietest minute.", { hp: 54, atk: 16, def: 9, spd: 22 }, { wild: true, scale: 2.0 }),
  P("geodude", "Geodude", 74, "common", 0, ["rock"], "#9d8e74", "A heavy 'five more minutes' in rock form.", { hp: 66, atk: 20, def: 20, spd: 6 }, { wild: true, scale: 1.9 }),
  P("onix", "Onix", 95, "rare", 0, ["rock"], "#8a8a92", "The long, long email thread.", { hp: 96, atk: 22, def: 28, spd: 8 }, { wild: true, scale: 3.1 }),
  P("haunter", "Haunter", 93, "rare", 0, ["ghost"], "#6a4a96", "Whispers 'just check your phone'.", { hp: 76, atk: 24, def: 12, spd: 20 }, { wild: true, scale: 2.4 }),
  P("machop", "Machop", 66, "common", 0, ["fighting"], "#8fa3bf", "Pure overtime energy.", { hp: 74, atk: 22, def: 14, spd: 10 }, { wild: true, scale: 2.0 }),
];

export const SPECIES_BY_ID: Record<string, Species> = Object.fromEntries(SPECIES.map((s) => [s.id, s]));
export const SHOP_SPECIES = SPECIES.filter((s) => !s.wild);
export const WILD_SPECIES = SPECIES.filter((s) => s.wild);

export function artworkUrl(dex: number) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${dex}.png`;
}
export function animatedUrl(dex: number) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/versions/generation-v/black-white/animated/${dex}.gif`;
}

export const RARITY_META: Record<Rarity, { label: string; color: string }> = {
  common: { label: "Common", color: "#8b8b95" },
  rare: { label: "Rare", color: "#4aa3e8" },
  epic: { label: "Epic", color: "#a874ee" },
  legendary: { label: "Legendary", color: "#e9b949" },
};

export const TYPE_COLOR: Record<ElementType, string> = {
  normal: "#a8a77a",
  fire: "#ee8130",
  water: "#6390f0",
  grass: "#7ac74c",
  electric: "#f7d02c",
  psychic: "#f95587",
  ghost: "#735797",
  dragon: "#6f35fc",
  fairy: "#d685ad",
  fighting: "#c22e28",
  dark: "#705746",
  rock: "#b6a136",
  steel: "#8f9bb3",
  ice: "#96d9d6",
  flying: "#8fa8f0",
};

/* ------------------------------ progression ------------------------------ */

export interface OwnedPet {
  id: string; // species id
  level: number;
  xp: number;
  hunger: number; // 0 starving → 100 full
  joy: number; // 0 → 100
  adoptedAt: number;
  lastFed: number;
  lastPlayed: number;
  wins: number;
}

export function xpForLevel(level: number) {
  return 50 + level * 35;
}

export function statsFor(species: Species, level: number) {
  return {
    hp: Math.round(species.base.hp + level * 7),
    atk: Math.round(species.base.atk + level * 1.6),
    def: Math.round(species.base.def + level * 1.1),
    spd: Math.round(species.base.spd + level * 0.6),
  };
}

/* ------------------------------ battle rules ------------------------------ */

export interface Move {
  id: string;
  name: string;
  type: ElementType;
  power: number;
  cost: number;
  kind: "attack" | "heal" | "guard";
  blurb: string;
  fx: "slash" | "burst" | "bolt" | "wave" | "leaf" | "orb" | "shadow" | "heal" | "guard" | "flame" | "ice" | "rock";
}

const SIGNATURE: Record<ElementType, { name: string; special: string; fx: Move["fx"] }> = {
  normal: { name: "Body Slam", special: "Hyper Beam", fx: "burst" },
  fire: { name: "Ember", special: "Flare Blitz", fx: "flame" },
  water: { name: "Water Gun", special: "Hydro Pump", fx: "wave" },
  grass: { name: "Vine Whip", special: "Solar Beam", fx: "leaf" },
  electric: { name: "Thunder Shock", special: "Thunderbolt", fx: "bolt" },
  psychic: { name: "Confusion", special: "Psystrike", fx: "orb" },
  ghost: { name: "Shadow Ball", special: "Nightmare Wave", fx: "shadow" },
  dragon: { name: "Dragon Claw", special: "Draco Meteor", fx: "burst" },
  fairy: { name: "Dazzling Gleam", special: "Moonblast", fx: "orb" },
  fighting: { name: "Karate Chop", special: "Close Combat", fx: "slash" },
  dark: { name: "Bite", special: "Dark Pulse", fx: "shadow" },
  rock: { name: "Rock Throw", special: "Stone Edge", fx: "rock" },
  steel: { name: "Metal Claw", special: "Flash Cannon", fx: "slash" },
  ice: { name: "Ice Shard", special: "Blizzard", fx: "ice" },
  flying: { name: "Gust", special: "Brave Bird", fx: "wave" },
};

export function movesFor(species: Species): Move[] {
  const t = species.types[0];
  const t2 = species.types[1] ?? t;
  const a = SIGNATURE[t];
  const b = SIGNATURE[t2];
  return [
    { id: "tackle", name: "Tackle", type: "normal", power: 13, cost: 0, kind: "attack", blurb: "Free, reliable. Builds energy.", fx: "slash" },
    { id: "sig", name: a.name, type: t, power: 21, cost: 2, kind: "attack", blurb: `${cap(t)} attack`, fx: a.fx },
    { id: "special", name: t2 !== t ? b.special : a.special, type: t2, power: 36, cost: 4, kind: "attack", blurb: `Heavy ${t2} strike`, fx: (t2 !== t ? b : a).fx },
    { id: "recover", name: "Recover", type: "normal", power: 0, cost: 3, kind: "heal", blurb: "Restore 30% HP", fx: "heal" },
  ];
}

function cap(s: string) {
  return s[0].toUpperCase() + s.slice(1);
}

const STRONG: Partial<Record<ElementType, ElementType[]>> = {
  fire: ["grass", "ice", "steel"],
  water: ["fire", "rock"],
  grass: ["water", "rock"],
  electric: ["water", "flying"],
  psychic: ["fighting"],
  ghost: ["psychic", "ghost"],
  dragon: ["dragon"],
  fairy: ["dragon", "fighting", "dark"],
  fighting: ["normal", "rock", "dark", "steel", "ice"],
  dark: ["psychic", "ghost"],
  rock: ["fire", "ice", "flying"],
  steel: ["ice", "rock", "fairy"],
  ice: ["grass", "dragon", "flying"],
  flying: ["grass", "fighting"],
};
const WEAK: Partial<Record<ElementType, ElementType[]>> = {
  normal: ["rock", "steel"],
  fire: ["water", "rock", "fire", "dragon"],
  water: ["grass", "dragon", "water"],
  grass: ["fire", "flying", "grass", "dragon", "steel"],
  electric: ["grass", "electric", "dragon"],
  psychic: ["dark", "steel", "psychic"],
  ghost: ["dark", "normal"],
  dragon: ["fairy", "steel"],
  fairy: ["fire", "steel"],
  fighting: ["psychic", "fairy", "flying", "ghost"],
  dark: ["fighting", "fairy", "dark"],
  rock: ["fighting", "steel"],
  steel: ["fire", "water", "electric", "steel"],
  ice: ["fire", "water", "steel", "ice"],
  flying: ["electric", "rock", "steel"],
};

export function effectiveness(move: ElementType, defender: ElementType[]): number {
  let m = 1;
  for (const d of defender) {
    if (STRONG[move]?.includes(d)) m *= 2;
    if (WEAK[move]?.includes(d)) m *= 0.5;
  }
  return m;
}

export function levelProgress(p: OwnedPet) {
  return Math.min(1, p.xp / xpForLevel(p.level));
}

export function moodOf(p: OwnedPet): { label: string; tone: "ok" | "warn" | "bad" } {
  const score = (p.hunger + p.joy) / 2;
  if (p.hunger < 20) return { label: "Hungry", tone: "bad" };
  if (score > 70) return { label: "Thriving", tone: "ok" };
  if (score > 40) return { label: "Content", tone: "ok" };
  return { label: "Lonely", tone: "warn" };
}
