import { SPECIES_BY_ID } from "./pets";
import { dayKey, streakOf, weekKey, type AppState } from "./store";

export interface Mission {
  id: string;
  title: string;
  desc: string;
  goal: number;
  progress: number;
  coins: number;
  xp: number;
  period: "daily" | "weekly";
  key: string;
  claimed: boolean;
  unit: string;
}

export function computeMissions(s: AppState): Mission[] {
  const now = Date.now();
  const today = dayKey(now);
  const wk = weekKey(now);
  const todaySessions = s.sessions.filter((x) => dayKey(x.end) === today);
  const weekSessions = s.sessions.filter((x) => weekKey(x.end) === wk);
  const todayMin = todaySessions.reduce((a, x) => a + x.minutes, 0);
  const weekMin = weekSessions.reduce((a, x) => a + x.minutes, 0);
  const days = new Set(weekSessions.map((x) => dayKey(x.end))).size;
  const tasksToday = s.tasks.filter((t) => t.doneAt && dayKey(t.doneAt) === today).length;
  const winsToday = s.battle.log.filter((l) => l.win && dayKey(l.ts) === today).length;
  const winsWeek = s.battle.log.filter((l) => l.win && weekKey(l.ts) === wk).length;

  const mk = (m: Omit<Mission, "key" | "claimed" | "progress"> & { progress: number }): Mission => {
    const key = `${m.period === "daily" ? "d" : "w"}:${m.id}:${m.period === "daily" ? today : wk}`;
    return { ...m, progress: Math.min(m.goal, m.progress), key, claimed: !!s.claimed[key] };
  };

  return [
    mk({ id: "min50", title: "Warm up", desc: "Focus for 50 minutes today", goal: 50, progress: todayMin, coins: 40, xp: 60, period: "daily", unit: "min" }),
    mk({ id: "ses3", title: "Three in a row", desc: "Complete 3 focus blocks today", goal: 3, progress: todaySessions.length, coins: 50, xp: 70, period: "daily", unit: "blocks" }),
    mk({ id: "task1", title: "Close the loop", desc: "Finish a task today", goal: 1, progress: tasksToday, coins: 30, xp: 40, period: "daily", unit: "task" }),
    mk({ id: "win1", title: "Prove yourself", desc: "Win a battle today", goal: 1, progress: winsToday, coins: 45, xp: 50, period: "daily", unit: "win" }),
    mk({ id: "wmin", title: "Deep week", desc: "Focus for 300 minutes this week", goal: 300, progress: weekMin, coins: 220, xp: 300, period: "weekly", unit: "min" }),
    mk({ id: "wdays", title: "Show up", desc: "Focus on 5 different days this week", goal: 5, progress: days, coins: 180, xp: 240, period: "weekly", unit: "days" }),
    mk({ id: "wwins", title: "Arena regular", desc: "Win 5 battles this week", goal: 5, progress: winsWeek, coins: 200, xp: 260, period: "weekly", unit: "wins" }),
  ];
}

export interface Achievement {
  id: string;
  title: string;
  desc: string;
  goal: number;
  progress: number;
}

export function computeAchievements(s: AppState): Achievement[] {
  const total = s.sessions.reduce((a, x) => a + x.minutes, 0);
  const streak = streakOf(s.sessions);
  const late = s.sessions.some((x) => new Date(x.end).getHours() >= 22 || new Date(x.end).getHours() < 4);
  const maxLevel = Math.max(1, ...s.pets.map((p) => p.level));
  const legend = s.pets.some((p) => SPECIES_BY_ID[p.id]?.rarity === "legendary");
  const poke = s.pets.filter((p) => SPECIES_BY_ID[p.id]?.kind === "pokemon").length;
  const a = (id: string, title: string, desc: string, goal: number, progress: number): Achievement => ({ id, title, desc, goal, progress: Math.min(goal, progress) });
  return [
    a("first", "First block", "Complete your first focus session", 1, s.sessions.length),
    a("s25", "Habit forming", "Complete 25 focus sessions", 25, s.sessions.length),
    a("h10", "Ten hours deep", "Log 10 hours of focus", 600, total),
    a("h50", "Fifty hours deep", "Log 50 hours of focus", 3000, total),
    a("streak7", "Seven-day streak", "Focus 7 days in a row", 7, streak),
    a("owl", "Night owl", "Finish a block after 10 pm", 1, late ? 1 : 0),
    a("pets3", "Small zoo", "Own 3 companions", 3, s.pets.length),
    a("poke2", "Trainer", "Own 2 Pokémon companions", 2, poke),
    a("lv10", "Bonded", "Raise a companion to level 10", 10, maxLevel),
    a("wins10", "Arena veteran", "Win 10 battles", 10, s.battle.wins),
    a("legend", "Legend", "Adopt a legendary companion", 1, legend ? 1 : 0),
  ];
}
