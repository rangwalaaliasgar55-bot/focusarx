import { useSyncExternalStore } from "react";

function current() {
  const h = window.location.hash.replace(/^#/, "");
  return h && h.startsWith("/") ? h : "/";
}

let path = current();
const subs = new Set<() => void>();

window.addEventListener("hashchange", () => {
  path = current();
  subs.forEach((s) => s());
  window.scrollTo({ top: 0 });
});

export function navigate(to: string) {
  window.location.hash = to;
}

export function useRoute() {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => path,
    () => path,
  );
}
