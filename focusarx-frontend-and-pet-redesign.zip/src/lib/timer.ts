import { useSyncExternalStore } from "react";
import { completeFocusSession, getState, type SessionResult } from "./store";
import { toast } from "./toast";

export type Mode = "focus" | "short" | "long";
export type Status = "idle" | "running" | "paused";

export interface TimerSnap {
  mode: Mode;
  status: Status;
  totalSec: number;
  secondsLeft: number;
  cycle: number;
  taskId: string | null;
  completedAt: number;
  completedMode: Mode | null;
  lastResult: SessionResult | null;
}

const KEY = "focusarx.timer.v1";

interface Persist {
  mode: Mode;
  status: Status;
  totalSec: number;
  endAt: number;
  pausedLeftMs: number;
  cycle: number;
  taskId: string | null;
  customSec: number | null;
}

export const MODE_LABEL: Record<Mode, string> = { focus: "Focus", short: "Short break", long: "Long break" };

function durationFor(mode: Mode) {
  const s = getState().settings;
  return (mode === "focus" ? s.focusMin : mode === "short" ? s.shortMin : s.longMin) * 60;
}

let p: Persist = (() => {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as Persist;
  } catch {
    /* ignore */
  }
  return { mode: "focus", status: "idle", totalSec: 0, endAt: 0, pausedLeftMs: 0, cycle: 0, taskId: null, customSec: null } as Persist;
})();
if (!p.totalSec) p.totalSec = durationFor(p.mode);

let completedAt = 0;
let completedMode: Mode | null = null;
let lastResult: SessionResult | null = null;
let snap: TimerSnap = build();
const subs = new Set<() => void>();
let handle: number | null = null;

function leftSec(): number {
  if (p.status === "running") return Math.max(0, Math.ceil((p.endAt - Date.now()) / 1000));
  if (p.status === "paused") return Math.max(0, Math.ceil(p.pausedLeftMs / 1000));
  return p.totalSec;
}

function build(): TimerSnap {
  return {
    mode: p.mode,
    status: p.status,
    totalSec: p.totalSec,
    secondsLeft: leftSec(),
    cycle: p.cycle,
    taskId: p.taskId,
    completedAt,
    completedMode,
    lastResult,
  };
}

function emit() {
  snap = build();
  try {
    localStorage.setItem(KEY, JSON.stringify(p));
  } catch {
    /* ignore */
  }
  updateTitle();
  subs.forEach((s) => s());
}

function fmt(sec: number) {
  return `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`;
}

function updateTitle() {
  if (p.status === "idle") {
    document.title = "FocusArx — Focus timer with a 3D companion";
  } else {
    document.title = `${fmt(snap.secondsLeft)} · ${MODE_LABEL[p.mode]}${p.status === "paused" ? " (paused)" : ""}`;
  }
}

function startTicker() {
  if (handle != null) return;
  handle = window.setInterval(() => {
    if (p.status !== "running") return stopTicker();
    const left = leftSec();
    if (left <= 0) return complete();
    if (left !== snap.secondsLeft) emit();
  }, 250);
}
function stopTicker() {
  if (handle != null) {
    window.clearInterval(handle);
    handle = null;
  }
}

/* ------------------------------ audio ------------------------------ */

let ctx: AudioContext | null = null;
export function unlockAudio() {
  try {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!ctx) ctx = new AC();
    if (ctx.state === "suspended") void ctx.resume();
  } catch {
    /* no audio */
  }
}

export function chime(kind: "done" | "break" | "click" = "done") {
  const s = getState().settings;
  if (!s.sound) return;
  unlockAudio();
  if (!ctx) return;
  const notes = kind === "done" ? [523.25, 659.25, 783.99, 1046.5] : kind === "break" ? [783.99, 659.25, 523.25] : [880];
  const t0 = ctx.currentTime;
  notes.forEach((f, i) => {
    const o = ctx!.createOscillator();
    const g = ctx!.createGain();
    o.type = "sine";
    o.frequency.value = f;
    const start = t0 + i * (kind === "click" ? 0 : 0.16);
    const vol = 0.18 * s.volume;
    g.gain.setValueAtTime(0.0001, start);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol), start + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, start + (kind === "click" ? 0.1 : 0.6));
    o.connect(g).connect(ctx!.destination);
    o.start(start);
    o.stop(start + 0.7);
  });
}

/* ------------------------------ transitions ------------------------------ */

function complete() {
  stopTicker();
  const finished = p.mode;
  const settings = getState().settings;
  completedAt = Date.now();
  completedMode = finished;
  if (finished === "focus") {
    const mins = Math.max(1, Math.round(p.totalSec / 60));
    lastResult = completeFocusSession(mins, p.taskId);
    p.cycle += 1;
    p.mode = p.cycle % settings.longEvery === 0 ? "long" : "short";
    chime("done");
    toast(`Session complete · +${lastResult.coins} coins`, "ok", `+${lastResult.xp} XP, your companion earned ${lastResult.petXp} XP`);
    notify("Focus block complete", `Nice work. Time for a ${p.mode === "long" ? "long" : "short"} break.`);
  } else {
    lastResult = null;
    p.mode = "focus";
    chime("break");
    toast("Break over — ready when you are", "info");
    notify("Break over", "Ready for the next focus block?");
  }
  p.customSec = null;
  p.totalSec = durationFor(p.mode);
  p.status = "idle";
  p.endAt = 0;
  emit();
  if (settings.autoStart) start();
}

function notify(title: string, body: string) {
  try {
    if ("Notification" in window && Notification.permission === "granted" && document.hidden) new Notification(title, { body });
  } catch {
    /* ignore */
  }
}

export function start() {
  unlockAudio();
  if (p.status === "running") return;
  if (p.status === "paused") {
    p.endAt = Date.now() + p.pausedLeftMs;
  } else {
    p.endAt = Date.now() + p.totalSec * 1000;
  }
  p.status = "running";
  chime("click");
  try {
    if ("Notification" in window && Notification.permission === "default") void Notification.requestPermission();
  } catch {
    /* ignore */
  }
  emit();
  startTicker();
}

export function pause() {
  if (p.status !== "running") return;
  p.pausedLeftMs = Math.max(0, p.endAt - Date.now());
  p.status = "paused";
  stopTicker();
  emit();
}

export function reset() {
  stopTicker();
  p.status = "idle";
  p.endAt = 0;
  p.totalSec = p.customSec ?? durationFor(p.mode);
  emit();
}

export function skip() {
  stopTicker();
  if (p.mode === "focus") {
    p.mode = "short";
  } else {
    p.mode = "focus";
  }
  p.customSec = null;
  p.status = "idle";
  p.totalSec = durationFor(p.mode);
  emit();
}

export function setMode(mode: Mode) {
  if (p.status === "running") return;
  p.mode = mode;
  p.customSec = null;
  p.status = "idle";
  p.totalSec = durationFor(mode);
  emit();
}

export function setCustomMinutes(min: number) {
  if (p.status === "running") return;
  const sec = Math.max(1, Math.min(240, Math.round(min))) * 60;
  p.customSec = sec;
  p.totalSec = sec;
  if (p.status === "paused") p.pausedLeftMs = sec * 1000;
  emit();
}

export function syncIdle() {
  if (p.status === "idle" && p.customSec == null) {
    const t = durationFor(p.mode);
    if (t !== p.totalSec) {
      p.totalSec = t;
      emit();
    }
  }
}

export function selectTask(id: string | null) {
  p.taskId = id;
  emit();
}

export function useTimer(): TimerSnap {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => snap,
    () => snap,
  );
}

export function getTimer() {
  return snap;
}

/* resume a running session after reload */
export function bootTimer() {
  if (p.status === "running") {
    if (p.endAt <= Date.now()) {
      complete();
    } else {
      emit();
      startTicker();
    }
  } else {
    syncIdle();
    emit();
  }
}
