import { useSyncExternalStore } from "react";
import { SPECIES_BY_ID, xpForLevel, type OwnedPet } from "./pets";

/* ------------------------------- types ------------------------------- */

export interface Session {
  id: string;
  end: number; // ts
  minutes: number;
  score: number;
  petId: string;
  label?: string;
  demo?: boolean;
}

export interface Task {
  id: string;
  title: string;
  done: boolean;
  est: number; // pomodoros
  spent: number;
  priority: "low" | "med" | "high";
  createdAt: number;
  doneAt?: number;
}

export type FaceId = "classic" | "neon" | "zen" | "flip" | "analog" | "hourglass" | "orbit" | "segment";

export interface Settings {
  theme: "dark" | "light";
  accent: string;
  face: FaceId;
  focusMin: number;
  shortMin: number;
  longMin: number;
  longEvery: number;
  autoStart: boolean;
  sound: boolean;
  volume: number;
  dailyGoal: number; // minutes
  companionMode: "companion" | "boss";
  name: string;
}

export interface BattleStats {
  wins: number;
  losses: number;
  streak: number;
  best: number;
  log: { ts: number; win: boolean; foe: string; pet: string }[];
}

export interface AppState {
  v: 2;
  coins: number;
  xp: number;
  sessions: Session[];
  tasks: Task[];
  pets: OwnedPet[];
  activePet: string;
  settings: Settings;
  claimed: Record<string, true>;
  battle: BattleStats;
  seeded: boolean;
}

/* ------------------------------ helpers ------------------------------ */

export const uid = () => Math.random().toString(36).slice(2, 10);

export function dayKey(ts: number) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
export function weekKey(ts: number) {
  const d = new Date(ts);
  const day = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - day);
  return dayKey(d.getTime());
}

export function userLevel(xp: number) {
  const level = Math.floor(Math.sqrt(xp / 60)) + 1;
  const floor = 60 * (level - 1) ** 2;
  const next = 60 * level ** 2;
  return { level, into: xp - floor, need: next - floor, pct: (xp - floor) / (next - floor) };
}

/* ------------------------------ defaults ------------------------------ */

const KEY = "focusarx.v2";

function newPet(id: string, level = 1): OwnedPet {
  const now = Date.now();
  return { id, level, xp: 0, hunger: 80, joy: 80, adoptedAt: now, lastFed: now, lastPlayed: now, wins: 0 };
}

function mulberry(a: number) {
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function seedSessions(): Session[] {
  const rnd = mulberry(7);
  const out: Session[] = [];
  const now = new Date();
  for (let d = 20; d >= 1; d--) {
    if (rnd() < 0.18) continue;
    const n = 1 + Math.floor(rnd() * 4);
    let hour = 8 + Math.floor(rnd() * 4);
    for (let i = 0; i < n; i++) {
      const t = new Date(now.getFullYear(), now.getMonth(), now.getDate() - d, hour, Math.floor(rnd() * 50));
      const minutes = rnd() < 0.2 ? 50 : rnd() < 0.15 ? 15 : 25;
      out.push({ id: uid(), end: t.getTime() + minutes * 60000, minutes, score: 68 + Math.floor(rnd() * 31), petId: "hoot", demo: true });
      hour += 1 + Math.floor(rnd() * 3);
      if (hour > 22) break;
    }
  }
  return out;
}

const DEFAULT_SETTINGS: Settings = {
  theme: "dark",
  accent: "#6e7bff",
  face: "classic",
  focusMin: 25,
  shortMin: 5,
  longMin: 15,
  longEvery: 4,
  autoStart: false,
  sound: true,
  volume: 0.5,
  dailyGoal: 120,
  companionMode: "companion",
  name: "Focuser",
};

function initial(): AppState {
  const now = Date.now();
  const seeds: Task[] = [
    { id: uid(), title: "Read chapter 4 and write notes", done: false, est: 3, spent: 1, priority: "high", createdAt: now },
    { id: uid(), title: "Problem set — linear algebra", done: false, est: 2, spent: 0, priority: "med", createdAt: now },
    { id: uid(), title: "Reply to lab group thread", done: true, est: 1, spent: 1, priority: "low", createdAt: now - 3600_000, doneAt: now - 1800_000 },
  ];
  const hoot = newPet("hoot", 3);
  hoot.xp = 40;
  return {
    v: 2,
    coins: 520,
    xp: 640,
    sessions: seedSessions(),
    tasks: seeds,
    pets: [hoot],
    activePet: "hoot",
    settings: DEFAULT_SETTINGS,
    claimed: {},
    battle: { wins: 3, losses: 1, streak: 2, best: 2, log: [] },
    seeded: true,
  };
}

function load(): AppState {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const s = JSON.parse(raw) as AppState;
      if (s && s.v === 2) {
        s.settings = { ...DEFAULT_SETTINGS, ...s.settings };
        return s;
      }
    }
  } catch {
    /* corrupted → fall through */
  }
  return initial();
}

/* ------------------------------- store ------------------------------- */

let state: AppState = load();
const listeners = new Set<() => void>();

function commit(next: AppState) {
  state = next;
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    /* storage full / blocked */
  }
  listeners.forEach((l) => l());
}

export function getState() {
  return state;
}

export function useApp<T>(selector: (s: AppState) => T): T {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => selector(state),
    () => selector(state),
  );
}

/* ------------------------------- actions ------------------------------- */

export function setSetting<K extends keyof Settings>(key: K, value: Settings[K]) {
  commit({ ...state, settings: { ...state.settings, [key]: value } });
}

export function addCoins(n: number) {
  commit({ ...state, coins: Math.max(0, state.coins + n) });
}

function mapPet(pets: OwnedPet[], id: string, fn: (p: OwnedPet) => OwnedPet) {
  return pets.map((p) => (p.id === id ? fn(p) : p));
}

export function givePetXp(id: string, amount: number): { leveled: boolean; level: number } {
  let leveled = false;
  let level = 1;
  const pets = mapPet(state.pets, id, (p) => {
    let { xp, level: lv } = p;
    xp += amount;
    while (xp >= xpForLevel(lv)) {
      xp -= xpForLevel(lv);
      lv += 1;
      leveled = true;
    }
    level = lv;
    return { ...p, xp, level: lv };
  });
  commit({ ...state, pets });
  return { leveled, level };
}

export interface SessionResult {
  coins: number;
  xp: number;
  petXp: number;
  leveledPet: boolean;
  score: number;
}

export function completeFocusSession(minutes: number, taskId?: string | null): SessionResult {
  const score = Math.min(100, 80 + Math.floor(Math.random() * 20));
  const coins = Math.max(1, Math.round(minutes * 1.2));
  const xp = Math.round(minutes * 2);
  const petXp = Math.round(minutes * 1.5);
  const label = taskId ? state.tasks.find((t) => t.id === taskId)?.title : undefined;
  const session: Session = { id: uid(), end: Date.now(), minutes, score, petId: state.activePet, label };
  const tasks = taskId ? state.tasks.map((t) => (t.id === taskId ? { ...t, spent: t.spent + 1 } : t)) : state.tasks;
  commit({
    ...state,
    sessions: [...state.sessions, session],
    tasks,
    coins: state.coins + coins,
    xp: state.xp + xp,
    pets: mapPet(state.pets, state.activePet, (p) => ({ ...p, joy: Math.min(100, p.joy + 6) })),
  });
  const r = givePetXp(state.activePet, petXp);
  return { coins, xp, petXp, leveledPet: r.leveled, score };
}

export function clearDemo() {
  commit({ ...state, sessions: state.sessions.filter((s) => !s.demo), seeded: false });
}

export function resetAll() {
  localStorage.removeItem(KEY);
  commit(initial());
}

/* tasks */
export function addTask(title: string, est = 1, priority: Task["priority"] = "med") {
  if (!title.trim()) return;
  commit({ ...state, tasks: [{ id: uid(), title: title.trim(), done: false, est, spent: 0, priority, createdAt: Date.now() }, ...state.tasks] });
}
export function toggleTask(id: string) {
  commit({
    ...state,
    tasks: state.tasks.map((t) => (t.id === id ? { ...t, done: !t.done, doneAt: !t.done ? Date.now() : undefined } : t)),
  });
}
export function deleteTask(id: string) {
  commit({ ...state, tasks: state.tasks.filter((t) => t.id !== id) });
}
export function updateTask(id: string, patch: Partial<Task>) {
  commit({ ...state, tasks: state.tasks.map((t) => (t.id === id ? { ...t, ...patch } : t)) });
}

/* pets */
export function adoptPet(id: string): boolean {
  const sp = SPECIES_BY_ID[id];
  if (!sp || state.pets.some((p) => p.id === id) || state.coins < sp.price) return false;
  commit({ ...state, coins: state.coins - sp.price, pets: [...state.pets, newPet(id)], activePet: id });
  return true;
}
export function setActivePet(id: string) {
  if (state.pets.some((p) => p.id === id)) commit({ ...state, activePet: id });
}
export function feedPet(id: string, cost = 15): boolean {
  if (state.coins < cost) return false;
  commit({
    ...state,
    coins: state.coins - cost,
    pets: mapPet(state.pets, id, (p) => ({ ...p, hunger: Math.min(100, p.hunger + 40), joy: Math.min(100, p.joy + 5), lastFed: Date.now() })),
  });
  givePetXp(id, 8);
  return true;
}
export function playWithPet(id: string): boolean {
  const p = state.pets.find((x) => x.id === id);
  if (!p || Date.now() - p.lastPlayed < 4000) return false;
  commit({
    ...state,
    pets: mapPet(state.pets, id, (x) => ({ ...x, joy: Math.min(100, x.joy + 12), hunger: Math.max(0, x.hunger - 4), lastPlayed: Date.now() })),
  });
  givePetXp(id, 3);
  return true;
}

/* missions */
export function claimReward(key: string, coins: number, xp: number) {
  if (state.claimed[key]) return;
  commit({ ...state, claimed: { ...state.claimed, [key]: true }, coins: state.coins + coins, xp: state.xp + xp });
}

/* battle */
export function recordBattle(win: boolean, petId: string, foe: string, coins: number, xp: number, petXp: number) {
  const b = state.battle;
  const streak = win ? b.streak + 1 : 0;
  commit({
    ...state,
    coins: state.coins + coins,
    xp: state.xp + xp,
    pets: mapPet(state.pets, petId, (p) => ({ ...p, wins: p.wins + (win ? 1 : 0), joy: Math.min(100, Math.max(0, p.joy + (win ? 8 : -6))) })),
    battle: {
      wins: b.wins + (win ? 1 : 0),
      losses: b.losses + (win ? 0 : 1),
      streak,
      best: Math.max(b.best, streak),
      log: [{ ts: Date.now(), win, foe, pet: petId }, ...b.log].slice(0, 30),
    },
  });
  givePetXp(petId, petXp);
}

/* ------------------------------ analytics ------------------------------ */

export function minutesByDay(sessions: Session[]) {
  const m = new Map<string, number>();
  for (const s of sessions) m.set(dayKey(s.end), (m.get(dayKey(s.end)) ?? 0) + s.minutes);
  return m;
}

export function streakOf(sessions: Session[]) {
  const days = minutesByDay(sessions);
  let streak = 0;
  const d = new Date();
  if (!days.has(dayKey(d.getTime()))) d.setDate(d.getDate() - 1);
  while (days.has(dayKey(d.getTime()))) {
    streak++;
    d.setDate(d.getDate() - 1);
  }
  return streak;
}

export function applyTheme(settings: Settings) {
  const root = document.documentElement;
  root.classList.toggle("light", settings.theme === "light");
  const hex = settings.accent;
  root.style.setProperty("--brand-500", hex);
  root.style.setProperty("--brand-600", shade(hex, -0.12));
  const strong = settings.theme === "light" ? shade(hex, -0.3) : shade(hex, 0.35);
  root.style.setProperty("--brand-strong", strong);
  root.style.setProperty("--brand-soft", hexA(hex, settings.theme === "light" ? 0.1 : 0.14));
}

function parseHex(hex: string) {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
export function shade(hex: string, amt: number) {
  const [r, g, b] = parseHex(hex).map((v) => {
    const t = amt < 0 ? 0 : 255;
    const p = Math.abs(amt);
    return Math.round((t - v) * p + v);
  });
  return `#${[r, g, b].map((v) => v.toString(16).padStart(2, "0")).join("")}`;
}
export function hexA(hex: string, a: number) {
  const [r, g, b] = parseHex(hex);
  return `rgba(${r}, ${g}, ${b}, ${a})`;
}
