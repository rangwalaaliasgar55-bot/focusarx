import { useSyncExternalStore } from "react";

export interface ToastItem {
  id: number;
  text: string;
  detail?: string;
  tone: "info" | "ok" | "warn" | "bad";
}

let items: ToastItem[] = [];
let n = 0;
const subs = new Set<() => void>();

function emit() {
  subs.forEach((s) => s());
}

export function toast(text: string, tone: ToastItem["tone"] = "info", detail?: string) {
  const id = ++n;
  items = [...items, { id, text, tone, detail }].slice(-4);
  emit();
  window.setTimeout(() => dismiss(id), 4200);
}

export function dismiss(id: number) {
  items = items.filter((i) => i.id !== id);
  emit();
}

export function useToasts() {
  return useSyncExternalStore(
    (cb) => {
      subs.add(cb);
      return () => subs.delete(cb);
    },
    () => items,
    () => items,
  );
}
